# SPDX-License-Identifier: Apache-2.0
"""DeepSeek V4 runtime support for the pinned mlx-lm.

Brings PR 1192 (https://github.com/ml-explore/mlx-lm/pull/1192) into omlx
without modifying the pinned mlx-lm. The patch:

1. Injects ``PoolingCache`` and ``BatchPoolingCache`` into
   ``mlx_lm.models.cache``.
2. Registers ``mlx_lm.models.hyper_connection`` and
   ``mlx_lm.models.deepseek_v4`` modules in ``sys.modules`` so the
   built-in ``importlib.import_module(f"mlx_lm.models.{model_type}")``
   path used by ``_get_classes`` finds them. Also aliases
   ``deepseek_v4_mtp`` to the same module for converted checkpoints that
   encode the MTP variant in ``model_type``.
3. Replaces ``mlx_lm.utils.load_model`` with a copy that handles
   ``F8_E8M0`` dtype fallback and the DeepSeek V4 ``fp8`` quant_method.
4. Wraps ``mlx_lm.tokenizer_utils.AutoTokenizer`` with a fallback that
   retries with an empty ``PreTrainedConfig()`` when transformers does
   not yet recognize the ``deepseek_v4`` model_type (PR 45643 was
   merged 2026-05-02 but is missing from transformers <=5.7.0). This
   adopts PR 1189's tokenizer-fallback strategy.
5. Registers omlx-side cache handlers for the two new cache classes so
   prefix-cache / SSD-cache state extraction does not silently fall
   through to ``DefaultCacheHandler``.

The whole patch is gated on ``model_type.startswith("deepseek_v4")`` in
``config.json``; other models pay zero cost.

Once mlx-lm merges PR 1192 upstream this package can be removed in a
single delete (along with the conditional dispatch in
``omlx/utils/model_loading.py`` and ``omlx/engine/batched.py``).
"""

from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

PR_HEAD_SHA = "5c10538136b9038b9626c134612b08afc18d697a"
PR_URL = "https://github.com/ml-explore/mlx-lm/pull/1192"

_APPLIED = False
_POOLING_APPLIED = False


def _inject_cache_extras() -> None:
    """Add PoolingCache + BatchPoolingCache as attributes of mlx_lm.models.cache.

    Same setattr pattern used by turboquant_attention.py for
    ``scaled_dot_product_attention``. Idempotent.
    """
    import mlx_lm.models.cache as _cache_mod

    if hasattr(_cache_mod, "PoolingCache") and hasattr(_cache_mod, "BatchPoolingCache"):
        return

    from . import cache_extras as _extras

    _cache_mod.PoolingCache = _extras.PoolingCache
    _cache_mod.BatchPoolingCache = _extras.BatchPoolingCache
    # Also expose at __dict__ level so callers that reload the module
    # after the patch (e.g. ``from mlx_lm.models.cache import PoolingCache``)
    # see them too.
    _cache_mod.__dict__["PoolingCache"] = _extras.PoolingCache
    _cache_mod.__dict__["BatchPoolingCache"] = _extras.BatchPoolingCache

    # Reattach the classes' __module__ so any class-name introspection
    # (e.g. type(c).__module__) matches what mlx-lm code expects.
    _extras.PoolingCache.__module__ = "mlx_lm.models.cache"
    _extras.BatchPoolingCache.__module__ = "mlx_lm.models.cache"

    logger.info("PoolingCache / BatchPoolingCache injected into mlx_lm.models.cache")


def _register_module(qualname: str, file_name: str) -> None:
    """Load a local file as if it were ``qualname`` (e.g. mlx_lm.models.deepseek_v4).

    Sets ``__package__`` to ``mlx_lm.models`` so relative imports inside
    the loaded file (``from .cache import PoolingCache``,
    ``from .hyper_connection import HyperConnection``) resolve through
    the real mlx_lm package — *not* through omlx.

    Idempotent.
    """
    if qualname in sys.modules:
        return

    here = Path(__file__).parent
    file_path = here / file_name
    spec = importlib.util.spec_from_file_location(qualname, str(file_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not create spec for {qualname} from {file_path}")
    module = importlib.util.module_from_spec(spec)
    module.__package__ = "mlx_lm.models"
    sys.modules[qualname] = module
    spec.loader.exec_module(module)
    logger.info("Registered %s from %s", qualname, file_path.name)


def _register_cache_handlers() -> None:
    """Register PoolingCache / BatchPoolingCache handlers in omlx CacheTypeRegistry."""
    from omlx.cache.type_registry import CacheTypeRegistry

    from .cache_handlers import BatchPoolingCacheHandler, PoolingCacheHandler

    CacheTypeRegistry.register(PoolingCacheHandler())
    CacheTypeRegistry.register(BatchPoolingCacheHandler())
    logger.info("PoolingCacheHandler + BatchPoolingCacheHandler registered")


def _register_model_type_aliases() -> None:
    """Map DeepSeek V4 variant model_types to the injected base module."""
    try:
        import mlx_lm.utils as _utils

        remapping = getattr(_utils, "MODEL_REMAPPING", None)
        if isinstance(remapping, dict):
            remapping.setdefault("deepseek_v4_mtp", "deepseek_v4")
    except Exception as e:
        logger.debug("DeepSeek V4 model_type remapping skipped: %s", e)

    base_module = sys.modules.get("mlx_lm.models.deepseek_v4")
    if base_module is not None:
        sys.modules.setdefault("mlx_lm.models.deepseek_v4_mtp", base_module)


def _probe_native_indexer_kernels() -> None:
    """One-time startup probe for the native indexer kernels.

    The per-chunk gate in ``Indexer.__call__`` only warns the first time a
    native-eligible chunk actually hits the fallback, which can be minutes
    into a long prefill. Surface availability (and the rebuild fix) once at
    patch time instead.
    """
    try:
        from omlx.custom_kernels.glm_moe_dsa import fast as glm_fast

        have = glm_fast.has_symbol("dsa_indexer_scores") and glm_fast.has_symbol(
            "dsa_topk_indices"
        )
    except Exception:
        have = False
    if have:
        logger.info(
            "deepseek_v4: native indexer kernels available "
            "(dsa_indexer_scores/dsa_topk_indices)"
        )
    else:
        logger.warning(
            "deepseek_v4: native indexer kernels dsa_indexer_scores/"
            "dsa_topk_indices unavailable (glm_moe_dsa extension not built); "
            "the indexer will use the MLX fallback and long-context prefill "
            "will be several times slower. Rebuild with "
            "OMLX_WITH_CUSTOM_KERNEL=1."
        )


def apply_pooling_cache_support() -> bool:
    """Install the model-neutral PoolingCache runtime and oMLX handlers."""
    global _POOLING_APPLIED
    if _POOLING_APPLIED:
        return False

    try:
        import mlx_lm  # noqa: F401
    except ImportError:
        logger.debug("mlx-lm not importable — pooling cache support skipped")
        return False

    _inject_cache_extras()

    _register_cache_handlers()
    _POOLING_APPLIED = True
    return True


def apply_deepseek_v4_patch() -> bool:
    """Apply the DeepSeek V4 patch to mlx-lm. Idempotent.

    Must run *before* ``mlx_lm.load()`` encounters a deepseek_v4 model.

    Returns ``True`` if the patch was freshly applied, ``False`` if already
    applied or if mlx-lm is not importable.
    """
    global _APPLIED
    if _APPLIED:
        return False

    try:
        import mlx_lm  # noqa: F401
    except ImportError:
        logger.debug("mlx_lm not importable — deepseek_v4 patch skipped")
        return False

    # Order matters:
    # 1. Inject PoolingCache / BatchPoolingCache and install their batch/cache
    #    integration. GLM-5.3 also consumes this model-neutral subset.
    apply_pooling_cache_support()

    # 2. Register hyper_connection BEFORE deepseek_v4 (deepseek_v4 imports
    #    HyperConnection / HyperHead / hc_expand from it).
    _register_module("mlx_lm.models.hyper_connection", "hyper_connection.py")

    # 3. Register deepseek_v4 itself and aliases for known variants.
    _register_module("mlx_lm.models.deepseek_v4", "deepseek_v4_model.py")
    _register_model_type_aliases()

    # 4. Patch utils.load_model (F8_E8M0 fallback + fp8 quant branch).
    from .utils_patch import apply_utils_patch

    apply_utils_patch()

    # 5. Wrap tokenizer_utils.AutoTokenizer (deepseek_v4 fallback for
    #    transformers releases that pre-date PR 45643 / 2026-05-02).
    from .tokenizer_patch import apply_load_patch, apply_tokenizer_patch

    apply_tokenizer_patch()

    # 7. Wrap tokenizer_utils.load to inject DSML chat_template +
    #    tool_parser for deepseek_v4 models whose published jinja is
    #    minimal and lacks tool grammar.
    apply_load_patch()

    # 6. One-time native indexer kernel probe (INFO/WARNING only).
    _probe_native_indexer_kernels()

    # 7. sanitize() stacks the expert biases, so sharded_load's weight-index
    #     gate would reject a local checkpoint the normal loader handles fine.
    from omlx.patches.mlx_lm_sharded_load import install_local_sharded_load_fallback

    install_local_sharded_load_fallback()

    _APPLIED = True
    logger.info("DeepSeek V4 patch applied (PR 1192 head %s)", PR_HEAD_SHA[:8])
    return True


def is_applied() -> bool:
    return _APPLIED


__all__ = [
    "PR_HEAD_SHA",
    "PR_URL",
    "apply_deepseek_v4_patch",
    "apply_pooling_cache_support",
    "is_applied",
]
