# SPDX-License-Identifier: Apache-2.0
"""
Cache type handlers for different KV cache implementations.

This module provides abstract and concrete handlers for various cache types
from mlx-lm, enabling type-aware cache operations like slicing and reconstruction.
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Any

from ._rotating_subclass import PrefillReadyRotatingKVCache

logger = logging.getLogger(__name__)

# Try to import mlx for tensor operations
try:
    import mlx.core as mx

    HAS_MLX = True
except ImportError:
    HAS_MLX = False
    mx = None


class CacheType(Enum):
    """Supported cache types from mlx-lm."""

    KVCACHE = "KVCache"
    CHUNKED_KVCACHE = "ChunkedKVCache"
    ROTATING_KVCACHE = "RotatingKVCache"
    BATCH_KVCACHE = "BatchKVCache"
    BATCH_ROTATING_KVCACHE = "BatchRotatingKVCache"
    ARRAYS_CACHE = "ArraysCache"
    DEEPSEEK_V41 = "DeepseekV41Cache"
    QUANTIZED_KVCACHE = "QuantizedKVCache"
    CACHE_LIST = "CacheList"
    POOLING_CACHE = "PoolingCache"
    BATCH_POOLING_CACHE = "BatchPoolingCache"
    MINIMAX_M3_KVCACHE = "MiniMaxM3KVCache"
    MINIMAX_M3_BATCH_KVCACHE = "MiniMaxM3BatchKVCache"
    QWEN4_QSA_KVCACHE = "QSAKVCache"
    QWEN4_QSA_QUANTIZED_KVCACHE = "QSAQuantizedKVCache"
    QWEN4_BATCH_QSA_KVCACHE = "BatchQSAKVCache"


@dataclass
class CacheStateInfo:
    """Information about a cache state for serialization."""

    cache_type: str
    state_keys: tuple[str, ...]
    meta_state_keys: tuple[str, ...]
    supports_block_slicing: bool
    is_full_state: bool = False


@dataclass
class CacheStateAxisInfo:
    """Per-element metadata of a cache's ``state`` tuple.

    Each entry describes one element of ``cache_obj.state``:
    - ``name``: logical name (e.g. ``keys``, ``values``, ``buf_kv``, ``pooled``)
    - ``sequence_axis``: axis index of the sequence dimension, or ``None``
      when the element is per-batch metadata (e.g. ``offset``, ``left_padding``
      arrays in ``BatchKVCache.state``)
    - ``sliceable``: whether this element can be sliced along ``sequence_axis``
      for block-level prefix cache storage. Elements without a sequence_axis
      are also non-sliceable; non-sliceable elements get last-block-only or
      boundary-snapshot storage instead.
    """

    name: str
    sequence_axis: int | None
    sliceable: bool


class CacheTypeHandler(ABC):
    """Abstract handler for cache type-specific operations.

    Each handler implements operations specific to a cache type,
    including state extraction, slicing, and reconstruction.
    """

    @property
    @abstractmethod
    def cache_type(self) -> CacheType:
        """Return the cache type this handler manages."""
        pass

    @property
    @abstractmethod
    def supports_block_slicing(self) -> bool:
        """Whether this cache type supports sequence-level block slicing."""
        pass

    @abstractmethod
    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        """Extract serializable state from cache object.

        Args:
            cache_obj: The mlx-lm cache object (KVCache, ArraysCache, etc.)

        Returns:
            Dictionary containing state tensors and metadata
        """
        pass

    @abstractmethod
    def get_seq_len(self, state: dict[str, Any]) -> int:
        """Get sequence length from state.

        Args:
            state: State dictionary from extract_state()

        Returns:
            Sequence length (number of tokens)
        """
        pass

    @abstractmethod
    def slice_state(
        self,
        state: dict[str, Any],
        start_idx: int,
        end_idx: int,
    ) -> dict[str, Any] | None:
        """Slice state for block-level storage.

        Args:
            state: State dictionary from extract_state()
            start_idx: Start token index
            end_idx: End token index (exclusive)

        Returns:
            Sliced state dictionary, or None if slicing not supported
        """
        pass

    @abstractmethod
    def concatenate_states(
        self,
        states: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Concatenate multiple block states into one.

        Args:
            states: List of state dictionaries to concatenate

        Returns:
            Combined state dictionary
        """
        pass

    @abstractmethod
    def reconstruct_cache(
        self,
        state: dict[str, Any],
        meta_state: tuple | None = None,
    ) -> Any:
        """Reconstruct cache object from stored state.

        Args:
            state: State dictionary (may be concatenated)
            meta_state: Optional metadata (offset, etc.)

        Returns:
            Reconstructed mlx-lm cache object
        """
        pass

    def get_state_info(self) -> CacheStateInfo:
        """Get information about this cache type's state structure."""
        return CacheStateInfo(
            cache_type=self.cache_type.value,
            state_keys=self._get_state_keys(),
            meta_state_keys=self._get_meta_state_keys(),
            supports_block_slicing=self.supports_block_slicing,
        )

    def _get_state_keys(self) -> tuple[str, ...]:
        """Return keys used in state dictionary."""
        return ("keys", "values")

    def _get_meta_state_keys(self) -> tuple[str, ...]:
        """Return keys used in meta_state."""
        return ("offset",)

    # ------------------------------------------------------------------
    # N-tuple state interface
    #
    # The legacy interface (extract_state/reconstruct_cache with a dict
    # of "keys"/"values") only models 2-tuple state. mlx-lm caches like
    # BatchKVCache (4-tuple) and DeepSeek V4's PoolingCache (5-tuple)
    # carry more elements that omlx core needs to preserve through the
    # prefix-cache, boundary-snapshot, and SSD round-trip without
    # silently dropping elements past index 1.
    #
    # The methods below give handlers a way to describe their state
    # tuple element-by-element so omlx core can dispatch generically
    # without hard-coded ``state[0], state[1]`` unpacking. Default
    # implementations match the legacy 2-tuple ``(keys, values)``
    # contract so existing handlers keep working with no change.
    # ------------------------------------------------------------------

    def get_state_axis_info(self) -> tuple[CacheStateAxisInfo, ...]:
        """Per-element metadata of the stable serialized tensor layout.

        Length and order match the tuple returned by ``serialize_state()``.
        Default = legacy 2-tuple ``(keys, values)`` with sequence_axis=2
        and sliceable=True (matches KVCache and friends).
        """
        return (
            CacheStateAxisInfo(name="keys", sequence_axis=2, sliceable=True),
            CacheStateAxisInfo(name="values", sequence_axis=2, sliceable=True),
        )

    def serialize_state(self, cache_obj: Any) -> tuple[Any, ...]:
        """Return the stable SSD tensor layout for this cache.

        omlx core uses this to serialize state element-by-element instead
        of going through the legacy ``extract_state`` dict (which is still
        supported via the default ``deserialize_state`` below).

        Core caches use the stable SSD tensor layout, without buffer capacity
        or batch bookkeeping. Custom cache layouts retain their own state.
        """
        from mlx_lm.models.cache import (
            ArraysCache,
            BatchKVCache,
            BatchRotatingKVCache,
            KVCache,
            RotatingKVCache,
        )

        inner = (
            cache_obj._inner if isinstance(cache_obj, SizedArraysCache) else cache_obj
        )
        if isinstance(inner, ArraysCache):
            return tuple(inner.cache)
        if isinstance(inner, (BatchKVCache, BatchRotatingKVCache)):
            keys, values = (
                inner.keys_and_values() if inner.keys is not None else (None, None)
            )
            return keys, values, inner.offset, inner.left_padding
        if isinstance(inner, (KVCache, RotatingKVCache)):
            return inner.keys_and_values() if inner.keys is not None else (None, None)
        state = getattr(cache_obj, "state", None)
        if isinstance(state, (list, tuple)):
            return tuple(state)
        return ()

    def serialize_meta_state(self, cache_obj: Any) -> Any:
        """Return JSON-safe metadata for ``cache_obj``.

        Core cache metadata is read from live attributes. Normalize custom
        string metadata so snapshot storage does not iterate its characters.
        """
        from mlx_lm.models.cache import BatchRotatingKVCache, RotatingKVCache

        if isinstance(cache_obj, BatchRotatingKVCache):
            return (
                cache_obj.max_size,
                cache_obj._offset,
                cache_obj._idx,
                cache_obj.rotated,
            )
        if isinstance(cache_obj, RotatingKVCache):
            return (
                cache_obj.keep,
                cache_obj.max_size,
                cache_obj.offset,
                cache_obj._idx,
            )
        meta_state = getattr(cache_obj, "meta_state", ())
        if meta_state in (None, ""):
            return ()
        if isinstance(meta_state, tuple):
            return meta_state
        if isinstance(meta_state, list):
            return tuple(meta_state)
        return (meta_state,)

    def deserialize_state(
        self,
        elements: tuple[Any, ...],
        meta_state: Any | None = None,
    ) -> Any:
        """Reconstruct a cache object from ordered state ``elements``.

        Default behavior maps elements to the legacy ``keys``/``values``
        dict by zipping with ``get_state_axis_info()`` names, then calls
        ``reconstruct_cache``. Handlers whose state cannot be expressed
        as ``(keys, values)`` (e.g. PoolingCacheHandler with 5 elements)
        should override this method.
        """
        axis_info = self.get_state_axis_info()
        state_dict: dict[str, Any] = {}
        for info, elem in zip(axis_info, elements):
            state_dict[info.name] = elem
        state_dict["cache_type"] = self.cache_type.value
        return self.reconstruct_cache(state_dict, meta_state)

    def get_state_seq_len_from_tuple(self, state_tuple: tuple[Any, ...]) -> int:
        """Return sequence length from the first sliceable element.

        Walks ``get_state_axis_info()`` for the first entry with
        ``sliceable=True`` and a defined ``sequence_axis``, then reads the
        corresponding tensor's shape on that axis. Returns 0 if no
        sliceable element with seq dim is present.
        """
        if not isinstance(state_tuple, (list, tuple)):
            return 0
        axis_info = self.get_state_axis_info()
        for info, elem in zip(axis_info, state_tuple):
            if not info.sliceable or info.sequence_axis is None:
                continue
            if elem is None or not hasattr(elem, "shape"):
                continue
            shape = elem.shape
            if info.sequence_axis < len(shape):
                return int(shape[info.sequence_axis])
        return 0

    def is_variable_length_state(self) -> bool:
        """Whether the state tuple length is variable (e.g. ArraysCache).

        Variable-length caches need different on-disk storage (a count
        prefix). Most caches are fixed-length and return False.
        """
        return False

    def is_composite_cache(self) -> bool:
        """Whether this is a composite cache wrapping sub-caches.

        Composite caches (CacheList) need recursive sub-handler dispatch
        rather than direct state element serialization. Default False.
        """
        return False


class KVCacheHandler(CacheTypeHandler):
    """Handler for standard KVCache (4D tensors).

    KVCache uses:
    - keys: shape (batch, n_kv_heads, seq_len, head_dim)
    - values: shape (batch, n_kv_heads, seq_len, head_dim)
    - offset: current sequence length
    """

    @property
    def cache_type(self) -> CacheType:
        return CacheType.KVCACHE

    @property
    def supports_block_slicing(self) -> bool:
        return True

    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        """Extract state from KVCache object."""
        keys, values = self.serialize_state(cache_obj)
        return {
            "keys": keys,
            "values": values,
            "offset": getattr(
                cache_obj, "offset", keys.shape[2] if keys is not None else 0
            ),
            "cache_type": self.cache_type.value,
        }

    def get_seq_len(self, state: dict[str, Any]) -> int:
        """Get sequence length from keys tensor."""
        keys = state.get("keys")
        if keys is not None and hasattr(keys, "shape") and len(keys.shape) >= 3:
            return keys.shape[2]
        return state.get("offset", 0)

    def slice_state(
        self,
        state: dict[str, Any],
        start_idx: int,
        end_idx: int,
    ) -> dict[str, Any] | None:
        """Slice keys and values along sequence dimension (axis 2)."""
        if not HAS_MLX:
            return None

        keys = state.get("keys")
        values = state.get("values")

        if keys is None or values is None:
            return None

        try:
            # Slice along axis 2 (sequence dimension)
            # Shape: (batch, n_kv_heads, seq_len, head_dim)
            keys_slice = keys[:, :, start_idx:end_idx, :]
            values_slice = values[:, :, start_idx:end_idx, :]

            return {
                "keys": keys_slice,
                "values": values_slice,
                "cache_type": self.cache_type.value,
            }
        except Exception as e:
            logger.warning(f"Failed to slice KVCache state: {e}")
            return None

    def concatenate_states(
        self,
        states: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Concatenate multiple KVCache states along sequence dimension."""
        if not HAS_MLX or not states:
            return {}

        keys_list = [s["keys"] for s in states if s.get("keys") is not None]
        values_list = [s["values"] for s in states if s.get("values") is not None]

        if not keys_list or not values_list:
            return {}

        concat_keys = mx.concatenate(keys_list, axis=2)
        concat_values = mx.concatenate(values_list, axis=2)

        return {
            "keys": concat_keys,
            "values": concat_values,
            "offset": concat_keys.shape[2],
            "cache_type": self.cache_type.value,
        }

    def reconstruct_cache(
        self,
        state: dict[str, Any],
        meta_state: tuple | None = None,
    ) -> Any:
        """Reconstruct KVCache from state."""
        try:
            from mlx_lm.models.cache import KVCache
        except ImportError:
            logger.error("mlx_lm not available for cache reconstruction")
            return None

        keys = state.get("keys")
        values = state.get("values")

        if keys is None or values is None:
            return None

        cache = KVCache()
        cache.keys = keys
        cache.values = values

        # Always use tensor shape for offset. meta_state stores the offset
        # from the full cache at storage time, which can exceed the actual
        # tensor length after partial prefix match or walk-back truncation
        # (all blocks are stored with the same layer_meta_states).
        cache.offset = keys.shape[2]

        return cache


class ChunkedKVCacheHandler(KVCacheHandler):
    """Preserve the absolute position of a front-trimmed attention cache."""

    @property
    def cache_type(self):
        return CacheType.CHUNKED_KVCACHE

    @property
    def supports_block_slicing(self):
        return False

    def get_state_axis_info(self):
        return (
            CacheStateAxisInfo("keys", 2, False),
            CacheStateAxisInfo("values", 2, False),
        )

    def serialize_state(self, cache_obj):
        if cache_obj.keys is None:
            return None, None
        length = cache_obj.offset - cache_obj.start_position
        return (
            cache_obj.keys[..., :length, :],
            cache_obj.values[..., :length, :],
        )

    def serialize_meta_state(self, cache_obj):
        return (cache_obj.chunk_size, cache_obj.start_position, cache_obj.offset)

    def extract_state(self, cache_obj):
        state = super().extract_state(cache_obj)
        state["meta_state"] = self.serialize_meta_state(cache_obj)
        return state

    def slice_state(self, state, start_idx, end_idx):
        return state

    def concatenate_states(self, states):
        return states[-1] if states else {}

    def reconstruct_cache(self, state, meta_state=None):
        from mlx_lm.models.cache import ChunkedKVCache

        if not meta_state or len(meta_state) != 3:
            raise ValueError("ChunkedKVCache requires its window and absolute position")
        chunk_size, start, offset = map(int, meta_state)
        return ChunkedKVCache.from_state(
            (state["keys"], state["values"], offset, chunk_size, start)
        )


class RotatingKVCacheHandler(CacheTypeHandler):
    """Handler for RotatingKVCache (sliding window attention).

    RotatingKVCache uses:
    - keys/values: shape (batch, n_kv_heads, max_size, head_dim)
    - offset: total tokens processed
    - _idx: current rotation index
    - max_size: maximum window size
    - keep: tokens to always keep

    IMPORTANT: RotatingKVCache does NOT support block slicing because:
    1. The cache has a fixed max_size and uses circular buffer semantics
    2. The _idx pointer tracks the current position in the circular buffer
    3. Slicing would break the rotation index and cause shape mismatches
    4. When merged with other caches, all must have same max_size
    """

    @property
    def cache_type(self) -> CacheType:
        return CacheType.ROTATING_KVCACHE

    @property
    def supports_block_slicing(self) -> bool:
        return False  # Cannot safely slice rotating cache

    def get_state_axis_info(self) -> tuple[CacheStateAxisInfo, ...]:
        # State is (keys, values) with sequence_axis=2 but the rotation
        # index makes per-block slicing unsafe. Mark non-sliceable so
        # omlx core uses the last-block-only / boundary-snapshot path.
        return (
            CacheStateAxisInfo(name="keys", sequence_axis=2, sliceable=False),
            CacheStateAxisInfo(name="values", sequence_axis=2, sliceable=False),
        )

    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        """Extract state from RotatingKVCache object."""
        keys, values = self.serialize_state(cache_obj)

        # Get meta_state: (keep, max_size, offset, _idx)
        meta_state = self.serialize_meta_state(cache_obj)

        return {
            "keys": keys,
            "values": values,
            "offset": getattr(cache_obj, "offset", 0),
            "max_size": getattr(
                cache_obj, "max_size", keys.shape[2] if keys is not None else 0
            ),
            "keep": getattr(cache_obj, "keep", 0),
            "_idx": getattr(cache_obj, "_idx", 0),
            "meta_state": meta_state,
            "cache_type": self.cache_type.value,
        }

    def get_seq_len(self, state: dict[str, Any]) -> int:
        """Get effective sequence length (offset, not buffer size)."""
        return state.get("offset", 0)

    def slice_state(
        self,
        state: dict[str, Any],
        start_idx: int,
        end_idx: int,
    ) -> dict[str, Any] | None:
        """RotatingKVCache cannot be sliced by sequence position.

        Returns the full state instead, similar to ArraysCache.
        The circular buffer semantics make slicing unsafe.
        """
        return {
            "keys": state.get("keys"),
            "values": state.get("values"),
            "meta_state": state.get("meta_state", ()),
            "max_size": state.get("max_size"),
            "offset": state.get("offset"),
            "keep": state.get("keep"),
            "_idx": state.get("_idx"),
            "is_full_state": True,
            "cache_type": self.cache_type.value,
        }

    def concatenate_states(
        self,
        states: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """For RotatingKVCache, use the most recent state.

        Rotating cache states cannot be concatenated like KV caches
        because they use circular buffer semantics.
        """
        if not states:
            return {}

        # Use the last (most recent) state
        latest = states[-1]
        return {
            "keys": latest.get("keys"),
            "values": latest.get("values"),
            "meta_state": latest.get("meta_state", ()),
            "max_size": latest.get("max_size"),
            "offset": latest.get("offset"),
            "keep": latest.get("keep"),
            "_idx": latest.get("_idx"),
            "is_full_state": True,
            "cache_type": self.cache_type.value,
        }

    def reconstruct_cache(
        self,
        state: dict[str, Any],
        meta_state: tuple | None = None,
    ) -> Any:
        """Reconstruct RotatingKVCache from state.

        mlx-lm v0.31.3 contract:
          - ``keys.shape[2]`` is the actual buffer length (≤ ``max_size``).
          - ``_idx == keys.shape[2]`` puts ``_temporal_order`` in case 1
            (return as-is), so the buffer is read in temporal order
            during merge.
          - ``size()`` (clamped via PrefillReadyRotatingKVCache) reports
            the real RHS slice length, never overshooting the buffer.

        We never zero-pad the buffer to ``max_size``: doing so would
        leak zero positions into attention during BatchRotatingKVCache
        merge, causing softmax dilution (#934, #903).
        """
        keys = state.get("keys")
        values = state.get("values")

        if keys is None or values is None:
            return None

        # Parse meta_state: (keep, max_size, offset, _idx)
        if meta_state and len(meta_state) >= 4:
            keep, max_size, offset, _idx_unused = map(int, meta_state[:4])
        else:
            # Live-path states carry the window fields explicitly
            # (extract_state / slice_state / concatenate_states all emit
            # them). A restored state without them and without meta_state
            # has unknown window geometry: guessing offset/max_size from
            # the buffer shape silently shifts RoPE positions once the
            # window has rotated (true offset > buffer length) and shrinks
            # the window. Reject so the caller re-prefills instead.
            keep = state.get("keep")
            max_size = state.get("max_size")
            offset = state.get("offset")
            if keep is None or max_size is None or offset is None:
                logger.warning(
                    "RotatingKVCache reconstruction is missing meta_state "
                    "and explicit window fields (keep/max_size/offset). "
                    "Rejecting the cached state instead of guessing the "
                    "window geometry from the buffer shape."
                )
                return None
            keep, max_size, offset = int(keep), int(max_size), int(offset)

        # Trim oversized prefill-internal snapshots back to max_size.
        # Boundary snapshots can hold seq_len = max_size + chunk_size - 1
        # (mid-prefill state) which is not merge-safe when reintroduced
        # as a per-request prompt cache.
        if (
            hasattr(keys, "shape")
            and len(keys.shape) >= 3
            and max_size > 0
            and keys.shape[2] > max_size
            and HAS_MLX
            and mx is not None
        ):
            if keep > 0 and keep < max_size:
                tail_len = max_size - keep
                keys = mx.concatenate(
                    [keys[..., :keep, :], keys[..., -tail_len:, :]],
                    axis=2,
                )
                values = mx.concatenate(
                    [values[..., :keep, :], values[..., -tail_len:, :]],
                    axis=2,
                )
            else:
                keys = keys[..., -max_size:, :]
                values = values[..., -max_size:, :]

            keys = mx.contiguous(keys)
            values = mx.contiguous(values)

        # Force case 1 of _temporal_order by setting _idx = keys.shape[2].
        # The buffer is already in temporal order (extract() guarantees this
        # for SSD-restored caches; oversized trim above preserves it). Letting
        # _idx fall into the rotated branch (case 2) would re-slice the
        # buffer for no gain and obscure the merge contract.
        seq_len = (
            int(keys.shape[2]) if hasattr(keys, "shape") and len(keys.shape) >= 3 else 0
        )
        _idx = seq_len

        cache = PrefillReadyRotatingKVCache(max_size=max_size, keep=keep)
        cache.keys = keys
        cache.values = values
        cache.offset = offset
        cache._idx = _idx

        return cache

    def _get_meta_state_keys(self) -> tuple[str, ...]:
        return ("keep", "max_size", "offset", "_idx")


class SizedArraysCache:
    """ArraysCache wrapper that provides a correct size() method.

    mlx-lm's ArraysCache.size() always returns 0 because _BaseCache.size()
    returns 0 by default. This causes BatchGenerator batch ordering issues
    when sorting by prompt length + cache size.

    This wrapper tracks token_count and delegates all other methods to the
    inner ArraysCache, ensuring BatchGenerator sees the correct cache size.
    """

    def __init__(self, inner_cache: Any, token_count: int = 0):
        """Initialize the wrapper.

        Args:
            inner_cache: The ArraysCache to wrap.
            token_count: Number of tokens this cache represents.
        """
        self._inner = inner_cache
        self._token_count = token_count

    def size(self) -> int:
        """Return the cached token count (instead of 0)."""
        return self._token_count

    def empty(self) -> bool:
        """Delegate to inner cache."""
        return self._inner.empty()

    @property
    def state(self):
        """Delegate to inner cache."""
        return self._inner.state

    @state.setter
    def state(self, v):
        """Delegate to inner cache."""
        self._inner.state = v

    @property
    def cache(self):
        """Delegate to inner cache."""
        return self._inner.cache

    def __getitem__(self, idx):
        """Delegate to inner cache."""
        return self._inner[idx]

    def __setitem__(self, idx, value):
        """Delegate to inner cache."""
        self._inner[idx] = value

    def __len__(self):
        """Return length of inner cache's state list.

        ArraysCache doesn't have __len__, so we return len(cache) instead.
        """
        return len(self._inner.cache)

    def __getattr__(self, name):
        """Delegate unknown attributes to inner cache.

        This handles attributes like 'lengths', 'left_padding', etc.
        that may be set by BatchGenerator.prepare().
        """
        # Avoid infinite recursion for _inner
        if name == "_inner":
            raise AttributeError(name)
        return getattr(self._inner, name)

    def __setattr__(self, name, value):
        """Set attributes on inner cache for non-wrapper attributes."""
        if name in ("_inner", "_token_count"):
            object.__setattr__(self, name, value)
        else:
            setattr(self._inner, name, value)

    # BatchGenerator interface methods
    def prepare(self, **kwargs):
        """Delegate to inner cache."""
        return self._inner.prepare(**kwargs)

    def finalize(self):
        """Delegate to inner cache."""
        return self._inner.finalize()

    def advance(self, N):
        """Delegate to inner cache."""
        return self._inner.advance(N)

    def make_mask(self, N):
        """Delegate to inner cache."""
        return self._inner.make_mask(N)

    def filter(self, batch_indices):
        """Delegate to inner cache."""
        return self._inner.filter(batch_indices)

    def extend(self, other):
        """Delegate to inner cache."""
        # Unwrap if other is also a SizedArraysCache
        other_inner = other._inner if isinstance(other, SizedArraysCache) else other
        return self._inner.extend(other_inner)

    def extract(self, idx):
        """Extract and wrap to preserve token_count."""
        extracted = self._inner.extract(idx)
        return SizedArraysCache(extracted, self._token_count)

    @classmethod
    def merge(cls, caches: list["SizedArraysCache"]) -> "SizedArraysCache":
        """Merge multiple caches, preserving size information."""
        inner_caches = [c._inner if isinstance(c, cls) else c for c in caches]
        # Use first inner cache's merge method
        merged_inner = inner_caches[0].merge(inner_caches)
        # Preserve token_count from first cache
        token_count = caches[0]._token_count if isinstance(caches[0], cls) else 0
        return cls(merged_inner, token_count)


class ArraysCacheHandler(CacheTypeHandler):
    """Handler for generic ArraysCache (multiple state arrays).

    ArraysCache is a base class for caches with variable number of states.
    """

    @property
    def cache_type(self) -> CacheType:
        return CacheType.ARRAYS_CACHE

    @property
    def supports_block_slicing(self) -> bool:
        return False  # Generic arrays may not be sequence-indexed

    def is_variable_length_state(self) -> bool:
        return True  # state is a list of arrays of variable count

    def get_state_axis_info(self) -> tuple[CacheStateAxisInfo, ...]:
        # ArraysCache state length is dynamic. omlx core treats this as
        # variable-length (count prefix); axis info is not consulted but
        # we return an empty tuple to signal "no fixed schema".
        return ()

    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        """Extract state from ArraysCache object."""
        # Unwrap if wrapped in SizedArraysCache
        inner = (
            cache_obj._inner if isinstance(cache_obj, SizedArraysCache) else cache_obj
        )
        state_list = self.serialize_state(inner)

        return {
            "states": list(state_list) if state_list else [],
            "is_full_state": True,
            "cache_type": self.cache_type.value,
        }

    def get_seq_len(self, state: dict[str, Any]) -> int:
        return state.get("token_count", 0)

    def slice_state(
        self,
        state: dict[str, Any],
        start_idx: int,
        end_idx: int,
    ) -> dict[str, Any] | None:
        # Return full state
        return {
            "states": state.get("states", []),
            "is_full_state": True,
            "cache_type": self.cache_type.value,
        }

    def concatenate_states(
        self,
        states: list[dict[str, Any]],
    ) -> dict[str, Any]:
        if not states:
            return {}
        # Use latest state
        return states[-1]

    def deserialize_state(
        self,
        elements: tuple[Any, ...],
        meta_state: Any | None = None,
    ) -> Any:
        """Reconstruct every element of a variable-length ArraysCache state."""
        return self.reconstruct_cache(
            {"states": list(elements)},
            meta_state,
        )

    def reconstruct_cache(
        self,
        state: dict[str, Any],
        meta_state: tuple | None = None,
        token_count: int = 0,
    ) -> Any:
        """Reconstruct ArraysCache from state.

        Args:
            state: State dictionary with 'states' key.
            meta_state: Optional metadata (unused for ArraysCache).
            token_count: Number of tokens this cache represents.
                Used by SizedArraysCache wrapper for correct size() return.

        Returns:
            SizedArraysCache wrapping the reconstructed ArraysCache.
        """
        try:
            from mlx_lm.models.cache import ArraysCache
        except ImportError:
            logger.error("mlx_lm not available for cache reconstruction")
            return None

        states = state.get("states", [])
        if meta_state and tuple(meta_state) == ("deepseek_v41", "2"):
            from ..patches.deepseek_v41.cache import DeepseekV41Cache

            return DeepseekV41Cache.from_state(states, meta_state)
        cache = ArraysCache(size=len(states))
        for i, s in enumerate(states):
            cache.cache[i] = s

        # Wrap with SizedArraysCache to provide correct size()
        return SizedArraysCache(cache, token_count)

    def _get_state_keys(self) -> tuple[str, ...]:
        return ("states",)

    def _get_meta_state_keys(self) -> tuple[str, ...]:
        return ()


class CacheListHandler(CacheTypeHandler):
    """Handler for CacheList (composite cache with multiple sub-caches).

    CacheList wraps multiple sub-caches (e.g., KVCache + ArraysCache) into a
    single per-layer cache object. Used by models like deepseek_v32 (MLA),
    falcon_h1 (Mamba + Attention), baichuan_m1 (SSM + Attention).

    Uses last-block-only storage: only the last block stores full state,
    non-last blocks get placeholders. Partial prefix match → reject.
    """

    # Normalize sub-cache class names for mlx-lm CacheList.from_state() compat
    _CLASS_NAME_NORMALIZE = {
        "SizedArraysCache": "ArraysCache",
    }

    @property
    def cache_type(self) -> CacheType:
        return CacheType.CACHE_LIST

    def is_composite_cache(self) -> bool:
        return True  # delegate to sub-handlers per sub-cache

    def get_state_axis_info(self) -> tuple[CacheStateAxisInfo, ...]:
        # CacheList wraps sub-caches; per-element axis info is not
        # meaningful at this level. omlx core dispatches per sub-cache.
        return ()

    @property
    def supports_block_slicing(self) -> bool:
        return False  # Mixed sub-cache types prevent slicing

    def serialize_state(self, cache_obj: Any) -> tuple[Any, ...]:
        return tuple(self.extract_state(cache_obj)["sub_states"])

    def deserialize_state(
        self, elements: tuple[Any, ...], meta_state: Any | None = None
    ) -> Any:
        return self.reconstruct_cache({"sub_states": list(elements)}, meta_state)

    def serialize_meta_state(self, cache_obj: Any) -> tuple[Any, ...]:
        state = self.extract_state(cache_obj)
        return (state["sub_class_names"], state["sub_meta_states"])

    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        """Extract state from CacheList object.

        Iterates over sub-caches and extracts each one's state, meta_state,
        and class_name individually.

        Returns:
            Dictionary with sub_states, sub_class_names, sub_meta_states,
            cache_type, and is_full_state fields.
        """
        sub_caches = getattr(cache_obj, "caches", None)
        if not sub_caches:
            return {
                "sub_states": [],
                "sub_class_names": [],
                "sub_meta_states": [],
                "cache_type": self.cache_type.value,
                "is_full_state": True,
            }

        sub_states = []
        sub_class_names = []
        sub_meta_states = []

        from .type_registry import CacheTypeRegistry

        for sc in sub_caches:
            handler = CacheTypeRegistry.get_handler_for_object(sc)
            sub_states.append(handler.serialize_state(sc))

            # Get class name (normalize SizedArraysCache → ArraysCache)
            raw_name = type(sc).__name__
            # Unwrap SizedArraysCache
            if isinstance(sc, SizedArraysCache):
                raw_name = "ArraysCache"
            normalized = self._CLASS_NAME_NORMALIZE.get(raw_name, raw_name)
            sub_class_names.append(normalized)

            # Get meta_state
            sub_meta_states.append(handler.serialize_meta_state(sc))

        return {
            "sub_states": sub_states,
            "sub_class_names": sub_class_names,
            "sub_meta_states": sub_meta_states,
            "cache_type": self.cache_type.value,
            "is_full_state": True,
        }

    def get_seq_len(self, state: dict[str, Any]) -> int:
        """Get sequence length from sub-caches.

        Returns the maximum seq_len found among sub-caches that have
        4D tensors (batch, n_kv_heads, seq_len, head_dim).
        """
        max_seq_len = 0
        sub_states = state.get("sub_states", [])
        for sub_state in sub_states:
            if isinstance(sub_state, (list, tuple)) and len(sub_state) >= 2:
                sub_keys = sub_state[0]
                if hasattr(sub_keys, "shape") and len(sub_keys.shape) == 4:
                    max_seq_len = max(max_seq_len, sub_keys.shape[2])
        return max_seq_len

    def slice_state(
        self,
        state: dict[str, Any],
        start_idx: int,
        end_idx: int,
    ) -> dict[str, Any] | None:
        """CacheList cannot be sliced — return full state."""
        return {
            "sub_states": state.get("sub_states", []),
            "sub_class_names": state.get("sub_class_names", []),
            "sub_meta_states": state.get("sub_meta_states", []),
            "is_full_state": True,
            "cache_type": self.cache_type.value,
        }

    def concatenate_states(
        self,
        states: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Use the most recent (last) state."""
        if not states:
            return {}
        return states[-1]

    def reconstruct_cache(
        self,
        state: dict[str, Any],
        meta_state: tuple | None = None,
    ) -> Any:
        """Reconstruct CacheList from stored state.

        Rebuild sub-caches through omlx handlers. This is required for
        restored nested caches whose local contracts differ from mlx-lm's raw
        constructor, notably RotatingKVCache snapshots that must be trimmed into
        PrefillReadyRotatingKVCache before reuse.

        Args:
            state: Dict with 'sub_states' key containing per-sub-cache states.
            meta_state: Tuple of ([class_names], [sub_meta_states]).

        Returns:
            Reconstructed CacheList object, or None on failure.
        """
        sub_states = state.get("sub_states", [])
        if (
            not meta_state
            or not isinstance(meta_state, (list, tuple))
            or len(meta_state) < 2
        ):
            logger.error("CacheList reconstruct: missing or invalid meta_state")
            return None

        class_names, sub_meta_states = meta_state[0], meta_state[1]

        # Validate lengths match to prevent silent zip truncation
        if len(sub_states) != len(class_names) or len(sub_states) != len(
            sub_meta_states
        ):
            logger.error(
                f"CacheList reconstruct: length mismatch — "
                f"sub_states={len(sub_states)}, class_names={len(class_names)}, "
                f"sub_meta_states={len(sub_meta_states)}"
            )
            return None

        # NOTE: CacheTypeRegistry must be imported locally to avoid circular import
        # (type_handlers.py is imported by type_registry.py)
        try:
            from mlx_lm.models.cache import CacheList
        except ImportError:
            logger.error("mlx_lm not available for CacheList reconstruction")
            return None

        from .type_registry import CacheTypeRegistry as _Registry  # local import

        handler_reconstruct_failed = False
        sub_caches = []
        try:
            for sub_state, cls_name, sub_meta in zip(
                sub_states, class_names, sub_meta_states
            ):
                # Normalize class name for handler lookup
                normalized_name = self._CLASS_NAME_NORMALIZE.get(cls_name, cls_name)
                sub_handler = _Registry.get_handler_by_class_name(normalized_name)

                try:
                    if normalized_name in ("ArraysCache", "SizedArraysCache"):
                        sub_cache = sub_handler.reconstruct_cache(
                            {"states": list(sub_state)}, sub_meta
                        )
                    elif isinstance(sub_state, (list, tuple)):
                        # Generic N-tuple dispatch via the new deserialize_state
                        # interface. Handlers that have a 3-tuple state (e.g.
                        # PoolingCache: buf_kv, buf_gate, pooled) override
                        # deserialize_state to consume all elements; default
                        # implementation maps the first two to (keys, values)
                        # which matches the legacy contract for KVCache /
                        # RotatingKVCache.
                        sub_cache = sub_handler.deserialize_state(
                            tuple(sub_state), sub_meta
                        )
                    else:
                        logger.debug(
                            f"CacheList handler reconstruction skipped: "
                            f"unexpected sub_state format for {cls_name}"
                        )
                        handler_reconstruct_failed = True
                        break
                except Exception as e:
                    logger.debug(
                        f"CacheList handler reconstruction failed for {cls_name}: {e}"
                    )
                    handler_reconstruct_failed = True
                    break

                if sub_cache is None:
                    logger.debug(
                        f"CacheList handler reconstruction failed: "
                        f"sub-cache {cls_name} returned None"
                    )
                    handler_reconstruct_failed = True
                    break

                # Unwrap SizedArraysCache for CacheList (CacheList expects raw ArraysCache)
                if isinstance(sub_cache, SizedArraysCache):
                    sub_cache = sub_cache._inner

                sub_caches.append(sub_cache)
        except Exception as e:
            logger.debug(f"CacheList handler reconstruction failed: {e}")
            handler_reconstruct_failed = True

        if not handler_reconstruct_failed:
            return CacheList(*sub_caches)

        logger.error("CacheList reconstruction failed for a nested cache")
        return None

    def _get_state_keys(self) -> tuple[str, ...]:
        return ("sub_states", "sub_class_names", "sub_meta_states")

    def _get_meta_state_keys(self) -> tuple[str, ...]:
        return ("class_names", "sub_meta_states")


def _minimax_index_offset(index_keys: Any, meta_state: Any | None = None) -> int:
    if (
        index_keys is not None
        and hasattr(index_keys, "shape")
        and len(index_keys.shape) >= 3
    ):
        return int(index_keys.shape[2])
    if isinstance(meta_state, str):
        try:
            return int(meta_state)
        except ValueError:
            pass
    if isinstance(meta_state, (list, tuple)) and meta_state:
        try:
            return int(meta_state[0])
        except (TypeError, ValueError):
            pass
    return 0


class _MiniMaxM3CacheHandlerBase(CacheTypeHandler):
    """Shared MiniMax M3 sparse-cache serialization helpers."""

    @property
    def supports_block_slicing(self) -> bool:
        return False

    def get_state_axis_info(self) -> tuple[CacheStateAxisInfo, ...]:
        return (
            CacheStateAxisInfo("keys", 2, False),
            CacheStateAxisInfo("values", 2, False),
            CacheStateAxisInfo("index_keys", 2, False),
        )

    def serialize_meta_state(self, cache_obj: Any) -> tuple[Any, ...]:
        return (int(getattr(cache_obj, "index_offset", 0) or 0),)

    def get_seq_len(self, state: dict[str, Any]) -> int:
        keys = state.get("keys")
        if keys is not None and hasattr(keys, "shape") and len(keys.shape) >= 3:
            return int(keys.shape[2])
        index_keys = state.get("index_keys")
        if (
            index_keys is not None
            and hasattr(index_keys, "shape")
            and len(index_keys.shape) >= 3
        ):
            return int(index_keys.shape[2])
        return 0

    def slice_state(
        self,
        state: dict[str, Any],
        start_idx: int,
        end_idx: int,
    ) -> dict[str, Any] | None:
        return {
            **state,
            "is_full_state": True,
            "cache_type": self.cache_type.value,
        }

    def concatenate_states(self, states: list[dict[str, Any]]) -> dict[str, Any]:
        return states[-1] if states else {}

    def _get_state_keys(self) -> tuple[str, ...]:
        return ("keys", "values", "index_keys")

    def _get_meta_state_keys(self) -> tuple[str, ...]:
        return ("index_offset",)


class MiniMaxM3KVCacheHandler(_MiniMaxM3CacheHandlerBase):
    """Handler for MiniMax M3 sparse attention side-index caches."""

    @property
    def cache_type(self) -> CacheType:
        return CacheType.MINIMAX_M3_KVCACHE

    @property
    def supports_block_slicing(self) -> bool:
        return True

    def get_state_axis_info(self) -> tuple[CacheStateAxisInfo, ...]:
        return (
            CacheStateAxisInfo("keys", 2, True),
            CacheStateAxisInfo("values", 2, True),
            CacheStateAxisInfo("index_keys", 2, True),
        )

    def serialize_state(self, cache_obj: Any) -> tuple[Any, ...]:
        kv_state, index_state = cache_obj.state
        if kv_state is None:
            return (None, None, index_state)
        if isinstance(kv_state, (list, tuple)) and len(kv_state) >= 2:
            return (kv_state[0], kv_state[1], index_state)
        return (None, None, index_state)

    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        keys, values, index_keys = self.serialize_state(cache_obj)
        return {
            "keys": keys,
            "values": values,
            "index_keys": index_keys,
            "states": (keys, values, index_keys),
            "cache_type": self.cache_type.value,
        }

    def slice_state(
        self,
        state: dict[str, Any],
        start_idx: int,
        end_idx: int,
    ) -> dict[str, Any] | None:
        if not HAS_MLX:
            return None

        keys = state.get("keys")
        values = state.get("values")
        index_keys = state.get("index_keys")
        if keys is None or values is None:
            return None

        try:
            seq_len = int(keys.shape[2])
            actual_end = min(end_idx, seq_len)
            if start_idx >= actual_end:
                return None

            keys_slice = keys[:, :, start_idx:actual_end, :]
            values_slice = values[:, :, start_idx:actual_end, :]
            if index_keys is not None:
                index_end = min(actual_end, int(index_keys.shape[2]))
                index_slice = index_keys[:, :, start_idx:index_end, :]
            else:
                index_slice = None

            return {
                "keys": keys_slice,
                "values": values_slice,
                "index_keys": index_slice,
                "states": (keys_slice, values_slice, index_slice),
                "cache_type": self.cache_type.value,
            }
        except Exception as e:
            logger.warning("Failed to slice MiniMax M3 cache state: %s", e)
            return None

    def concatenate_states(self, states: list[dict[str, Any]]) -> dict[str, Any]:
        if not HAS_MLX or not states:
            return {}

        keys_list = [s.get("keys") for s in states if s.get("keys") is not None]
        values_list = [s.get("values") for s in states if s.get("values") is not None]
        index_list = [
            s.get("index_keys") for s in states if s.get("index_keys") is not None
        ]
        if not keys_list or not values_list:
            return {}

        keys = mx.concatenate(keys_list, axis=2)
        values = mx.concatenate(values_list, axis=2)
        index_keys = mx.concatenate(index_list, axis=2) if index_list else None
        return {
            "keys": keys,
            "values": values,
            "index_keys": index_keys,
            "states": (keys, values, index_keys),
            "cache_type": self.cache_type.value,
        }

    def deserialize_state(
        self,
        elements: tuple[Any, ...],
        meta_state: Any | None = None,
    ) -> Any:
        try:
            from ..patches.mlx_vlm_minimax_m3_compat import (
                apply_mlx_vlm_minimax_m3_compat_patch,
            )

            apply_mlx_vlm_minimax_m3_compat_patch()

            from mlx_vlm.models.minimax_m3_vl.language import MiniMaxM3KVCache
        except Exception as e:  # noqa: BLE001
            logger.error("mlx-vlm MiniMaxM3KVCache unavailable: %s", e)
            return None

        keys = elements[0] if len(elements) > 0 else None
        values = elements[1] if len(elements) > 1 else None
        index_keys = elements[2] if len(elements) > 2 else None

        cache = MiniMaxM3KVCache()
        if keys is not None and values is not None:
            cache.kv_cache.keys = keys
            cache.kv_cache.values = values
            cache.kv_cache.offset = keys.shape[2]
        cache.index_keys = index_keys
        cache.index_offset = _minimax_index_offset(index_keys, meta_state)
        return cache

    def reconstruct_cache(
        self,
        state: dict[str, Any],
        meta_state: tuple | None = None,
    ) -> Any:
        elements = state.get("states")
        if elements is None:
            elements = (
                state.get("keys"),
                state.get("values"),
                state.get("index_keys"),
            )
        return self.deserialize_state(tuple(elements), meta_state)


class MiniMaxM3BatchKVCacheHandler(_MiniMaxM3CacheHandlerBase):
    """Handler for batched MiniMax M3 sparse attention caches."""

    @property
    def cache_type(self) -> CacheType:
        return CacheType.MINIMAX_M3_BATCH_KVCACHE

    def get_state_axis_info(self) -> tuple[CacheStateAxisInfo, ...]:
        return (
            CacheStateAxisInfo("keys", 2, False),
            CacheStateAxisInfo("values", 2, False),
            CacheStateAxisInfo("offset", None, False),
            CacheStateAxisInfo("left_padding", None, False),
            CacheStateAxisInfo("index_keys", 2, False),
        )

    def serialize_state(self, cache_obj: Any) -> tuple[Any, ...]:
        kv_state, index_state = cache_obj.state
        if isinstance(kv_state, (list, tuple)) and len(kv_state) >= 4:
            return (
                kv_state[0],
                kv_state[1],
                kv_state[2],
                kv_state[3],
                index_state,
            )
        return (None, None, None, None, index_state)

    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        keys, values, offset, left_padding, index_keys = self.serialize_state(cache_obj)
        return {
            "keys": keys,
            "values": values,
            "offset": offset,
            "left_padding": left_padding,
            "index_keys": index_keys,
            "states": (keys, values, offset, left_padding, index_keys),
            "is_full_state": True,
            "cache_type": self.cache_type.value,
        }

    def deserialize_state(
        self,
        elements: tuple[Any, ...],
        meta_state: Any | None = None,
    ) -> Any:
        try:
            from ..patches.mlx_vlm_minimax_m3_compat import (
                apply_mlx_vlm_minimax_m3_compat_patch,
            )

            apply_mlx_vlm_minimax_m3_compat_patch()

            from mlx_vlm.models.minimax_m3_vl.language import MiniMaxM3BatchKVCache
        except Exception as e:  # noqa: BLE001
            logger.error("mlx-vlm MiniMaxM3BatchKVCache unavailable: %s", e)
            return None

        keys = elements[0] if len(elements) > 0 else None
        values = elements[1] if len(elements) > 1 else None
        offset = elements[2] if len(elements) > 2 else None
        left_padding = elements[3] if len(elements) > 3 else None
        index_keys = elements[4] if len(elements) > 4 else None

        left_padding_arg = left_padding if left_padding is not None else [0]
        cache = MiniMaxM3BatchKVCache(left_padding_arg)
        cache.state = ((keys, values, offset, left_padding_arg), index_keys)
        cache.index_offset = _minimax_index_offset(index_keys, meta_state)
        return cache

    def reconstruct_cache(
        self,
        state: dict[str, Any],
        meta_state: tuple | None = None,
    ) -> Any:
        elements = state.get("states")
        if elements is None:
            elements = (
                state.get("keys"),
                state.get("values"),
                state.get("offset"),
                state.get("left_padding"),
                state.get("index_keys"),
            )
        return self.deserialize_state(tuple(elements), meta_state)


def _serialize_qsa_positions(position_ids: Any) -> Any:
    """Normalize text/MRoPE positions to a fixed ``[B, C, S]`` layout."""
    if position_ids is None or not hasattr(position_ids, "ndim"):
        return position_ids
    if position_ids.ndim == 2:
        return position_ids[:, None, :]
    if position_ids.ndim == 3:
        return position_ids.transpose(1, 0, 2)
    raise ValueError(
        "QSA position IDs must be [B, S] or [3, B, S], got " f"{position_ids.shape}."
    )


def _deserialize_qsa_positions(position_ids: Any) -> Any:
    """Restore the model-facing text/MRoPE position layout."""
    if position_ids is None or not hasattr(position_ids, "ndim"):
        return position_ids
    if position_ids.ndim != 3:
        raise ValueError(
            "Serialized QSA position IDs must be [B, C, S], got "
            f"{position_ids.shape}."
        )
    channels = int(position_ids.shape[1])
    if channels not in (1, 3):
        raise ValueError(
            "Serialized QSA position IDs require 1 text channel or 3 "
            f"MRoPE channels, got {position_ids.shape}."
        )
    if channels == 1:
        return position_ids[:, 0, :]
    return position_ids.transpose(1, 0, 2)


def _normalize_qsa_position_states(position_states: list[Any]) -> list[Any]:
    """Promote mixed text/MRoPE QSA positions to [B, 3, S].

    Qwen4 represents text positions as [B, S] and MRoPE positions as
    [3, B, S]. Serialization stores those as [B, 1, S] and [B, 3, S]
    respectively. The model's indexer cache promotes the text form by
    broadcasting it across all three MRoPE coordinates when the two forms
    meet, so block reconstruction must perform the equivalent operation
    before concatenating along the sequence axis.
    """
    if not position_states:
        return position_states

    batch_size = None
    channels: set[int] = set()
    for position_state in position_states:
        if not hasattr(position_state, "ndim") or position_state.ndim != 3:
            shape = getattr(position_state, "shape", None)
            raise ValueError(
                "Serialized QSA position IDs must be [B, C, S], " f"got {shape}."
            )
        current_batch, current_channels, _ = position_state.shape
        if current_channels not in (1, 3):
            raise ValueError(
                "Serialized QSA position IDs require 1 text channel or 3 "
                f"MRoPE channels, got {position_state.shape}."
            )
        if batch_size is None:
            batch_size = current_batch
        elif current_batch != batch_size:
            raise ValueError(
                "Serialized QSA position IDs must have a consistent batch "
                f"dimension, got {batch_size} and {current_batch}."
            )
        channels.add(current_channels)

    # Preserve both homogeneous paths without introducing broadcast views.
    if len(channels) == 1:
        return position_states

    return [
        (
            mx.broadcast_to(state, (state.shape[0], 3, state.shape[2]))
            if state.shape[1] == 1
            else state
        )
        for state in position_states
    ]


class Qwen4QSAKVCacheHandler(CacheTypeHandler):
    """Handler for Qwen4 QSA caches with raw index keys and positions."""

    @property
    def cache_type(self) -> CacheType:
        return CacheType.QWEN4_QSA_KVCACHE

    @property
    def supports_block_slicing(self) -> bool:
        return True

    def get_state_axis_info(self) -> tuple[CacheStateAxisInfo, ...]:
        return (
            CacheStateAxisInfo("keys", 2, True),
            CacheStateAxisInfo("values", 2, True),
            CacheStateAxisInfo("index_keys", 1, True),
            CacheStateAxisInfo("index_position_ids", 2, True),
        )

    def _get_state_keys(self) -> tuple[str, ...]:
        return tuple(info.name for info in self.get_state_axis_info())

    @staticmethod
    def _validate_serialized_state(elements: tuple[Any, ...]) -> int:
        """Validate one complete, serialized QSA cache state."""
        if len(elements) != 4:
            raise ValueError(
                "Serialized QSA cache state requires keys, values, index keys, "
                "and index positions"
            )

        keys, values, index_keys, position_ids = elements
        present = tuple(element is not None for element in elements)
        if not any(present):
            return 0
        if not all(present):
            raise ValueError(
                "Non-empty QSA cache blocks require complete QSA auxiliary state"
            )

        shapes = tuple(getattr(element, "shape", None) for element in elements)
        if any(shape is None for shape in shapes):
            raise ValueError("Serialized QSA cache state must contain tensors")
        if len(shapes[3]) != 3:
            raise ValueError(
                "Serialized QSA position IDs must be [B, C, S], got " f"{shapes[3]}."
            )
        if len(shapes[0]) != 4 or len(shapes[1]) != 4 or len(shapes[2]) != 3:
            raise ValueError(
                "Serialized QSA cache state requires 4-D K/V and 3-D index "
                f"keys, got {shapes[:3]}"
            )

        channels = int(shapes[3][1])
        if channels not in (1, 3):
            raise ValueError(
                "Serialized QSA position IDs require 1 text channel or 3 "
                f"MRoPE channels, got {shapes[3]}."
            )

        batch_sizes = tuple(int(shape[0]) for shape in shapes)
        if len(set(batch_sizes)) != 1:
            raise ValueError(
                "Serialized QSA state requires a consistent batch dimension, "
                f"got {batch_sizes}."
            )

        lengths = (
            int(shapes[0][2]),
            int(shapes[1][2]),
            int(shapes[2][1]),
            int(shapes[3][2]),
        )
        if len(set(lengths)) != 1:
            raise ValueError(
                "Serialized QSA K/V and auxiliary state must have the same "
                f"sequence length, got {lengths}."
            )
        return lengths[0]

    def get_state_seq_len_from_tuple(self, state_tuple: tuple[Any, ...]) -> int:
        return self._validate_serialized_state(tuple(state_tuple))

    def serialize_state(self, cache_obj: Any) -> tuple[Any, ...]:
        keys, values, index_keys, position_ids = cache_obj.state
        elements = (
            keys,
            values,
            index_keys,
            _serialize_qsa_positions(position_ids),
        )
        self._validate_serialized_state(elements)
        return elements

    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        elements = self.serialize_state(cache_obj)
        return {
            "keys": elements[0],
            "values": elements[1],
            "index_keys": elements[2],
            "index_position_ids": elements[3],
            "states": elements,
            "offset": getattr(cache_obj, "offset", 0),
            "cache_type": self.cache_type.value,
        }

    def get_seq_len(self, state: dict[str, Any]) -> int:
        keys = state.get("keys")
        return int(keys.shape[2]) if keys is not None else 0

    def slice_state(
        self,
        state: dict[str, Any],
        start_idx: int,
        end_idx: int,
    ) -> dict[str, Any] | None:
        if not HAS_MLX:
            return None
        elements = state.get("states")
        if elements is None:
            elements = tuple(
                state.get(info.name) for info in self.get_state_axis_info()
            )
        seq_len = self.get_state_seq_len_from_tuple(tuple(elements))
        actual_end = min(end_idx, seq_len)
        if seq_len <= 0 or start_idx >= actual_end:
            return None
        sliced = []
        for info, element in zip(self.get_state_axis_info(), elements):
            if element is None:
                sliced.append(None)
                continue
            slices = [slice(None)] * element.ndim
            slices[info.sequence_axis] = slice(start_idx, actual_end)
            sliced.append(element[tuple(slices)])
        return {
            **{
                info.name: value
                for info, value in zip(self.get_state_axis_info(), sliced)
            },
            "states": tuple(sliced),
            "cache_type": self.cache_type.value,
        }

    def concatenate_states(self, states: list[dict[str, Any]]) -> dict[str, Any]:
        if not HAS_MLX or not states:
            return {}
        grouped: list[list[Any]] = [[] for _ in self.get_state_axis_info()]
        state_lengths = []
        for state in states:
            elements = state.get("states")
            if elements is None:
                elements = tuple(
                    state.get(info.name) for info in self.get_state_axis_info()
                )
            elements = tuple(elements)
            state_lengths.append(self._validate_serialized_state(elements))
            for index, element in enumerate(elements):
                if element is not None:
                    grouped[index].append(element)
        if any(length == 0 for length in state_lengths) and any(
            length > 0 for length in state_lengths
        ):
            raise ValueError(
                "Non-empty QSA prefix chains cannot contain empty cache blocks"
            )
        concatenated = []
        for info, elements in zip(self.get_state_axis_info(), grouped):
            if info.name == "index_position_ids":
                elements = _normalize_qsa_position_states(elements)
            concatenated.append(
                mx.concatenate(elements, axis=info.sequence_axis) if elements else None
            )
        return {
            **{
                info.name: value
                for info, value in zip(self.get_state_axis_info(), concatenated)
            },
            "states": tuple(concatenated),
            "cache_type": self.cache_type.value,
        }

    def deserialize_state(
        self,
        elements: tuple[Any, ...],
        meta_state: Any | None = None,
    ) -> Any:
        del meta_state
        try:
            from ..patches.mlx_vlm_qwen4_exp_compat import (
                apply_mlx_vlm_qwen4_exp_compat_patch,
            )

            apply_mlx_vlm_qwen4_exp_compat_patch()
            from mlx_vlm.models.qwen4_exp.language import QSAKVCache
        except Exception as exc:  # noqa: BLE001
            logger.error("Qwen4 QSAKVCache unavailable: %s", exc)
            return None

        elements = tuple(elements)
        self._validate_serialized_state(elements)
        keys, values, index_keys, position_ids = elements
        cache = QSAKVCache()
        cache.state = (
            keys,
            values,
            index_keys,
            _deserialize_qsa_positions(position_ids),
        )
        return cache

    def reconstruct_cache(
        self,
        state: dict[str, Any],
        meta_state: tuple | None = None,
    ) -> Any:
        elements = state.get("states")
        if elements is None:
            elements = tuple(
                state.get(info.name) for info in self.get_state_axis_info()
            )
        return self.deserialize_state(tuple(elements), meta_state)


class Qwen4QSAQuantizedKVCacheHandler(Qwen4QSAKVCacheHandler):
    """Store Qwen4 quantized QSA caches as dense APC-compatible blocks."""

    @property
    def cache_type(self) -> CacheType:
        return CacheType.QWEN4_QSA_QUANTIZED_KVCACHE

    def serialize_state(self, cache_obj: Any) -> tuple[Any, ...]:
        keys, values = cache_obj.dequantize_for_apc()
        elements = (
            keys,
            values,
            cache_obj.index_keys,
            _serialize_qsa_positions(cache_obj.index_position_ids),
        )
        self._validate_serialized_state(elements)
        return elements


class Qwen4BatchQSAKVCacheHandler(CacheTypeHandler):
    """Full-state handler for batched Qwen4 QSA caches."""

    @property
    def cache_type(self) -> CacheType:
        return CacheType.QWEN4_BATCH_QSA_KVCACHE

    @property
    def supports_block_slicing(self) -> bool:
        return False

    def get_state_axis_info(self) -> tuple[CacheStateAxisInfo, ...]:
        return (
            CacheStateAxisInfo("keys", 2, False),
            CacheStateAxisInfo("values", 2, False),
            CacheStateAxisInfo("offset", None, False),
            CacheStateAxisInfo("left_padding", None, False),
            CacheStateAxisInfo("index_keys", 1, False),
            CacheStateAxisInfo("index_position_ids", 2, False),
        )

    def serialize_state(self, cache_obj: Any) -> tuple[Any, ...]:
        kv_state, index_keys, position_ids = cache_obj.state
        keys, values, offset, left_padding = kv_state
        return (
            keys,
            values,
            offset,
            left_padding,
            index_keys,
            _serialize_qsa_positions(position_ids),
        )

    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        elements = self.serialize_state(cache_obj)
        return {
            **{
                info.name: value
                for info, value in zip(self.get_state_axis_info(), elements)
            },
            "states": elements,
            "is_full_state": True,
            "cache_type": self.cache_type.value,
        }

    def get_seq_len(self, state: dict[str, Any]) -> int:
        keys = state.get("keys")
        return int(keys.shape[2]) if keys is not None else 0

    def slice_state(
        self,
        state: dict[str, Any],
        start_idx: int,
        end_idx: int,
    ) -> dict[str, Any] | None:
        del start_idx, end_idx
        return {**state, "is_full_state": True}

    def concatenate_states(self, states: list[dict[str, Any]]) -> dict[str, Any]:
        return states[-1] if states else {}

    def deserialize_state(
        self,
        elements: tuple[Any, ...],
        meta_state: Any | None = None,
    ) -> Any:
        del meta_state
        try:
            from ..patches.mlx_vlm_qwen4_exp_compat import (
                apply_mlx_vlm_qwen4_exp_compat_patch,
            )

            apply_mlx_vlm_qwen4_exp_compat_patch()
            from mlx_vlm.models.qwen4_exp.language import BatchQSAKVCache
        except Exception as exc:  # noqa: BLE001
            logger.error("Qwen4 BatchQSAKVCache unavailable: %s", exc)
            return None

        padded = tuple(elements) + (None,) * max(0, 6 - len(elements))
        keys, values, offset, left_padding, index_keys, position_ids = padded[:6]
        left_padding_arg = left_padding if left_padding is not None else [0]
        cache = BatchQSAKVCache(left_padding_arg)
        cache.state = (
            (keys, values, offset, left_padding_arg),
            index_keys,
            _deserialize_qsa_positions(position_ids),
        )
        return cache

    def reconstruct_cache(
        self,
        state: dict[str, Any],
        meta_state: tuple | None = None,
    ) -> Any:
        elements = state.get("states")
        if elements is None:
            elements = tuple(
                state.get(info.name) for info in self.get_state_axis_info()
            )
        return self.deserialize_state(tuple(elements), meta_state)


# Default handler for unknown types - falls back to KVCache behavior
class DefaultCacheHandler(KVCacheHandler):
    """Default handler that assumes KVCache-like behavior.

    Used as fallback for unknown cache types.
    """

    @property
    def cache_type(self) -> CacheType:
        return CacheType.KVCACHE

    def extract_state(self, cache_obj: Any) -> dict[str, Any]:
        """Try to extract state assuming KVCache-like structure."""
        try:
            if hasattr(cache_obj, "state"):
                state = cache_obj.state
                if isinstance(state, tuple) and len(state) == 2:
                    keys, values = state
                    return {
                        "keys": keys,
                        "values": values,
                        "offset": getattr(cache_obj, "offset", 0),
                        "cache_type": "Unknown",
                    }
        except Exception as e:
            logger.warning(f"Failed to extract state from unknown cache type: {e}")

        return {"cache_type": "Unknown"}
