"""Fast Qwen3.5/3.6 prefill kernels with optional native dispatch."""

from __future__ import annotations

import logging
import platform
import re
from pathlib import Path
from typing import Any

import mlx.core as mx

logger = logging.getLogger(__name__)


def _detach_import_error(exc: Exception) -> Exception:
    """Keep the diagnostic message without retaining import caller frames."""
    exc.__traceback__ = None
    exc.__cause__ = None
    exc.__context__ = None
    return exc


try:
    from . import _ext
except Exception as exc:  # pragma: no cover - depends on local native build
    _ext = None
    _IMPORT_ERROR = _detach_import_error(exc)
    # Default installs ship no extension; warn only when a built _ext fails
    # to load (e.g. unresolved @rpath/libmlx.dylib, issue #2233) so the
    # silent-slow-path fallback leaves a trace in the server log.
    if any(Path(__file__).parent.glob("_ext*.so")):
        logger.warning(
            "%s: native extension is present but failed to load; falling "
            "back to the slow path: %s",
            __name__,
            _IMPORT_ERROR,
        )
else:
    _IMPORT_ERROR = None


def _verify_abi(ext, import_error):
    """Disable the native symbols when the extension rejects mlx arrays.

    An extension built with a nanobind whose ABI tag differs from the mlx
    wheel's imports cleanly and lists every symbol, but its type casters
    live in an isolated NB_DOMAIN, so every call raises ``TypeError:
    incompatible function arguments`` (issue #2139). Probe once at import
    and degrade with a single warning instead of failing per call; builds
    predating the ``abi_probe`` binding are assumed compatible.
    """
    if ext is None:
        return ext, import_error
    probe = getattr(ext, "abi_probe", None)
    if probe is None:
        return ext, import_error
    try:
        probe(mx.zeros((1,)))
    except TypeError as exc:
        logger.warning(
            "%s: native kernels disabled — the extension was built with a "
            "nanobind ABI that does not match this mlx wheel; rebuild it "
            "against the installed mlx (see pyproject build-system pins).",
            __name__,
        )
        return None, _detach_import_error(exc)
    return ext, import_error


_ext, _IMPORT_ERROR = _verify_abi(_ext, _IMPORT_ERROR)


def set_command_buffer_caps(ops: int, mb: int) -> tuple[int, int] | None:
    """Set MLX's per-command-buffer caps and return the previous pair.

    Returns None when the native extension is unavailable; MLX keeps its caps.
    """
    setter = getattr(_ext, "set_command_buffer_caps", None)
    if setter is None:
        return None
    return tuple(setter(int(ops), int(mb)))


NATIVE_SYMBOLS = (
    "qwen35_fa256_attention",
    "qwen35_q2_affine_qmm_t",
    "qwen35_q4_affine_qmm_t",
    "qwen35_q5_affine_qmm_t",
    "qwen35_q6_affine_qmm_t",
    "qwen35_q8_affine_qmm_t",
    "qwen35_moe_weighted_sum",
    "qwen35_ane_q4_affine_qmm_t",
    "qwen35_ane_affine_qmm_t",
    "qwen35_ane_q4_swiglu_t",
    "qwen35_ane_affine_swiglu_t",
    "qwen35_ane_cpu_fp16_affine_qmm_t",
    "qwen35_ane_cpu_fp16_swiglu_t",
    "qwen35_ane_cpu_fp16_q4_swiglu_t",
    "qwen35_ane_compile_linear_bank",
    "qwen35_ane_compile_swiglu_down_bank",
    "qwen35_cpu_fp16_affine_qmm_t",
    "qwen35_ane_dual_affine_qmm_t",
    "qwen35_ane_dual_cpu_fp16_affine_qmm_t",
    "qwen35_ane_dual_cpu_fp16_swiglu_t",
    "qwen35_ane_dual_q4_swiglu_t",
    "qwen35_ane_dual_affine_swiglu_t",
    "qwen35_ane_dual_cpu_fp16_q4_swiglu_t",
    "qwen35_ane_q4_swiglu_down_t",
    "qwen35_ane_dual_q4_swiglu_down_t",
    "qwen35_ane_dual_cpu_fp16_q4_swiglu_down_t",
    "oq_a8_kernels_available",
    "qwen35_oq_a8_quantize",
    "qwen35_oq_a8_qmm_t",
    "qwen35_oq_a8_decode_weights",
    "qwen35_oq_a8_stage_a_v8",
    "qwen35_oq_a8_stage_a_natural",
)


def qwen35_cpu_fp16_affine_qmm_t(
    x: mx.array,
    cpu_weight: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    bits: int,
    variant: int = 8,
    group_size: int = 128,
    cpu_threads: int = 0,
    cpu_shared_resource: bool = False,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_cpu_fp16_affine_qmm_t"):
        raise RuntimeError("CPU/GPU fp16 hybrid qmm native kernel is unavailable")
    args = (
        x,
        cpu_weight,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        bits,
        variant,
        group_size,
        cpu_threads,
    )
    if hasattr(_ext, "qwen35_cpu_shared_resource_available"):
        return _ext.qwen35_cpu_fp16_affine_qmm_t(
            *args, cpu_shared_resource
        )
    return _ext.qwen35_cpu_fp16_affine_qmm_t(*args)


def qwen35_ane_dual_cpu_fp16_q4_swiglu_t(
    x: mx.array,
    cpu_weight: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model0,
    ane_model1,
    variant: int = 8,
    group_size: int = 128,
    cpu_threads: int = 0,
    cpu_shared_resource: bool = False,
) -> mx.array:
    if _ext is None or not hasattr(
        _ext, "qwen35_ane_dual_cpu_fp16_q4_swiglu_t"
    ):
        raise RuntimeError("ANE/CPU/GPU fp16 hybrid SwiGLU is unavailable")
    args = (
        x,
        cpu_weight,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model0,
        ane_model1,
        variant,
        group_size,
        cpu_threads,
    )
    if hasattr(_ext, "qwen35_cpu_shared_resource_available"):
        return _ext.qwen35_ane_dual_cpu_fp16_q4_swiglu_t(
            *args, cpu_shared_resource
        )
    return _ext.qwen35_ane_dual_cpu_fp16_q4_swiglu_t(*args)


def qwen35_ane_cpu_fp16_q4_swiglu_t(
    x: mx.array,
    cpu_weight: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model,
    variant: int = 8,
    group_size: int = 128,
    cpu_threads: int = 0,
    cpu_shared_resource: bool = False,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_cpu_fp16_q4_swiglu_t"):
        raise RuntimeError("Single-ANE/CPU/GPU fp16 q4 SwiGLU is unavailable")
    return _ext.qwen35_ane_cpu_fp16_q4_swiglu_t(
        x,
        cpu_weight,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model,
        variant,
        group_size,
        cpu_threads,
        cpu_shared_resource,
    )


def qwen35_ane_cpu_fp16_swiglu_t(
    x: mx.array,
    cpu_weight: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model,
    bits: int,
    variant: int = 8,
    group_size: int = 128,
    cpu_threads: int = 0,
    cpu_shared_resource: bool = False,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_cpu_fp16_swiglu_t"):
        raise RuntimeError("Single-ANE/CPU/GPU fp16 SwiGLU is unavailable")
    return _ext.qwen35_ane_cpu_fp16_swiglu_t(
        x,
        cpu_weight,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model,
        bits,
        variant,
        group_size,
        cpu_threads,
        cpu_shared_resource,
    )


def qwen35_ane_cpu_fp16_affine_qmm_t(
    x: mx.array,
    cpu_weight: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model,
    bits: int,
    variant: int = 8,
    group_size: int = 128,
    profile_category: int = 1,
    cpu_threads: int = 0,
    cpu_shared_resource: bool = False,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_cpu_fp16_affine_qmm_t"):
        raise RuntimeError("Single-ANE/CPU/GPU fp16 affine qmm is unavailable")
    return _ext.qwen35_ane_cpu_fp16_affine_qmm_t(
        x,
        cpu_weight,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model,
        bits,
        variant,
        group_size,
        profile_category,
        cpu_threads,
        cpu_shared_resource,
    )


def qwen35_ane_dual_cpu_fp16_swiglu_t(
    x: mx.array,
    cpu_weight: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model0,
    ane_model1,
    bits: int,
    variant: int = 8,
    group_size: int = 128,
    cpu_threads: int = 0,
    cpu_shared_resource: bool = False,
) -> mx.array:
    if _ext is None or not hasattr(
        _ext, "qwen35_ane_dual_cpu_fp16_swiglu_t"
    ):
        raise RuntimeError("ANE/CPU/GPU fp16 hybrid SwiGLU is unavailable")
    return _ext.qwen35_ane_dual_cpu_fp16_swiglu_t(
        x,
        cpu_weight,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model0,
        ane_model1,
        bits,
        variant,
        group_size,
        cpu_threads,
        cpu_shared_resource,
    )


def qwen35_ane_dual_cpu_fp16_affine_qmm_t(
    x: mx.array,
    cpu_weight: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model0,
    ane_model1,
    bits: int,
    variant: int = 8,
    group_size: int = 128,
    profile_category: int = 1,
    cpu_threads: int = 0,
    cpu_shared_resource: bool = False,
) -> mx.array:
    if _ext is None or not hasattr(
        _ext, "qwen35_ane_dual_cpu_fp16_affine_qmm_t"
    ):
        raise RuntimeError("ANE/CPU/GPU fp16 hybrid affine qmm is unavailable")
    return _ext.qwen35_ane_dual_cpu_fp16_affine_qmm_t(
        x,
        cpu_weight,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model0,
        ane_model1,
        bits,
        variant,
        group_size,
        profile_category,
        cpu_threads,
        cpu_shared_resource,
    )


def qwen35_cpu_shared_resource_available() -> bool:
    """Whether dispatch_apply supports shared-resource scheduling attributes."""
    return bool(
        _ext is not None
        and hasattr(_ext, "qwen35_cpu_shared_resource_available")
        and _ext.qwen35_cpu_shared_resource_available()
    )


def qwen35_ane_available() -> bool:
    """Whether the opt-in private ANE runtime is usable on this host."""
    return bool(
        _ext is not None
        and hasattr(_ext, "qwen35_ane_available")
        and _ext.qwen35_ane_available()
    )


def qwen35_ane_hybrid_nax_enabled() -> bool:
    """Whether ANE hybrid GPU suffixes currently select bundled NAX QMM."""
    return bool(
        _ext is not None
        and hasattr(_ext, "qwen35_ane_hybrid_nax_enabled")
        and _ext.qwen35_ane_hybrid_nax_enabled()
    )


_ANE_PROFILE_KEYS = (
    "operations",
    "pack_ns",
    "ane_region_ns",
    "ane0_eval_ns",
    "ane1_eval_ns",
    "ane0_launch_ns",
    "ane1_launch_ns",
    "gpu_qmm_ns",
    "gpu_completion_ns",
    "cpu_matmul_ns",
    "cpu_completion_ns",
    "ane_last",
    "gpu_last",
    "gap_before_ns",
)


def qwen35_ane_profile_reset() -> None:
    if _ext is not None and hasattr(_ext, "qwen35_ane_profile_reset"):
        _ext.qwen35_ane_profile_reset()


def qwen35_ane_profile_set_enabled(enabled: bool) -> bool:
    """Enable native ANE phase counters for a bounded diagnostic window."""
    if _ext is None or not hasattr(_ext, "qwen35_ane_profile_set_enabled"):
        return False
    _ext.qwen35_ane_profile_set_enabled(bool(enabled))
    return True


def qwen35_ane_profile_snapshot() -> dict[str, dict[str, float]]:
    if _ext is None or not hasattr(_ext, "qwen35_ane_profile_snapshot"):
        return {}
    values = list(_ext.qwen35_ane_profile_snapshot())
    width = len(_ANE_PROFILE_KEYS)
    if len(values) != 2 * width:
        return {}
    return {
        name: dict(zip(_ANE_PROFILE_KEYS, values[index * width : (index + 1) * width]))
        for index, name in enumerate(("mlp", "gdn"))
    }


def qwen35_ane_compile_linear(
    weight: mx.array, sequence_length: int, ane_instance: int = 0
):
    if not qwen35_ane_available():
        raise RuntimeError("Private ANE runtime is unavailable")
    try:
        return _ext.qwen35_ane_compile_linear(weight, sequence_length, ane_instance)
    except TypeError:
        if ane_instance:
            raise RuntimeError(
                "The native extension does not support ANE instance pinning"
            ) from None
        return _ext.qwen35_ane_compile_linear(weight, sequence_length)


def qwen35_ane_bank_compiler_available() -> bool:
    """True when both the private ANE runtime and the procedure-bank compiler
    entry point are present. Callers that would otherwise discover
    unavailability via the RuntimeError below (the ANE tuner in particular)
    can probe this up front instead of failing deep inside a compile ladder
    (#3044)."""
    return (
        qwen35_ane_available()
        and _ext is not None
        and hasattr(_ext, "qwen35_ane_compile_linear_bank")
    )


def qwen35_ane_compile_linear_bank(
    weights: list[mx.array], sequence_length: int, ane_instance: int
):
    if not qwen35_ane_bank_compiler_available():
        raise RuntimeError("Private ANE procedure-bank compiler is unavailable")
    return _ext.qwen35_ane_compile_linear_bank(
        weights, sequence_length, ane_instance
    )


def qwen35_ane_linear_bank_builder(sequence_length: int):
    """Incremental bank builder: add() converts one fp32 slice at a time so
    the caller can release each staging array immediately (issue #2781)."""
    if not qwen35_ane_available() or _ext is None or not hasattr(
        _ext, "AneLinearBankBuilder"
    ):
        raise RuntimeError("Private ANE procedure-bank builder is unavailable")
    return _ext.AneLinearBankBuilder(sequence_length)


def qwen35_ane_fused_bank_builder(sequence_length: int):
    """Incremental fused SwiGLU/down bank builder: add() converts one fp32
    gate/up/down triple at a time so the caller can release each staging
    array immediately (the issue #2781 recipe applied to fused banks)."""
    if not qwen35_ane_available() or _ext is None or not hasattr(
        _ext, "AneFusedBankBuilder"
    ):
        raise RuntimeError("Private ANE procedure-bank builder is unavailable")
    return _ext.AneFusedBankBuilder(sequence_length)


def qwen35_ane_affine_qmm_t(
    x: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model,
    bits: int,
    variant: int = 8,
    group_size: int = 128,
    profile_category: int = 1,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_affine_qmm_t"):
        raise RuntimeError("ANE hybrid affine qmm native kernel is unavailable")
    return _ext.qwen35_ane_affine_qmm_t(
        x,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model,
        bits,
        variant,
        group_size,
        profile_category,
    )


def qwen35_ane_compile_fp16_linear(weight: mx.array, sequence_length: int):
    if not qwen35_ane_available() or not hasattr(
        _ext, "qwen35_ane_compile_fp16_linear"
    ):
        raise RuntimeError("Private ANE fp16 runtime is unavailable")
    return _ext.qwen35_ane_compile_fp16_linear(weight, sequence_length)


def qwen35_ane_swiglu_down_available() -> bool:
    return bool(
        qwen35_ane_available()
        and hasattr(_ext, "qwen35_ane_compile_swiglu_down")
        and hasattr(_ext, "qwen35_ane_q4_swiglu_down_t")
    )


def qwen35_ane_compile_swiglu_down(
    gate_weight: mx.array,
    up_weight: mx.array,
    down_weight: mx.array,
    sequence_length: int,
    ane_instance: int = 0,
):
    if not qwen35_ane_swiglu_down_available():
        raise RuntimeError("Private ANE SwiGLU/down runtime is unavailable")
    return _ext.qwen35_ane_compile_swiglu_down(
        gate_weight, up_weight, down_weight, sequence_length, ane_instance
    )


def qwen35_ane_compile_swiglu_down_bank(
    gate_weights: list[mx.array],
    up_weights: list[mx.array],
    down_weights: list[mx.array],
    sequence_length: int,
    ane_instance: int,
):
    if _ext is None or not hasattr(_ext, "qwen35_ane_compile_swiglu_down_bank"):
        raise RuntimeError("Private ANE SwiGLU/down bank compiler is unavailable")
    return _ext.qwen35_ane_compile_swiglu_down_bank(
        gate_weights,
        up_weights,
        down_weights,
        sequence_length,
        ane_instance,
    )


def qwen35_ane_q4_affine_qmm_t(
    x: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model,
    variant: int = 8,
    group_size: int = 128,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_q4_affine_qmm_t"):
        raise RuntimeError("ANE hybrid q4 qmm native kernel is unavailable")
    return _ext.qwen35_ane_q4_affine_qmm_t(
        x,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model,
        variant,
        group_size,
    )


def qwen35_ane_q4_swiglu_t(
    x: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model,
    variant: int = 8,
    group_size: int = 128,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_q4_swiglu_t"):
        raise RuntimeError("ANE hybrid q4 SwiGLU native kernel is unavailable")
    return _ext.qwen35_ane_q4_swiglu_t(
        x,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model,
        variant,
        group_size,
    )


def qwen35_ane_affine_swiglu_t(
    x: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model,
    bits: int,
    variant: int = 8,
    group_size: int = 128,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_affine_swiglu_t"):
        raise RuntimeError("ANE hybrid affine SwiGLU native kernel is unavailable")
    return _ext.qwen35_ane_affine_swiglu_t(
        x,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model,
        bits,
        variant,
        group_size,
    )


def qwen35_ane_dual_affine_qmm_t(
    x: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model0,
    ane_model1,
    bits: int,
    variant: int = 8,
    group_size: int = 128,
    profile_category: int = 1,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_dual_affine_qmm_t"):
        raise RuntimeError("Dual ANE hybrid affine qmm native kernel is unavailable")
    return _ext.qwen35_ane_dual_affine_qmm_t(
        x,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model0,
        ane_model1,
        bits,
        variant,
        group_size,
        profile_category,
    )


def qwen35_ane_dual_q4_swiglu_t(
    x: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model0,
    ane_model1,
    variant: int = 8,
    group_size: int = 128,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_dual_q4_swiglu_t"):
        raise RuntimeError("Dual ANE hybrid q4 SwiGLU native kernel is unavailable")
    return _ext.qwen35_ane_dual_q4_swiglu_t(
        x,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model0,
        ane_model1,
        variant,
        group_size,
    )


def qwen35_ane_dual_affine_swiglu_t(
    x: mx.array,
    gpu_weight: mx.array,
    gpu_scales: mx.array,
    gpu_biases: mx.array,
    ane_model0,
    ane_model1,
    bits: int,
    variant: int = 8,
    group_size: int = 128,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_dual_affine_swiglu_t"):
        raise RuntimeError(
            "Dual ANE hybrid affine SwiGLU native kernel is unavailable"
        )
    return _ext.qwen35_ane_dual_affine_swiglu_t(
        x,
        gpu_weight,
        gpu_scales,
        gpu_biases,
        ane_model0,
        ane_model1,
        bits,
        variant,
        group_size,
    )


def qwen35_ane_q4_swiglu_down_t(
    x: mx.array,
    gpu_gate_up_weight: mx.array,
    gpu_gate_up_scales: mx.array,
    gpu_gate_up_biases: mx.array,
    gpu_down_weight: mx.array,
    gpu_down_scales: mx.array,
    gpu_down_biases: mx.array,
    ane_model,
    variant: int = 8,
    group_size: int = 128,
) -> mx.array:
    if not qwen35_ane_swiglu_down_available():
        raise RuntimeError("ANE hybrid SwiGLU/down native kernel is unavailable")
    return _ext.qwen35_ane_q4_swiglu_down_t(
        x,
        gpu_gate_up_weight,
        gpu_gate_up_scales,
        gpu_gate_up_biases,
        gpu_down_weight,
        gpu_down_scales,
        gpu_down_biases,
        ane_model,
        variant,
        group_size,
    )


def qwen35_ane_dual_q4_swiglu_down_t(
    x: mx.array,
    gpu_gate_up_weight: mx.array,
    gpu_gate_up_scales: mx.array,
    gpu_gate_up_biases: mx.array,
    gpu_down_weight: mx.array,
    gpu_down_scales: mx.array,
    gpu_down_biases: mx.array,
    ane_model0,
    ane_model1,
    variant: int = 8,
    group_size: int = 128,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_ane_dual_q4_swiglu_down_t"):
        raise RuntimeError("Dual-ANE hybrid SwiGLU/down native kernel is unavailable")
    return _ext.qwen35_ane_dual_q4_swiglu_down_t(
        x,
        gpu_gate_up_weight,
        gpu_gate_up_scales,
        gpu_gate_up_biases,
        gpu_down_weight,
        gpu_down_scales,
        gpu_down_biases,
        ane_model0,
        ane_model1,
        variant,
        group_size,
    )


def qwen35_ane_dual_cpu_fp16_q4_swiglu_down_t(
    x: mx.array,
    cpu_gate_up_weight: mx.array,
    cpu_down_weight: mx.array,
    gpu_gate_up_weight: mx.array,
    gpu_gate_up_scales: mx.array,
    gpu_gate_up_biases: mx.array,
    gpu_down_weight: mx.array,
    gpu_down_scales: mx.array,
    gpu_down_biases: mx.array,
    ane_model0,
    ane_model1,
    variant: int = 8,
    group_size: int = 128,
    cpu_threads: int = 0,
    cpu_shared_resource: bool = False,
) -> mx.array:
    if _ext is None or not hasattr(
        _ext, "qwen35_ane_dual_cpu_fp16_q4_swiglu_down_t"
    ):
        raise RuntimeError(
            "Dual-ANE/CPU fused SwiGLU/down native kernel is unavailable"
        )
    return _ext.qwen35_ane_dual_cpu_fp16_q4_swiglu_down_t(
        x,
        cpu_gate_up_weight,
        cpu_down_weight,
        gpu_gate_up_weight,
        gpu_gate_up_scales,
        gpu_gate_up_biases,
        gpu_down_weight,
        gpu_down_scales,
        gpu_down_biases,
        ane_model0,
        ane_model1,
        variant,
        group_size,
        cpu_threads,
        cpu_shared_resource,
    )


# Extensions built before the NAX split reject the use_nax/nax_variant kwargs,
# so only pass them when the rebuilt binding is present.
_EXT_HAS_NAX = _ext is not None and hasattr(_ext, "is_nax_available")

# Extensions built before the chunked-dispatch fix (issue #2225) reject the
# dispatch_budget kwarg, so only forward it when the rebuilt binding is
# present; those older builds keep the single-dispatch behavior.
_EXT_HAS_FA256_DISPATCH_BUDGET = _ext is not None and hasattr(
    _ext, "FA256_HAS_DISPATCH_BUDGET"
)

# Extensions built before the Bonsai group_size=128 support reject the
# group_size kwarg on the qmm bindings, so only forward it when the rebuilt
# binding is present.  The q2 binding ships in the same rebuild, so its
# presence marks the new ABI.  Older builds only carry gs=64 kernels; callers
# must keep gs!=64 layers on stock mlx (see qmm_supports_group_size).
_EXT_HAS_QMM_GROUP_SIZE = _ext is not None and hasattr(_ext, "qwen35_q2_affine_qmm_t")


def _qmm_group_size_kwargs(group_size: int) -> dict:
    if _EXT_HAS_QMM_GROUP_SIZE:
        return {"group_size": group_size}
    return {}


def qmm_supports_group_size(group_size: int) -> bool:
    """True if the compiled extension can run qmm at this group size.

    gs=64 always works (the pre-group_size builds are gs=64-only).  Other
    group sizes require the rebuilt binding; routing a gs=128 layer through
    an old build would silently run the gs=64 kernel on gs=128 data.
    """
    return group_size == 64 or _EXT_HAS_QMM_GROUP_SIZE


_NAX_ARCH_RE = re.compile(r"applegpu_g(\d+)([a-z])")
_NAX_KERNEL_NEEDLE = b"affine_qmm_t_nax"

_nax_available_cache: bool | None = None
_stock_nax_cache: bool | None = None
_qmm_nax_cache: bool | None = None

# Bundled NAX tiles (must match qwen_q_affine_nax_variant in qwen35_prefill.cpp):
#   0: 64x64x64 wm2 wn2 (stock MLX tile, default)   1: bm 32   2: bm 128
#   3: bn 128   4: bk 32   5: wm4 wn1
NAX_QMM_VARIANTS = range(6)
QMM_NAX_VARIANT = 0


def _nax_available_fallback(
    version: str | None = None, arch: str | None = None
) -> bool:
    """Python mirror of mlx metal::is_nax_available() for pre-NAX extensions."""
    if version is None or arch is None:
        if not mx.metal.is_available():
            return False
        if version is None:
            version = platform.mac_ver()[0]
        if arch is None:
            arch = str(mx.device_info().get("architecture", ""))
    try:
        release = tuple(int(part) for part in version.split(".")[:2])
    except ValueError:
        return False
    if len(release) < 2 or release < (26, 2):
        return False
    match = _NAX_ARCH_RE.fullmatch(arch)
    if match is None:
        return False
    gen = int(match.group(1))
    suffix = match.group(2)
    return gen >= (18 if suffix == "p" else 17)


def _stock_mlx_has_nax(lib_path: Path | None = None) -> bool:
    """True when the installed mlx wheel ships the NAX kernels.

    Wheels built for macOS < 26.2 are compiled with MLX_METAL_NO_NAX (e.g.
    the macosx_15 wheel in the sequoia app bundle): on those installs stock
    stays on the classic kernels even on M5 hardware, so route-to-stock
    decisions must not fire. Unreadable/absent metallibs (JIT builds) fall
    back to True, which reduces to the hardware-only gate.
    """
    global _stock_nax_cache
    if lib_path is None and _stock_nax_cache is not None:
        return _stock_nax_cache
    path = lib_path
    if path is None:
        core_file = getattr(mx, "__file__", None)
        if core_file is None:
            return True
        path = Path(core_file).parent / "lib" / "mlx.metallib"
    found = True
    try:
        if path.is_file():
            overlap = len(_NAX_KERNEL_NEEDLE) - 1
            tail = b""
            found = False
            with open(path, "rb") as f:
                while chunk := f.read(1 << 23):
                    if _NAX_KERNEL_NEEDLE in tail + chunk:
                        found = True
                        break
                    tail = chunk[-overlap:]
    except OSError:
        found = True
    if lib_path is None:
        _stock_nax_cache = found
    return found


def is_nax_available() -> bool:
    """True when stock MLX will dispatch to the M5 tensor-unit (NAX) kernels.

    Requires both NAX hardware (mirroring mlx metal::is_nax_available) and an
    mlx install whose metallib actually ships the NAX kernels.
    """
    global _nax_available_cache
    if _nax_available_cache is None:
        if _EXT_HAS_NAX:
            hardware = bool(_ext.is_nax_available())
        else:
            hardware = _nax_available_fallback()
        _nax_available_cache = hardware and _stock_mlx_has_nax()
    return _nax_available_cache


def nax_qmm_kernels_built() -> bool:
    if not _EXT_HAS_NAX:
        return False
    return bool(_ext.nax_qmm_kernels_built())


def _qmm_use_nax() -> bool:
    global _qmm_nax_cache
    if _qmm_nax_cache is None:
        _qmm_nax_cache = (
            _EXT_HAS_NAX
            and bool(_ext.is_nax_available())
            and bool(_ext.nax_qmm_kernels_built())
        )
        if _qmm_nax_cache:
            logger.info(
                "Qwen qmm NAX dispatch enabled (nax_variant=%d)",
                QMM_NAX_VARIANT,
            )
    return _qmm_nax_cache


def _qmm_nax_kwargs(bits: int) -> dict[str, object]:
    # The NAX metal kernel only defines bits 4/5/6/8 (qwen35_qmm_nax.metal).
    # Routing a q2 call through NAX anyway hits a kernel-lookup failure that
    # latches `nax_qmm_runtime_ok=false` process-wide, permanently demoting
    # every q4/q5/q6/q8 layer to the classic kernel for the rest of the
    # process. Never request NAX for bits==2.
    if bits == 2 or not _EXT_HAS_NAX:
        return {}
    return {"use_nax": _qmm_use_nax(), "nax_variant": QMM_NAX_VARIANT}


def is_native_available() -> bool:
    return _ext is not None


def import_error() -> Exception | None:
    return _IMPORT_ERROR


def _has_weighted_sum() -> bool:
    return hasattr(_ext, "qwen35_moe_weighted_sum") or hasattr(
        mx.fast, "qwen35_moe_weighted_sum"
    )


def has_symbol(name: str) -> bool:
    if name == "qwen35_moe_weighted_sum":
        return _has_weighted_sum()
    return hasattr(_ext, name) or hasattr(mx.fast, name)


def native_symbols() -> tuple[str, ...]:
    symbols: list[str] = []
    if _ext is not None:
        symbols.extend(name for name in NATIVE_SYMBOLS if hasattr(_ext, name))
    if _has_weighted_sum() and "qwen35_moe_weighted_sum" not in symbols:
        symbols.append("qwen35_moe_weighted_sum")
    return tuple(symbols)


def missing_symbols(required: tuple[str, ...]) -> list[str]:
    return [name for name in required if not has_symbol(name)]


def _native_stream_kwargs(stream) -> dict[str, object]:
    """Accept the same stream shorthand that mlx.fast kernels accept."""
    if isinstance(stream, mx.DeviceType):
        stream = None
    return {"stream": stream}


def fa256_supports_dispatch_budget() -> bool:
    return _EXT_HAS_FA256_DISPATCH_BUDGET


def qwen35_fa256_attention(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    scale: float,
    causal: bool = True,
    q_block: int = 32,
    k_block: int = 8,
    dispatch_budget: int = 0,
    *,
    stream=None,
) -> mx.array:
    if _ext is not None and hasattr(_ext, "qwen35_fa256_attention"):
        budget_kwargs: dict[str, int] = {}
        if _EXT_HAS_FA256_DISPATCH_BUDGET:
            budget_kwargs["dispatch_budget"] = int(dispatch_budget)
        return _ext.qwen35_fa256_attention(
            q,
            k,
            v,
            scale,
            causal=causal,
            q_block=q_block,
            k_block=k_block,
            **budget_kwargs,
            **_native_stream_kwargs(stream),
        )
    raise RuntimeError("qwen35_fa256_attention native kernel is unavailable")


def qwen35_q2_affine_qmm_t(
    x: mx.array,
    weight: mx.array,
    scales: mx.array,
    biases: mx.array,
    variant: int = 8,
    group_size: int = 64,
    *,
    stream=None,
) -> mx.array:
    if _ext is not None and hasattr(_ext, "qwen35_q2_affine_qmm_t"):
        return _ext.qwen35_q2_affine_qmm_t(
            x,
            weight,
            scales,
            biases,
            variant,
            **_qmm_nax_kwargs(2),
            **_qmm_group_size_kwargs(group_size),
            **_native_stream_kwargs(stream),
        )
    raise RuntimeError("qwen35_q2_affine_qmm_t native kernel is unavailable")


def qwen35_q4_affine_qmm_t(
    x: mx.array,
    weight: mx.array,
    scales: mx.array,
    biases: mx.array,
    variant: int = 8,
    group_size: int = 64,
    *,
    stream=None,
) -> mx.array:
    if _ext is not None and hasattr(_ext, "qwen35_q4_affine_qmm_t"):
        return _ext.qwen35_q4_affine_qmm_t(
            x,
            weight,
            scales,
            biases,
            variant,
            **_qmm_nax_kwargs(4),
            **_qmm_group_size_kwargs(group_size),
            **_native_stream_kwargs(stream),
        )
    raise RuntimeError("qwen35_q4_affine_qmm_t native kernel is unavailable")


def qwen35_q5_affine_qmm_t(
    x: mx.array,
    weight: mx.array,
    scales: mx.array,
    biases: mx.array,
    variant: int = 8,
    group_size: int = 64,
    *,
    stream=None,
) -> mx.array:
    if _ext is not None and hasattr(_ext, "qwen35_q5_affine_qmm_t"):
        return _ext.qwen35_q5_affine_qmm_t(
            x,
            weight,
            scales,
            biases,
            variant,
            **_qmm_nax_kwargs(5),
            **_qmm_group_size_kwargs(group_size),
            **_native_stream_kwargs(stream),
        )
    raise RuntimeError("qwen35_q5_affine_qmm_t native kernel is unavailable")


def qwen35_q6_affine_qmm_t(
    x: mx.array,
    weight: mx.array,
    scales: mx.array,
    biases: mx.array,
    variant: int = 8,
    group_size: int = 64,
    *,
    stream=None,
) -> mx.array:
    if _ext is not None and hasattr(_ext, "qwen35_q6_affine_qmm_t"):
        return _ext.qwen35_q6_affine_qmm_t(
            x,
            weight,
            scales,
            biases,
            variant,
            **_qmm_nax_kwargs(6),
            **_qmm_group_size_kwargs(group_size),
            **_native_stream_kwargs(stream),
        )
    raise RuntimeError("qwen35_q6_affine_qmm_t native kernel is unavailable")


def qwen35_q8_affine_qmm_t(
    x: mx.array,
    weight: mx.array,
    scales: mx.array,
    biases: mx.array,
    variant: int = 8,
    group_size: int = 64,
    *,
    stream=None,
) -> mx.array:
    if _ext is not None and hasattr(_ext, "qwen35_q8_affine_qmm_t"):
        return _ext.qwen35_q8_affine_qmm_t(
            x,
            weight,
            scales,
            biases,
            variant,
            **_qmm_nax_kwargs(8),
            **_qmm_group_size_kwargs(group_size),
            **_native_stream_kwargs(stream),
        )
    raise RuntimeError("qwen35_q8_affine_qmm_t native kernel is unavailable")


def qwen35_moe_weighted_sum(
    x_sorted: mx.array,
    inv_order: mx.array,
    scores: mx.array,
    *,
    stream=None,
) -> mx.array:
    if _ext is not None and hasattr(_ext, "qwen35_moe_weighted_sum"):
        return _ext.qwen35_moe_weighted_sum(
            x_sorted,
            inv_order,
            scores,
            **_native_stream_kwargs(stream),
        )
    if hasattr(mx.fast, "qwen35_moe_weighted_sum"):
        return mx.fast.qwen35_moe_weighted_sum(
            x_sorted,
            inv_order,
            scores,
            stream=stream or mx.gpu,
        )
    raise RuntimeError("qwen35_moe_weighted_sum native kernel is unavailable")


# --- oQ mixed-bit QxA8 (Q4/Q5/Q8, GS64, affine) on the M5 tensor units ------


def oq_a8_available() -> bool:
    """True when the INT8 NAX GEMM can actually run on this machine.

    Distinct from ``has_symbol``: the binding can exist in a build whose NAX
    metallib was skipped (SDK < 26.2) or on hardware without tensor units.
    """
    if _ext is None or not hasattr(_ext, "oq_a8_kernels_available"):
        return False
    try:
        return bool(_ext.oq_a8_kernels_available())
    except Exception:
        return False


def qwen35_oq_a8_quantize(
    x: mx.array,
    act_mode: int = 0,
    *,
    stream=None,
) -> tuple[mx.array, mx.array, mx.array]:
    """Stage A: BF16/FP16 activations -> (Qa int8, Sa float32, Ra int16).

    Run this once per shared activation and feed the result to every
    projection that consumes it, whatever their bit widths.
    """
    if _ext is None or not hasattr(_ext, "qwen35_oq_a8_quantize"):
        raise RuntimeError("qwen35_oq_a8_quantize native kernel is unavailable")
    qa, sa, ra = _ext.qwen35_oq_a8_quantize(
        x,
        act_mode,
        **_native_stream_kwargs(stream),
    )
    return qa, sa, ra


def qwen35_oq_a8_qmm_t(
    qa: mx.array,
    sa: mx.array,
    ra: mx.array,
    weight: mx.array,
    scales: mx.array,
    biases: mx.array,
    bits: int,
    act_mode: int = 0,
    variant: int = 800,
    *,
    packed: bool = False,
    stream=None,
) -> mx.array:
    if _ext is None or not hasattr(_ext, "qwen35_oq_a8_qmm_t"):
        raise RuntimeError("qwen35_oq_a8_qmm_t native kernel is unavailable")
    return _ext.qwen35_oq_a8_qmm_t(
        qa,
        sa,
        ra,
        weight,
        scales,
        biases,
        bits,
        act_mode,
        variant,
        packed=packed,
        **_native_stream_kwargs(stream),
    )


def qwen35_oq_a8_linear(
    x: mx.array,
    weight: mx.array,
    scales: mx.array,
    biases: mx.array,
    bits: int,
    act_mode: int = 0,
    variant: int = 800,
    *,
    stream=None,
) -> mx.array:
    """Convenience Stage-A + GEMM for a projection with no shared activation."""
    if bits == 8:
        qa, sa, ra = qwen35_oq_a8_stage_a_natural(x, act_mode, stream=stream)
    else:
        qa, sa, ra = qwen35_oq_a8_stage_a_v8(x, act_mode, stream=stream)
        scales, biases = mx.contiguous(scales.T), mx.contiguous(biases.T)
    return qwen35_oq_a8_qmm_t(
        qa,
        sa,
        ra,
        weight,
        scales,
        biases,
        bits,
        act_mode,
        variant,
        stream=stream,
    )


def qwen35_oq_a8_stage_a_v8(
    x: mx.array,
    act_mode: int = 0,
    *,
    stream=None,
) -> tuple[mx.array, mx.array, mx.array]:
    """Reorder activations for the native GEMM and transpose group metadata.

    Within each GS64 group, slot ``16c + 4t + j`` holds
    ``k = 16c + 8*(t>>1) + 2j + (t&1)``. This permutation preserves the
    group sum and requires a temporary contiguous INT8 activation copy.
    """
    qa, sa, ra = qwen35_oq_a8_quantize(x, act_mode, stream=stream)
    shape = qa.shape
    k = shape[-1]
    m = qa.size // k
    # Reshaped back to the input's own rank, not to [M, K]: the op derives the
    # output shape from Qa, so flattening a [B, S, K] activation here would
    # hand the caller a [B*S, N] result. With B == 1 that broadcasts against
    # the residual and hides; with B > 1 it is silently wrong.
    qa = mx.contiguous(
        qa.reshape(m, k // 64, 4, 2, 4, 2).transpose(0, 1, 2, 3, 5, 4).reshape(shape)
    )
    # Flattened to [M, groups] before transposing, not transposed in place:
    # mx.transpose reverses *every* axis, so a [B, S, groups] Ra would come
    # back as [groups, S, B] -- which is the layout the kernel wants only when
    # B == 1, and silently interleaves the sequences when it is not.
    ra = mx.contiguous(ra.reshape(m, -1).T)
    if act_mode != 0:
        sa = mx.contiguous(sa.reshape(m, -1).T)
    return qa, sa, ra


def qwen35_oq_a8_stage_a_natural(
    x: mx.array,
    act_mode: int = 0,
    *,
    stream=None,
) -> tuple[mx.array, mx.array, mx.array]:
    """Stage A for the Q8 kernel: activations stay in checkpoint K order.

    Q4/Q5 use :func:`qwen35_oq_a8_stage_a_v8`. Only the group metadata is
    transposed here, so there is no INT8 activation copy.
    """
    qa, sa, ra = qwen35_oq_a8_quantize(x, act_mode, stream=stream)
    ra = mx.contiguous(ra.reshape(qa.size // qa.shape[-1], -1).T)
    if act_mode != 0:
        sa = mx.contiguous(sa.reshape(qa.size // qa.shape[-1], -1).T)
    return qa, sa, ra


def qwen35_oq_a8_decode_weights(
    weight: mx.array,
    bits: int,
    group_count: int,
    *,
    stream=None,
) -> mx.array:
    """Unpack Q4/Q5/Q8 codes to INT8 (Q8 centered to q - 128).

    Test helper only: the production path never materializes unpacked weights
    in device memory.
    """
    if _ext is None or not hasattr(_ext, "qwen35_oq_a8_decode_weights"):
        raise RuntimeError(
            "qwen35_oq_a8_decode_weights native kernel is unavailable"
        )
    return _ext.qwen35_oq_a8_decode_weights(
        weight,
        bits,
        group_count,
        **_native_stream_kwargs(stream),
    )


def __getattr__(name: str) -> Any:
    if _ext is not None and hasattr(_ext, name):
        return getattr(_ext, name)
    return getattr(mx.fast, name)


def __dir__() -> list[str]:
    names = set(globals())
    names.update(NATIVE_SYMBOLS)
    names.update(dir(mx.fast))
    if _ext is not None:
        names.update(dir(_ext))
    return sorted(names)
