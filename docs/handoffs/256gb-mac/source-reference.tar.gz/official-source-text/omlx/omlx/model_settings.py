"""Per-model settings management for oMLX.

This module provides dataclasses and a manager for storing and retrieving
per-model configuration settings, including sampling parameters, pinned/default
flags, and metadata.
"""

import copy
import hashlib
import json
import logging
import os
import tempfile
import threading
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from .model_profiles import (
    MODEL_SPECIFIC_PROFILE_FIELDS,
    UNIVERSAL_FIELDS_SET,
    filter_profile_fields,
    filter_universal_fields,
    normalize_turboquant_kv_bits,
    slugify_profile_api_name,
    validate_profile_name,
    utcnow,
)

logger = logging.getLogger(__name__)

# Current settings file format version
SETTINGS_VERSION = 1

# The Lightning MTP runtime clamps deeper requests to this global ceiling.
# Keep API validation and runtime normalization on the same contract.
MAX_LIGHTNING_MTP_DRAFT_TOKENS = 8

# These families keep the MTP head resident while backbone experts stream.
# qwen4_exp (Qwen3.8-Flash-Next) drafts from its embedded native head, whose
# experts the generic SwitchGLU adapter leaves resident (see
# apply_moe_expert_offload's mtp_resident).
MOE_OFFLOAD_MTP_MODEL_TYPES = ("deepseek_v41", "glm5_next", "qwen4_exp")


def validate_moe_expert_offload(settings: dict, model_type: str | None = None) -> None:
    fraction = settings.get("moe_expert_offload_resident_fraction", 0.25)
    if (
        isinstance(fraction, bool)
        or not isinstance(fraction, (int, float))
        or not 0 < fraction <= 1
    ):
        raise ValueError("moe_expert_offload_resident_fraction must be in (0, 1]")
    if not settings.get("moe_expert_offload_enabled"):
        return
    # VLM MTP and DFlash have no offload-aware draft path at all.
    if any(settings.get(key) for key in ("vlm_mtp_enabled", "dflash_enabled")):
        raise ValueError(
            "MoE expert offload cannot be combined with Lightning MTP, "
            "VLM MTP, or DFlash; disable speculative decoding first."
        )
    # Settings can load before the checkpoint family is known.
    if settings.get("mtp_enabled") and model_type is not None:
        family = model_type.replace("-", "_").lower()
        if family not in MOE_OFFLOAD_MTP_MODEL_TYPES:
            raise ValueError(
                "MoE expert offload cannot be combined with Lightning MTP, "
                "VLM MTP, or DFlash; disable speculative decoding first."
            )


def ane_prefill_backend(model_type: str | None) -> str | None:
    """Select the ANE implementation from model metadata."""
    model_type = (model_type or "").lower().replace("-", "_")
    if model_type == "k2_horizon":
        return "k2"
    if model_type.startswith(("qwen3_5", "qwen3_6", "qwen3_8")):
        return "qwen"
    return None


def ane_prefill_fraction(value: float | None, model_type: str | None) -> float:
    """Resolve an unset split without changing an explicitly saved fraction."""
    if value is not None:
        return value
    return 1 / 3 if ane_prefill_backend(model_type) == "k2" else 0.53


def validate_ane_prefill(settings: dict, model_type: str | None) -> None:
    """Validate common controls against the selected backend's limits."""
    backend = ane_prefill_backend(model_type)
    if settings.get("qwen35_ane_prefill_enabled") and backend is None:
        raise ValueError("ANE prefill is unavailable for this model.")
    width = settings.get("qwen35_ane_prefill_sequence_length", 2048)
    minimum, alignment = (32, 32) if backend == "k2" else (1024, 64)
    if type(width) is not int or width < minimum or width % alignment:
        raise ValueError(
            f"ANE prompt block must be a multiple of {alignment} and at least {minimum}."
        )
    fraction = ane_prefill_fraction(
        settings.get("qwen35_ane_prefill_fraction"), model_type
    )
    valid_fraction = 0 < fraction <= 1 if backend == "k2" else 0.05 <= fraction <= 0.90
    if not valid_fraction:
        bounds = "in (0, 1]" if backend == "k2" else "between 0.05 and 0.90"
        raise ValueError(f"MLP ANE fraction must be {bounds}.")
    shared = settings.get("qwen35_ane_prefill_shared_fraction", 1.0)
    if shared is None or not 0 <= shared <= 1:
        raise ValueError("ANE shared fraction must be in [0, 1].")
    if backend == "k2" and settings.get("qwen35_ane_prefill_enabled"):
        for name in (
            "dflash_enabled",
            "specprefill_enabled",
            "mtp_enabled",
            "vlm_mtp_enabled",
        ):
            if settings.get(name, False):
                raise ValueError(f"K2 ANE prefill cannot be combined with {name}.")


def vlm_mtp_processor_conflicts(data: dict) -> list:
    """Names of settings that need per-request logits processors and
    therefore cannot combine with ``vlm_mtp_enabled``.

    The vlm_mtp decode path bypasses mlx-lm BatchGenerator, where logits
    processors are applied; with any of these set, every request would fall
    back to BatchGenerator and the toggle would never engage (#2399).
    Neutral values (repetition 1.0, presence 0.0) build no processor and do
    not conflict.

    ``thinking_budget_enabled`` is intentionally absent: the vlm_mtp path
    applies ``ThinkingBudgetProcessor`` at verify time via
    ``MTPProcessingSampler`` (see omlx/speculative/processing_sampler.py),
    so a thinking-budget default no longer forces the BatchGenerator
    fallback.
    """
    conflicts = []
    rep = data.get("repetition_penalty")
    if rep is not None and rep != 1.0:
        conflicts.append("repetition_penalty")
    pres = data.get("presence_penalty")
    if pres is not None and pres != 0.0:
        conflicts.append("presence_penalty")
    if data.get("guided_grammar_enabled"):
        conflicts.append("guided_grammar_enabled")
    return conflicts


def resolve_vlm_mtp_conflicts(data: dict) -> tuple:
    """Clear ``vlm_mtp_enabled`` from ``data`` when it conflicts with
    processor-backed settings; returns ``(data, conflict_names)``.

    The sampling / grammar side wins because those settings shape output
    content while vlm_mtp only affects speed. Used for settings dicts that
    predate the exclusivity rule (persisted files, profile merges) so
    ``ModelSettings.__post_init__`` does not reject the whole blob.
    """
    if not data.get("vlm_mtp_enabled"):
        return data, []
    conflicts = vlm_mtp_processor_conflicts(data)
    if not conflicts:
        return data, []
    resolved = dict(data)
    resolved["vlm_mtp_enabled"] = False
    return resolved, conflicts


def resolve_qwen35_prefill_conflicts(data: dict) -> tuple:
    """Clear ``qwen35_oq_a8_enabled`` when ANE prefill is also on.

    Both wrap ``Qwen3_5MLP.__call__`` and claim the same projections, so
    enabling both leaves whichever patched last in charge -- with the other
    silently inert. ANE prefill wins because it is the older setting and the
    one a saved profile is more likely to have been tuned around. Used for
    dicts that predate the exclusivity rule so ``__post_init__`` does not
    reject the whole blob.
    """
    if not (data.get("qwen35_oq_a8_enabled") and data.get("qwen35_ane_prefill_enabled")):
        return data, []
    resolved = dict(data)
    resolved["qwen35_oq_a8_enabled"] = False
    return resolved, ["qwen35_ane_prefill_enabled"]


PROFILES_VERSION = 1
TEMPLATES_VERSION = 1


@dataclass
class ModelSettings:
    """Per-model configuration settings.

    Attributes:
        max_context_window: Maximum prompt token count before rejection (None = use global default).
        max_tokens: Maximum number of tokens to generate (None = use global default).
        temperature: Sampling temperature (None = use global default).
        top_p: Nucleus sampling probability (None = use global default).
        top_k: Top-k sampling parameter (None = use global default).
        min_p: Minimum probability threshold (None = use global default).
        repetition_penalty: Repetition penalty (None = use default 1.0, i.e. disabled).
        presence_penalty: Presence penalty (None = use global default).
        force_sampling: Force sampling even with temperature=0.
        max_tool_result_tokens: Maximum tokens in tool result (None = use global default).
        chat_template_kwargs: Extra chat template keyword arguments.
        forced_ct_kwargs: Keys in chat_template_kwargs that cannot be overridden.
        ttl_seconds: Auto-unload after idle seconds (None = no TTL).
        model_type_override: "llm", "vlm", "embedding", "reranker", "decision",
            or None (auto-detect).
        model_alias: API-visible alternative to the directory name.
        index_cache_freq: IndexCache: every Nth layer keeps indexer (DeepSeek DSA
            only; GLM-5.2 uses its native checkpoint schedule).
        enable_thinking: Explicit toggle for thinking/reasoning mode (None = auto).
        thinking_budget_enabled: Whether a thinking token budget is active.
        thinking_budget_tokens: Max tokens for thinking/reasoning.
        reasoning_parser: xgrammar builtin name: "qwen", "harmony", "llama", etc.
        guided_grammar_enabled: Whether a default guided grammar is active.
        guided_grammar: Default EBNF grammar for constrained decoding.
        turboquant_kv_enabled: Enable TurboQuant KV cache compression.
        turboquant_kv_bits: TurboQuant bit depth (2/2.5/3/3.5/4/6/8).
        turboquant_skip_last: Skip last KVCache layer to prevent corruption.
        qwen35_ane_prefill_enabled: Enable ANE/GPU prompt processing for a
            supported model. Model metadata selects the implementation.
        qwen35_ane_prefill_sequence_length: Compiled ANE prompt block size.
        qwen35_ane_prefill_tail_padding_min_tokens: Smallest residual tokenwise
            projection block padded to the compiled ANE shape (zero disables).
        qwen35_ane_prefill_fraction: Fraction of eligible MLP outputs assigned
            across the ANE instances (None = backend default).
        qwen35_ane_prefill_shared_fraction: Shared-expert MLP share where supported.
        qwen35_ane_prefill_fused_down: Fuse SwiGLU and partial down projection
            into each dual-ANE/CPU hidden-channel branch.
        qwen35_ane_prefill_max_layers: Maximum eligible MLP layers accelerated.
        qwen35_ane_prefill_dual_ane: Pin a procedure bank to each physical ANE.
        qwen35_ane_prefill_gdn: Also accelerate eligible GDN input projections.
        qwen35_ane_prefill_gdn_fraction: Fraction of eligible GDN projection
            outputs assigned across the ANE instances.
        qwen35_ane_prefill_gdn_max_layers: Maximum eligible GDN layers accelerated.
        qwen35_ane_prefill_cpu_enabled: Share eligible q4 MLP gate/up outputs
            with the CPU. Requires a separately preprocessed FP16 checkpoint.
        qwen35_ane_prefill_cpu_fraction: Fraction of each eligible gate/up
            projection assigned to the CPU.
        qwen35_ane_prefill_cpu_down_fraction: Fraction of each eligible MLP
            down projection assigned to the CPU.
        qwen35_ane_prefill_cpu_gdn_fraction: Fraction of the eligible GDN
            z+qkv projection outputs assigned to the CPU after the ANE prefix.
        qwen35_ane_prefill_cpu_threads: Requested Accelerate worker count
            (zero lets Accelerate choose).
        qwen35_ane_prefill_cpu_shared_resource: Use dispatch_apply's
            shared-resource scheduling attributes for manually sharded CPU work.
        qwen35_oq_a8_enabled: Route eligible Qwen3.5/3.6/3.8 prefill matmuls
            through the oQ mixed-bit INT8-activation (QxA8) tensor kernels.
            Prefill only, and only a speed-up on hardware with native INT8
            tensor operations -- M5-series and newer. On anything older the
            kernels do not load and the setting is refused. Decode is
            unaffected. Changes numerics: activations are quantized to INT8.
            Also covers the routed-expert gate/up of Qwen3.8-Flash-Next
            (affine Q4 / GS64 experts); the MTP draft layer and the down
            projection stay on the A16 path.
            Mutually exclusive with qwen35_ane_prefill_enabled.
        qwen35_oq_a8_min_tokens: Shortest sequence routed to the kernels.
        moe_expert_offload_enabled: Stream MoE expert weights from the
            checkpoint on demand instead of keeping them all resident (fits
            models larger than memory; costs decode speed). Requires reload.
        moe_expert_offload_resident_fraction: Fraction of each layer's experts
            kept resident (0 < f <= 1, default 0.25).
        specprefill_enabled: Enable SpecPrefill (experimental sparse prefill for MoE).
        specprefill_draft_model: Path to draft model for SpecPrefill.
        specprefill_keep_pct: Keep rate for SpecPrefill (0.1–0.5).
        specprefill_threshold: Min tokens to trigger SpecPrefill.
        dflash_enabled: Enable DFlash speculative decoding. Qwen3.5-family VLM
            targets draft inside the batched engine (Lightning MTP verify path
            with greedy or sampled acceptance, continuous batching); other
            targets use the single-stream DFlash engine, which alone honours
            the max_ctx, cache, window, sink and verify_mode settings below.
        dflash_draft_model: Path/repo for DFlash draft checkpoint.
        dflash_draft_quant_enabled: Enable draft model quantization.
        dflash_draft_quant_weight_bits: Quantization weight bits (2, 4, 8).
        dflash_draft_quant_activation_bits: Quantization activation bits (16, 32).
        dflash_draft_quant_group_size: Quantization group size (32, 64, 128).
        dflash_max_ctx: Token threshold to fall back to BatchedEngine (None = unlimited).
        dflash_in_memory_cache: Enable DFlash L1 (RAM) prefix cache.
        dflash_in_memory_cache_max_entries: L1 cache max entries (default 4, matches dflash balanced profile).
        dflash_in_memory_cache_max_bytes: L1 cache byte budget.
        dflash_ssd_cache: Enable DFlash L2 (SSD) prefix cache spill (uses omlx SSD cache dir).
        dflash_ssd_cache_max_bytes: L2 (SSD) disk budget; dflash evicts oldest entries when exceeded.
        dflash_draft_window_size: Draft model sliding-attention window
            (None = use the draft checkpoint's sliding_window when present).
            Helps stabilise acceptance rate on long-context prompts.
        dflash_draft_sink_size: Attention-sink tokens always kept regardless of window
            (default 0, disabling sink tokens).
        dflash_block_size: Draft/verify tokens per cycle (None = checkpoint default).
        dflash_verify_mode: Verifier algorithm — "dflash", "adaptive", "ddtree", or "off"
            (None = dflash default "adaptive"). "adaptive" can shrink block size when
            acceptance drops.
        mtp_enabled: Enable native multi-token prediction (mlx-lm PR 990 / PR 15 monkey-patch).
            When True, BatchGenerator uses MTP draft+verify for singleton decode and
            for multi-row decode batches whose cache positions are aligned. Unaligned
            continuous batches fall back to standard decoding automatically. Compatible
            model_types: qwen3_5*, qwen3_6*, deepseek_v4*. Mutually exclusive with
            dflash_enabled.
        vlm_mtp_enabled: Enable VLM MTP speculative decoding via an external assistant
            drafter (mlx-vlm 191d7c8+). Target = Gemma4 VLM body, drafter must be a
            "gemma4_assistant" model. Mutually exclusive with processor-backed
            settings (guided grammar, thinking budget, repetition/presence
            penalties); requests carrying such per-request parameters fall back
            to BatchGenerator so the constraints stay enforced (#2399).
        vlm_mtp_draft_model: Path/repo of the assistant drafter (e.g. "gemma-4-26B-A4B-it-assistant").
        vlm_mtp_draft_block_size: Tokens drafted per round (None = mlx-vlm default).
        is_pinned: Keep model loaded in memory.
        is_default: Use this model when no model is specified.
        display_name: Human-readable name for UI display.
        description: Optional description of the model.
        active_profile_name: Name of the currently-applied profile (None = no profile).
    """

    # Sampling parameters (None means use global default)
    max_context_window: Optional[int] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    repetition_penalty: Optional[float] = None
    min_p: Optional[float] = None
    presence_penalty: Optional[float] = None
    force_sampling: bool = False
    max_tool_result_tokens: Optional[int] = None
    chat_template_kwargs: Optional[Dict[str, Any]] = None
    forced_ct_kwargs: Optional[list[str]] = (
        None  # Keys that cannot be overridden by API requests
    )
    ttl_seconds: Optional[int] = None  # Auto-unload after idle seconds (None = no TTL)
    model_type_override: Optional[str] = (
        None  # "llm", "vlm", "embedding", "reranker", "decision", or None (auto)
    )
    model_alias: Optional[str] = (
        None  # API-visible name (alternative to directory name)
    )
    index_cache_freq: Optional[int] = (
        None  # IndexCache: every Nth layer keeps indexer (DeepSeek DSA only)
    )
    enable_thinking: Optional[bool] = (
        None  # Explicit toggle for thinking/reasoning mode (None = auto)
    )
    # Qwen4-Exp only: keep the large PLE N-gram table on SSD and gather rows
    # through mmap. The runtime may force this on when resident loading cannot
    # fit under the configured model-memory ceiling but mmap loading can.
    qwen4_ple_ssd_offload: bool = False
    deepseek_v41_engram_ssd_offload: bool = False
    # DeepSeek V4.1 CED: during prefill the decoder half only forwards the
    # last window-size tokens; decoder global KV is the encoder-final
    # projection already produced by the midpoint CSA2 layer.
    deepseek_v41_ced_prefill_enabled: bool = False
    preserve_thinking: Optional[bool] = (
        None  # Keep <think> blocks in historical turns (None = auto, True when template supports it)
    )
    cache_reasoning_output: Optional[bool] = (
        None  # Cache <think> output for the next turn (None = auto: when history keeps it)
    )
    thinking_budget_enabled: bool = False
    thinking_budget_tokens: Optional[int] = None
    reasoning_parser: Optional[str] = (
        None  # xgrammar builtin name: "qwen", "harmony", "llama", etc.
    )
    guided_grammar_enabled: bool = False
    guided_grammar: Optional[str] = None

    # TurboQuant KV cache (mlx-vlm backend)
    turboquant_kv_enabled: bool = False
    turboquant_kv_bits: float = 4  # 2, 2.5, 3, 3.5, 4, 6, 8
    turboquant_skip_last: bool = (
        True  # Skip last KVCache layer (prevents corruption on sensitive models)
    )

    # Shared ANE/GPU prefill controls retain the original Qwen setting names.
    # Backend-specific controls apply only to models that support them.
    # Off by default because the fixed-shape ANE models add load-time/runtime
    # cache memory and rely on undocumented AppleNeuralEngine interfaces.
    qwen35_ane_prefill_enabled: bool = False
    qwen35_ane_prefill_sequence_length: int = 2048
    qwen35_ane_prefill_tail_padding_min_tokens: int = 0
    qwen35_ane_prefill_fraction: Optional[float] = None  # Backend default
    qwen35_ane_prefill_shared_fraction: float = 1.0
    qwen35_ane_prefill_fused_down: bool = False
    qwen35_ane_prefill_max_layers: int = 64
    qwen35_ane_prefill_dual_ane: bool = True
    qwen35_ane_prefill_gdn: bool = True
    qwen35_ane_prefill_gdn_fraction: float = 0.50
    qwen35_ane_prefill_gdn_max_layers: int = 48
    qwen35_ane_prefill_cpu_enabled: bool = False
    qwen35_ane_prefill_cpu_fraction: float = 0.135
    qwen35_ane_prefill_cpu_down_fraction: float = 0.0
    qwen35_ane_prefill_cpu_gdn_fraction: float = 0.0
    qwen35_ane_prefill_cpu_threads: int = 8
    qwen35_ane_prefill_cpu_shared_resource: bool = True

    # oQ mixed-bit QxA8 prefill kernels for Qwen3.5/3.6/3.8 and Qwen3.8 Flash-Next.
    #
    # Off by default because it is an accuracy decision, not just a speed one:
    # activations are quantized to INT8 per row, which the W4/W5A16 path does
    # not do. On M5 the Q4 GEMM measures 42 TOP/s against 23 for the shipping
    # NAX path -- about 1.66x on an MLP block at 2048 tokens, and about 1.4x
    # on end-to-end prompt processing, which is the figure the UI quotes
    # because only part of prefill is routed.
    #
    # The kernel reads the checkpoint's own packed weight stream, so a routed
    # projection costs no extra weight memory and the module's arrays stay
    # readable by the decode path.
    qwen35_oq_a8_enabled: bool = False
    qwen35_oq_a8_min_tokens: int = 128

    # MoE expert offload (stream non-resident experts from the checkpoint)
    moe_expert_offload_enabled: bool = False
    moe_expert_offload_resident_fraction: float = 0.25  # 0 < fraction <= 1

    # SpecPrefill (experimental: attention-based sparse prefill for MoE models)
    specprefill_enabled: bool = False
    specprefill_draft_model: Optional[str] = (
        None  # Path to draft model (must share tokenizer)
    )
    specprefill_keep_pct: Optional[float] = None  # Keep rate (0.1-0.5, default 0.2)
    specprefill_threshold: Optional[int] = None  # Min tokens to trigger (default 8192)

    # DFlash (block diffusion speculative decoding)
    dflash_enabled: bool = False
    dflash_draft_model: Optional[str] = None  # Path/repo for DFlash draft checkpoint
    dflash_draft_quant_enabled: Optional[bool] = None
    dflash_draft_quant_weight_bits: Optional[int] = None  # 2, 4, 8
    dflash_draft_quant_activation_bits: Optional[int] = None  # 16, 32
    dflash_draft_quant_group_size: Optional[int] = None  # 32, 64, 128
    dflash_max_ctx: Optional[int] = (
        None  # None = unlimited; trigger BatchedEngine fallback when prompt_len >= this
    )
    # DFlash prefix cache (private to dflash; separate from omlx tiered cache because
    # snapshots include draft model GDN state and target hidden chunks omlx never tracks)
    dflash_in_memory_cache: bool = True
    dflash_in_memory_cache_max_entries: int = (
        4  # Matches dflash balanced profile default
    )
    dflash_in_memory_cache_max_bytes: int = (
        8 * 1024 * 1024 * 1024
    )  # 8 GiB (balanced profile default)
    dflash_ssd_cache: bool = (
        False  # Requires in-memory cache and an omlx paged SSD cache dir
    )
    dflash_ssd_cache_max_bytes: int = 20 * 1024 * 1024 * 1024  # 20 GiB L2 disk budget
    # DFlash runtime tuning knobs. None window size uses the draft checkpoint's
    # sliding_window when present; sink size defaults to no attention-sink tokens.
    dflash_draft_window_size: Optional[int] = None
    dflash_draft_sink_size: Optional[int] = 0
    dflash_block_size: Optional[int] = None
    dflash_verify_mode: Optional[str] = None  # "dflash" | "adaptive" | "ddtree" | "off"

    # Lightning MTP uses the embedded head for single and concurrent requests.
    # Equal-depth rows share target verification when supported by the backbone;
    # each request keeps its own acceptance, draft history and cache frontier.
    # Mutually exclusive with DFlash.
    mtp_enabled: bool = False
    # Maximum chained MTP draft tokens per verify cycle (speculative depth).
    # Qwen 27B enforces a minimum adaptive ceiling of 4.
    # None = model-specific default (4 for dense Qwen3.5-family on M5, else 3
    # for DeepSeek-V4 and Qwen3.5/3.6). An adaptive controller picks 1..max
    # per sequence from rolling acceptance/latency estimates.
    mtp_adaptive_max_depth: Optional[int] = None
    # Draft exactly this many tokens every cycle, with no adaptive controller.
    # Takes precedence over mtp_adaptive_max_depth; None = adaptive.
    mtp_fixed_depth: Optional[int] = None

    # VLM MTP speculative decoding via external MTP drafter (mlx-vlm f96138e+).
    # Supported drafter types: gemma4_assistant (for Gemma 4 VLMs), qwen3_5_mtp
    # (for Qwen 3.5/3.6). Both resolve to draft_kind="mtp" in mlx-vlm.
    # Mutually exclusive with all other speculative paths because the wrapper
    # bypasses mlx-lm BatchGenerator at decode time. Also exclusive with
    # processor-backed settings (guided grammar, thinking budget, penalties)
    # — see vlm_mtp_processor_conflicts().
    vlm_mtp_enabled: bool = False
    vlm_mtp_draft_model: Optional[str] = (
        None  # Path / model id of the assistant drafter
    )
    vlm_mtp_draft_block_size: Optional[int] = (
        None  # Tokens per draft round (None = mlx-vlm default)
    )

    # Model management flags
    is_pinned: bool = False
    is_default: bool = False  # Only one model can be default
    is_hidden: bool = False  # Hidden from /v1/models (still shown, badged, in admin)
    is_favorite: bool = False  # Listed first in /v1/models and admin lists

    # Security: opt-in per model. When True, mlx-lm/mlx-vlm/mlx-embeddings/reranker
    # loaders are allowed to execute custom Python from the model repository
    # (modeling_*.py, tokenization_*.py). Off by default — see issue #926.
    trust_remote_code: bool = False

    # Embedding models with an audio tower (EmbeddingGemma 2): load it so
    # /v1/embeddings accepts items[].audio. Off by default because the tower is
    # resident even for text-only requests (EmbeddingGemma 2: 0.88 -> 1.46 GB).
    embedding_audio_enabled: bool = False
    # Longest audio item, in seconds, an embedding model reads before cutting
    # the waveform. None keeps the processor default (Gemma 4 audio: 30 s).
    # The model's context still bounds it: EmbeddingGemma 2 fits about 327 s
    # (8192 tokens at 40 ms each); longer inputs get the token-limit error.
    embedding_audio_max_seconds: Optional[float] = None

    # Metadata
    display_name: Optional[str] = None
    description: Optional[str] = None
    active_profile_name: Optional[str] = None  # Name of the currently-applied profile

    def __post_init__(self) -> None:
        # Profiles retain raw JSON types; engine signatures use repr().
        self.turboquant_kv_bits = normalize_turboquant_kv_bits(self.turboquant_kv_bits)
        if self.qwen35_oq_a8_enabled and self.qwen35_oq_a8_min_tokens < 1:
            raise ValueError("qwen35_oq_a8_min_tokens must be at least 1")
        # Both accelerate the same Qwen3.5 prefill projections by wrapping
        # Qwen3_5MLP.__call__, so enabling both leaves whichever patched last
        # in charge and the other silently inert -- with different numerics
        # depending on which won. Rejected at construction time so the clash
        # surfaces in the admin UI / API rather than as a silent no-op.
        if self.qwen35_oq_a8_enabled and self.qwen35_ane_prefill_enabled:
            raise ValueError(
                "qwen35_oq_a8_enabled and qwen35_ane_prefill_enabled cannot "
                "both be True; choose one Qwen3.5 prefill accelerator per model"
            )
        # Native MTP is mutually exclusive with DFlash (also speculative).
        # Reject the combo at construction time so the conflict surfaces in
        # the admin UI / API rather than at model load. TurboQuant KV is
        # compatible: its attention patch routes MTP's decode-shaped
        # multi-row verify through the quantized decode kernels.
        if self.mtp_enabled and self.dflash_enabled:
            raise ValueError(
                "mtp_enabled and dflash_enabled cannot both be True; choose one "
                "speculative-decoding path per model"
            )
        # vlm_mtp wraps mlx-vlm's MTP loop and bypasses mlx-lm BatchGenerator
        # at decode time, so it cannot coexist with any other speculative path
        # or with TurboQuant (which mutates the same cache objects).
        if self.vlm_mtp_enabled:
            conflicts = [
                ("dflash_enabled", self.dflash_enabled),
                ("specprefill_enabled", self.specprefill_enabled),
                ("mtp_enabled", self.mtp_enabled),
                ("turboquant_kv_enabled", self.turboquant_kv_enabled),
            ]
            for name, value in conflicts:
                if value:
                    raise ValueError(
                        f"vlm_mtp_enabled and {name} cannot both be True; "
                        "choose one speculative path per model"
                    )
            # Grammar / penalty defaults materialize as per-request logits
            # processors, which the vlm_mtp decode path cannot apply —
            # every request would fall back to BatchGenerator and the
            # toggle would silently never engage (#2399). Reject the combo
            # at construction time like the speculative-path conflicts
            # above. Thinking budget is exempt: it is applied at verify
            # time via MTPProcessingSampler.
            processor_conflicts = vlm_mtp_processor_conflicts(self.to_dict())
            if processor_conflicts:
                raise ValueError(
                    "vlm_mtp_enabled cannot be combined with "
                    f"{', '.join(processor_conflicts)}; these settings "
                    "require per-request logits processors, which the "
                    "vlm_mtp decode path does not apply"
                )
        validate_moe_expert_offload(self.to_dict())

    def to_dict(self) -> dict:
        """Convert to dictionary, excluding None values.

        Returns:
            Dictionary representation with None values filtered out.
        """
        result = {}
        for f in fields(self):
            value = getattr(self, f.name)
            if f.name == "turboquant_kv_bits":
                value = normalize_turboquant_kv_bits(value)
            if value is not None:
                result[f.name] = value
        return result

    @classmethod
    def from_dict(cls, data: dict) -> "ModelSettings":
        """Create ModelSettings from a dictionary.

        Args:
            data: Dictionary containing settings values.

        Returns:
            New ModelSettings instance with values from dict.
        """
        # Get valid field names
        valid_fields = {f.name for f in fields(cls)}

        # Filter to only valid keys
        filtered_data = {k: v for k, v in data.items() if k in valid_fields}

        return cls(**filtered_data)


class ModelSettingsManager:
    """Manager for per-model settings with file persistence.

    Handles loading, saving, and accessing model settings from a JSON file.
    Thread-safe for concurrent access.

    Attributes:
        base_path: Base directory for settings storage.
        settings_file: Path to the settings JSON file.
    """

    def __init__(self, base_path: Path):
        """Initialize the settings manager.

        Args:
            base_path: Base directory for settings storage.
        """
        self.base_path = Path(base_path)
        self.settings_file = self.base_path / "model_settings.json"
        self.profiles_file = self.base_path / "model_profiles.json"
        self.templates_file = self.base_path / "global_templates.json"
        self._lock = threading.Lock()
        self._settings: Dict[str, ModelSettings] = {}
        self._profiles: Dict[str, Dict[str, Dict[str, Any]]] = {}
        self._templates: Dict[str, Dict[str, Any]] = {}

        # Ensure base directory exists
        self.base_path.mkdir(parents=True, exist_ok=True)

        # Repair raw references before normal loading can normalize old records.
        self._repair_profile_references()
        self._load()
        self._load_profiles()
        self._load_templates()

    def _repair_profile_references(self) -> None:
        """Detach missing references without changing saved settings or IDs."""
        originals = {}
        documents = {}
        try:
            for path, key, version in (
                (self.settings_file, "models", SETTINGS_VERSION),
                (self.profiles_file, "profiles", PROFILES_VERSION),
                (self.templates_file, "templates", TEMPLATES_VERSION),
            ):
                if path.exists():
                    originals[path] = path.read_bytes()
                    document = json.loads(originals[path])
                else:
                    document = {"version": version, key: {}}
                if (
                    not isinstance(document, dict)
                    or document.get("version", 1) != version
                ):
                    raise ValueError(f"Unsupported profile storage format: {path.name}")
                records = document.get(key, {})
                if not isinstance(records, dict) or any(
                    not isinstance(record, dict) for record in records.values()
                ):
                    raise ValueError(f"Invalid profile records: {path.name}")
                documents[path] = document

            profiles = documents[self.profiles_file].get("profiles", {})
            templates = documents[self.templates_file].get("templates", {})
            settings = documents[self.settings_file].get("models", {})
            detached = cleared = 0
            for model_profiles in profiles.values():
                for profile in model_profiles.values():
                    if not isinstance(profile, dict):
                        raise ValueError("Invalid model profile record")
                    source = profile.get("source_template")
                    if source is not None and source not in templates:
                        profile["source_template"] = None
                        detached += 1
            for model_id, model_settings in settings.items():
                active = model_settings.get("active_profile_name")
                if active is not None and active not in profiles.get(model_id, {}):
                    model_settings["active_profile_name"] = None
                    cleared += 1
        except (OSError, ValueError, TypeError) as error:
            logger.warning("Skipped profile reference repair: %s", error)
            return

        changed = []
        if detached:
            changed.append(self.profiles_file)
        if cleared:
            changed.append(self.settings_file)
        if not changed:
            return

        digest = hashlib.sha256()
        for path, content in originals.items():
            digest.update(path.name.encode("utf-8") + b"\0")
            digest.update(len(content).to_bytes(8, "big"))
            digest.update(content)
        backup = self.base_path / f"profile-reference-backup-{digest.hexdigest()}"
        written = []
        try:
            backup.mkdir(exist_ok=True)
            for path, content in originals.items():
                target = backup / path.name
                if not target.exists():
                    self._write_profile_repair(target, content)
                if target.read_bytes() != content:
                    raise OSError(f"Profile backup does not match original: {target}")
            for path in changed:
                content = json.dumps(
                    documents[path], indent=2, ensure_ascii=False
                ).encode("utf-8")
                self._write_profile_repair(path, content)
                written.append(path)
        except OSError:
            try:
                for path in written:
                    self._write_profile_repair(path, originals[path])
            except OSError:
                logger.exception(
                    "Profile reference repair rollback failed; recover originals from %s",
                    backup,
                )
                raise
            logger.exception("Profile reference repair failed; original files retained")
            return
        logger.info(
            "Repaired profile references: %d detached copies, %d cleared active references; backup: %s",
            detached,
            cleared,
            backup,
        )

    @staticmethod
    def _write_profile_repair(path: Path, content: bytes) -> None:
        """Replace one raw document atomically, including when rolling back."""
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
                temporary = Path(stream.name)
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            temporary.replace(path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    def _load(self) -> None:
        """Load settings from the JSON file.

        If the file doesn't exist or is invalid, starts with empty settings.
        """
        if not self.settings_file.exists():
            logger.debug(f"Settings file not found: {self.settings_file}")
            self._settings = {}
            return

        try:
            with open(self.settings_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Check version
            version = data.get("version", 1)
            if version != SETTINGS_VERSION:
                logger.warning(
                    f"Settings file version {version} differs from current {SETTINGS_VERSION}"
                )

            # Load model settings
            models_data = data.get("models", {})
            self._settings = {}

            for model_id, model_data in models_data.items():
                # Settings saved before the vlm_mtp exclusivity rule may
                # combine vlm_mtp_enabled with processor-backed settings;
                # __post_init__ would raise and the except below would drop
                # the model's entire settings blob. Keep the content-shaping
                # settings and turn vlm_mtp off instead.
                model_data, conflicts = resolve_vlm_mtp_conflicts(model_data)
                if conflicts:
                    logger.warning(
                        "Model '%s': vlm_mtp_enabled disabled on load; it "
                        "cannot be combined with %s. Unset those settings "
                        "to re-enable vlm_mtp.",
                        model_id,
                        ", ".join(conflicts),
                    )
                model_data, prefill_conflicts = resolve_qwen35_prefill_conflicts(
                    model_data
                )
                if prefill_conflicts:
                    logger.warning(
                        "Model '%s': qwen35_oq_a8_enabled disabled on load; it "
                        "cannot be combined with %s. Unset that setting to "
                        "re-enable the oQ A8 prefill kernels.",
                        model_id,
                        ", ".join(prefill_conflicts),
                    )
                try:
                    self._settings[model_id] = ModelSettings.from_dict(model_data)
                except Exception as e:
                    logger.warning(
                        f"Failed to load settings for model '{model_id}': {e}"
                    )

            logger.info(f"Loaded settings for {len(self._settings)} models")

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in settings file: {e}")
            self._settings = {}
        except Exception as e:
            logger.error(f"Failed to load settings file: {e}")
            self._settings = {}

    def _save(self) -> None:
        """Save settings to the JSON file.

        Must be called while holding the lock.
        """
        data = {
            "version": SETTINGS_VERSION,
            "models": {
                model_id: settings.to_dict()
                for model_id, settings in self._settings.items()
            },
        }

        # Write to temp file first, then rename for atomicity. The pid in
        # the temp name keeps concurrent processes from sharing a temp path
        # and renaming each other's partial writes into place.
        temp_file = self.settings_file.with_name(
            f"{self.settings_file.name}.{os.getpid()}.tmp"
        )
        try:
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())

            temp_file.replace(self.settings_file)
            logger.debug(f"Saved settings for {len(self._settings)} models")

        except Exception as e:
            logger.error(f"Failed to save settings file: {e}")
            temp_file.unlink(missing_ok=True)
            raise

    def get_settings(self, model_id: str) -> ModelSettings:
        """Get settings for a specific model.

        Args:
            model_id: The model identifier.

        Returns:
            ModelSettings for the model, or default settings if not found.
        """
        with self._lock:
            if model_id in self._settings:
                # Return a copy to prevent external modification
                settings = self._settings[model_id]
                return ModelSettings.from_dict(settings.to_dict())

            return ModelSettings()

    def get_settings_for_request(
        self,
        model_id: str,
        resolved_model_id: Optional[str] = None,
    ) -> ModelSettings:
        """Get settings for an API-requested model name.

        Exposed profile model IDs return the base model's settings merged
        with the profile's universal (request-time) overrides. Engine-
        construction fields are handled separately by
        get_exposed_profile_runtime_settings_for_request(), which may trigger
        a transient engine variant reload without mutating persisted settings.
        Any other name falls back to the settings of the already-resolved
        physical model.
        """
        with self._lock:
            candidates = [model_id]
            if "/" in model_id:
                candidates.append(model_id.split("/", 1)[1])
            for candidate in candidates:
                profile_match = self._find_exposed_profile_locked(candidate)
                if profile_match is not None:
                    base_model_id, profile = profile_match
                    return self._settings_with_profile_locked(base_model_id, profile)

        return self.get_settings(resolved_model_id or model_id)

    def set_settings(self, model_id: str, settings: ModelSettings) -> None:
        """Set settings for a specific model.

        If the new settings have is_default=True, clears is_default from all
        other models to maintain the exclusive default constraint.

        Args:
            model_id: The model identifier.
            settings: The settings to apply.
        """
        with self._lock:
            # Handle exclusive default constraint
            if settings.is_default:
                for mid, s in self._settings.items():
                    if mid != model_id and s.is_default:
                        s.is_default = False
                        logger.info(
                            f"Cleared is_default from model '{mid}' "
                            f"(new default: '{model_id}')"
                        )

            # Store a copy of the settings
            self._settings[model_id] = ModelSettings.from_dict(settings.to_dict())
            logger.info(f"Updated settings for model '{model_id}'")

            self._save()

    def delete_settings(self, model_id: str) -> bool:
        """Remove all persisted state for a model (settings + profiles).

        Called when a model is deleted so its alias and other settings are
        released and can be reused by another model.

        Args:
            model_id: The model identifier.

        Returns:
            True if any state was removed, False if nothing was stored.
        """
        with self._lock:
            removed = False
            if model_id in self._settings:
                del self._settings[model_id]
                self._save()
                removed = True
            if model_id in self._profiles:
                del self._profiles[model_id]
                self._save_profiles()
                removed = True
            if removed:
                logger.info(f"Deleted settings for model '{model_id}'")
            return removed

    def get_default_model_id(self) -> Optional[str]:
        """Get the ID of the default model.

        Returns:
            The model ID marked as default, or None if no default is set.
        """
        with self._lock:
            for model_id, settings in self._settings.items():
                if settings.is_default:
                    return model_id
            return None

    def get_pinned_model_ids(self) -> list[str]:
        """Get list of all pinned model IDs.

        Returns:
            List of model IDs that are marked as pinned.
        """
        with self._lock:
            return [
                model_id
                for model_id, settings in self._settings.items()
                if settings.is_pinned
            ]

    def get_all_settings(self) -> Dict[str, ModelSettings]:
        """Get a copy of all model settings.

        Returns:
            Dictionary mapping model IDs to their settings (deep copy).
        """
        with self._lock:
            return {
                model_id: ModelSettings.from_dict(settings.to_dict())
                for model_id, settings in self._settings.items()
            }

    # ==================== Profiles ====================

    def _load_profiles(self) -> None:
        if not self.profiles_file.exists():
            self._profiles = {}
            return
        try:
            with open(self.profiles_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            version = data.get("version", 1)
            if version != PROFILES_VERSION:
                logger.warning(
                    f"Profiles file version {version} differs from current {PROFILES_VERSION}"
                )
            self._profiles = data.get("profiles", {}) or {}
            # Migration: strip ttl_seconds from existing profile settings and
            # add api_name for exposed-model IDs without changing internal keys.
            changed = False
            for model_id, profiles in self._profiles.items():
                model_changed = False
                used_api_names: set[str] = set()
                for name, profile in profiles.items():
                    settings = profile.get("settings")
                    # Normalize in memory only; the next save writes floats.
                    if settings and "turboquant_kv_bits" in settings:
                        settings["turboquant_kv_bits"] = normalize_turboquant_kv_bits(
                            settings["turboquant_kv_bits"]
                        )
                    if settings and "ttl_seconds" in settings:
                        del settings["ttl_seconds"]
                        changed = True
                        model_changed = True
                    current_api_name = profile.get("api_name")
                    if current_api_name:
                        try:
                            validate_profile_name(current_api_name)
                            base_api_name = current_api_name
                        except Exception:
                            base_api_name = slugify_profile_api_name(
                                profile.get("display_name") or name,
                                fallback="profile",
                            )
                    else:
                        base_api_name = slugify_profile_api_name(
                            profile.get("display_name") or name,
                            fallback="profile",
                        )
                    api_name = self._dedupe_profile_api_name(
                        base_api_name,
                        used_api_names,
                    )
                    if current_api_name != api_name:
                        profile["api_name"] = api_name
                        changed = True
                        model_changed = True
                if model_changed:
                    logger.info(f"Migrated profile api names for model '{model_id}'")
            if changed:
                self._save_profiles()
        except Exception as e:
            logger.error(f"Failed to load profiles file: {e}")
            self._profiles = {}

    def _save_profiles(self) -> None:
        """Write profiles to disk atomically (temp file + rename)."""
        data = {"version": PROFILES_VERSION, "profiles": self._profiles}
        temp_file = self.profiles_file.with_name(
            f"{self.profiles_file.name}.{os.getpid()}.tmp"
        )
        try:
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False, default=str)
                f.flush()
                os.fsync(f.fileno())
            temp_file.replace(self.profiles_file)
        except Exception as e:
            logger.error(f"Failed to save profiles file: {e}")
            temp_file.unlink(missing_ok=True)
            raise

    @staticmethod
    def _dedupe_profile_api_name(base: str, used: set[str]) -> str:
        validate_profile_name(base)
        candidate = base
        index = 2
        while candidate in used:
            suffix = f"-{index}"
            root = base[: 32 - len(suffix)].rstrip("-_") or "profile"
            candidate = f"{root}{suffix}"
            index += 1
        used.add(candidate)
        return candidate

    @staticmethod
    def _profile_api_name(profile: Dict[str, Any]) -> str:
        api_name = profile.get("api_name") or profile["name"]
        validate_profile_name(api_name)
        return api_name

    def _allocate_profile_api_name_locked(
        self,
        profiles: Dict[str, Dict[str, Any]],
        value: str | None,
        *,
        display_name: str | None,
        internal_name: str,
        exclude_name: str | None = None,
    ) -> str:
        if value:
            validate_profile_name(value)
            base = value
        else:
            base = slugify_profile_api_name(
                display_name or internal_name,
                fallback="profile",
            )
        used = {
            self._profile_api_name(profile)
            for name, profile in profiles.items()
            if name != exclude_name
        }
        return self._dedupe_profile_api_name(base, used)

    def _profile_model_id(self, model_id: str, api_name: str) -> str:
        return f"{model_id}:{api_name}"

    def _display_profile_model_id_locked(
        self, model_id: str, profile: Dict[str, Any]
    ) -> str:
        """Advertised form of an exposed profile's model ID.

        Uses the base model's alias when set, mirroring how /v1/models
        lists the base model itself. The directory-name form remains
        accepted for requests, exactly like the base model's directory
        name.
        """
        base = self._settings.get(model_id)
        display_base = base.model_alias if base and base.model_alias else model_id
        return self._profile_model_id(display_base, self._profile_api_name(profile))

    def _find_exposed_profile_locked(
        self, model_id: str
    ) -> Optional[tuple[str, Dict[str, Any]]]:
        for base_model_id, profiles in self._profiles.items():
            base = self._settings.get(base_model_id)
            alias = base.model_alias if base else None
            for profile in profiles.values():
                if not profile.get("expose_as_model"):
                    continue
                api_name = self._profile_api_name(profile)
                if model_id == self._profile_model_id(base_model_id, api_name):
                    return base_model_id, profile
                if alias and model_id == self._profile_model_id(alias, api_name):
                    return base_model_id, profile
        return None

    def _settings_with_profile_locked(
        self, model_id: str, profile: Dict[str, Any]
    ) -> ModelSettings:
        base = self._settings.get(model_id)
        merged = base.to_dict() if base is not None else {}
        # Request-time settings still use only universal fields. Engine-
        # construction fields are handled separately by
        # get_exposed_profile_runtime_settings_for_request(), which can
        # trigger an engine variant reload without persisting base settings.
        merged.update(filter_universal_fields(profile.get("settings", {}) or {}))
        # A profile overriding penalties / grammar / thinking budget on a
        # vlm_mtp base model would make __post_init__ raise on this
        # request-time merge; drop vlm_mtp for the merged view instead.
        merged, _ = resolve_vlm_mtp_conflicts(merged)
        merged, _ = resolve_qwen35_prefill_conflicts(merged)
        return ModelSettings.from_dict(merged)

    def _runtime_settings_with_profile_locked(
        self, model_id: str, profile: Dict[str, Any]
    ) -> ModelSettings:
        base = self._settings.get(model_id)
        merged = base.to_dict() if base is not None else {}
        merged.update(filter_profile_fields(profile.get("settings", {}) or {}))
        merged, _ = resolve_vlm_mtp_conflicts(merged)
        merged, _ = resolve_qwen35_prefill_conflicts(merged)
        return ModelSettings.from_dict(merged)

    def get_exposed_profile_source_model_id(self, model_id: str) -> Optional[str]:
        """Return the base model for an exposed profile model ID, if any."""
        with self._lock:
            candidates = [model_id]
            if "/" in model_id:
                candidates.append(model_id.split("/", 1)[1])
            for candidate in candidates:
                match = self._find_exposed_profile_locked(candidate)
                if match is not None:
                    return match[0]
            return None

    def get_exposed_profile_runtime_settings_for_request(
        self,
        model_id: str,
    ) -> Optional[tuple[str, ModelSettings]]:
        """Return full runtime settings for an exposed profile request.

        Unlike ``get_settings_for_request()``, this includes model-specific
        engine-construction fields. It is used only for transient engine
        loading and never mutates the base model's persisted settings.
        """
        with self._lock:
            candidates = [model_id]
            if "/" in model_id:
                candidates.append(model_id.split("/", 1)[1])
            for candidate in candidates:
                match = self._find_exposed_profile_locked(candidate)
                if match is not None:
                    base_model_id, profile = match
                    return (
                        base_model_id,
                        self._runtime_settings_with_profile_locked(
                            base_model_id, profile
                        ),
                    )
            return None

    def get_exposed_profile_model_ids(
        self,
        *,
        exclude_model_id: str | None = None,
        exclude_profile_name: str | None = None,
    ) -> set[str]:
        """Return every request ID accepted by exposed profiles."""
        with self._lock:
            model_ids: set[str] = set()
            for base_model_id, profiles in self._profiles.items():
                base = self._settings.get(base_model_id)
                alias = base.model_alias if base else None
                for profile in profiles.values():
                    if not profile.get("expose_as_model"):
                        continue
                    if (
                        exclude_model_id == base_model_id
                        and exclude_profile_name == profile["name"]
                    ):
                        continue
                    api_name = self._profile_api_name(profile)
                    model_ids.add(self._profile_model_id(base_model_id, api_name))
                    if alias:
                        model_ids.add(self._profile_model_id(alias, api_name))
            return model_ids

    def _profile_request_ids_locked(
        self,
        model_id: str,
        profile: Dict[str, Any],
    ) -> set[str]:
        base = self._settings.get(model_id)
        base_ids = {model_id}
        if base and base.model_alias:
            base_ids.add(base.model_alias)
        api_name = self._profile_api_name(profile)
        return {self._profile_model_id(base_id, api_name) for base_id in base_ids}

    def _validate_exposed_profile_ids_available_locked(
        self,
        model_id: str,
        profile: Dict[str, Any],
        *,
        exclude_profile_name: str | None = None,
        reserved_model_ids: set[str] | None = None,
    ) -> None:
        if not profile.get("expose_as_model"):
            return
        candidate_ids = self._profile_request_ids_locked(model_id, profile)

        if reserved_model_ids:
            for candidate_id in candidate_ids:
                if candidate_id != model_id and candidate_id in reserved_model_ids:
                    raise ValueError(
                        f"Exposed profile model ID '{candidate_id}' conflicts "
                        "with a model directory name"
                    )

        for mid, settings in self._settings.items():
            if settings.model_alias and settings.model_alias in candidate_ids:
                raise ValueError(
                    f"Exposed profile model ID '{settings.model_alias}' "
                    f"conflicts with model alias for '{mid}'"
                )

        existing_ids: set[str] = set()
        for base_model_id, profiles in self._profiles.items():
            for other in profiles.values():
                if not other.get("expose_as_model"):
                    continue
                if base_model_id == model_id and other["name"] == exclude_profile_name:
                    continue
                existing_ids.update(
                    self._profile_request_ids_locked(base_model_id, other)
                )
        conflict = candidate_ids & existing_ids
        if conflict:
            conflict_id = sorted(conflict)[0]
            raise ValueError(f"Exposed profile model ID '{conflict_id}' already exists")

    def list_exposed_profile_models(self) -> list[dict]:
        """Return profile records promoted to independently visible model IDs."""
        with self._lock:
            exposed = []
            for base_model_id, profiles in self._profiles.items():
                for profile in profiles.values():
                    if not profile.get("expose_as_model"):
                        continue
                    item = dict(profile)
                    item["model_id"] = self._display_profile_model_id_locked(
                        base_model_id, profile
                    )
                    item["source_model_id"] = base_model_id
                    item["settings"] = self._settings_with_profile_locked(
                        base_model_id, item
                    ).to_dict()
                    exposed.append(item)
            return exposed

    @staticmethod
    def _has_engine_fields(profile: Dict[str, Any]) -> bool:
        """True when the profile overrides any engine-construction field.

        Those fields are ignored by the request-time sampling overlay but are
        used for transient engine variant reloads on exposed-profile requests.
        UIs use this flag to indicate that a profile changes load-time state.
        """
        settings = profile.get("settings", {}) or {}
        return any(
            k in MODEL_SPECIFIC_PROFILE_FIELDS and v is not None
            for k, v in settings.items()
        )

    def list_profiles(self, model_id: str) -> list[dict]:
        """Return all profiles for ``model_id`` as serializable dicts."""
        with self._lock:
            per_model = self._profiles.get(model_id, {})
            return [
                {
                    **p,
                    "model_id": self._display_profile_model_id_locked(model_id, p),
                    "has_engine_fields": self._has_engine_fields(p),
                }
                for p in per_model.values()
            ]

    def get_profile(self, model_id: str, name: str) -> Optional[dict]:
        with self._lock:
            return dict(self._profiles.get(model_id, {}).get(name, {})) or None

    def save_profile(
        self,
        model_id: str,
        name: str,
        display_name: str,
        description: Optional[str],
        settings: Dict[str, Any],
        source_template: Optional[str] = None,
        expose_as_model: bool = False,
        api_name: Optional[str] = None,
        reserved_model_ids: Optional[set[str]] = None,
    ) -> dict:
        """Create a new profile. Raises if name is invalid or already exists."""
        validate_profile_name(name)
        filtered = filter_profile_fields(settings or {})
        with self._lock:
            per_model = self._profiles.setdefault(model_id, {})
            if name in per_model:
                raise ValueError(
                    f"Profile '{name}' already exists for model '{model_id}'"
                )
            now = utcnow().isoformat()
            profile_api_name = self._allocate_profile_api_name_locked(
                per_model,
                api_name,
                display_name=display_name,
                internal_name=name,
            )
            profile_record = {
                "name": name,
                "display_name": display_name or name,
                "api_name": profile_api_name,
                "description": description,
                "created_at": now,
                "updated_at": now,
                "settings": filtered,
                "source_template": source_template,
                "expose_as_model": bool(expose_as_model),
            }
            self._validate_exposed_profile_ids_available_locked(
                model_id,
                profile_record,
                reserved_model_ids=reserved_model_ids,
            )
            per_model[name] = profile_record
            self._save_profiles()
            return dict(per_model[name])

    def update_profile(
        self,
        model_id: str,
        name: str,
        *,
        new_name: Optional[str] = None,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        settings: Optional[Dict[str, Any]] = None,
        source_template: Optional[str] = None,
        expose_as_model: Optional[bool] = None,
        api_name: Optional[str] = None,
        reserved_model_ids: Optional[set[str]] = None,
    ) -> Optional[dict]:
        """Update a profile's metadata/settings. Returns updated dict or None if not found."""
        with self._lock:
            per_model = self._profiles.get(model_id, {})
            if name not in per_model:
                return None
            profile = dict(per_model[name])
            target_name = name
            rename_mode = False
            if new_name is not None and new_name != name:
                validate_profile_name(new_name)
                if new_name in per_model:
                    raise ValueError(
                        f"Profile '{new_name}' already exists for model '{model_id}'"
                    )
                target_name = new_name
                profile["name"] = new_name
                rename_mode = True
            if display_name is not None:
                profile["display_name"] = display_name
            if api_name is not None:
                profile["api_name"] = self._allocate_profile_api_name_locked(
                    per_model,
                    api_name,
                    display_name=profile.get("display_name"),
                    internal_name=target_name,
                    exclude_name=name,
                )
            if description is not None:
                profile["description"] = description
            if settings is not None:
                profile["settings"] = filter_profile_fields(settings)
            if source_template is not None:
                profile["source_template"] = source_template or None
            if expose_as_model is not None:
                profile["expose_as_model"] = bool(expose_as_model)
            profile["updated_at"] = utcnow().isoformat()
            self._validate_exposed_profile_ids_available_locked(
                model_id,
                profile,
                exclude_profile_name=name,
                reserved_model_ids=reserved_model_ids,
            )

            # Snapshot for rollback on write failure
            profiles_snapshot = copy.deepcopy(self._profiles)
            settings_snapshot = copy.deepcopy(self._settings)

            # Also update ModelSettings.active_profile_name if renamed and it was active
            old_active = None
            if rename_mode:
                old_active = self._settings.get(model_id)
                if old_active is not None and old_active.active_profile_name == name:
                    old_active.active_profile_name = target_name
                del per_model[name]

            per_model[target_name] = profile

            # Write profiles first; if this throws, rollback everything
            try:
                self._save_profiles()
                if rename_mode and old_active is not None:
                    self._save()
            except Exception:
                self._profiles = profiles_snapshot
                self._settings = settings_snapshot
                raise

            return dict(profile)

    def delete_profile(self, model_id: str, name: str) -> bool:
        with self._lock:
            per_model = self._profiles.get(model_id, {})
            if name not in per_model:
                return False

            profiles_snapshot = copy.deepcopy(self._profiles)
            settings_snapshot = copy.deepcopy(self._settings)

            del per_model[name]
            if not per_model and model_id in self._profiles:
                del self._profiles[model_id]
            # Clear active_profile_name if it referenced this profile
            old_active = self._settings.get(model_id)
            if old_active is not None and old_active.active_profile_name == name:
                old_active.active_profile_name = None

            try:
                self._save_profiles()
                if old_active is not None and old_active.active_profile_name is None:
                    self._save()
            except Exception:
                self._profiles = profiles_snapshot
                self._settings = settings_snapshot
                raise
            return True

    def apply_profile(
        self,
        model_id: str,
        name: str,
        settings_sanitizer: Optional[Callable[[dict[str, Any]], None]] = None,
    ) -> Optional[ModelSettings]:
        """Merge profile settings into the model's live settings and persist."""
        with self._lock:
            per_model = self._profiles.get(model_id, {})
            if name not in per_model:
                return None
            profile_settings = per_model[name].get("settings", {}) or {}

            settings_snapshot = copy.deepcopy(self._settings)

            new_settings = self._applied_profile_settings_locked(
                model_id, name, profile_settings, settings_sanitizer
            )
            self._settings[model_id] = new_settings
            try:
                self._save()
            except Exception:
                self._settings = settings_snapshot
                raise
            return ModelSettings.from_dict(new_settings.to_dict())

    def _applied_profile_settings_locked(
        self,
        model_id: str,
        name: str,
        profile_settings: dict[str, Any],
        settings_sanitizer: Callable[[dict[str, Any]], None] | None,
    ) -> ModelSettings:
        current = self._settings.get(model_id)
        if current is None:
            current = ModelSettings()
        # Universal fields: the profile is authoritative — absent keys
        # reset to ModelSettings defaults. Model-specific fields keep
        # additive overlay so preset/template chips (materialized as
        # universal-only profiles) never disturb engine settings.
        merged = {
            k: v for k, v in current.to_dict().items() if k not in UNIVERSAL_FIELDS_SET
        }
        overlay = filter_profile_fields(profile_settings)
        merged.update(overlay)
        # A profile that sets the Lightning MTP toggle also owns the depth
        # choice; no fixed depth there selects adaptive depth.
        if "mtp_enabled" in overlay and "mtp_fixed_depth" not in overlay:
            merged["mtp_fixed_depth"] = None
        merged["active_profile_name"] = name
        if settings_sanitizer is not None:
            settings_sanitizer(merged)
        # Keep persistent profile application consistent with request-time
        # profile overlays: output-shaping settings win over the speed-only
        # VLM MTP toggle when the merged settings need logits processors.
        merged, _ = resolve_vlm_mtp_conflicts(merged)
        merged, _ = resolve_qwen35_prefill_conflicts(merged)
        new_settings = ModelSettings.from_dict(merged)
        return new_settings

    def apply_template(
        self,
        model_id: str,
        template_name: str,
        settings_sanitizer: Callable[[dict[str, Any]], None] | None = None,
    ) -> ModelSettings | None:
        """Apply the latest template without replacing an unrelated model profile."""
        with self._lock:
            template = self._templates.get(template_name)
            if template is None:
                return None
            per_model = self._profiles.get(model_id, {})
            copies = [
                p
                for p in per_model.values()
                if p.get("source_template") == template_name
            ]
            active = self._settings.get(model_id)
            profile = next(
                (
                    p
                    for p in copies
                    if active and p["name"] == active.active_profile_name
                ),
                copies[0] if copies else None,
            )
            now = utcnow().isoformat()
            if profile is None:
                name = self._dedupe_profile_api_name(template_name, set(per_model))
                profile = {
                    "name": name,
                    "api_name": self._allocate_profile_api_name_locked(
                        per_model,
                        None,
                        display_name=template["display_name"],
                        internal_name=name,
                    ),
                    "created_at": now,
                    "expose_as_model": False,
                }
            else:
                profile = dict(profile)
            profile.update(
                display_name=template["display_name"],
                description=template.get("description"),
                source_template=template_name,
                settings=filter_universal_fields(template.get("settings", {})),
                updated_at=now,
            )
            applied = self._applied_profile_settings_locked(
                model_id, profile["name"], profile["settings"], settings_sanitizer
            )
            profiles_snapshot = copy.deepcopy(self._profiles)
            settings_snapshot = copy.deepcopy(self._settings)
            self._profiles.setdefault(model_id, {})[profile["name"]] = profile
            self._settings[model_id] = applied
            profiles_saved = False
            try:
                self._save_profiles()
                profiles_saved = True
                self._save()
            except Exception:
                self._profiles = profiles_snapshot
                self._settings = settings_snapshot
                if profiles_saved:
                    self._save_profiles()
                raise
            return ModelSettings.from_dict(applied.to_dict())

    # ==================== Templates ====================

    def _load_templates(self) -> None:
        # Built-in defaults ship inside the package (omlx/default_global_templates.json)
        # and are merged in at read time — they are NEVER copied to disk and never
        # appear in `self._templates`. The user file under <base_path> holds
        # ONLY user-created templates; a missing/empty file is the legitimate
        # initial state.
        if not self.templates_file.exists():
            self._templates = {}
            return
        try:
            with open(self.templates_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            version = data.get("version", 1)
            if version != TEMPLATES_VERSION:
                logger.warning(
                    f"Templates file version {version} differs from current {TEMPLATES_VERSION}"
                )
            self._templates = data.get("templates", {}) or {}
            # Migration: strip ttl_seconds from existing template settings
            for name, template in self._templates.items():
                settings = template.get("settings")
                if settings and "ttl_seconds" in settings:
                    del settings["ttl_seconds"]
        except Exception as e:
            logger.error(f"Failed to load templates file: {e}")
            self._templates = {}

    def _save_templates(self) -> None:
        """Must be called while holding the lock."""
        data = {"version": TEMPLATES_VERSION, "templates": self._templates}
        temp_file = self.templates_file.with_name(
            f"{self.templates_file.name}.{os.getpid()}.tmp"
        )
        try:
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False, default=str)
                f.flush()
                os.fsync(f.fileno())
            temp_file.replace(self.templates_file)
        except Exception as e:
            logger.error(f"Failed to save templates file: {e}")
            temp_file.unlink(missing_ok=True)
            raise

    def list_templates(self) -> list[dict]:
        # Shipped JSON seeds were retired in favor of the client-side preset
        # bundle (`omlx_web/static/omlx_preset.json`); every entry on this
        # surface is user-created. Callers that distinguish presets from
        # user templates do so via the preset bundle, not an `is_builtin`
        # flag on this response.
        with self._lock:
            return [dict(t) for t in self._templates.values()]

    def get_template(self, name: str) -> Optional[dict]:
        with self._lock:
            u = self._templates.get(name)
            return dict(u) if u is not None else None

    def save_template(
        self,
        name: str,
        display_name: str,
        description: Optional[str],
        settings: Dict[str, Any],
    ) -> dict:
        validate_profile_name(name)
        filtered = filter_universal_fields(settings or {})
        with self._lock:
            if name in self._templates:
                raise ValueError(f"Template '{name}' already exists")
            now = utcnow().isoformat()
            self._templates[name] = {
                "name": name,
                "display_name": display_name or name,
                "description": description,
                "created_at": now,
                "updated_at": now,
                "settings": filtered,
            }
            self._save_templates()
            return dict(self._templates[name])

    def upsert_template(
        self,
        name: str,
        display_name: str,
        description: Optional[str],
        settings: Dict[str, Any],
    ) -> dict:
        """Create or replace a template with the given settings."""
        validate_profile_name(name)
        filtered = filter_universal_fields(settings or {})
        with self._lock:
            now = utcnow().isoformat()
            existing = self._templates.get(name)
            created_at = existing["created_at"] if existing else now
            self._templates[name] = {
                "name": name,
                "display_name": display_name or name,
                "description": description,
                "created_at": created_at,
                "updated_at": now,
                "settings": filtered,
            }
            self._save_templates()
            return dict(self._templates[name])

    def update_template(
        self,
        name: str,
        *,
        new_name: Optional[str] = None,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        settings: Optional[Dict[str, Any]] = None,
    ) -> Optional[dict]:
        with self._lock:
            if name not in self._templates:
                return None
            template = dict(self._templates[name])
            target = name
            if new_name is not None and new_name != name:
                validate_profile_name(new_name)
                if new_name in self._templates:
                    raise ValueError(f"Template '{new_name}' already exists")
                target = new_name
                template["name"] = new_name
            if display_name is not None:
                template["display_name"] = display_name
            if description is not None:
                template["description"] = description
            if settings is not None:
                template["settings"] = filter_universal_fields(settings)
            template["updated_at"] = utcnow().isoformat()
            templates_snapshot = copy.deepcopy(self._templates)
            profiles_snapshot = copy.deepcopy(self._profiles)
            if target != name:
                del self._templates[name]
                for profiles in self._profiles.values():
                    for profile in profiles.values():
                        if profile.get("source_template") == name:
                            profile["source_template"] = target
            self._templates[target] = template
            self._save_template_references(templates_snapshot, profiles_snapshot)
            return dict(template)

    def delete_template(self, name: str) -> bool:
        with self._lock:
            if name not in self._templates:
                return False
            templates_snapshot = copy.deepcopy(self._templates)
            profiles_snapshot = copy.deepcopy(self._profiles)
            del self._templates[name]
            for profiles in self._profiles.values():
                for profile in profiles.values():
                    if profile.get("source_template") == name:
                        profile["source_template"] = None
            self._save_template_references(templates_snapshot, profiles_snapshot)
            return True

    def _save_template_references(
        self, templates_snapshot: dict, profiles_snapshot: dict
    ) -> None:
        profiles_changed = self._profiles != profiles_snapshot
        profiles_saved = False
        try:
            if profiles_changed:
                self._save_profiles()
                profiles_saved = True
            self._save_templates()
        except Exception:
            self._templates = templates_snapshot
            self._profiles = profiles_snapshot
            if profiles_saved:
                self._save_profiles()
            raise


def forced_ct_keys(settings: "ModelSettings | None") -> set[str]:
    """Chat-template keys a request is not allowed to override."""
    if settings is None:
        return set()
    return set(settings.forced_ct_kwargs or [])


def merge_chat_template_request_kwargs(
    settings: "ModelSettings | None",
    request_ct_kwargs: "dict[str, Any] | None" = None,
) -> "dict[str, Any]":
    """Merge model/profile defaults with per-request chat-template kwargs.

    Precedence, lowest to highest:
      1. ``settings.chat_template_kwargs``
      2. the dedicated ``enable_thinking`` / ``preserve_thinking`` toggles
      3. per-request kwargs, except keys listed in ``forced_ct_kwargs``
    """
    merged: dict[str, Any] = {}
    forced_keys = forced_ct_keys(settings)

    if settings is not None:
        if settings.chat_template_kwargs:
            merged.update(settings.chat_template_kwargs)
        # Dedicated toggles take precedence over chat_template_kwargs.
        if settings.enable_thinking is not None:
            merged["enable_thinking"] = settings.enable_thinking
        # preserve_thinking: keep <think> blocks in historical turns (Qwen 3.6+)
        if settings.preserve_thinking is not None:
            merged["preserve_thinking"] = settings.preserve_thinking

    if request_ct_kwargs:
        for key, value in request_ct_kwargs.items():
            if key not in forced_keys:
                merged[key] = value

    return merged


def merge_chat_template_kwargs(
    settings: "ModelSettings | None",
    request_ct_kwargs: "dict[str, Any] | None" = None,
    *,
    thinking_budget: "int | None" = None,
    preserve_thinking_default: "bool | None" = None,
) -> "dict[str, Any]":
    """Resolve the effective chat_template_kwargs for prompt rendering.

    Precedence, lowest to highest:
      1. ``settings.chat_template_kwargs``
      2. the dedicated ``enable_thinking`` / ``preserve_thinking`` toggles
      3. per-request kwargs, except keys listed in ``forced_ct_kwargs``
      4. positive thinking budget activation when ``enable_thinking`` is still unset
      5. the model's preserve-thinking default when it is supported and unset
    """
    merged = merge_chat_template_request_kwargs(settings, request_ct_kwargs)

    if (
        thinking_budget is None
        and settings is not None
        and settings.thinking_budget_enabled
        and settings.thinking_budget_tokens
    ):
        thinking_budget = settings.thinking_budget_tokens
    if (
        thinking_budget is not None
        and thinking_budget > 0
        and "enable_thinking" not in merged
    ):
        merged["enable_thinking"] = True

    if (
        preserve_thinking_default is True
        and merged.get("enable_thinking") is not False
        and "preserve_thinking" not in merged
    ):
        merged["preserve_thinking"] = True

    return merged
