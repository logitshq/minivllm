# Next NVFP4 matvec source study — CPU only
Status: one executable source hypothesis; numerical equivalence UNKNOWN; M4 speedup UNKNOWN; no adoption recommendation.
Scope: source/text reads only; no MLX import, GPU/model load, test, benchmark, app, source/raw edit or Git mutation.

## Candidate: narrow the existing fast-QMV output tile, independently per projection
For B1/T1 BF16 `x[1,1,5120]`, U32 `w[17408,640]`, U8 `scales[17408,320]`, gs16/bits4/nvfp4/no bias/global scale:
handwrite an isolated `fp_qmv_fast_impl`-equivalent with `results_per_simdgroup=2` instead of4.
Keep two SIMD groups (64 threads)/threadgroup; grid output groups change2176→4352, four output rows/group instead of8.
Leave gate/up as two separate matvecs, with original weights/scales/outputs; no concatenation, repacking or precision change.
Start with layer0 gate projection only; other shapes, B2/B4, prefill and unsupported dtypes use the original primitive.

## Source basis and limits
[S1] MLX0.32.3 `quantized.cpp:435–503` explicitly passes this template parameter and selects2 for large-N NVFP4 on M5 Max.
Its fast admission requires N divisible8 and K divisible512 for bits4;5120/17408 meet both. M4 follows4.
The M5 condition is donor evidence for a register-pressure tradeoff, not evidence of a missing M4 optimization or an M4 gain.
[S2] `fp_quantized.h` fast body has independent per-row accumulators, identical K/lane ownership and `simd_sum` for each row.
This reduces independent row accumulator/work per SIMD; it doubles groups and activation reloads. Already abundant groups may negate it.
[S3] Pinned Lithos `gemv_nvfp4_rows.metal:7–20,55–110` also exposes per-SIMD row count; `emit.py:628–652` specializes1-row static T1.
Lithos has different pack/input permutation, explicit FMA and epilogues: do not transplant its arithmetic or packed layout.
This candidate changes per-kernel output ownership only, unlike rejected V20 four-projection/V21 two-projection launch merging.

## Numerical contract
Preserve MLX qdot grouping of four FP32 products, four ordered subgroups per16 values, scale multiplication, then ordered K accumulation.
Each lane still consumes16 consecutive BF16 inputs/group;32 lanes cover512 columns, exactly10 iterations atK5120.
Decode FP4 E2M1 nibbles and U8 E4M3 scale identically; retain FP32 accumulators, same SIMD reduction and one final BF16 store.
No split-K, shuffle ladder, fused activation/norm, global scaling, sum reassociation or changed fast-math/contraction policy.
Source independence suggests possible bit equality, but changed compiler scheduling/unrolling means it must be proved, never assumed.

## Smallest validation before any engine work (optimizer-owned, not executed here)
Use the existing V21 layer0 gate tensor and saved BF16 inputs only; compare original matvec with r4-control custom kernel first.
Require exact BF16 bytes for all existing input scales and zero/finite cancellation edge cases; r4-control failure stops the approach.
Then compare r2 to both controls with identical inputs; any byte mismatch stops. B2/B4/fallback admission stays unchanged.
Only after exactness: one symmetric paired micro comparison r4 vs r2, identical residency/warmup/eval boundaries and resource gates.
Stop if no repeatable gain above existing micro noise; run no full model/E2E merely on the M5 donor rationale.
A positive micro still requires the existing forced-logit/cache/lifecycle checks and paired full-engine threshold before promotion.
C1 API spans do not identify QMV register pressure or bandwidth; they cannot support a predicted end-to-end percentage.
