# V22 prototype — not adopted
CPU only: `python test_cpu.py`; `python micro.py cpu --out <fresh-dir>`; `python micro.py --help`.
Root-only GPU command after review: `python micro.py run --out <fresh-dir>` under the four frozen V21 MLX environment controls.
Only layer0 gate weight/scales ranges are copied. No model or engine module import.
R4 must pass all nine exact BF16-byte cases before any R2 call; all27 comparisons must pass before the single timing schedule.
Full fp_quantized.h has unrelated GEMM dependencies: needed definitions plus fp4/fp8 small headers are flattened verbatim, with provenance/hash/ranges frozen.
No compiler math flag or contraction pragma. METAL_FUNC defaults to inline only if absent. K/N are Metal constant globals.
MLX source MIT notice/license retained. No Lithos arithmetic/layout copied. Compile, numerical and performance status remain UNKNOWN until root runs.
