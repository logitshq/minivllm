"""CPU tests for exact range loading and symmetric block schedule; no MLX."""
import ast
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('v22_micro', HERE / 'micro.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Tests(unittest.TestCase):
    def test_exact_range_metadata(self):
        table = {'chosen': {'dtype': 'U32', 'shape': [2, 2], 'data_offsets': [3, 19]}}
        raw = json.dumps(table).encode()
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'tiny.safetensors'
            p.write_bytes(struct.pack('<Q', len(raw)) + raw + b'pad' + bytes(range(16)) + b'untouched')
            meta = m.tensor_meta(p, 'chosen', 'U32', (2, 2))
            self.assertEqual(meta['offset'], 8 + len(raw) + 3)
            self.assertEqual(meta['nbytes'], 16)
            with self.assertRaises(AssertionError):
                m.tensor_meta(p, 'chosen', 'U8', (2, 2))
            p.write_bytes(p.read_bytes()[:-20])
            with self.assertRaises(AssertionError):
                m.tensor_meta(p, 'chosen', 'U32', (2, 2))

    def test_prime_schedule_equal(self):
        class MX:
            def synchronize(self): events.append('sync')
        signatures = []
        for variant in ('A', 'B'):
            events = []
            def invoke(v, j):
                self.assertEqual(v, variant)
                events.append(j)
                return [j] * m.SEGMENTS
            rec, output = m.block(MX(), invoke, variant)
            self.assertEqual(events, list(range(m.PRIME)) + ['sync'] + list(range(m.REPEATS)) + ['sync'])
            self.assertEqual(len(output), m.SEGMENTS)
            self.assertLessEqual(rec['prime_end_ns'], rec['start_ns'])
            self.assertLessEqual(rec['start_ns'], rec['end_ns'])
            signatures.append(events)
        self.assertEqual(signatures[0], signatures[1])

    def test_memmap_only_target_and_close_after_eval(self):
        events = []
        class Map:
            def __init__(self): self._mmap = self
            def close(self): events.append('close')
        class NP:
            def dtype(self, name): return name
            def array(self, mapping, copy):
                self_mapping = mapping
                events.append(('copy', copy, isinstance(self_mapping, Map)))
                return 'detached-host'
            def memmap(self, path, **kwargs):
                events.append((path, kwargs))
                return Map()
        class MX:
            def array(self, host): events.append(('array', host)); return 'tensor'
            def eval(self, value): events.append(('eval', value))
        meta = {'dtype': 'U32', 'path': '/tmp/fixture', 'offset': 123, 'shape': [2, 3]}
        self.assertEqual(m.load_range(NP(), MX(), meta), 'tensor')
        self.assertEqual(events, [('/tmp/fixture', {'mode': 'r', 'dtype': '<u4', 'offset': 123, 'shape': (2, 3)}),
                                  ('copy', True, True), ('array', 'detached-host'), ('eval', 'tensor'), 'close'])

    def test_new_direction_and_control_boundaries(self):
        self.assertEqual(m.LAYERS, (0,))
        self.assertEqual(m.ROWS, (17408,))
        self.assertEqual((m.PRIME, m.REPEATS, m.SEGMENTS), (128, 512, 1))
        self.assertTrue(m.control_passes({'A': [.98, 1.02], 'B': [1., 1.]}))
        self.assertFalse(m.control_passes({'A': [.97, .97], 'B': [1., 1.]}))
        self.assertFalse(m.control_passes({'A': [.949, 1.051], 'B': [1., 1.]}))

    def test_plan_and_no_whole_model_loading(self):
        self.assertEqual(len(m.ORDERS), 6)
        self.assertEqual(m.ORDERS.count(('A', 'B')), 3)
        self.assertEqual(m.ORDERS.count(('B', 'A')), 3)
        self.assertEqual(len(m.SCHEDULE), 10)
        self.assertEqual(m.SCHEDULE.count(('A', 'A')), 2)
        self.assertEqual(m.SCHEDULE.count(('B', 'B')), 2)
        source = (HERE / 'micro.py').read_text()
        tree = ast.parse(source)
        self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                             and n.func.attr == 'load' for n in ast.walk(tree)))
        self.assertNotIn('load_model(', source)
        self.assertIn('np.memmap(', source)
        self.assertIn("minimum_wins': 5", source)
        self.assertNotIn('clear_cache(', source)


    def test_target_identity_and_kernel_geometry(self):
        ident = m.identity()
        self.assertEqual(set(ident['tensors']), {0})
        self.assertEqual(len(ident['tensors'][0]), 1)
        self.assertEqual(ident['tensors'][0][0][0]['shape'], [17408, 640])
        self.assertEqual(ident['tensors'][0][0][1]['shape'], [17408, 320])
        class V:
            def __init__(self, shape, dtype): self.shape, self.dtype = shape, dtype
        class MX: bfloat16='bf16'; uint32='u32'; uint8='u8'
        for r, groups in ((4,2176),(2,4352)):
            def kernel(**kwargs):
                self.assertEqual(kwargs['grid'], (64,groups,1))
                self.assertEqual(kwargs['threadgroup'], (64,1,1))
                self.assertEqual(kwargs['template'], [('T','bf16'),('R',r)])
                return ['out']
            self.assertEqual(m.project(MX(),kernel,V((17408,640),'u32'),V((17408,320),'u8'),V((1,5120),'bf16'),r), 'out')
        body=(HERE/'kernel_body.metal').read_text(); header=(HERE/'kernel_header.metal').read_text()
        self.assertIn('uint3(0, threadgroup_position_in_grid.y, 0)', body)
        self.assertIn('local / 32, local % 32', body)
        self.assertIn('constant int v22_in_vec_size = 5120;', header)
        self.assertNotIn('pragma clang fp', header)


if __name__ == '__main__':
    unittest.main(verbosity=2)
