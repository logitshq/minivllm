"""CPU stdlib checks plus real Scheduler/LLMEngine with a small runner double."""
import ast
from collections import deque
import copy
from dataclasses import dataclass, field
import hashlib
import importlib.util
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace as NS
import unittest

D=Path(__file__).resolve().parent
P=D.parent
spec=importlib.util.spec_from_file_location("lifecycle_cpu_module",D/"lifecycle.py")
life=importlib.util.module_from_spec(spec);spec.loader.exec_module(life)
BASE=P/"candidate-v23-gdn-conv-build2-root/tutorial_code/miniengine"

def cpu_engine():
    ns={"__name__":__name__,"mx":NS(bfloat16="bf16",set_cache_limit=lambda n:None),"load_model":lambda *a,**k:(NS(),NS()),"read_eos_ids":lambda p:set()}
    for name in ("sampling_params.py","engine/request.py","engine/scheduler.py"):
        tree=ast.parse((BASE/name).read_text());tree.body=[n for n in tree.body if not isinstance(n,ast.ImportFrom) or n.level==0]
        exec(compile(tree,name,"exec"),ns)
    expected=json.loads((P/"workload.json").read_text())["continuation_ids"]
    class Runner:
        def __init__(self,*a):
            self.spec=None;self.staging={};self.feats={};self._ahead=None
            self.batch=NS(req_ids=[],lens=[],layers=[None]*64)
            self.discards=[]
        def run(self,out):
            result={}
            if out.decode:
                self.batch.req_ids=[r.req_id for r in out.decode]
                self.batch.lens=[r.num_computed_tokens+1 for r in out.decode]
                for r in out.decode:
                    self.staging.pop(r.req_id,None);result[r.req_id]=expected[len(r.output_token_ids)]
                self._ahead=True if not out.prefill and all(len(r.output_token_ids)+1<r.sampling.max_tokens for r in out.decode) else None
            for r,n in out.prefill:
                self.staging[r.req_id]=True
                result[r.req_id]=expected[0]
            return result
        def drop(self,rid):
            self.discards.append((rid,self._ahead is not None));self._ahead=None;self.staging.pop(rid,None)
            keep=[j for j,r in enumerate(self.batch.req_ids) if r!=rid]
            self.batch.req_ids=[self.batch.req_ids[j] for j in keep]
            self.batch.lens=[self.batch.lens[j] for j in keep]
            if not keep:self.batch.layers=[None]*64
    ns["ModelRunner"]=Runner
    tree=ast.parse((BASE/"engine/llm_engine.py").read_text());tree.body=[n for n in tree.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
    exec(compile(tree,"llm_engine.py","exec"),ns)
    return ns,expected

class Checks(unittest.TestCase):
    def test_compile_and_fixed_budget(self):
        for p in (D/"lifecycle.py",D/"check_cpu.py"):compile(p.read_text(),str(p),"exec")
        protocol=json.loads((D/"protocol.json").read_text())
        self.assertEqual(sum(p["tokens"] for p in protocol["phases"]),life.EXPECTED_TOTAL)
        self.assertEqual(life.EXPECTED_TOTAL,142);self.assertLessEqual(life.EXPECTED_TOTAL,200)
        tree=ast.parse((D/"lifecycle.py").read_text())
        imports=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))]
        self.assertFalse(any("mlx" in ast.unparse(n) for n in imports))
    def test_manifest_both_formats_and_mismatch(self):
        with TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/"tutorial_code/miniengine";source.mkdir(parents=True);f=source/"one.py";f.write_text("x=1\n")
            h=hashlib.sha256(f.read_bytes()).hexdigest();m=root/"manifest.json"
            for files,extra in [({"tutorial_code/miniengine/one.py":h},{}),({"one.py":h},{"source_root":str(source)})]:
                m.write_text(json.dumps(dict(files=files,**extra)));self.assertEqual(len(life.identity(root,m)["files"]),1)
            f.write_text("x=2\n")
            with self.assertRaises(AssertionError):life.identity(root,m)
    def test_manifest_requires_complete_package(self):
        with TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/"tutorial_code/miniengine";source.mkdir(parents=True);f=source/"one.py";f.write_text("x=1\n");(source/"unlisted.py").write_text("x=2\n")
            m=root/"manifest.json";m.write_text(json.dumps({"files":{"one.py":hashlib.sha256(f.read_bytes()).hexdigest()},"source_root":str(source)}))
            with self.assertRaises(AssertionError):life.identity(root,m)
    def test_toggle_invalidates_before_conv_at_idle(self):
        tree=ast.parse((D/"lifecycle.py").read_text());fn=copy.deepcopy(next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=="configure"))
        log=[];runner=NS(set_functional_decode=lambda on:log.append(("functional",on)))
        nets=[NS(set_conv_silu=lambda on:log.append(("conv",on)))]
        ns={"idle":lambda name:log.append(("idle",name)),"runner":runner,"nets":nets,"args":NS(conv=True,functional=True),"receipt":{"switches":[]},"parameter_identity":lambda:{},"parameter_before":{}}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),"<toggle>","exec"),ns)
        ns["configure"](True);self.assertEqual(log,[("idle","toggle"),("functional",False),("conv",True),("functional",True)])
        log.clear();ns["configure"](False);self.assertEqual(log,[("idle","toggle"),("functional",False),("conv",False)])
    def test_actual_engine_early_stop_ahead_discard(self):
        ns,expected=cpu_engine();engine=ns["LLMEngine"]("unused",max_seqs=2,max_len=256);params=ns["SamplingParams"](max_tokens=32,stop_token_ids=(220,))
        engine.add_request([1]*19,params,"early");values=[]
        for _ in range(40):
            if not engine.has_work():break
            values.extend(tok for rid,tok,done in engine.step())
        self.assertEqual(values,expected[:3]);self.assertIn(("early",True),engine.runner.discards)
        self.assertFalse(engine.requests);self.assertFalse(engine.runner.staging);self.assertIsNone(engine.runner._ahead)
        self.assertEqual(engine.step(),[]);self.assertFalse(engine.scheduler._finished_since_last_step)
    def test_actual_engine_c2_filter_admit(self):
        ns,expected=cpu_engine();engine=ns["LLMEngine"]("unused",max_seqs=2,max_len=256);S=ns["SamplingParams"]
        for name,count in (("short",3),("long",8)):engine.add_request([1]*19,S(max_tokens=count,ignore_eos=True),name)
        values={"short":[],"long":[]};admitted=False;filtered=False;reused=False
        for _ in range(80):
            if not engine.has_work():break
            for rid,tok,done in engine.step():values[rid].append(tok)
            if len(values["short"])==3 and not admitted:
                filtered=engine.runner.batch.req_ids==["long"]
                engine.add_request([1]*19,S(max_tokens=32,ignore_eos=True),"new");values["new"]=[];admitted=True
            reused |= engine.runner.batch.req_ids==["long","new"]
        self.assertTrue(filtered and reused);self.assertEqual(values,{"short":expected[:3],"long":expected[:8],"new":expected})
        self.assertFalse(engine.has_work());self.assertEqual(engine.step(),[]);self.assertFalse(engine.requests)
    def test_resource_and_real_interface_scope(self):
        text=(D/"lifecycle.py").read_text()
        for token in ['probe("afterload-beforetoken")','model-ready.json','state["steps"] % 4 == 0','probe("finally")','state["tokens"] <= args.max_total_tokens','state["steps"] < 200','stop_token_ids=(220,)','"abort_API_tested": False','helper.snapshot()','["hits"] > 0','parameter_identity() == parameter_before']:
            self.assertIn(token,text)
        self.assertEqual(text.count('engine = LLMEngine('),1)
        self.assertLess(text.index('probe("afterload-beforetoken")'),text.index('engine.add_request('))

if __name__=="__main__":unittest.main()
