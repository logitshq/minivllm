"""One-load actual LLMEngine lifecycle qualification; CPU default, root owns GPU."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import time
import traceback

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
P = D.parent
WORKLOAD = P / "workload.json"
EXPECTED_TOTAL = 142


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def identity(package_root, manifest_path):
    root = package_root.resolve()
    manifest = json.loads(manifest_path.read_text())
    files = manifest["files"]
    assert files and all(isinstance(v, str) and len(v) == 64 for v in files.values())
    prefixed = all(n.startswith("tutorial_code/miniengine/") for n in files)
    source = root if prefixed else root / "tutorial_code/miniengine"
    if not prefixed:
        assert Path(manifest["source_root"]).resolve() == source
    actual = {}
    for name, expected in files.items():
        path = (source / name).resolve()
        assert path.is_relative_to(source.resolve()) and path.suffix == ".py"
        actual[name] = sha(path)
        assert actual[name] == expected, ("source differs", name)
    expected_python = {str(p.relative_to(source)) for p in (root / "tutorial_code/miniengine").rglob("*.py")}
    assert expected_python == set(files), "source manifest must cover every package Python file"
    return {"package_root": str(root), "source_manifest": str(manifest_path.resolve()),
            "source_manifest_sha256": sha(manifest_path), "files": actual,
            "driver_sha256": sha(__file__), "workload_sha256": sha(WORKLOAD)}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--package-root", type=Path, required=True)
    ap.add_argument("--source-manifest", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--conv", action="store_true", help="V23 opt-in; default OFF")
    ap.add_argument("--functional", action="store_true", help="V24 adapter opt-in; default OFF")
    ap.add_argument("--max-total-tokens", type=int, default=200)
    ap.add_argument("--execute-gpu", action="store_true")
    args = ap.parse_args(argv)
    assert EXPECTED_TOTAL <= args.max_total_tokens <= 200
    ident = identity(args.package_root, args.source_manifest)
    if not args.execute_gpu:
        assert not any(n == "mlx" or n.startswith(("mlx.", "tutorial_code")) for n in sys.modules)
        print(json.dumps({"status": "CPU_READY_ONLY", "GPU_run": False, "identity": ident,
                          "expected_output_tokens": EXPECTED_TOTAL, "conv": args.conv, "functional": args.functional}))
        return 0
    versions = {n: importlib.metadata.version(n) for n in ("mlx", "mlx-metal")}
    assert versions == {"mlx": "0.32.3", "mlx-metal": "0.32.3"}
    args.out.mkdir(exist_ok=False)
    receipt = {"status": "STARTED", "identity": ident, "versions": versions, "phases": [],
               "events": [], "switches": [], "model_loads": 0, "performance_qualified": False,
               "E2E_benchmark_run": False, "adopted": False, "abort_API_tested": False,
               "early_stop_actual_interface": True, "max_output_tokens": args.max_total_tokens}
    resources = []
    mx = None
    original_drop = original_sync = original_conv = None
    started = time.perf_counter()
    write(args.out / "receipt.json", receipt)
    try:
        import mlx.core as mx
        sys.path.insert(0, str(args.package_root.resolve()))
        sys.path.insert(0, str(P))
        import resource_snapshot_power_v1 as resource
        from mlx.utils import tree_flatten
        from tutorial_code.miniengine.engine.llm_engine import LLMEngine
        from tutorial_code.miniengine.sampling_params import SamplingParams
        from tutorial_code.miniengine.engine.request import Status
        device = mx.device_info()
        assert mx.default_device() == mx.gpu and device.get("device_name") == "Apple M4 Max" and device.get("architecture") == "applegpu_g16s"
        receipt["device_info"] = device

        def probe(label):
            mx.synchronize()
            raw = resource.snapshot(label, os.getpid())
            write(args.out / ("resource-%03d-%s.json" % (len(resources), label)), raw)
            resources.append(raw)
            resource.deltas(resources)
            write(args.out / "resources.json", resources)
            resource.guard(resources)
            assert raw["pressure_level_value"] == 1
            assert raw["power_metadata"]["source"] == "AC Power"
            assert raw["processinfo_thermal_metadata"]["code"] in (0, 1)
            assert not [p for p in raw["known_inference_processes"] if p["pid"] != os.getpid()]

        probe("beforeload")
        workload = json.loads(WORKLOAD.read_text())
        expected = workload["continuation_ids"]
        assert len(expected) == 32 and expected[2] == 220 and 220 not in expected[:2]
        engine = LLMEngine(workload["model_dir"], max_seqs=2, max_len=256,
                           max_batched_tokens=512, dtype=mx.bfloat16, cache_limit_gb=2)
        receipt["model_loads"] = 1
        mx.synchronize()
        probe("afterload-beforetoken")
        write(args.out / "model-ready.json", {"pid": os.getpid(), "ready": True, "model_loads": 1})
        runner = engine.runner
        assert runner.spec is None
        nets = [layer.linear_attn for layer in engine.model.layers if not layer.is_attn]
        assert len(nets) == 48
        for net in nets:
            net.set_gates_compile(True)
            if hasattr(net, "set_conv_silu"):
                assert not object.__getattribute__(net, "_conv_silu_enabled")
        assert getattr(runner, "_functional_decode_helper", None) is None
        receipt["default_off_observed"] = True
        receipt["gates_enabled"] = True

        def parameter_identity():
            return {name: [id(value), list(value.shape), str(value.dtype)]
                    for name, value in tree_flatten(engine.model.parameters())}

        parameter_before = parameter_identity()
        state = {"phase": "initial", "steps": 0, "tokens": 0, "conv_python_calls": 0}
        if args.conv:
            assert all(hasattr(net, "set_conv_silu") for net in nets)
            from tutorial_code.miniengine.kernels import gdn_conv_silu_metal as conv_module
            original_conv = conv_module.conv_silu_raw_tail
            def conv_delegate(raw, tail, weight):
                state["conv_python_calls"] += 1
                return original_conv(raw, tail, weight)
            conv_module.conv_silu_raw_tail = conv_delegate

        original_drop = runner.drop
        def drop(req_id):
            before = {"batch_ids": list(runner.batch.req_ids), "had_ahead": runner._ahead is not None}
            result = original_drop(req_id)
            receipt["events"].append({"kind": "drop", "phase": state["phase"], "request": req_id,
                "before": before, "after_batch_ids": list(runner.batch.req_ids),
                "after_ahead_none": runner._ahead is None})
            return result
        runner.drop = drop
        original_sync = runner._sync_batch
        def sync_batch(decode):
            before = list(runner.batch.req_ids)
            result = original_sync(decode)
            receipt["events"].append({"kind": "sync_batch", "phase": state["phase"],
                "before_ids": before, "decode_ids": [r.req_id for r in decode],
                "after_ids": list(runner.batch.req_ids), "staging_ids": sorted(runner.staging)})
            return result
        runner._sync_batch = sync_batch

        def step():
            assert state["steps"] < 200, "bounded engine steps exceeded"
            result = engine.step()
            state["steps"] += 1
            state["tokens"] += len(result)
            assert state["tokens"] <= args.max_total_tokens, "bounded generated token count exceeded"
            if state["steps"] % 4 == 0:
                probe("step%03d" % state["steps"])
            return result

        def idle(label):
            assert not engine.has_work()
            assert step() == []  # Flush scheduler's completed-ID notification through the real API.
            mx.synchronize()
            s = engine.scheduler
            facts = {"requests_empty": not engine.requests, "staging_empty": not runner.staging,
                "batch_ids_empty": not runner.batch.req_ids, "batch_lens_empty": not runner.batch.lens,
                "batch_layers_empty": all(x is None for x in runner.batch.layers),
                "ahead_none": runner._ahead is None, "feats_empty": not runner.feats,
                "waiting_empty": not s.waiting, "running_empty": not s.running,
                "finished_notifications_empty": not s._finished_since_last_step,
                "all_slots_free": sorted(s.free_slots) == [0, 1]}
            assert all(facts.values()), (label, facts)
            assert parameter_identity() == parameter_before, "parameter object replacement"
            return facts

        def configure(on):
            idle("toggle")
            # Invalidate any compiled graphs before changing a captured conv opt-in.
            if hasattr(runner, "set_functional_decode"):
                runner.set_functional_decode(False)
            else:
                assert not (on and args.functional), "functional adapter absent"
            for net in nets:
                if hasattr(net, "set_conv_silu"):
                    net.set_conv_silu(on and args.conv)
            if on and args.functional:
                runner.set_functional_decode(True)
            receipt["switches"].append({"on": on, "conv": bool(on and args.conv),
                                         "functional": bool(on and args.functional)})
            assert parameter_identity() == parameter_before

        def add(req_id, count, early=False):
            params = SamplingParams(max_tokens=count, temperature=0.0,
                                    ignore_eos=False, stop_token_ids=(220,) if early else ())
            engine.add_request(workload["prompt_ids"], params, req_id=req_id)
            return engine.requests[req_id]

        def single(label, count=32, early=False):
            state["phase"] = label
            req = add(label, count, early)
            values = []
            while engine.has_work():
                for rid, token, finished in step():
                    assert rid == label
                    values.append(token)
            wanted = expected[:3] if early else expected[:count]
            assert values == wanted and req.output_token_ids == wanted, (label, values, wanted)
            assert req.status is (Status.FINISHED_STOP if early else Status.FINISHED_LENGTH)
            facts = idle(label)
            receipt["phases"].append({"phase": label, "ids": values, "status": req.status.name, "idle": facts})
            write(args.out / "receipt.json", receipt)
            return values

        configure(False)
        off_ids = single("off-normal32")
        assert state["conv_python_calls"] == 0
        configure(True)
        single("on-early-stop3", early=True)
        assert any(e["kind"] == "drop" and e["phase"] == "on-early-stop3" and e["before"]["had_ahead"] and e["after_ahead_none"] for e in receipt["events"]), "no observed early-stop ahead discard"
        assert single("on-fresh-after-stop32") == off_ids
        state["phase"] = "on-c2-filter-admit"
        short = add("c2-short", 3)
        long = add("c2-long", 8)
        values = {"c2-short": [], "c2-long": []}
        new_req = None
        observed = {"filtered_short_row": False, "new_admitted_during_long": False, "reused_batch_with_new": False}
        while engine.has_work():
            for rid, token, finished in step():
                assert rid in values
                values[rid].append(token)
            if short.is_finished and new_req is None:
                assert values["c2-short"] == expected[:3] and not long.is_finished
                assert runner.batch.req_ids == ["c2-long"] and "c2-short" not in runner.staging
                observed["filtered_short_row"] = True
                new_req = add("c2-new", 32)
                values["c2-new"] = []
            if new_req is not None and new_req.prompt_done and not long.is_finished:
                observed["new_admitted_during_long"] = True
            if runner.batch.req_ids == ["c2-long", "c2-new"]:
                observed["reused_batch_with_new"] = True
        assert all(observed.values()), observed
        assert values == {"c2-short": expected[:3], "c2-long": expected[:8], "c2-new": expected}
        assert all(req.status is Status.FINISHED_LENGTH for req in (short, long, new_req))
        receipt["phases"].append({"phase": state["phase"], "ids": values, "observed": observed, "idle": idle("c2")})
        if args.conv:
            assert state["conv_python_calls"] > 0, "conv never constructed on enabled path"
        helper = getattr(runner, "_functional_decode_helper", None)
        if args.functional:
            assert helper is not None
            receipt["functional_before_reset"] = helper.snapshot()
            assert receipt["functional_before_reset"]["hits"] > 0, "functional enabled but no warm cache hit"
        on_conv_calls = state["conv_python_calls"]
        configure(False)
        assert getattr(runner, "_functional_decode_helper", None) is None
        assert single("reset-off-normal32") == off_ids
        assert state["conv_python_calls"] == on_conv_calls, "conv still called after OFF reset"
        assert state["tokens"] == EXPECTED_TOTAL
        assert parameter_identity() == parameter_before
        final_idle = idle("final")
        receipt.update(status="PASS_ENGINE_LIFECYCLE", generated_tokens=state["tokens"], engine_steps=state["steps"],
            conv_python_construction_calls=state["conv_python_calls"], conv_calls_may_include_compile_traces=True,
            parameter_objects_unchanged=True, feature_reset_off=True, early_stop_ahead_discard_observed=True,
            C2_filter_admit_reuse_observed=True, final_idle=final_idle)
        probe("qualification-complete")
        return 0
    except BaseException as error:
        receipt.update(status="FAIL_STOP", error=repr(error), traceback=traceback.format_exc())
        raise
    finally:
        if original_drop is not None:
            runner.drop = original_drop
        if original_sync is not None:
            runner._sync_batch = original_sync
        if original_conv is not None:
            conv_module.conv_silu_raw_tail = original_conv
        receipt["wall_seconds"] = time.perf_counter() - started
        write(args.out / "receipt.json", receipt)
        if mx is not None and "probe" in locals():
            try:
                probe("finally")
            except BaseException as error:
                receipt.update(status="FAIL_STOP", final_resource_error=repr(error))
                write(args.out / "receipt.json", receipt)
                raise


if __name__ == "__main__":
    raise SystemExit(main())
