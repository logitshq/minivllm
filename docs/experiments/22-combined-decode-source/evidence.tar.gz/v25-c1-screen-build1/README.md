# V25 C1 HTTP paired screen

CPU-prepared harness; source A/B are frozen. Execution requires actual combination fullmodel and lifecycle PASS receipts. No GPU/model has been imported or run by this preparation.

A uses accepted25 manifest 31fa0539…b5cb41c with gates ON. B uses combined27 manifest 54f76862…67e06af with gates, conv+SiLU and functional decode ON. Both use allocator cache limit 2 GiB, prefix cache 0, BF16, max_seqs 4/max_len 2048/max_batched_tokens 512, greedy normal EOS, no draft, 19 prompt IDs and 32 actual output IDs. Four Metal buffer controls are 50/50/20/0 through the original bootstrap.

The fixed plan is six fresh server processes: pair1 A→B, pair2 B→A, pair3 A→B. Each receives exactly three warm and three measured C1 requests. Request/group and HTTP Handler AST are unchanged from m4-final-native15-official-attempt2; X is the original client chunk delivery estimate and Y is 32 / POST-to-SSE-DONE window. Resource probes are outside requests, with original AC thermal0/1, pressure1 and paging guards. Original per-step shim traces remain equal in A/B. No decode or gates hooks are installed at any time.

B warm eligibility uses helper misses=31/hits=62/entries=31, zero failures/fallbacks/evictions/invalidations, 48 gates callables and enabled conv flags. Python GDN-call counts are not asserted because compiled traces bypass Python on hits. Parameter object identity is unchanged after switches and warmup; warm publication occurs at idle with batch empty and ahead cleared. All six requests per arm require raw IDs = visible canonical IDs = pinned continuation32.

Root creates the following bridge after actual qualification is available. Each actual receipt must have status beginning PASS and contain the combined-source manifest SHA. This bridge references existing qualification; it cannot make failed or pending receipts eligible.

```json
{"source_manifest_sha256":"54f76862eb05d7ef8a28ad877afa43b4b08a1bb400c4347af18318c3767e06af","combo_fullqual":{"path":"/absolute/PASS/receipt.json","sha256":"ACTUAL_SHA"},"lifecycle":{"path":"/absolute/PASS/receipt.json","sha256":"ACTUAL_SHA"}}
```

```sh
/Users/ryanli/code/minivllm/.venv/bin/python -B /private/tmp/minivllm-engine-optimization-20261014/v25-c1-screen-build1/driver.py --cpu-dry-run
/Users/ryanli/code/minivllm/.venv/bin/python -B /private/tmp/minivllm-engine-optimization-20261014/v25-c1-screen-build1/driver.py --run --eligibility /absolute/eligibility.json --output /private/tmp/minivllm-engine-optimization-20261014/v25-c1-screen-build1/output-attempt1
```

Use root's external owner wrapper, empty selected parent controls, exclusive GPU ownership and an immutable new output directory. Per-child readiness/request timeout remains 180s. Driver SIGTERM enters finally: verify exact birth, TERM10/KILL15/wait15, strict PID absence and port refusal. Root's wrapper owns the overall deadline, driver wait/reap and final external exact-PID absence. Receipt leaves GPU_released=false pending that external proof. Stop on first failure; preserve old output, with no automatic retry.

Expected duration: six model loads plus 36 short requests; allow 10–15 min external owner deadline. Weights dominate memory; the sole child has a 2 GiB allocator-cache ceiling, while the driver holds tokenizers/HTTP metadata. This is not a total GPU-memory cap. Output reports three paired X/Y ratios and wins. No new adoption threshold, official-engine comparison, E2E promotion, or Pareto claim follows from this screen alone.

cpu-checks.json records parse/compile, original AST boundaries and inert dry-run; it is not GPU numerical evidence. manifest.json binds this ready harness and reused resource/runtime inputs. Old source, raw evidence, ready packages and Git state are unchanged.
