"""Native token-ID engine with original loopback SSE/queue shim; no engine hooks."""
import argparse,builtins,hashlib,inspect,json,os,queue,sys,threading,time,traceback
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from support import *
from identity import SOURCES,preimport,imported_runtime,verify_source
pending=queue.Queue();ready=threading.Event();fail=[];live={};trace=[];runtime_identity={}
def work():
 try:
  import mlx.core as mx
  import mlx.nn as nn
  import mlx.nn.layers.activations as activations
  actual_runtime=imported_runtime(pre,mx,nn,activations)
  from tutorial_code.miniengine.engine.llm_engine import LLMEngine
  from tutorial_code.miniengine.sampling_params import SamplingParams
  from tutorial_code.miniengine.model.gdn import GatedDeltaNet
  import tutorial_code.miniengine as actual_package
  from mlx.utils import tree_flatten
  actual_root=Path(actual_package.__file__).resolve().parent
  assert str(actual_root)==pre['source']['package_root']
  source=verify_source(a.arm)
  e=LLMEngine(a.model,max_seqs=4,max_len=2048,max_batched_tokens=512,dtype=mx.bfloat16,cache_limit_gb=2)
  def parameter_metadata():
   rows=[]
   for key,value in tree_flatten(e.model.parameters()):
    assert isinstance(value,mx.array)
    rows.append({'key':key,'shape':list(value.shape),'dtype':str(value.dtype),'python_array_identity':builtins.id(value)})
   return rows
  gdns=[layer.linear_attn for layer in e.model.layers if not layer.is_attn]
  assert len(gdns)==48 and all(type(g) is GatedDeltaNet for g in gdns)
  parameters=parameter_metadata();assert len(parameters)==1349
  assert all(g._gates_compile_enabled is False and g._compiled_decode_gates is None for g in gdns)
  for g in gdns:g.set_gates_compile(True)
  if a.arm=='B':
   assert all(g._conv_silu_enabled is False for g in gdns) and e.runner._functional_decode_helper is None
   for g in gdns:g.set_conv_silu(True)
   e.runner.set_functional_decode(True)
  assert parameters==parameter_metadata()
  def metadata():
   flags=[g._gates_compile_enabled for g in gdns];assert all(v is True for v in flags)
   helper=None if a.arm=='A' else e.runner._functional_decode_helper.snapshot()
   conv=[] if a.arm=='A' else [g._conv_silu_enabled for g in gdns]
   assert a.arm=='A' or (all(v is True for v in conv) and helper is not None)
   return {'gates':{'enabled':True,'count':48,'flags':flags,'compiled_callable_count':sum(callable(g._compiled_decode_gates) for g in gdns)},'conv_flags':conv,'functional':helper,'hooks_installed':False,'measurement_hook_free':True,'parameter_tree_unchanged':parameters==parameter_metadata(),'parameter_array_count':len(parameters)}
  runtime_identity.update({'arm':a.arm,'manifest_all_sources_match':True,'source':source,'actual_runtime':actual_runtime,'allocator_cache_limit_bytes':2<<30,'prefix_cache':0,'startup':metadata(),'server_max_seqs':4,'scheduler':{'max_len':2048,'max_batched_tokens':512},'scope':'same original queue/HTTP shim and step trace in both arms; no decode/gates hooks'})
  write_new(a.run_dir/'startup-metadata.json',runtime_identity)
  completed_requests=0;warm_metadata_written=False
  mx.synchronize();mx.clear_cache();ready.set()
  while True:
   if not e.has_work(): job=pending.get();rid=e.add_request(job['ids'],SamplingParams(max_tokens=job['max_tokens'],temperature=0,ignore_eos=False));live[rid]=job
   while True:
    try: job=pending.get_nowait()
    except queue.Empty: break
    rid=e.add_request(job['ids'],SamplingParams(max_tokens=job['max_tokens'],temperature=0,ignore_eos=False));live[rid]=job
   s=time.perf_counter();results=e.step();end=time.perf_counter()
   trace.append({'start_s':s,'end_s':end,'delivered_ids':len(results),'active_decode_batch':e.runner.batch.size,'pending_requests':len(e.requests)})
   for rid,id,done in results:
    job=live[rid];job['queue'].put((id,done,end))
    if done:live.pop(rid,None);completed_requests+=1
   if not e.has_work():
    if completed_requests==3 and not warm_metadata_written:
     assert e.runner._ahead is None and e.runner.batch.size==0 and not e.requests and not live
     meta=metadata();assert meta['parameter_tree_unchanged'] and meta['gates']['compiled_callable_count']==48
     if a.arm=='B':
      h=meta['functional'];assert h['misses']==31 and h['hits']==62 and h['entries']==31 and h['failures']==h['fallbacks']==h['evictions']==h['invalidations']==0,h
     meta.update(completed_requests=3,scope='idle after exactly three warm requests; host metadata only; no values/eval/logits/state reads')
     write_new(a.run_dir/'warm-metadata-pending.json',meta)
     (a.run_dir/'warm-metadata-pending.json').rename(a.run_dir/'warm-metadata.json');warm_metadata_written=True
    a.trace.write_text(json.dumps({'runtime_source_identity':runtime_identity,'steps':trace,'mlx_active_bytes':mx.get_active_memory(),'mlx_peak_bytes':mx.get_peak_memory(),'scope':'MLX allocator incl weights/cache, not RSS/system memory'},indent=2))
 except BaseException:
  fail.append(traceback.format_exc());ready.set();print(fail[-1],flush=True)

class Handler(BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def do_GET(self):
  if not ready.is_set() or fail:self.send_error(503);return
  body=json.dumps({'data':[{'id':'tutorial-core'}],'benchmark_identity':runtime_identity}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def do_POST(self):
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])));ids=tok.encode(body['prompt'],add_special_tokens=False).ids
  q=queue.Queue();pending.put({'ids':ids,'max_tokens':body['max_tokens'],'queue':q})
  self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Cache-Control','no-cache');self.send_header('Connection','close');self.end_headers()
  def send(d):self.wfile.write(('data: '+json.dumps(d,ensure_ascii=False)+'\n\n').encode());self.wfile.flush()
  out=[];previous=''
  while True:
   t,done,when=q.get(timeout=180);out.append(t);decoded=tok.decode(out,skip_special_tokens=True).rstrip('\ufffd')
   assert decoded.startswith(previous),(decoded,previous)
   piece=decoded[len(previous):];previous=decoded
   if piece:send({'choices':[{'text':piece,'finish_reason':None}],'benchmark_delivery':{'emitted_id_ordinal':len(out),'id':t,'engine_delivery_perf_counter':when}})
   if done:break
  eos=out[-1] in {248044,248046};n=len(out)-int(eos)
  send({'choices':[{'text':'','finish_reason':'stop' if eos else 'length'}],'usage':{'prompt_tokens':len(ids),'completion_tokens':n,'total_tokens':len(ids)+n,'prompt_tokens_details':{'cached_tokens':0}},'benchmark_output_ids':out})
  self.wfile.write(b'data: [DONE]\n\n');self.wfile.flush();self.close_connection=True

def main():
 global a,pre,tok
 ap=argparse.ArgumentParser();ap.add_argument('--arm',choices=['A','B'],required=True);ap.add_argument('--model',required=True);ap.add_argument('--port',type=int,required=True);ap.add_argument('--trace',type=Path,required=True);ap.add_argument('--run-dir',type=Path,required=True);ap.add_argument('--owner-pid',type=int,required=True);a=ap.parse_args()
 assert os.getppid()==a.owner_pid
 boot.environment(os.environ,'50',child=True)
 pre=preimport(a.arm);write_new(a.run_dir/'preimport-child.json',{'pid':os.getpid(),'ppid':os.getppid(),'identity':pre,'environment':boot.environment_record(os.environ)})
 sys.path.insert(0,SOURCES[a.arm]['root'])
 from tokenizers import Tokenizer
 tok=Tokenizer.from_file(str(Path(a.model)/'tokenizer.json'))
 threading.Thread(target=work,daemon=True).start()
 ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
if __name__=='__main__':main()
