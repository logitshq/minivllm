"""Six fresh C1 arms AB/BA/AB. CPU dry-run is inert; --run needs actual qualification receipts."""
import argparse,json,os,secrets,signal,socket,statistics,subprocess,sys,time,traceback
from pathlib import Path
from support import *
from identity import SOURCES,verify_source,eligibility
PLAN=[{'label':f'pair{i+1}-{arm}','pair':i+1,'arm':arm} for i,order in enumerate(['AB','BA','AB']) for arm in order]
def lock_identity(proc,birth,run_dir,phase):
 if proc.poll() is not None:return birth
 current=identity(proc.pid)
 if current is None:return birth
 assert birth is not None and current==birth,'owned native identity changed; no signal authorized'
 assert process_parent(proc.pid)['ppid']==os.getpid(),'not exact direct Popen child'
 write_new(run_dir/('owned-'+phase+'-identity.json'),{'pid':proc.pid,'owner_pid':os.getpid(),'identity_words':current,'unchanged_exact_identity':True})
 return current
def validate_warm(meta,arm):
 assert meta['completed_requests']==3 and meta['parameter_tree_unchanged'] is True and meta['hooks_installed'] is False and meta['measurement_hook_free'] is True
 assert meta['gates']['enabled'] is True and meta['gates']['count']==48 and meta['gates']['compiled_callable_count']==48 and all(v is True for v in meta['gates']['flags'])
 if arm=='A':assert meta['functional'] is None and meta['conv_flags']==[]
 else:
  h=meta['functional'];assert h['misses']==31 and h['hits']==62 and h['entries']==31 and h['failures']==h['fallbacks']==h['evictions']==h['invalidations']==0
  assert len(meta['conv_flags'])==48 and all(v is True for v in meta['conv_flags'])
def run_one(item,output,shared):
 import httpx
 from tokenizers import Tokenizer
 from boundary import bind
 arm=item['arm'];run_dir=output/item['label'];run_dir.mkdir();samples=[];proc=None;lf=None;birth=None;port=None;first_error=None;cleanup_errors=[];report=None;exit_record=None
 def sample(label):return probe(samples,run_dir/'resource-snapshots.json',label,'AC',proc.pid if proc else None)
 try:
  source=verify_source(arm);w=json.loads((P/'workload.json').read_text());model=Path(w['model_dir'])
  assert model.name=='5ff8ef173ad0d7c3aae92f0be43031a6ab8067c6' and len(w['prompt_ids'])==19 and len(w['continuation_ids'])==32
  tok=Tokenizer.from_file(str(model/'tokenizer.json'));prompt=tok.decode(w['prompt_ids'],skip_special_tokens=False);assert tok.encode(prompt,add_special_tokens=False).ids==w['prompt_ids']
  with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
  key='benchmark-'+secrets.token_urlsafe(24);env=child_environment(os.environ)
  shared.setdefault('environment',dict(env));assert env==shared['environment'],'identical arm environment required'
  command=[PYTHON,'-B',str(D/'server.py'),'--arm',arm,'--model',str(model),'--port',str(port),'--trace',str(run_dir/'engine-trace.json'),'--owner-pid',str(os.getpid()),'--run-dir',str(run_dir)]
  write_new(run_dir/'launch.json',{'command':command,'environment':boot.environment_record(env),'selected_environment':selected(env),'source':source,'allocator_cache_limit_bytes':2<<30,'prefix_cache':0,'gates':True,'conv':arm=='B','functional':arm=='B','hooks_installed':False,'shim':'original HTTP/queue/step trace unchanged'})
  sample('before-model-launch');start=time.perf_counter();lf=(run_dir/'server.log').open('w');proc=subprocess.Popen(command,stdout=lf,stderr=subprocess.STDOUT,env=env)
  write_new(run_dir/'owned-pid.json',{'pid':proc.pid,'ppid':os.getpid()});birth=identity(proc.pid);assert birth is not None,'child exited before ownership capture'
  write_new(run_dir/'owned-birth.json',{'pid':proc.pid,'ppid':os.getpid(),'identity_words':birth,'birth_start_words':birth[:5]})
  base=f'http://127.0.0.1:{port}';headers={'Authorization':'Bearer '+key}
  with httpx.Client(headers=headers,trust_env=False,timeout=180) as c:
   while True:
    if proc.poll() is not None:raise RuntimeError('owned server exited before ready')
    try:
     resp=c.get(base+'/v1/models',timeout=1)
     if resp.status_code==200:break
    except httpx.HTTPError:pass
    if time.perf_counter()-start>180:raise TimeoutError('readiness')
    time.sleep(.2)
  ready_s=time.perf_counter()-start;exact_listener(proc.pid,port,run_dir/'server-ready-exact-listener.json');birth=lock_identity(proc,birth,run_dir,'ready')
  runtime_identity=resp.json()['benchmark_identity'];assert runtime_identity['manifest_all_sources_match'] is True and runtime_identity['source']['manifest_sha256']==SOURCES[arm]['manifest_sha256']
  assert runtime_identity['allocator_cache_limit_bytes']==2<<30 and runtime_identity['prefix_cache']==0
  name=resp.json()['data'][0]['id'];sample('server-ready-before-warmup')
  path='/v1/completions';body={'model':name,'prompt':prompt,'temperature':0,'repetition_penalty':1.0,'max_tokens':32}
  group=bind(httpx,headers,base,path,body,tok);groups={};metadata=None
  for phase in ['warm','measure']:
   groups[phase]=[]
   for i in range(3):
    gid=f'C1-{phase}-{i}';sample('before-'+gid);result=group(1,gid)
    write_new(run_dir/(gid+'.json'),result);groups[phase].append(result);sample('after-'+gid)
   if phase=='warm':
    deadline=time.monotonic()+30
    while not (run_dir/'warm-metadata.json').exists():
     assert proc.poll() is None,'child exited before warm metadata'
     if time.monotonic()>deadline:raise TimeoutError('warm metadata')
     time.sleep(.01)
    metadata=json.loads((run_dir/'warm-metadata.json').read_text());validate_warm(metadata,arm);sample('after-three-warmup-groups-before-measurement')
  sample('after-measurement-before-unload')
  requests=[q for phase in ['warm','measure'] for g in groups[phase] for q in g['requests']]
  assert len(requests)==6 and all(q['output_ids_when_available']==q['visible_roundtrip_ids']==w['continuation_ids'] for q in requests),'canonical raw32 pinned continuation mismatch'
  report={'schema':'v25-c1-screen-arm-v1',**item,'warmup_groups':3,'repeat':3,'warmups':groups['warm'],'runs':groups['measure'],'runtime_source_identity':runtime_identity,'post_warm_metadata':metadata,'ready_s':ready_s,'prompt_ids':w['prompt_ids'],'continuation_ids':w['continuation_ids'],'model_dir':str(model),'checkpoint_revision':model.name,'config_sha256':sha(model/'config.json'),'activation_dtype':'bfloat16','sampling':{'temperature':0,'output_cap':32,'EOS':'normal','draft':None},'scheduler':{'max_seqs':4,'max_len':2048,'max_batched_tokens':512},'prefix_cache':0,'allocator_cache_limit_bytes':2<<30,'boundary':'unchanged original POST start through SSE DONE; cleanup excluded','x_definition':'median (32-reconstructed first nonempty chunk token count)/(DONE-first text); client delivery estimate','y_definition':'32 actual completion tokens / POST-through-DONE group window; HTTP/queue/prefill included','median_x_client_estimated_interactivity_tok_s_user':statistics.median(g['x_client_estimated_interactivity_tok_s_user'] for g in groups['measure']),'median_y_total_output_throughput_tok_s_mac':statistics.median(g['y_total_output_throughput_tok_s_mac'] for g in groups['measure']),'source_identity':verify_source(arm),'environment':boot.environment_record(env),'hooks_installed':False,'scope':'C1 HTTP paired screen only; no official comparator or adoption claim'}
 except BaseException as exc:
  first_error=exc;write_new(run_dir/'first-failure.json',{'type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),'raw_groups_preserved':True})
 finally:
  if proc is not None:
   try:
    birth=lock_identity(proc,birth,run_dir,'pre-cleanup');exit_record=cleanup_owned(proc,birth,run_dir/'cleanup-signal-identities.json');write_new(run_dir/'owned-process-exit.json',exit_record)
   except BaseException as exc:cleanup_errors.append({'phase':'wait-reap-absence','type':type(exc).__name__,'error':str(exc)})
  if port is not None:
   try:write_new(run_dir/'port-absence.json',wait_port_absence(port))
   except BaseException as exc:cleanup_errors.append({'phase':'port-absence','type':type(exc).__name__,'error':str(exc)})
  try:probe(samples,run_dir/'resource-snapshots.json','after-owned-server-unload-finally','AC')
  except BaseException as exc:cleanup_errors.append({'phase':'postflight','type':type(exc).__name__,'error':str(exc)})
  if lf is not None:lf.close()
  write_new(run_dir/'cleanup.json',{'first_error':None if first_error is None else str(first_error),'cleanup_errors':cleanup_errors,'exit_record':exit_record})
 if first_error is not None:raise first_error
 if cleanup_errors:raise RuntimeError('cleanup/postflight failed: '+str(cleanup_errors))
 report.update(resource_snapshots=samples,owned_process_exit=exit_record);write_new(run_dir/'result.json',report)
 return {**item,'report':str(run_dir/'result.json'),'report_sha256':sha(run_dir/'result.json'),'x':report['median_x_client_estimated_interactivity_tok_s_user'],'y':report['median_y_total_output_throughput_tok_s_mac'],'actual_requests':6,'actual_completion_tokens':192}
def main(argv=None):
 ap=argparse.ArgumentParser();m=ap.add_mutually_exclusive_group(required=True);m.add_argument('--cpu-dry-run',action='store_true');m.add_argument('--run',action='store_true');ap.add_argument('--eligibility',type=Path);ap.add_argument('--output',type=Path,default=D/'output');a=ap.parse_args(argv)
 sources={arm:verify_source(arm) for arm in ['A','B']}
 if a.cpu_dry_run:
  assert not any(n=='mlx' or n.startswith('mlx.') for n in sys.modules)
  print(json.dumps({'status':'PASS_CPU_DRY_RUN','plan':PLAN,'source_counts':{k:v['count'] for k,v in sources.items()},'live_actions':0,'MLX_imported':False,'qualification_pending':True}));return 0
 assert a.eligibility is not None,'--run requires actual combo numeric + lifecycle PASS receipts'
 eligible=eligibility(a.eligibility)
 assert sys.executable==PYTHON and not selected(os.environ) and not any(n=='mlx' or n.startswith('mlx.') for n in sys.modules)
 output=a.output;output.mkdir();completed=[];shared={};samples=[];error=None;cleanup_errors=[]
 def stop(sig,frame):raise KeyboardInterrupt('owned driver signal '+str(sig))
 old=signal.signal(signal.SIGTERM,stop)
 try:
  write_new(output/'execution-plan.json',{'plan':PLAN,'eligibility':eligible,'source_identities':sources,'driver_pid':os.getpid(),'fresh_loads':6,'requests':36,'measured_requests':18,'actual_completion_tokens':1152,'warmups_per_arm':3,'measure_per_arm':3,'GPU_released':False})
  probe(samples,output/'owner-resource-derived.json','owner-before-first-model','AC')
  for item in PLAN:
   print(json.dumps({'event':'ARM_STARTED',**item}),flush=True);completed.append(run_one(item,output,shared));write_new(output/(item['label']+'-validated.json'),completed[-1]);print(json.dumps({'event':'ARM_COMPLETED',**item}),flush=True)
  assert eligibility(a.eligibility)==eligible
  assert {arm:verify_source(arm) for arm in ['A','B']}==sources
 except BaseException as exc:
  error={'type':type(exc).__name__,'text':str(exc),'traceback':traceback.format_exc()};write_new(output/'suite-failure.json',{'first_error':error,'completed_arms':len(completed),'raw_groups_preserved':True,'no_automatic_retry':True})
 finally:
  try:probe(samples,output/'owner-resource-derived.json','owner-finally-postflight','AC')
  except BaseException as exc:cleanup_errors.append({'type':type(exc).__name__,'text':str(exc)})
  signal.signal(signal.SIGTERM,old);write_new(output/'owner-cleanup.json',{'pid':os.getpid(),'completed_arms':len(completed),'first_error':error,'cleanup_errors':cleanup_errors,'GPU_released':False,'external_tool_wait_reap_and_exact_absence_required':True})
 if error or cleanup_errors:return 1
 assert len(completed)==6 and sum(r['actual_requests'] for r in completed)==36
 pairs=[]
 for i in range(1,4):
  rows={r['arm']:r for r in completed if r['pair']==i}
  pairs.append({'pair':i,'order':'AB' if i!=2 else 'BA','A':rows['A'],'B':rows['B'],'x_B_over_A':rows['B']['x']/rows['A']['x'],'y_B_over_A':rows['B']['y']/rows['A']['y']})
 receipt={'status':'PASS_C1_HTTP_PAIRED_SCREEN_AWAIT_EXTERNAL_RELEASE','pairs':pairs,'median_pair_x_B_over_A':statistics.median(p['x_B_over_A'] for p in pairs),'median_pair_y_B_over_A':statistics.median(p['y_B_over_A'] for p in pairs),'x_wins':sum(p['x_B_over_A']>1 for p in pairs),'y_wins':sum(p['y_B_over_A']>1 for p in pairs),'eligibility':eligible,'source_identities':sources,'actual_requests':36,'actual_completion_tokens':1152,'measured_requests':18,'measured_completion_tokens':576,'GPU_released':False,'scope':'three C1 HTTP pairs with original client boundary; screen only; no default-on, Pareto, model-only or official-engine claim'}
 write_new(output/'receipt.json',receipt);print(json.dumps({'event':'DRIVER_FINISHED','status':receipt['status'],'median_pair_x_B_over_A':receipt['median_pair_x_B_over_A'],'median_pair_y_B_over_A':receipt['median_pair_y_B_over_A'],'GPU_released':False}),flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
