"""Small source/runtime/qualification checks. Import is CPU-only."""
import importlib.metadata as md,json,sys
from pathlib import Path
from support import P,D,PYTHON,sha,boot
SOURCES=json.loads((D/'sources.json').read_text())
COMBO_SHA=SOURCES['B']['manifest_sha256']
def verify_source(arm):
 c=SOURCES[arm];root=Path(c['root']);pkg=root/'tutorial_code/miniengine';manifest=Path(c['manifest'])
 assert sha(manifest)==c['manifest_sha256'],'source manifest changed'
 declared=json.loads(manifest.read_text())['files']
 expected={k.removeprefix('tutorial_code/miniengine/'):v for k,v in declared.items()}
 actual={str(p.relative_to(pkg)):sha(p) for p in pkg.rglob('*.py')}
 assert actual==expected and len(actual)==c['count'],'actual source differs from manifest'
 return {'root':str(root),'package_root':str(pkg),'manifest':str(manifest),'manifest_sha256':sha(manifest),'files':actual,'count':len(actual)}
def preimport(arm):
 assert sys.executable==PYTHON,'wrong interpreter'
 assert not any(n=='mlx' or n.startswith(('mlx.','tutorial_code.')) for n in sys.modules),'preloaded runtime/model namespace'
 versions={n:md.version(n) for n in ('mlx','mlx-metal')};assert set(versions.values())=={'0.32.3'}
 plan=json.loads((P/'v18-activation-runtime-identity-build3.json').read_text())
 checks={}
 for group in ('required_modules','source_modules','native_images'):
  rows=plan[group]['required'] if group=='native_images' else plan[group]
  if isinstance(rows,dict):rows=rows.values()
  for rec in rows:
   assert sha(rec['path'])==rec['sha256'],'runtime byte mismatch: '+rec['path'];checks[rec['path']]=rec['sha256']
 rec=plan['metal_library'];assert sha(rec['path'])==rec['sha256'],'Metal library mismatch';checks[rec['path']]=rec['sha256']
 return {'source':verify_source(arm),'versions':versions,'runtime_files':checks,'required_modules':plan['required_modules']}
def imported_runtime(pre,mx,nn,activations):
 for name,module in [('mlx.core',mx),('mlx.nn',nn),('mlx.nn.layers.activations',activations)]:
  rec=pre['required_modules'][name];assert Path(module.__file__).resolve()==Path(rec['path']).resolve() and sha(rec['path'])==rec['sha256']
 device=mx.metal.device_info();assert mx.default_device()==mx.gpu and device['device_name']=='Apple M4 Max' and device['architecture']=='applegpu_g16s'
 return {'device':device,'versions':pre['versions'],'required_modules':pre['required_modules']}
def contains(value,needle):
 if isinstance(value,dict):return any(contains(v,needle) for v in value.values())
 if isinstance(value,list):return any(contains(v,needle) for v in value)
 return value==needle
def eligibility(path):
 bridge=json.loads(Path(path).read_text());assert bridge['source_manifest_sha256']==COMBO_SHA
 refs={}
 for key in ('combo_fullqual','lifecycle'):
  ref=bridge[key];assert sha(ref['path'])==ref['sha256'],key+' receipt changed'
  receipt=json.loads(Path(ref['path']).read_text());status=receipt['status']
  assert isinstance(status,str) and status.startswith('PASS'),key+' requires actual PASS receipt'
  assert contains(receipt,COMBO_SHA),key+' must bind actual combo source manifest'
  refs[key]={'path':ref['path'],'sha256':ref['sha256'],'status':status}
 return {'bridge_path':str(Path(path).resolve()),'bridge_sha256':sha(path),'source_manifest_sha256':COMBO_SHA,'receipts':refs}
