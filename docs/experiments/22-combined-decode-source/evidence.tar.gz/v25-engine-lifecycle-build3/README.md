# V25 engine lifecycle runner
CPU-authored generic runner; root owns every actual GPU/model run. Candidate source is never modified.
Explicit `--package-root` is the directory containing tutorial_code; `--source-manifest` must list every miniengine Python file with SHA. Both V23 prefixed-file and V24/V25 source_root-relative formats are supported.
Conv and functional flags default OFF. Gates are ON for both sides. OFF32 → OFF C2 max3/8 then admit32 reference → ON stop-token220 after3 → fresh32 → ON identical C2 compared with actual OFF IDs → resetOFF32 =185 generated tokens (hard token and step bounds200).
Use the actual LLMEngine.add_request/step and SamplingParams stop interface. No abort API is invented or claimed. Early-stop drop instrumentation records a pending ahead and its removal; C2 checks row filtering while long request remains, new admission, reused batch, exact IDs and final idle.
At idle, clear functional cache first, change conv flag, then enable requested functional helper; no switch while ahead pending. Parameter object IDs/shapes/dtypes must remain unchanged. Functional snapshot must contain warm hits before reset; conv Python construction count may include compiler traces and is not GPU invocation count.
This is lifecycle output-ID correctness, not another strict full-cache numeric qualification, HTTP throughput test, or adoption.
Root must first qualify the exact combination source numerically. Internal resources: raw beforeload/afterload-beforetoken/every4 engine steps/finally; original guard plus AC/thermal0or1/pressure1/foreign-none. Root external owner supplies ongoing monitoring, timeout and owned child reap.
One model load through LLMEngine, cache limit2GiB, max_seqs2/max_len256; no duplicate weights. Live batch/ahead state can have2 rows; no state-memory qualification is inferred.
CPU: `python3 -B check_cpu.py`; help: `python3 -B lifecycle.py --help`.
Example actual child (root owner only; new output directory):
```
/Users/ryanli/code/minivllm/.venv/bin/python -B /private/tmp/minivllm-engine-optimization-20261014/v25-engine-lifecycle-build3/lifecycle.py --package-root /private/tmp/minivllm-engine-optimization-20261014/candidate-v25-combined-build1-root --source-manifest COMBINED_MANIFEST --out NEWDIR --conv --functional --execute-gpu
```
Without --execute-gpu, verifies source SHA and reports CPU_READY_ONLY without importing MLX or creating output.
Root uses fixed env50/50/20/FAST0 and serial GPU ownership, identical to fullmodel qualification.
