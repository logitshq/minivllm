# V25 combined conv+functional fullmodel numerical worker

CPU preparation only. No MLX/NumPy import, resource sampling, device/GPU/model execution or performance measurement occurred here. Original accepted, V23, V24 and all old raw evidence remain unchanged. No result from an individual component is inherited as a combined PASS.

## Immutable source composition

`../candidate-v25-combined-build1-root` contains27 Python files: the entire V23 fixed-conv build2 parent, replacing only ModelRunner with frozen V24 adapter and adding the byte-identical functional helper. Source manifest/diff are in `../v25-combined-source-build1`; manifest SHA is54f76862eb05d7ef8a28ad877afa43b4b08a1bb400c4347af18318c3767e06af. Functional helper SHA48aafe7ae7e6053b7fd3f10dbe75b2761e7ca855d42b02d4f0f183af478f9309; adapter runner SHAa1385a586ffeb56c0f5844ba55e6e63fdf01a2d84f957528bb85edfc0b17b77d. Conv and functional remain independent defaultOFF opt-ins; the ordinary gates configuration is unchanged.

For future service use, enable all48 ordinary gates and choose the conv opt-in **before** enabling the functional adapter; the helper then expects frozen weights/configuration/opt-ins. This numerical worker does not construct the service adapter or claim its lifecycle PASS. It uses the same model instance as two controlled routes: original Python model with conv metadataOFF for A, functional helper invoked exclusively with conv metadataON for B. A's temporary OFF calls never invoke or reuse candidate compiled entries. Every B trace/invocation is ON; existing B graphs keep their ON trace. Only object metadata is toggled, no weights or source code.

## Root-only argv

```sh
/Users/ryanli/code/minivllm/.venv/bin/python -B /private/tmp/minivllm-engine-optimization-20261014/v25-combined-fullqual-build1/fullqual.py --out NEW_ABSOLUTE_DIRECTORY --tokens 32
```

`--inert`/`--help` are CPU-safe, and absent/invalid output arguments fail before runtime. The outer root owner handles sole-GPU resources, timeout, wait/reap and exact final absence. The worker pins the actual27-source package, workload/checkpoint metadata, original resource helpers and component manifest, then verifies imported paths/hashes. It loads one actual model, requires MLX/mlx-metal0.32.3/GPU, explicitly sets allocator cache limit2GiB, enables all48 ordinary gates, checks conv defaultOFF and supported M4 backend, and preserves model parameter identity.

One original prefill uses the fixed19 prompt IDs. A convOFF/original and B convON/functional separately advance the32 greedy outputs over31 exact-L cold graphs (L20..50). Every decode compares complete logits and128 full-capacity K/V/conv/S arrays, shape/dtype/finite/strict actual BF16/FP32 bytes, raw A/B logits, retained external input readonly, IDs and EOS against the fixed workload. Extra K[:]/V[:] wrappers isolate original BatchKV.write from retained inputs; GDN arrays are reassigned. The reference is the qualified conv-parent's OFF arithmetic, not a second loaded model.

After the cold chain, the same candidate helper reuses the existing L20 graph twice from the retained original prefill state: original seed token79852, then predeclared distinct legal token48213. A remains convOFF and B ON. Both warm cases again check all logits/128states/input readonly. Each must add one actual helper hit with no miss. Repeated original inputs must match first cold decode; the token contrast must keep identical input state and observably change original output, with candidate strictly equal. Expected final helper counts:31misses/2hits/31entries. This is a controlled extra numerical probe, not another autonomous generation or service run.

The same original Resources/Numeric implementation from the qualified V24 cold worker is preserved in this new worker. Original raw resource snapshots are saved before derived annotations, with original guard plus pressure1/knownAC/thermal0or1/no-known-foreign conditions. Points are beforeload, synchronized-afterload before any token, every4 cold decode steps, after the two warm cases, and finally. Model-ready signals successful load/guard before prefill. Conv metadata resetsOFF in finally; a final synchronization/resource/reset failure changes verdict to FAIL_STOP.

First mismatch stops and keeps failure stage/raw bytes. Only a completed run can report PASS_V25_COMBINED_32_GREEDY_AND_WARM_NUMERICAL_ONLY. Host fncall/eval durations are instrumented numerical bookkeeping, not performance; allocator active/cache/peak and process RSS are not compiled-program-cache bytes (unknown/null). Functional graph reuse is not called an ICB. Source composition, CPU AST and inert checks do not prove actual compiled conv engagement, numerical correctness, service/ahead lifecycle or speedup. Service lifecycle qualification remains required before any measurement.
