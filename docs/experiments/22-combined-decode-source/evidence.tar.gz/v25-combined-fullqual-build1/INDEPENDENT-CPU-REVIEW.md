# V25 combined fullqual CPU cross-review
PASS for the stated cold-chain + two warm-token cases; CPU only, no GPU/numeric qualification.
Driver SHA 215a27d752ad5cbe2527fc9ee420fd91558ac3f5ab12cd2328cd8015fa742fef
Source manifest SHA 54f76862eb05d7ef8a28ad877afa43b4b08a1bb400c4347af18318c3767e06af; all27 actual Python files match39 source pins.
A invokes original model with conv OFF; B invokes functional helper only with conv ON. Gates ON both; one model load and unchanged parameter-object identity.
All31 decode outputs compare full logits and128 full-capacity K/V/conv/S arrays: shape/dtype/finite/actual raw-byte equality.
Retained independent K/V view handles protect original BatchKV writes; both A/B retained inputs rechecked after both branches; shared prefill inputs checked finally.
31 exact-L cold entries required. Existing L20 entry then receives seed79852 and distinct token48213; each must hit once without a miss, stay exact to original, and contrast output must change.
Warm state values remain identical across the two probes; changed-state warm is outside this run, as explicitly accepted by root.
Raw resource snapshots/guards beforeload, synchronized afterload beforetoken, every4decode, afterwarm and finally; final failures force FAIL_STOP.
No service adapter construction/lifecycle, E2E, performance or adoption claim. Root external owner remains responsible for timeout/PID cleanup.
AST/compile + help + inert PASS; inert confirms39 pins, no MLX import/GPU.
