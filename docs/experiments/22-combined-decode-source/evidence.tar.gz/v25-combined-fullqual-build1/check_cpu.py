"""AST/source identity and inert checks only; no MLX/NumPy/resource execution."""
from pathlib import Path
import ast
import builtins
import contextlib
import hashlib
import importlib.util
import io
import json
import sys

D = Path(__file__).resolve().parent
SOURCE = D.parent / "candidate-v25-combined-build1-root"


def main():
    manifest = json.loads((D.parent / "v25-combined-source-build1/manifest.json").read_text())
    files = sorted(SOURCE.rglob("*.py"))
    actual = {f.relative_to(SOURCE).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
    assert actual == manifest["files"] and len(files) == 27
    for f in files + [D / "fullqual.py"]:
        compile(ast.parse(f.read_text(), filename=str(f)), str(f), "exec")
    for f in [D / "fullqual.py", SOURCE / "tutorial_code/miniengine/kernels/functional_decode.py"]:
        for node in ast.parse(f.read_text()).body:
            if isinstance(node, ast.Import):
                assert all(x.name.split(".")[0] not in ("mlx", "numpy", "tutorial_code") for x in node.names)
            elif isinstance(node, ast.ImportFrom):
                assert (node.module or "").split(".")[0] not in ("mlx", "numpy", "tutorial_code")
    before = set(sys.modules)
    original = builtins.__import__
    def guarded(name, *args, **kwargs):
        if name.split(".")[0] in ("mlx", "numpy", "tutorial_code"):
            raise AssertionError("Forbidden inert import: " + name)
        return original(name, *args, **kwargs)
    builtins.__import__ = guarded
    try:
        spec = importlib.util.spec_from_file_location("v25_combined_inert", D / "fullqual.py")
        worker = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(worker)
        worker.module = lambda *a, **k: (_ for _ in ()).throw(AssertionError("Runtime module in inert mode"))
        with contextlib.redirect_stdout(io.StringIO()) as output:
            assert worker.main(["--inert"]) == 0
        assert json.loads(output.getvalue())["status"] == "CPU_INERT_ONLY"
        for argv in ([], ["--inert", "--tokens", "31"]):
            try:
                worker.main(argv)
            except ValueError:
                pass
            else:
                raise AssertionError("Invalid CLI admitted")
    finally:
        builtins.__import__ = original
    assert not any(n.split(".")[0] in ("mlx", "numpy", "tutorial_code") for n in set(sys.modules)-before)
    result = dict(status="CPU_AST_INERT_SOURCE_PASS_ONLY", source_py_count=27,
        source_manifest_sha256=hashlib.sha256((D.parent / "v25-combined-source-build1/manifest.json").read_bytes()).hexdigest(),
        fullqual_sha256=hashlib.sha256((D / "fullqual.py").read_bytes()).hexdigest(),
        inert_cases=3, MLX_imported=False, NumPy_imported=False,
        resource_snapshot_executed=False, GPU_initialized=False, model_loaded=False,
        actual_combined_numeric_qualification=False)
    (D / "CPU-RESULT.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
