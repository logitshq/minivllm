# Independent v21 MLP2→1 prelaunch CPU review — PASS for frozen exploratory micro
2026-10-16；仅CPU stdlib diff/source/header/历史input读取与5tests/--help；无MLX/GPU/model/探针执行；未改source/raw。
Driver SHA256: c42c704ce1709e5e4f71d5cf3610a2436f8a47fbc95d8d537bc3efb38dee6961
Test SHA256: bfe64547df695f87221987f61a381191804f754960b4db1e1d0fc5cf47aebc82
与已审v20逐hunk对照；5个CPU tests及--help均rc0，identity()未import MLX/tutorial模块。
新方向为MLP gate_proj/up_proj，各17408行，selected L0/32/63；无GDN qkv/z/b/a混入。
12个目标tensor为U32[17408,640]/U8[17408,320]，合300810240B；memmap明确offset/shape，不load完整shard或27B。
继承修复：np.array(mapping,copy=True)先detach，再mx.array+eval，finally close；组构建/首次call在timing外。
同一冻结generic helper两段row concat/split；spy检查总N34816、U32/U8布局及NVFP4 group16/bits4，需恰一次packed QMM。
8个synthetic BF16 timing输入先eval且hash唯一；每次invoke新建projection并eval全3组×2段，未预存输出或只消费gate。
每block对称prime128/repeat512；6对均衡AB/BA+前后AA/BB；CPU hash只在两block完成后，探针在pair外。
tight control要求每variant两次slot2/slot1中位[.98,1.02]且各次[.95,1.05]；未过优先CONTROL_DRIFT_STOP，测试覆盖边界拒绝。
性能门仍median降≥5%且≥5/6胜；不按结果加warm、扩样或改阈值。CPU PASS不证明这些门已过。
历史input来自swiglu-actual-micro-build1/gpu-actual-micro-run1/receipt.json，固定SHA94a9f5ab7ae3780f306e66d71e4f3b0f2fb559eef4d5a89ae179ef63ef3355c8。
旧receipt A_status=ACTUAL64_NUMERIC_PASS、整体status=STOP_BUILD1；不把旧STOP变成性能通过。CaptureHooks在normal decode MLP调用入口保存原x。
L0/32/63三份raw BF16均[1,5120]/10240B，文件SHA逐一匹配receipt且CPU解码全finite；历史V17/gates ON输入，本轮未capture。
历史real仅独立数值checks，不进入timing pool；byte预期3×(8 synthetic+1历史real+2 fallback B2/B4)×2段=66。
原refs删除及active前后口径沿用审计；300810240B为目标原payload，不是总峰值或物理内存释放证明。
每探针实际要求Battery、thermal0、pressure1、Swapouts等于首样本且swapMB不增长；known matcher0不排除所有外部GPU使用。
继承直接Popen-owned child的170s wait/异常poll terminate-kill-wait；finally严格ps rc1+stdout/stderr literal empty，rc2为正常STOP。
PASS仅允许root唯一GPU owner执行此精确冻结小组实验；adopted/full_model_qualified/E2E_run/AC_frontier_entry均false。
不继承GDN资格或旧21.9%收益；历史real输入/新N变化/完整MLP与全模型性能均不得据CPU审计提前宣称。
