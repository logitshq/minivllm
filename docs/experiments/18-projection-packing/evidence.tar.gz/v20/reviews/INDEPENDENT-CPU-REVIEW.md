# Independent prelaunch CPU review — PASS (frozen exploratory micro only)
2026-10-16；CPU stdlib review、CPU tests/--help only；无MLX/GPU/模型/资源探针执行；未修改实现。
Driver SHA256: 6f2b41217dbe7d0ea46316aa4f30cd953c0f31c002f6b3bf6f2d30f45ace135a
Test SHA256: 1201c19eeba39794586f6b88af5191733be57311d2b21ad609094f5650b968c7
完整首版362行及tests已读；最终修段/上述SHA复验，CPU tests与--help均rc0。
load_range只memmap明确offset+shape范围；无mx.load/load_model/全shard读取，selected3八tensor/组共142,387,200B原payload。
已修原阻点：np.array(mapping, copy=True)先detach，再mx.array+eval，finally才close mmap；不再以eval推定map已脱离。
同一旧v16 helper，按qkv/z/b/a row concat+split；构建及首次call都在计时外；spy要求每组选定slab恰一次QMM。
8个预声明synthetic BF16输入经eval后hash唯一；每次invoke新建projection表达式并eval全部12段，无预计算output池。
同x跨组使用不同真实权重；复用8个input不等同复用evaluated outputs，未见可使timed调用被裁除的同图CSE。
每variant固定prime16、repeats64，统一同步，全部四段消费；hash在两block都结束后，资源探针在pair外。
AA/BB各前后一次，6个AB/BA均衡；控制中位[.90,1.10]且每次[.80,1.20]，失败优先CONTROL_DRIFT_STOP。
性能门固定median降≥5%且≥5/6胜；任何strict byte失败立即child FAIL-STOP，未见tol放宽/选择性输出。
Byte样本为selected3×synthetic8×四段，加B2/B4原fallback；不认证真实GDN输入、T19/T33或full48。
原refs明确删除且局部alias清理；记录deleted reference payload与active before/after，不能由字段名推为物理allocation释放已证。
没有内存阈值参与EXPLORATORY-PASS；仅报告selected3观测，未把它作为full48或adoption内存资格。
170s监督wait；异常时poll后terminate/kill并wait；finally严格ps rc1、stdout和stderr均literal empty。rc2是正常STOP。
Battery domain与50/50/20/FAST0均实际断言；root仍须在GPU启动前检查环境/sole ownership，并保存实际runtime与resource证据。
PASS仅允许运行该冻结小组探索；不会证明timer stationarity、数值、内存或性能结果，均待root唯一GPU owner实测。
旧attempt2 STOP-MICRO-GATE完整保留；adopted/full_model_qualified/E2E_run/AC_frontier_entry均false。
