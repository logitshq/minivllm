#!/usr/bin/env python3
"""Battery exploration of three GDN projections; no full model or adoption.

CPU check reads only source and safetensor headers. GPU mode is root-only and
loads only selected tensor ranges via numpy.memmap, never a complete shard.
"""
import argparse
import copy
import gc
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import statistics
import struct
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
P = BASE.parent
ROOT = P / 'candidate-v16-gdn-projection-build1-root'
MANIFEST = P / 'source-manifest-v16-gdn-projection-build1.json'
CHECKPOINT = Path('/Users/ryanli/.cache/huggingface/hub/models--mlx-community--Qwen3.8-27B-nvfp4/snapshots/5ff8ef173ad0d7c3aae92f0be43031a6ab8067c6')
LAYERS, ROWS = (0, 32, 62), (10240, 6144, 48, 48)
NAMES = ('in_proj_qkv', 'in_proj_z', 'in_proj_b', 'in_proj_a')
Q = {'group_size': 16, 'bits': 4, 'mode': 'nvfp4'}
K, SEED, PRIME, REPEATS, PAIRS = 5120, 20261016, 16, 64, 6
ORDERS = (('A', 'B'), ('B', 'A')) * 3
SCHEDULE = (('A', 'A'), ('B', 'B')) + ORDERS + (('A', 'A'), ('B', 'B'))
CONTROLS = {'MLX_MAX_OPS_PER_BUFFER': '50', 'MLX_MAX_MB_PER_BUFFER': '50',
            'MLX_BFS_MAX_WIDTH': '20', 'MLX_METAL_FAST_SYNCH': '0'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def utc():
    return datetime.now(timezone.utc).isoformat()


def header(path):
    with Path(path).open('rb') as f:
        raw_size = f.read(8)
        assert len(raw_size) == 8, 'Truncated safetensors prefix'
        size = struct.unpack('<Q', raw_size)[0]
        assert 0 < size < (64 << 20), 'Invalid header size'
        raw = f.read(size)
    assert len(raw) == size, 'Truncated safetensors header'
    return json.loads(raw), 8 + size, hashlib.sha256(raw).hexdigest()


def tensor_meta(path, key, dtype, shape, parsed=None):
    table, data_start, header_sha = parsed or header(path)
    item = table[key]
    assert item['dtype'] == dtype and item['shape'] == list(shape), (key, item)
    lo, hi = item['data_offsets']
    width = {'U32': 4, 'U8': 1}[dtype]
    assert type(lo) is type(hi) is int and 0 <= lo < hi
    assert hi - lo == math.prod(shape) * width and data_start + hi <= Path(path).stat().st_size
    return {'path': str(path), 'key': key, 'dtype': dtype, 'shape': list(shape),
            'offset': data_start + lo, 'nbytes': hi - lo, 'header_sha256': header_sha}


def identity():
    manifest = json.loads(MANIFEST.read_text())
    source = ROOT / 'tutorial_code/miniengine'
    assert Path(manifest['source_root']) == source
    for name, rec in manifest['files'].items():
        assert sha(source / name) == rec['after_sha256'], name
    index_path = CHECKPOINT / 'model.safetensors.index.json'
    index = json.loads(index_path.read_text())['weight_map']
    parsed, tensors = {}, {}
    for layer in LAYERS:
        tensors[layer] = []
        for name, n in zip(NAMES, ROWS):
            fields = []
            for suffix, dtype, shape in [('weight', 'U32', (n, K // 8)), ('scales', 'U8', (n, K // 16))]:
                tail = f'.layers.{layer}.linear_attn.{name}.{suffix}'
                keys = [key for key in index if key.endswith(tail)]
                assert len(keys) == 1, tail
                key = keys[0]
                path = CHECKPOINT / index[key]
                if path not in parsed:
                    parsed[path] = header(path)
                fields.append(tensor_meta(path, key, dtype, shape, parsed[path]))
            tensors[layer].append(fields)
    config = json.loads((CHECKPOINT / 'config.json').read_text())
    assert config['quantization'] == Q and config['text_config']['hidden_size'] == K
    return {'driver_sha256': sha(__file__), 'source_manifest_sha256': sha(MANIFEST),
            'source_root': str(source), 'checkpoint': str(CHECKPOINT), 'tensors': tensors,
            'index_sha256': sha(index_path), 'config_sha256': sha(CHECKPOINT / 'config.json'),
            'resource_wrapper_sha256': sha(P / 'resource_snapshot_power_v1.py'),
            'plan': {'layers': LAYERS, 'rows': ROWS, 'seed': SEED, 'prime': PRIME,
                     'repeats': REPEATS, 'orders': ORDERS, 'schedule': SCHEDULE,
                     'position_control': {'median_slot2_div_slot1_bounds': [.90, 1.10],
                                          'each_pair_bounds': [.80, 1.20]},
                     'controls': CONTROLS, 'input_kind': 'synthetic only',
                     'input_pool': ['zero', 'alternating cancellation', 'random amp1/16',
                                    'random amp1', 'random amp16', 'random0.25a', 'random0.25b', 'random0.25c'],
                     'minimum_median_reduction': 0.05, 'minimum_wins': 5,
                     'power_domain': 'Battery exploration', 'full_model': False}}


def load_range(np, mx, meta):
    """Map exactly one tensor and detach it before the MLX constructor."""
    dtype = np.dtype('<u4' if meta['dtype'] == 'U32' else 'u1')
    mapping = np.memmap(meta['path'], mode='r', dtype=dtype,
                        offset=meta['offset'], shape=tuple(meta['shape']))
    try:
        host = np.array(mapping, copy=True)
        value = mx.array(host)
        mx.eval(value)
        return value
    finally:
        mapping._mmap.close()


def block(mx, invoke, variant):
    """The same prime and synchronizations precede either timed variant."""
    prime_utc, prime_begin = utc(), time.perf_counter_ns()
    for j in range(PRIME):
        result = invoke(variant, j)
    mx.synchronize()
    prime_end = time.perf_counter_ns()
    start_utc = utc()
    begin = time.perf_counter_ns()
    for j in range(REPEATS):
        result = invoke(variant, j)
    mx.synchronize()
    end = time.perf_counter_ns()
    return {'variant': variant, 'prime_start_utc': prime_utc,
            'prime_start_ns': prime_begin, 'prime_end_ns': prime_end,
            'prime_repeats': PRIME, 'start_utc': start_utc, 'end_utc': utc(),
            'start_ns': begin, 'end_ns': end, 'total_ns': end - begin,
            'ns_per_call': (end - begin) / REPEATS, 'repeats': REPEATS,
            'groups_per_call': 3, 'segments_per_call': 12}, result


def gpu(out, ident):
    import numpy as np
    import mlx.core as mx
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(P))
    from tutorial_code.miniengine.model import layers, projection_packing as packing
    from resource_snapshot_power_v1 import snapshot, deltas, guard
    assert layers.prefill_batch_backend_supported() and importlib.metadata.version('mlx') == '0.32.3'
    resources, checks, records, startups, pairs = [], [], [], [], []
    runtime = {'mlx': mx.__file__, 'mlx_version': importlib.metadata.version('mlx'),
               'device_info': mx.metal.device_info(), 'default_device': str(mx.default_device()),
               'source': {m.__name__: {'path': m.__file__, 'sha256': sha(m.__file__)} for m in (layers, packing)},
               'controls': {key: os.environ.get(key) for key in os.environ if key.startswith('MLX_')},
               'power_domain': 'Battery exploration', 'full_model_loaded': False}
    assert all(os.environ.get(key) == value for key, value in CONTROLS.items()), CONTROLS
    write(out / 'runtime.json', runtime)

    def probe(label):
        mx.synchronize()
        s = snapshot(label, os.getpid())
        s['mlx_memory'] = {'active': mx.get_active_memory(), 'cache': mx.get_cache_memory(), 'peak': mx.get_peak_memory()}
        resources.append(s)
        deltas(resources)
        write(out / 'resources.json', resources)
        guard(resources)
        assert s['power_metadata']['status'] == 'known' and s['power_metadata']['source'] == 'Battery Power'
        assert s['processinfo_thermal_metadata']['status'] == 'known' and s['processinfo_thermal_metadata']['code'] <= 1
        assert s['known_inference_process_count'] == 0 and s['exact_owned_pid_metadata']['status'] == 'known'
        return s

    def raw(value):
        return np.asarray(mx.contiguous(value).view(mx.uint16)).tobytes()

    def compare(left, right, label):
        mx.eval(left, right)
        item = {'label': label, 'shape': list(left.shape), 'dtype': str(left.dtype)}
        assert left.shape == right.shape and left.dtype == right.dtype == mx.bfloat16, item
        lb, rb = raw(left), raw(right)
        item.update(finite=bool(mx.all(mx.isfinite(left)).item() and mx.all(mx.isfinite(right)).item()),
                    left_sha256=hashlib.sha256(lb).hexdigest(), right_sha256=hashlib.sha256(rb).hexdigest(),
                    differing_bytes=sum(a != b for a, b in zip(lb, rb)), nbytes=len(lb))
        item['exact'] = item['finite'] and lb == rb
        checks.append(item)
        write(out / 'bytes.json', checks)
        assert item['exact'], ('Strict byte failure', item)

    probe('fresh-no-model')
    rng = np.random.default_rng(SEED)
    host = [np.zeros((1, K), np.float32), np.tile(np.array([1., -1.], np.float32), K // 2)[None]]
    host += [(rng.standard_normal((1, K)) * amp).astype(np.float32) for amp in (0.0625, 1, 16, .25, .25, .25)]
    pool = [mx.array(x, dtype=mx.bfloat16) for x in host]
    mx.eval(*pool)
    assert len({hashlib.sha256(raw(x)).hexdigest() for x in pool}) == 8
    write(out / 'inputs.json', [{'id': j, 'shape': list(x.shape), 'dtype': str(x.dtype),
                                'raw_sha256': hashlib.sha256(raw(x)).hexdigest(), 'synthetic': True} for j, x in enumerate(pool)])
    for layer in LAYERS:
        started = time.perf_counter_ns()
        ops = []
        for n, (wm, sm) in zip(ROWS, ident['tensors'][layer]):
            op = layers.Linear(K, n, dict(Q))
            op.weight, op.scales = load_range(np, mx, wm), load_range(np, mx, sm)
            ops.append(op)
        ops = tuple(ops)
        refs = tuple(copy.copy(op) for op in ops)
        assert all(r is not op and r.weight is op.weight and r.scales is op.scales for r, op in zip(refs, ops))
        group = packing.pack_projection_group(ops)
        assert group is not None and group.layout == (K, ROWS)
        records.append({'layer': layer, 'ops': ops, 'refs': refs, 'group': group})
        starts = {'layer': layer, 'load_pack_ns': time.perf_counter_ns() - started}
        original_qmm, seen = mx.quantized_matmul, []

        def spy(*args, **kwargs):
            if args[1] is group.weight:
                assert args[2] is group.scales and args[1].shape == (16480, 640)
                assert kwargs == dict(transpose=True, group_size=16, bits=4, mode='nvfp4')
                seen.append(1)
            return original_qmm(*args, **kwargs)

        try:
            mx.quantized_matmul = spy
            first_begin = time.perf_counter_ns()
            part = group.project(pool[0], ops)
            assert part is not None and len(part) == 4
            mx.eval(*part)
            starts['first_packed_ns'] = time.perf_counter_ns() - first_begin
        finally:
            mx.quantized_matmul = original_qmm
        assert seen == [1]
        starts['packed_qmm_count'] = len(seen)
        startups.append(starts)
        write(out / 'startup.json', startups)
        for j, x in enumerate(pool):
            left, right = tuple(r(x) for r in refs), group.project(x, ops)
            assert right is not None and len(right) == 4
            for name, n, l, r in zip(NAMES, ROWS, left, right):
                assert l.shape == r.shape == (1, n)
                compare(l, r, f'L{layer}.input{j}.{name}')
        for b in (2, 4):
            x = mx.concatenate([pool[3]] * b, axis=0)
            assert group.project(x, ops) is None
            for name, n, ref, op in zip(NAMES, ROWS, refs, ops):
                left, right = ref(x), op(x)
                assert left.shape == right.shape == (b, n)
                compare(left, right, f'L{layer}.fallbackB{b}.{name}')
        probe(f'layer{layer}-strict-pass')
    del op, ref, refs, ops, group, left, right, l, r, x, part, spy

    def invoke(variant, j):
        outputs = []
        for rec in records:
            x = pool[j % 8]
            part = tuple(op(x) for op in rec['refs']) if variant == 'A' else rec['group'].project(x, rec['ops'])
            assert part is not None and len(part) == 4
            outputs.extend(part)
        assert len(outputs) == 12
        mx.eval(*outputs)
        return outputs

    probe('timing-ready')
    for index, order in enumerate(SCHEDULE):
        probe(f'pair{index}-before')
        a, ao = block(mx, invoke, order[0])
        b, bo = block(mx, invoke, order[1])
        # Both timed blocks have finished before any CPU output conversion/hash.
        for rec, output in ((a, ao), (b, bo)):
            rec['hashes'] = [hashlib.sha256(raw(v)).hexdigest() for v in output]
        assert a['hashes'] == b['hashes'], 'Paired output hashes differ'
        item = {'pair': index, 'order': order, 'blocks': [a, b],
                'kind': 'position-control' if order[0] == order[1] else 'AB',
                'slot2_div_slot1': b['ns_per_call'] / a['ns_per_call']}
        if item['kind'] == 'AB':
            by = {a['variant']: a, b['variant']: b}
            item['reduction'] = 1 - by['B']['ns_per_call'] / by['A']['ns_per_call']
        pairs.append(item)
        write(out / 'pairs.json', pairs)
        del ao, bo, output
        probe(f'pair{index}-after')
    ab_pairs = [p for p in pairs if p['kind'] == 'AB']
    control = {v: [p['slot2_div_slot1'] for p in pairs if p['kind'] == 'position-control' and p['order'][0] == v] for v in ('A', 'B')}
    control_ok = all(len(ratios) == 2 and .90 <= statistics.median(ratios) <= 1.10
                     and all(.80 <= ratio <= 1.20 for ratio in ratios) for ratios in control.values())
    medians = {v: statistics.median(next(b['ns_per_call'] for b in p['blocks'] if b['variant'] == v) for p in ab_pairs) for v in ('A', 'B')}
    reduction, wins = 1 - medians['B'] / medians['A'], sum(p['reduction'] > 0 for p in ab_pairs)
    before_release = probe('before-release-originals')
    payload = sum(r.weight.nbytes + r.scales.nbytes for rec in records for r in rec['refs'])
    for rec in records:
        del rec['refs']
    gc.collect()
    after_release = probe('after-release-originals-no-clear-cache')
    status = 'CONTROL_DRIFT_STOP' if not control_ok else ('EXPLORATORY-PASS' if reduction >= .05 and wins >= 5 else 'STOP-MICRO-GATE')
    result = {'status': status, 'control_passed': control_ok, 'control_slot2_div_slot1': control,
              'power_domain': 'Battery exploration', 'all_bytes_exact': True, 'checks': len(checks),
              'medians_ns': medians, 'median_reduction': reduction, 'wins': wins, 'pairs': PAIRS,
              'minimum_reduction': .05, 'minimum_wins': 5, 'released_original_payload_bytes': payload,
              'active_before_release': before_release['mlx_memory']['active'],
              'active_after_release': after_release['mlx_memory']['active'],
              'scope': 'Synthetic selected3 projections only; no physical buffer-sharing claim',
              'adopted': False, 'full_model_qualified': False, 'E2E_run': False, 'AC_frontier_entry': False}
    write(out / 'result.json', result)
    return 0 if result['status'] == 'EXPLORATORY-PASS' else 2


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode', choices=('cpu', 'run', 'child'))
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    ident = identity()
    if args.mode == 'cpu':
        args.out.mkdir(exist_ok=False)
        assert not any(k == 'mlx' or k.startswith(('mlx.', 'tutorial_code')) for k in sys.modules)
        write(args.out / 'cpu.json', {'status': 'CPU-SOURCE-HEADER-PASS', 'identity': ident,
                                      'mlx_imported': False, 'GPU_used': False, 'tensor_payload_loaded': False})
        print('CPU source/header checks passed; no MLX/GPU/model/payload/resource calls')
        return 0
    if args.mode == 'child':
        try:
            return gpu(args.out, ident)
        except BaseException as exc:
            write(args.out / 'failure.json', {'status': 'FAIL-STOP', 'error': repr(exc),
                  'traceback': traceback.format_exc(), 'pid': os.getpid(), 'adopted': False})
            traceback.print_exc()
            return 1
        finally:
            write(args.out / 'child-finally.json', {'pid': os.getpid(), 'utc': utc(), 'exiting': True})
    args.out.mkdir(exist_ok=False)
    write(args.out / 'identity.json', ident)
    argv = [sys.executable, str(Path(__file__).resolve()), 'child', '--out', str(args.out)]
    with (args.out / 'child.log').open('w') as log:
        proc = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT)
        write(args.out / 'child.json', {'pid': proc.pid, 'argv': argv, 'timeout_s': 170})
        try:
            rc = proc.wait(timeout=170)
        except BaseException as exc:
            write(args.out / 'supervisor-failure.json', {'error': repr(exc), 'pid': proc.pid})
            # Only this Popen's direct child is signalled, never a name match.
            if proc.poll() is None:
                proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                if proc.poll() is None:
                    proc.kill()
                proc.wait(timeout=3)
            rc = 1
        finally:
            check = subprocess.run(['/bin/ps', '-p', str(proc.pid), '-o', 'pid='], text=True, capture_output=True)
            write(args.out / 'cleanup.json', {'pid': proc.pid, 'exit_code': proc.returncode,
                  'ps_returncode': check.returncode, 'ps_stdout': check.stdout, 'ps_stderr': check.stderr,
                  'owned_pid_absent': check.returncode == 1 and check.stdout == '' and check.stderr == ''})
    assert check.returncode == 1 and check.stdout == '' and check.stderr == ''
    print(f'child exit={rc}; reaped; evidence={args.out}')
    return rc


if __name__ == '__main__':
    sys.exit(main())
