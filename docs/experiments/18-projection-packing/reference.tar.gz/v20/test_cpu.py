"""CPU tests for exact range loading and symmetric block schedule; no MLX."""
import ast
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('v20_micro', HERE / 'micro.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Tests(unittest.TestCase):
    def test_exact_range_metadata(self):
        table = {'chosen': {'dtype': 'U32', 'shape': [2, 2], 'data_offsets': [3, 19]}}
        raw = json.dumps(table).encode()
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'tiny.safetensors'
            p.write_bytes(struct.pack('<Q', len(raw)) + raw + b'pad' + bytes(range(16)) + b'untouched')
            meta = m.tensor_meta(p, 'chosen', 'U32', (2, 2))
            self.assertEqual(meta['offset'], 8 + len(raw) + 3)
            self.assertEqual(meta['nbytes'], 16)
            with self.assertRaises(AssertionError):
                m.tensor_meta(p, 'chosen', 'U8', (2, 2))
            p.write_bytes(p.read_bytes()[:-20])
            with self.assertRaises(AssertionError):
                m.tensor_meta(p, 'chosen', 'U32', (2, 2))

    def test_prime_schedule_equal(self):
        class MX:
            def synchronize(self): events.append('sync')
        signatures = []
        for variant in ('A', 'B'):
            events = []
            def invoke(v, j):
                self.assertEqual(v, variant)
                events.append(j)
                return [j] * 12
            rec, output = m.block(MX(), invoke, variant)
            self.assertEqual(events, list(range(m.PRIME)) + ['sync'] + list(range(m.REPEATS)) + ['sync'])
            self.assertEqual(len(output), 12)
            self.assertLessEqual(rec['prime_end_ns'], rec['start_ns'])
            self.assertLessEqual(rec['start_ns'], rec['end_ns'])
            signatures.append(events)
        self.assertEqual(signatures[0], signatures[1])

    def test_memmap_only_target_and_close_after_eval(self):
        events = []
        class Map:
            def __init__(self): self._mmap = self
            def close(self): events.append('close')
        class NP:
            def dtype(self, name): return name
            def array(self, mapping, copy):
                self_mapping = mapping
                events.append(('copy', copy, isinstance(self_mapping, Map)))
                return 'detached-host'
            def memmap(self, path, **kwargs):
                events.append((path, kwargs))
                return Map()
        class MX:
            def array(self, host): events.append(('array', host)); return 'tensor'
            def eval(self, value): events.append(('eval', value))
        meta = {'dtype': 'U32', 'path': '/tmp/fixture', 'offset': 123, 'shape': [2, 3]}
        self.assertEqual(m.load_range(NP(), MX(), meta), 'tensor')
        self.assertEqual(events, [('/tmp/fixture', {'mode': 'r', 'dtype': '<u4', 'offset': 123, 'shape': (2, 3)}),
                                  ('copy', True, True), ('array', 'detached-host'), ('eval', 'tensor'), 'close'])

    def test_plan_and_no_whole_model_loading(self):
        self.assertEqual(len(m.ORDERS), 6)
        self.assertEqual(m.ORDERS.count(('A', 'B')), 3)
        self.assertEqual(m.ORDERS.count(('B', 'A')), 3)
        self.assertEqual(len(m.SCHEDULE), 10)
        self.assertEqual(m.SCHEDULE.count(('A', 'A')), 2)
        self.assertEqual(m.SCHEDULE.count(('B', 'B')), 2)
        source = (HERE / 'micro.py').read_text()
        tree = ast.parse(source)
        self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                             and n.func.attr == 'load' for n in ast.walk(tree)))
        self.assertNotIn('load_model(', source)
        self.assertIn('np.memmap(', source)
        self.assertIn("minimum_wins': 5", source)
        self.assertNotIn('clear_cache(', source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
