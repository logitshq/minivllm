"""Guarded route-formal registration and owner CPU preparation; explicit --run.

This does not invoke controller.prepare, create a service PREPARED journal,
start a process, or run a device. Root performs the later read-only service
prepare and receipt seal separately. Only actual closed GDN37 archive refs and
the source-matching complete 64-test CPU receipt are accepted.
"""
import argparse
import contextlib
import datetime
import hashlib
import importlib.abc
import importlib.util
import json
from pathlib import Path
import sys
import traceback

R=Path('/Users/ryanli/code/minivllm');B=R/'bench/m5_ultra_256gb';A=R/'.artifacts/m5-ultra-256gb'
HERE=B/'route_http_formal';SOURCE=HERE/'preregister.py'
SOURCE_SHA='bc91a33edfaf683753872e7c245a16488f4ae00264be9efda8533db313360e0f'
DEFAULT_OUT=A/'route-http-formal-v2-registration'
CPU_RUNNER=Path('/tmp/run-route-formal-prepared-cpu-v2.py').resolve()
CPU_RUNNER_SHA='bda0dcb56b4b35f961a46aa11338ae7112f78a5fd1ba46126b9f3e692927b5ee'
FAILED=A/'route-http-formal-v1-registration/result.json'
FAILED_SHA='fa9e4b860f246d09808fe01bfb8a64a41d4346098406659dc57e97abf38b6c14'
PRIOR=R/'docs/experiments/m5-ultra-256gb/E029-gdn-prework-serving-v1'
PRIOR_SHA='abddf49c3c43407e7903dfabb06f3227ee993b464f2f66055e22928d8f6dcbb5'
PRIOR_AUDIT_SHA='673d1ba136c784f445567015f15c4fb7c0b22c6635a33201b14026e2ba3edd29'
FORBIDDEN={'mlx','omlx','mlx_lm','mlx_vlm','torch','numpy','tutorial_code','monolith'}
SUITES={'bench.m5_ultra_256gb.route_http_formal.test_owner_cpu':14,
        'bench.m5_ultra_256gb.route_http_formal.test_controller_cpu':12,
        'bench.m5_ultra_256gb.route_http_formal.test_audit_restore_cpu':11,
        'bench.m5_ultra_256gb.route_http_formal.test_audit_formal_cpu':13,
        'bench.m5_ultra_256gb.route_http_formal.test_execute_cpu':12,
        'bench.m5_ultra_256gb.route_http_formal.test_preregister_cpu':2}

def need(ok,message):
    if not ok:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def run(args):
    out=args.out.resolve();need(out.parent==A and not out.exists(),'fresh registration evidence directory')
    need(args.cpu_receipt is not None and args.cpu_receipt.is_absolute(),'explicit closed CPU receipt')
    out.mkdir();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
    record=dict(schema='E024-route-formal-guarded-registration-v2',status='RUNNING',started_at=now(),
        argv=[sys.executable,*sys.argv],gpu_executed=False,service_changed=False,service_prepared=False,
        numerical_qualified=False,http_qualified=False,performance_qualified=False,
        denied_operations=[],source_before={},source_after={})
    guard=None
    def deny(kind,args):
        record['denied_operations'].append(dict(kind=kind,detail=str(args)))
        raise RuntimeError('forbidden registration operation: '+kind)
    def hook(event,args):
        if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','os.exec',
                     'os.spawn','os.kill','os.killpg','socket.connect','socket.bind'):
            deny(event,args)
    class Imports(importlib.abc.MetaPathFinder):
        def find_spec(self,fullname,path=None,target=None):
            if fullname.split('.')[0] in FORBIDDEN:deny('backend import',fullname)
            return None
    save(out/'result.json',record)
    try:
        cpu=read(args.cpu_receipt);(out/'cpu-result.json').write_bytes(args.cpu_receipt.read_bytes())
        need(cpu['schema']=='E024-route-formal-prepared-cpu-v2' and cpu['status']=='PASS'
             and cpu['tests']==cpu['expected_tests']==64 and cpu['failures']==cpu['errors']==cpu['skipped']==0
             and cpu['expected_failures']==cpu['unexpected_successes']==0 and cpu['loader_errors']==[]
             and cpu['source_unchanged'] is True and cpu['denied_operations']==[]
             and cpu['forbidden_modules_loaded']==[], 'complete guarded 64-test CPU PASS required')
        need(len(cpu['suites'])==len(SUITES) and {r['module']:r['expected_tests'] for r in cpu['suites']}==SUITES
             and all(r['expected_tests']==r['discovered_tests'] for r in cpu['suites']), 'exact six whole modules')
        need(sha(CPU_RUNNER)==CPU_RUNNER_SHA==cpu['source_before'][str(CPU_RUNNER)]['sha256']
             ==cpu['source_after'][str(CPU_RUNNER)]['sha256']
             and sha(args.cpu_receipt.parent/'runner.py')==CPU_RUNNER_SHA,
             'exact reviewed CPU guard and retained source')
        need(args.predecessor==PRIOR/'restored-journal.json' and args.restoration_audit==PRIOR/'restoration-audit.json'
             and args.predecessor_sha256==PRIOR_SHA==sha(args.predecessor)
             and args.restoration_audit_sha256==PRIOR_AUDIT_SHA==sha(args.restoration_audit),
             'actual archived GDN37 journal and independent restoration audit required')
        failure=read(FAILED)
        need(sha(FAILED)==FAILED_SHA and failure['status']=='FAIL'
             and failure['error']['message']=='route formal plan SHA'
             and failure['service_changed'] is failure['service_prepared'] is False,
             'original actual failed registration preserved')
        record['previous_registration']=dict(path=str(FAILED),sha256=FAILED_SHA,status='FAIL')
        (out/'first-registration-result.json').write_bytes(FAILED.read_bytes())
        predecessor=dict(path=str(args.predecessor),sha256=PRIOR_SHA,
            audit=dict(path=str(args.restoration_audit),sha256=PRIOR_AUDIT_SHA))
        record.update(cpu_guard=dict(path=str(CPU_RUNNER),sha256=CPU_RUNNER_SHA),
            cpu_receipt=dict(path=str(args.cpu_receipt),sha256=sha(args.cpu_receipt)),predecessor=predecessor)
        for name,path in (('predecessor.json',args.predecessor),('predecessor-audit.json',args.restoration_audit)):
            (out/name).write_bytes(path.read_bytes())
        need(not any(n.split('.')[0] in FORBIDDEN for n in sys.modules),'no backend preloaded')
        guard=Imports();sys.meta_path.insert(0,guard);sys.addaudithook(hook)
        need(sha(SOURCE)==SOURCE_SHA,'sealed registrar source changed')
        spec=importlib.util.spec_from_file_location('_guarded_route_formal_registration',SOURCE)
        reg=importlib.util.module_from_spec(spec);spec.loader.exec_module(reg)
        paths={HERE/name for name in reg.FIXED};paths.update({SOURCE,CPU_RUNNER})
        paths.update(HERE/(name.rsplit('.',1)[1]+'.py') for name in SUITES)
        for path in sorted(paths):
            digest=sha(path)
            need(cpu['source_before'][str(path)]['sha256']==cpu['source_after'][str(path)]['sha256']==digest,
                 'CPU receipt source changed: '+str(path))
            raw=path.read_bytes();record['source_before'][str(path)]=dict(sha256=digest,bytes=len(raw))
            dest=out/'frozen-source'/str(path).lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
        save(out/'result.json',record)
        with (out/'stdout.txt').open('x') as stdout,(out/'stderr.txt').open('x') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
            reg.prepare(predecessor)
            preparation=read(reg.P/'preparation.json');commands=read(reg.P/'commands.json')
            need(preparation['status']=='PLAN_BUILT' and preparation['service_prepared'] is False
                 and preparation['warm_requests']==96 and preparation['formal_requests']==768
                 and preparation['hard_work_seconds']==40524,'actual twelve-trial plan build')
            owner,_=reg.modules();command=commands['cpu_prepare'];owner_out=A/'route-http-formal-v2-cpu-prepare'
            expected=['--prepare-only','--plan',str(reg.P/'owner-plan.json'),
                      '--plan-sha256',preparation['owner_plan_sha256'],'--out',str(owner_out)]
            need(command[1:4]==['-I','-B',str(HERE/'owner.py')] and command[4:]==expected,
                 'actual saved owner --prepare-only command')
            need(owner.main(command[4:])==0,'actual in-process owner CPU preparation failed')
            prepared=read(owner_out/'prepared.json')
            need(prepared['status']=='PREPARED' and prepared['owner_plan_sha256']==preparation['owner_plan_sha256']
                 and prepared['runtime_weights_verified'] is False and len(prepared['formal_specs'])==12,
                 'actual small-source owner preparation receipt')
            need(not (A/'route-http-formal-v2-cold-journal').exists() and not (reg.P/'receipt.json').exists(),
                 'service PREPARED journal and final receipt are not produced here')
        record.update(status='PASS',owner_plan_sha256=preparation['owner_plan_sha256'],
            preparation=dict(path=str(reg.P/'preparation.json'),sha256=sha(reg.P/'preparation.json')),
            owner_prepared=dict(path=str(owner_out/'prepared.json'),sha256=sha(owner_out/'prepared.json')),
            commands=commands,runtime_weights_verified=False,
            scope='Small source/spec/closed receipt validation only. Real model/runtime payload preflight remains in the future owner run.')
        for name in ('preparation.json','commands.json','owner-plan.json'):
            (out/name).write_bytes((reg.P/name).read_bytes())
        (out/'owner-prepared.json').write_bytes((owner_out/'prepared.json').read_bytes())
    except BaseException as exc:
        record.update(status='FAIL',error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc()))
    finally:
        if guard in sys.meta_path:sys.meta_path.remove(guard)
        for path in record['source_before']:
            try:record['source_after'][path]=dict(sha256=sha(path),bytes=Path(path).stat().st_size)
            except BaseException as exc:record['source_after'][path]=dict(error=str(exc))
        record['source_unchanged']=bool(record['source_before']) and record['source_before']==record['source_after']
        record['forbidden_modules_loaded']=sorted(n for n in sys.modules if n.split('.')[0] in FORBIDDEN)
        if not record['source_unchanged'] or record['denied_operations'] or record['forbidden_modules_loaded']:record['status']='FAIL'
        record['ended_at']=now();save(out/'result.json',record)
        files={str(p.relative_to(out)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(out.rglob('*')) if p.is_file()}
        save(out/'artifact-manifest.json',dict(schema='cpu-registration-artifact-manifest-v1',files=files))
    print(json.dumps({k:record.get(k) for k in ('status','owner_plan_sha256','error')}))
    return int(record['status']!='PASS')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',action='store_true')
    p.add_argument('--cpu-receipt',type=Path);p.add_argument('--out',type=Path,default=DEFAULT_OUT)
    p.add_argument('--predecessor',type=Path);p.add_argument('--predecessor-sha256')
    p.add_argument('--restoration-audit',type=Path);p.add_argument('--restoration-audit-sha256');args=p.parse_args()
    if not args.run:
        print('DESCRIPTION_ONLY: explicit --run, closed CPU receipt, and archived GDN37 dual refs required. No services/device.');return 0
    return run(args)

if __name__=='__main__':raise SystemExit(main())
