# GLM5.3Flash CPU inputs — first attempt

The original frozen `prepare_inputs.py --run` returned **0** on its first invocation. This is CPU input preparation only; no service was prepared, no model/backend was loaded, and no numerical, physical-fit or performance qualification was performed.

The command in `attempt.json` preserves the outer repository `.venv/bin/python -I -B` entry. Its child invoked the original builder directly. `stdout.txt`, `stderr.txt`, `result.json`, the builder/probe/metadata-manifest copies and wrapper source are retained. The first result SHA is `f20d0b15ebc42825d6a90290874721ddd930174274ce8221e0df7e86b6893cce`. No failure was hidden or retried.

- Snapshot revision: `fa04cbc3622b16aa7475404060b05e506d81bd4e`, `model_type=glm5_next`, `text_config.model_type=glm5_next_text`.
- Plain coding prompt: `/Users/ryanli/code/minivllm/.artifacts/m5-ultra-256gb/glm-flash-inputs-v1-request/plain-coding-v1.utf8`; SHA `a9fc2a6c62fac5743b51744c329a42af81816805dd0b2e65f150e44418fe4f6d`. No chat template or pre-tokenization was applied. The actual official tokenizer must later enforce the existing 128-token maximum.
- Runtime inventory: 24 explicit resolved files / 43,842,459 bytes freshly hashed; 23 listed source/metadata pins. This is a supplied set, not a recursive dependency closure.
- 62 weight shards / 203,992,076,296 bytes: retained original download hashes plus current stat only; **no weight payload was opened or rehashed by the reviewed builder path**.
- Small model metadata read by the builder: config.json, README.md and model.safetensors.index.json (11,572,176 bytes total).
- Future probe caps remain `[8,32,32,32]`, normal EOS, plain completion and original official EnginePool route. Work/request/shutdown deadlines remain 1800/180/60 seconds. No probe was run here.

Inputs: `../glm-flash-inputs-v1/probe-plan.json` SHA `700f0a785138a75ebb4554d6eddee7dfbd1375c5b92bd596f8bd2e3e16f9be87` and `model-runtime-inventory.json` SHA `bdf025b9fdfd5cb22eb1991c9b3e7c20c73b962a3e86e4306a0af9c33aca58be`. The root controller is still unregistered for the future GDN formal predecessor; there is no owner plan, PREPARED journal or admission receipt from this operation. Service restoration remains the existing Qwen3.8-27B persisted-visible contract, separate from this GLM experiment.
