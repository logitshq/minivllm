"""One explicit CPU input-builder invocation; retain the first outcome."""
from pathlib import Path
import datetime,hashlib,json,subprocess,time,traceback
R=Path('/Users/ryanli/code/minivllm')
A=R/'.artifacts/m5-ultra-256gb'
E=A/'glm-flash-inputs-v1-execution';Q=A/'glm-flash-inputs-v1-request';O=A/'glm-flash-inputs-v1'
B=R/'bench/m5_ultra_256gb/glm_flash_cycle/prepare_inputs.py'
P=R/'.venv/bin/python'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
if any(p.exists() for p in (E,Q,O)):raise SystemExit('refuse existing attempt/request/output')
E.mkdir();Q.mkdir();(E/'sources').mkdir()
prompt=Q/'plain-coding-v1.utf8'
prompt.write_bytes(b'Write a Python function first_unique_index(s: str) -> int that returns the index of the first non-repeated character, or -1. Return only code.\n')
sources=[B,R/'bench/m5_ultra_256gb/glm_flash/load_probe.py',R/'bench/m5_ultra_256gb/glm_flash/metadata-v1/manifest.json',Path(__file__).resolve()]
pins={str(p):sha(p) for p in sources}
for i,p in enumerate(sources):(E/'sources'/f'{i}-{p.name}').write_bytes(p.read_bytes())
command=[str(P),'-I','-B',str(B),'--run','--prompt',str(prompt),'--prompt-sha256',sha(prompt),'--outer-python',str(P),'--out',str(O)]
start=time.time();record=dict(schema='GLM-cpu-input-execution-v1',status='RUNNING',command=command,cwd=str(R),started_at=start,
 source_pins=pins,prompt={'path':str(prompt),'sha256':sha(prompt),'bytes':prompt.stat().st_size},
 source_reviewed_scope='Only explicit source/runtime bytes and small model metadata; 62 shard stat calls, no shard payload hash or backend/model execution.',
 service_actions=False,model_loaded=False,performance_qualified=False,numerical_qualified=False)
write(E/'attempt.json',record)
try:
 with (E/'stdout.txt').open('xb') as out,(E/'stderr.txt').open('xb') as err:
  child=subprocess.run(command,cwd=R,stdout=out,stderr=err,timeout=360,check=False)
 record['returncode']=child.returncode
 record['source_pins_unchanged']=all(sha(p)==h for p,h in pins.items())
 record['status']='PASS_CPU_INPUTS_ONLY' if child.returncode==0 and record['source_pins_unchanged'] else 'FAIL'
except BaseException as exc:
 record.update(status='FAIL',error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
finally:
 record['ended_at']=time.time();record['elapsed_s']=record['ended_at']-start
 record['outputs']={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(O.glob('*')) if p.is_file()} if O.exists() else {}
 record['logs']={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in E.glob('*.txt')}
 write(E/'result.json',record)
 print(json.dumps({k:record[k] for k in ('status','returncode','elapsed_s','source_pins_unchanged') if k in record},indent=2))
 print('result_sha256='+sha(E/'result.json'))
raise SystemExit(0 if record['status']=='PASS_CPU_INPUTS_ONLY' else 1)
