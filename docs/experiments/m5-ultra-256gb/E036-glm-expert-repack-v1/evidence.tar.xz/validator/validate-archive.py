"""Independent metadata-only verification and archive of the closed E036 copy.

No candidate imports, MLX, subprocess, mmap or tensor payload reads. The only
reads of .safetensors files are their 8-byte length and bounded JSON headers.
Default is description only. Explicit --run requires the named final receipts.
"""
import argparse
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import struct
import tarfile
import traceback

R = Path('/Users/ryanli/code/minivllm')
S = R / 'bench/m5_ultra_256gb/glm_expert_repack'
E = R / '.artifacts/m5-ultra-256gb/glm-expert-repack-execution-v1'
O = R / '.artifacts/models/GLM-5.3-Flash-4bit-stacked-v1'
D = R / 'docs/experiments/m5-ultra-256gb/E036-glm-expert-repack-v1'
PLAN_SHA = '323ff8da5d2faf6bb774b1c03f3a52f49198cbb9898f21c91ac25aa546a4c50a'
CANDIDATE_SHA = 'fd3c30de034a2eba2e3002eb61df08737b07652bd86a9edaeaba75fd35d99d5b'
DTYPES = {'U32': 4, 'F16': 2, 'BF16': 2, 'F32': 4}


def check(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        check(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique)


def small(path):
    path = Path(path)
    check(path.suffix != '.safetensors' and path.stat().st_size < 32 << 20,
          'metadata-only bounded full read: ' + str(path))
    return path.read_bytes()


def identity(path):
    st = path.stat()
    return dict(resolved=str(path.resolve()), size=st.st_size, dev=st.st_dev,
                ino=st.st_ino, mtime_ns=st.st_mtime_ns, ctime_ns=st.st_ctime_ns)


def header_bytes(path):
    before = identity(path)
    with path.open('rb', buffering=0) as stream:
        prefix = stream.read(8)
        check(len(prefix) == 8, 'complete header prefix')
        size, = struct.unpack('<Q', prefix)
        check(2 <= size <= 16 << 20 and size + 8 <= before['size'], 'bounded header')
        raw = stream.read(size)
        check(len(raw) == size, 'complete header JSON')
    check(identity(path) == before, 'stable header source')
    return prefix + raw, before


def inspect_header(path):
    raw, stat = header_bytes(path)
    obj = parse(raw[8:])
    metadata = obj.pop('__metadata__', {})
    check(all(type(k) is str and type(v) is str for k, v in metadata.items()),
          'string safetensors metadata')
    ranges = []
    rows = {}
    for key, value in obj.items():
        check(set(value) == {'dtype', 'shape', 'data_offsets'}, 'exact tensor header fields')
        dtype, shape, offsets = value['dtype'], value['shape'], value['data_offsets']
        check(dtype in DTYPES and type(shape) is list and
              all(type(n) is int and n > 0 for n in shape), 'known tensor shape/dtype')
        check(type(offsets) is list and len(offsets) == 2 and
              all(type(n) is int and n >= 0 for n in offsets), 'valid header offsets')
        start, end = offsets
        check(end - start == math.prod(shape) * DTYPES[dtype], 'dtype/shape byte count')
        ranges.append((start, end))
        rows[key] = dict(dtype=dtype, shape=shape, shard=path.name,
                         offset=len(raw) + start, bytes=end - start)
    end = 0
    for start, stop in sorted(ranges):
        check(start == end, 'no gap/overlap in tensor ranges')
        end = stop
    check(end + len(raw) == stat['size'], 'header ranges cover full file stat size')
    return rows, dict(identity=stat, header_bytes=len(raw), header_sha256=sha(raw),
                      payload_bytes=end, metadata=metadata), raw


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def save(path, value):
    raw = json.dumps(value, indent=2, allow_nan=False).encode() + b'\n'
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def run():
    check(not D.exists(), 'fresh archive path required')
    files, data = {}, {}

    def retain(name, path, *, header=False):
        check(name not in files, 'unique archive member')
        path = Path(path)
        raw = header_bytes(path)[0] if header else small(path)
        files[name] = dict(source=str(path), bytes=len(raw), sha256=sha(raw),
                           kind='header_prefix_only' if header else 'metadata_file')
        data[name] = raw
        return raw

    plan_raw = retain('prereg/plan.json', S / 'prereg-v1/plan.json')
    check(sha(plan_raw) == PLAN_SHA, 'exact preregistered plan')
    plan = parse(plan_raw)
    check(plan['candidate_sha256'] == CANDIDATE_SHA, 'candidate pin in plan')
    check(sha(retain('source/candidate.py', S / 'candidate.py')) == CANDIDATE_SHA,
          'unchanged executed candidate')
    retain('source/README.md', S / 'README.md')
    retain('source/test_cpu.py', S / 'test_cpu.py')
    retain('validator/validate-archive.py', Path(__file__).resolve())
    for name in ('README.md', 'command.json', 'execution-wrapper.py', 'stderr.txt', 'stdout.txt'):
        retain('prereg/' + name, S / 'prereg-v1' / name)
    expected_execution = {'after-memory.json', 'after-swap.json', 'before-memory.json',
                          'before-swap.json', 'execute.py', 'final.json', 'invocation.json',
                          'stderr.txt', 'stdout.txt'}
    check({p.name for p in E.iterdir()} == expected_execution, 'exact closed execution evidence tree')
    for name in sorted(expected_execution):
        retain('execution/' + name, E / name)
    final = parse(data['execution/final.json'])
    invocation = parse(data['execution/invocation.json'])
    expected_command = [str(R / '.venv/bin/python'), '-I', '-B', str(S / 'candidate.py'),
                        '--run', '--plan', str(S / 'prereg-v1/plan.json'),
                        '--plan-sha256', PLAN_SHA, '--out', str(O)]
    check(final['status'] == 'PASS' and final['returncode'] == 0 and
          final['command'] == invocation['command'] == expected_command and
          final['source_plan_sha256'] == invocation['source_plan_sha256'] == PLAN_SHA and
          final['started_at'] == invocation['started_at'] and
          final['ended_at'] >= final['started_at'], 'closed exact execution command')
    check(data['execution/execute.py'] == data['prereg/execution-wrapper.py'], 'exact saved wrapper')
    check(not data['execution/stderr.txt'], 'empty actual stderr')
    for name in ('complete.json', 'input-plan.json', 'invocation.json',
                 'model.safetensors.index.json', 'repack-manifest.jsonl'):
        retain('output/' + name, O / name)
    complete = parse(data['output/complete.json'])
    check(data['output/input-plan.json'] == plan_raw, 'byte-exact plan copy')
    check(complete['status'] == 'PASS_BYTES_ONLY' and complete['candidate_sha256'] == CANDIDATE_SHA and
          complete['source_plan_sha256'] == PLAN_SHA and complete['summary'] == plan['summary'],
          'closed producer result agrees with preregistration')
    check(all(complete[k] is True for k in ('original_unchanged_stat', 'output_groups_reread',
                                           'source_payload_SHA_rechecked')), 'producer byte-proof flags')
    check(complete['runtime_load_executed'] is False and complete['performance_qualified'] is False,
          'no runtime/performance qualification in producer receipt')
    check(sha(data['output/model.safetensors.index.json']) == complete['index_sha256'] and
          sha(data['output/repack-manifest.jsonl']) == complete['manifest_sha256'],
          'producer metadata SHA matches actual index and manifest')
    actual_stdout = parse(data['execution/stdout.txt'])
    check(all(actual_stdout[k] == complete[k] for k in actual_stdout), 'actual stdout/complete agreement')
    output_invocation = parse(data['output/invocation.json'])
    check(output_invocation['buffer_bytes'] == 8 << 20 and
          output_invocation['shard_limit_bytes'] == 4 << 30 and
          output_invocation['reserve_bytes'] == 64 << 30 and
          output_invocation['candidate_sha256'] == CANDIDATE_SHA and
          output_invocation['source_payload_SHA_rechecked'] is True and
          output_invocation['payload_io_policy'] == plan['payload_io_policy'] == complete['payload_io_policy'],
          'actual bounded copy and per-FD cache policy')

    source = Path(plan['source'])
    check(set(p.name for p in O.iterdir()) == set(complete['files']) | set(plan['sidecars']) |
          {'complete.json', 'input-plan.json', 'invocation.json', 'model.safetensors.index.json',
           'repack-manifest.jsonl'}, 'exact completed output membership; no partial/failure files')
    refs = {}
    for label in ('download', 'inventory', 'index'):
        ref = plan[label]
        path = Path(ref['path'])
        raw = retain('original/' + ('model.safetensors.index.json' if label == 'index' else label + '.json'), path)
        check(identity(path) == ref['identity'] and sha(raw) == ref['sha256'], 'original pinned reference ' + label)
        refs[label] = parse(raw)
    check(refs['download']['status'] == 'PASS_PINNED_DOWNLOAD_AND_SHA_ONLY' and
          refs['inventory']['status'] == 'PASS_HEADER_INVENTORY_ONLY', 'historical original receipt scope')
    for number, (name, expected_sha) in enumerate(sorted(plan['runtime_source_pins'].items())):
        raw = retain(f'loader-sources/{number:02d}-' + Path(name).name, name)
        check(sha(raw) == expected_sha, 'pinned reviewed loader source unchanged')
    sidecars = []
    for name, ref in sorted(plan['sidecars'].items()):
        original = Path(ref['path'])
        check(original == source / name and identity(original) == ref['identity'], 'source sidecar identity')
        original_raw, output_raw = small(original), small(O / name)
        check(sha(original_raw) == sha(output_raw) == ref['sha256'] and original_raw == output_raw,
              'sidecar copied without changes: ' + name)
        sidecars.append(dict(name=name, bytes=len(original_raw), sha256=ref['sha256'],
                             original=str(original), output=str(O / name),
                             archived=len(original_raw) < 1 << 20))
        if len(original_raw) < 1 << 20:
            retain('output/sidecars/' + name, O / name)
    config = parse(small(O / 'config.json'))
    q = config['quantization']
    check(config['model_type'] == 'glm5_next' and q == config['quantization_config'] and
          q['group_size'] == 64 and q['bits'] == 4 and q.get('mode', 'affine') == 'affine',
          'unchanged original affine mixed quantization')
    tc = config['text_config']
    check(tc['num_hidden_layers'] == 45 and tc['n_routed_experts'] == 288 and
          tc['moe_intermediate_size'] == 2048 and tc['hidden_size'] == 4096 and
          tc['mlp_layer_types'] == ['dense'] * 3 + ['sparse'] * 42, 'exact model dimensions')

    original_rows, original_headers, output_rows, output_headers = {}, {}, {}, {}
    original_index = refs['index']['weight_map']
    check(len(plan['shards']) == 62 and set(original_index.values()) == set(plan['shards']), '62 original shards')
    historical_shards = {row['name']: row for row in refs['download']['shards']}
    historical_headers = {row['name']: row for row in refs['inventory']['shards']}
    for name, expected in sorted(plan['shards'].items()):
        rows, observed, raw = inspect_header(source / name)
        check(all(observed[k] == expected[k] for k in observed), 'original header/stat agrees with plan')
        check(expected['expected_full_sha256'] == historical_shards[name]['sha256'] and
              historical_shards[name]['sha256_verified'] is True and
              observed['header_sha256'] == historical_headers[name]['header_sha256'], 'original receipt correspondence')
        check(not set(original_rows) & set(rows) and all(original_index.get(k) == name for k in rows),
              'unique original tensors agree with original index')
        original_rows.update(rows)
        original_headers[name] = observed
        retain('original/headers/' + name + '.header', source / name, header=True)
    check(set(original_rows) == set(original_index), 'complete original index/header coverage')

    # Build the expected layout independently, using fixed actual model dimensions.
    # Keys not in the 42 backbone expert blocks remain unchanged, including MTP45.
    expected_rows = {}
    consumed = set()
    for layer in range(3, 45):
        for projection in ('gate_proj', 'up_proj', 'down_proj'):
            bits = 5 if projection == 'down_proj' else 4
            runtime_key = f'model.layers.{layer}.mlp.switch_mlp.{projection}'
            check(q.get(runtime_key, {'group_size': 64, 'bits': 4}) == {'group_size': 64, 'bits': bits},
                  'per-projection original quantization config')
            width, height = (2048, 4096) if projection == 'down_proj' else (4096, 2048)
            for suffix in ('weight', 'scales', 'biases'):
                target = f'model.language_model.layers.{layer}.mlp.switch_mlp.{projection}.{suffix}'
                part_shape = [height, width * bits // 32] if suffix == 'weight' else [height, width // 64]
                dtype = 'U32' if suffix == 'weight' else 'F16'
                parts = []
                for expert in range(288):
                    key = f'model.language_model.layers.{layer}.mlp.experts.{expert}.{projection}.{suffix}'
                    check(key in original_rows and key not in consumed, 'complete unique numeric expert sequence')
                    part = original_rows[key]
                    check(part['dtype'] == dtype and part['shape'] == part_shape, 'packed expert shape/dtype')
                    parts.append(dict(key=key, **part))
                    consumed.add(key)
                expected_rows[target] = dict(key=target, dtype=dtype, shape=[288] + part_shape, parts=parts)
    stacked_count = len(expected_rows)
    for key, row in original_rows.items():
        if key not in consumed:
            check(key not in expected_rows and '.mlp.switch_mlp.' not in key, 'passthrough target unique')
            match = re.fullmatch(r'model\.language_model\.layers\.(\d+)\.mlp\.experts\..*', key)
            check(match is None or int(match[1]) >= 45, 'all backbone experts transformed')
            expected_rows[key] = dict(key=key, dtype=row['dtype'], shape=row['shape'], parts=[dict(key=key, **row)])
    layout = [expected_rows[k] for k in sorted(expected_rows)]
    check(sha(encoded(layout)) == plan['layout_sha256'], 'independently reconstructed layout SHA matches preregistration')
    check(len(original_rows) == 113446 and len(expected_rows) == 4960 and stacked_count == 378 and
          len(consumed) == 108864, 'actual counts')
    mtp_keys = {k for k in original_rows if k.startswith('model.language_model.layers.45.')}
    check(mtp_keys and all(k in expected_rows and len(expected_rows[k]['parts']) == 1 for k in mtp_keys),
          'all original MTP45 tensors remain passthrough')

    output_index = parse(data['output/model.safetensors.index.json'])
    check(len(complete['files']) == 58 and set(output_index['weight_map'].values()) == set(complete['files']),
          '58 output shards')
    for name, producer_file in sorted(complete['files'].items()):
        check(not (O / name).is_symlink() and re.fullmatch(r'model-\d{5}-of-00058\.safetensors', name),
              'regular named output shard')
        rows, observed, raw = inspect_header(O / name)
        check(observed['identity']['size'] == producer_file['bytes'] and
              re.fullmatch('[0-9a-f]{64}', producer_file['sha256']) and
              observed['metadata'] == plan['safetensors_metadata'], 'output stat and format metadata')
        check(not set(output_rows) & set(rows) and all(output_index['weight_map'].get(k) == name for k in rows),
              'unique output tensors agree with output index')
        output_rows.update(rows)
        output_headers[name] = observed
        retain('output/headers/' + name + '.header', O / name, header=True)
    check(set(output_rows) == set(expected_rows) == set(output_index['weight_map']), 'exact expected output coverage')
    for key, expected in expected_rows.items():
        row = output_rows[key]
        check(row['dtype'] == expected['dtype'] and row['shape'] == expected['shape'] and
              row['bytes'] == sum(p['bytes'] for p in expected['parts']), 'output exact expected dtype/shape/bytes')
    payload_bytes = sum(row['bytes'] for row in output_rows.values())
    check(payload_bytes == sum(row['bytes'] for row in original_rows.values()) ==
          plan['summary']['payload_bytes'] == output_index['metadata']['total_size'] == 203976457080,
          'complete exact payload byte count conserved')
    seen, part_seen, order = set(), set(), []
    for raw in data['output/repack-manifest.jsonl'].splitlines():
        row = parse(raw)
        key = row['key']
        check(key in expected_rows and key not in seen, 'unique expected manifest output key')
        check(set(row) == {'key', 'dtype', 'shape', 'output_shard', 'output_offset', 'bytes', 'sha256', 'parts'},
              'exact manifest group fields')
        seen.add(key)
        order.append(key)
        actual, expected = output_rows[key], expected_rows[key]
        check(row['dtype'] == actual['dtype'] and row['shape'] == actual['shape'] and
              row['bytes'] == actual['bytes'] and row['output_shard'] == actual['shard'] and
              row['output_offset'] == actual['offset'] and re.fullmatch('[0-9a-f]{64}', row['sha256']),
              'manifest agrees with actual output header')
        check(len(row['parts']) == len(expected['parts']), 'exact manifest group part count')
        for part, want in zip(row['parts'], expected['parts']):
            check(set(part) == {'key', 'shard', 'offset', 'bytes', 'sha256'} and
                  all(part[k] == want[k] for k in ('key', 'shard', 'offset', 'bytes')) and
                  re.fullmatch('[0-9a-f]{64}', part['sha256']) and part['key'] not in part_seen,
                  'source exact-once part descriptors and numeric expert order')
            part_seen.add(part['key'])
        if len(row['parts']) == 1:
            check(row['sha256'] == row['parts'][0]['sha256'], 'passthrough group/part digest consistency')
    check(seen == set(expected_rows) and part_seen == set(original_rows) and order == sorted(expected_rows),
          'complete manifest output/source coverage and deterministic order')

    def memory(label):
        record = parse(data['execution/' + label + '-memory.json'])
        check(record['returncode'] == 0 and not record['stderr'], 'successful vm_stat endpoint')
        text = record['stdout']
        page_size = int(re.search(r'page size of (\d+) bytes', text)[1])
        values = {k.strip('"'): int(v) for k, v in re.findall(r'^(.+?):\s+(\d+)\.', text, re.M)}
        swap = parse(data['execution/' + label + '-swap.json'])
        check(swap['returncode'] == 0 and not swap['stderr'], 'successful swap endpoint')
        usage = {k: float(v) for k, v in re.findall(r'(total|used|free) = ([\d.]+)M', swap['stdout'])}
        check(set(usage) == {'total', 'used', 'free'}, 'complete reported swap quantities')
        return dict(page_size_bytes=page_size, vm_stat=values, swap_reported_M=usage)

    before, after = memory('before'), memory('after')
    check(before['page_size_bytes'] == after['page_size_bytes'] == 16384 and
          set(before['vm_stat']) == set(after['vm_stat']), 'comparable endpoint counters')
    memory_result = dict(before=before, after=after,
                         vm_stat_delta={k: after['vm_stat'][k] - v for k, v in before['vm_stat'].items()},
                         swap_reported_M_delta={k: after['swap_reported_M'][k] - v for k, v in before['swap_reported_M'].items()},
                         scope='Global endpoint snapshots/counters only, without process attribution or peak measurements. No causal or no-pressure claim.')
    headers_result = dict(schema='E036-independent-header-manifest-check-v1', status='PASS_HEADERS_INDEX_MANIFEST_ONLY',
                          plan_sha256=PLAN_SHA, candidate_sha256=CANDIDATE_SHA,
                          original_shards=len(original_headers), output_shards=len(output_headers),
                          input_tensors=len(original_rows), output_tensors=len(output_rows), stacked_tensors=stacked_count,
                          transformed_source_tensors=len(consumed), original_mtp45_tensors_preserved=len(mtp_keys),
                          payload_bytes=payload_bytes, source_headers=original_headers, output_headers=output_headers,
                          layout_sha256=plan['layout_sha256'], sidecars=sidecars,
                          index_sha256=complete['index_sha256'], producer_manifest_sha256=complete['manifest_sha256'],
                          source_stat_and_header_unchanged=True, all_source_tensors_exactly_once=True,
                          numeric_expert_order_0_through_287=True, sidecars_byte_identical=True,
                          original_payload_rehashed_by_this_validator=False, output_payload_read_by_this_validator=False,
                          loader_executed=False, numerical_qualified=False, performance_qualified=False,
                          scope='Independent header/index/manifest layout and small-sidecar check. Payload digests are preserved producer claims, not independently recomputed here.')
    # Write only after metadata checks have passed. All archive members are explicit;
    # safetensors members below contain prefix+JSON only, never tensor bytes.
    D.mkdir()
    save(D / 'header-verification.json', headers_result)
    save(D / 'memory-endpoints.json', memory_result)
    save(D / 'producer-complete.json', complete)
    retain('analysis/header-verification.json', D / 'header-verification.json')
    retain('analysis/memory-endpoints.json', D / 'memory-endpoints.json')
    for name, member in files.items():
        raw = header_bytes(Path(member['source']))[0] if member['kind'] == 'header_prefix_only' else small(member['source'])
        check(len(raw) == member['bytes'] and sha(raw) == member['sha256'], 'source metadata stable before archive')
    save(D / 'manifest.json', dict(schema='E036-metadata-archive-members-v1', members=files,
                                   excluded='All tensor payloads; tokenizer.json retained as checked hash reference only.'))
    archive = D / 'evidence.tar.xz'
    with tarfile.open(archive, 'x:xz', preset=3) as target:
        for name, member in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = member['bytes'], 0o644, 0
            target.addfile(info, io.BytesIO(data[name]))
    verified = set()
    with tarfile.open(archive, 'r:xz') as target:
        for member in target:
            check(member.isfile() and member.name in files and member.name not in verified, 'known unique regular archive member')
            verified.add(member.name)
            with target.extractfile(member) as stream:
                raw = stream.read()
            expected = files[member.name]
            check(len(raw) == member.size == expected['bytes'] and sha(raw) == expected['sha256'], 'every archive member readback SHA')
    check(verified == set(files), 'complete archive membership')
    for member in files.values():
        raw = header_bytes(Path(member['source']))[0] if member['kind'] == 'header_prefix_only' else small(member['source'])
        check(len(raw) == member['bytes'] and sha(raw) == member['sha256'], 'every original metadata member stable after archive')
    for name, observed in original_headers.items():
        check(identity(source / name) == observed['identity'], 'original weights stat unchanged at validator completion')
    for name, observed in output_headers.items():
        check(identity(O / name) == observed['identity'], 'output weights stat unchanged at validator completion')
    elapsed = final['ended_at'] - final['started_at']
    summary = dict(schema='E036-metadata-archive-verification-v1', status='PASS',
                   producer_status=complete['status'], independent_status=headers_result['status'],
                   execution_seconds=elapsed, execution_returncode=0, members=len(files),
                   raw_metadata_bytes=sum(m['bytes'] for m in files.values()),
                   archive=dict(name=archive.name, bytes=archive.stat().st_size, sha256=sha(small(archive))),
                   manifest_sha256=sha(small(D / 'manifest.json')),
                   header_verification_sha256=sha(small(D / 'header-verification.json')),
                   every_archive_member_readback_sha_verified=True, every_original_metadata_member_rechecked=True,
                   payload_bytes_archived=0, failed_actual_copy_attempts_in_this_execution=0,
                   GPU_executed=False, service_actions_executed=False, performance_qualified=False)
    save(D / 'archive-verification.json', summary)
    readme = f'''# E036: offline GLM expert repack

The actual offline copy exited 0 in **{elapsed:.6f} s**, with producer status
**PASS_BYTES_ONLY**. It converted 62 source shards into 58 output shards:
113,446 tensors become 4,960, including 378 stacks for backbone MoE layers 3–44.
The 203,976,457,080 payload bytes (about 190 GiB) are preserved without numerical
conversion. Original MTP layer 45 tensors remain unchanged and still need the
official loader's MTP stacking path.

The separate, candidate-independent validator reports
**PASS_HEADERS_INDEX_MANIFEST_ONLY**. It read the 62 original and 58 output
headers, both indices, the complete group/part manifest and sidecars. It checked
exact keys, shapes, dtypes, byte ranges, original expert order 0–287, exactly-once
source coverage, full payload-byte accounting and the preregistered layout SHA.
Config and tokenizer files are byte-identical; mixed 4/5/6-bit quantization maps
are unchanged. All original source stat identities and header hashes still match
the plan. It did not reread tensor payloads or import the candidate/model runtime.

The producer's source-full-SHA check, copy-time group/part hashes and independent
output reread are retained in the original receipts. Those establish its byte
copy result; the metadata validator does not independently re-prove payload
digests. Neither result establishes official-loader compatibility, physical
memory fit, inference correctness or speed. **No Pareto point was produced.**

`evidence.tar.xz` contains only explicit metadata members, including execution
stdout/stderr and final/invocation records, exact candidate and wrapper, source
pins, plan, original/output headers, indices, group/part SHA manifest and small
sidecars. Header members end in `.safetensors.header` and contain only the
8-byte length plus JSON. Tokenizer JSON is retained as a checked hash reference.
No weight payload is archived. Every one of {len(files)} members was reread and
SHA-verified; the original metadata was checked again after archiving.

The original RUNNING invocation and preparation-time text are preserved as
historical evidence; final.json and complete.json establish closure. This named
copy has no failed predecessor attempt. See RESULTS.md for global memory
endpoints and the limits of that observation. The offline operation contains no
service stop, reload or configuration change; service identity/health was not
independently sampled by this wrapper.

Archive SHA256: `{summary['archive']['sha256']}`.
Plan SHA256: `{PLAN_SHA}`.
'''
    results = f'''# E036 result and scope

| Observation | Result |
|---|---:|
| Actual wrapper return code | 0 |
| Offline operation duration | {elapsed:.6f} s |
| Original / output shards | 62 / 58 |
| Original / output tensors | 113,446 / 4,960 |
| Backbone expert stacks | 378 |
| Conserved payload bytes | 203,976,457,080 |
| Producer | PASS_BYTES_ONLY |
| Independent check | PASS_HEADERS_INDEX_MANIFEST_ONLY |

The independent check reconstructed all 378 stacked groups directly from actual
original headers, in numeric expert order. Gate/up packed weights retain U32
[2048,512] per expert at 4 bits; down retains U32 [4096,320] at 5 bits. Scale and
bias groups retain F16 and group size 64. Other tensors, including shared-expert
6-bit entries and all {len(mtp_keys):,} layer-45 tensors, remain passthrough. The
unchanged original config retains its original mixed-precision mappings. Runtime
MTP sanitization is still required; the repack does not eliminate that one stack.

Global endpoint counters use 16,384-byte pages. The exact raw vm_stat/sysctl
outputs remain in the archive; memory-endpoints.json contains all parsed values
and deltas.

| Global observation | Before | After | Delta |
|---|---:|---:|---:|
| Swap used (reported M / MiB) | 2023.25 | 2015.25 | −8.00 |
| Cumulative Swapouts (pages) | 782,442 | 782,442 | 0 |
| Cumulative Swapins (pages) | 135,038 | 135,410 | +372 |
| Cumulative compressions | 74,179,378 | 74,179,378 | 0 |
| Cumulative decompressions | 30,354,490 | 30,357,569 | +3,079 |
| Compressor occupied (pages) | 264,279 | 263,776 | −503 |
| Free pages | 111,408 | 94,152 | −17,256 |
| Speculative pages | 644 | 272,406 | +271,762 |

These are whole-machine observations over the copy interval. They do not assign
memory changes to the copy, establish a peak working set, or prove zero transient
pressure. F_NOCACHE was required per payload descriptor by the recorded code and
invocation; its effect is not causally isolated here. The copy does not alter or
control the original oMLX service. No service identity/health sample was taken.

Next evidence needed is a separately registered official-loader/memory trial,
followed by numerical inference qualification and performance measurement. This
archive contains no such trial, no benchmark and no mini engine GLM result.
'''
    for name, text in (('README.md', readme), ('RESULTS.md', results)):
        with (D / name).open('x') as stream:
            stream.write(text)
    print(json.dumps(summary))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if not args.run:
        print('DESCRIPTION_ONLY: metadata-only verification and archive of closed E036; no payload read, GPU or service actions.')
    else:
        try:
            run()
        except BaseException as error:
            if D.exists() and not (D / 'archive-failure.json').exists():
                save(D / 'archive-failure.json', dict(status='FAIL', type=type(error).__name__,
                                                     message=str(error), traceback=traceback.format_exc()))
            raise
