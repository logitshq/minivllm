"""One explicit small stdlib CPU attempt, immutable output and source receipts."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/ryanli/code/minivllm')
OUT = ROOT / '.artifacts/m5-ultra-256gb/state-log-exact-cpu-v1'
PYTHON = ROOT / '.venv/bin/python'
FILES = ['bench/m5_ultra_256gb/state_log_exact_reference/toy.py',
         'bench/m5_ultra_256gb/state_log_exact_reference/test_toy_cpu.py',
         'bench/m5_ultra_256gb/state_log_exact_reference/README.md',
         'tutorial_code/miniengine/kernels/gdn_norm_reuse_metal.py']


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    if sys.argv[1:] != ['--run']:
        print('Default OFF. --run records one stdlib-only test/toy attempt.')
        return 0
    OUT.mkdir()
    snapshots = OUT / 'sources'
    snapshots.mkdir()
    manifest = {}
    for name in FILES:
        data = (ROOT / name).read_bytes()
        copied = snapshots / Path(name).name
        with copied.open('xb') as stream:
            stream.write(data)
        manifest[name] = {'sha256': digest(data), 'bytes': len(data), 'copy': str(copied)}
    data = Path(__file__).read_bytes()
    (OUT / 'runner.py').write_bytes(data)
    write(OUT / 'source-pins.json', manifest)
    hook = '''import sys
sys.path.insert(0, %r)
def deny(event, args):
    if event == 'import' and str(args[0]).split('.')[0] in ('mlx', 'mlx_lm', 'omlx', 'torch', 'numpy'):
        raise RuntimeError('backend import forbidden')
    if event in ('subprocess.Popen','os.system','os.posix_spawn','os.kill','os.killpg','socket.connect','socket.bind'):
        raise RuntimeError('backend/network/process action forbidden: '+event)
sys.addaudithook(deny)
''' % str(ROOT)
    test_code = hook + '''import unittest
suite=unittest.defaultTestLoader.loadTestsFromName('bench.m5_ultra_256gb.state_log_exact_reference.test_toy_cpu')
assert suite.countTestCases()==8
r=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if r.wasSuccessful() and not r.skipped else 1)
'''
    toy_code = hook + '''from bench.m5_ultra_256gb.state_log_exact_reference.toy import main
raise SystemExit(main(['--run','--out',%r]))
''' % str(OUT / 'toy-result.json')
    record = {'schema': 'state-log-exact-cpu-attempt-v1', 'status': 'STARTED',
              'started_at': time.time(), 'runner_sha256': digest(data), 'runs': [],
              'expected_tests': 8, 'expected_toy_cases': 24,
              'metal_qualified': False, 'model_qualified': False, 'performance_qualified': False}
    write(OUT / 'started.json', record)
    try:
        for name, code in [('tests', test_code), ('toy', toy_code)]:
            command = [str(PYTHON), '-I', '-B', '-c', code]
            write(OUT / (name + '-command.json'), command)
            with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
                run = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=120)
            record['runs'].append({'name': name, 'returncode': run.returncode})
        record['source_unchanged'] = all(digest((ROOT / n).read_bytes()) == r['sha256'] for n, r in manifest.items())
        toy = json.loads((OUT / 'toy-result.json').read_text())
        record['status'] = 'PASS' if all(x['returncode'] == 0 for x in record['runs']) and record['source_unchanged'] and toy['status'] == 'PASS' and toy['completed_cases'] == 24 else 'FAIL'
        record['toy_result_sha256'] = digest((OUT / 'toy-result.json').read_bytes())
    except Exception as error:
        record.update(status='FAIL', error={'type': type(error).__name__, 'message': str(error)})
    record['ended_at'] = time.time()
    write(OUT / 'result.json', record)
    print(json.dumps(record, sort_keys=True))
    return 0 if record['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
