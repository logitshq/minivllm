from pathlib import Path
import hashlib,json,subprocess,time
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';P=R/'bench/m5_ultra_256gb/rowwise_native_verify_cost_v1'
code=r'''
import importlib.abc,json,os,socket,subprocess,sys,unittest,unittest.mock
forbidden=[]
class NoBackend(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in ('mlx','numpy','torch','jax','tensorflow','safetensors'):
   forbidden.append(fullname);raise AssertionError('forbidden backend '+fullname)
sys.meta_path.insert(0,NoBackend())
def deny(*a,**kw):forbidden.append('external operation');raise AssertionError('forbidden external operation')
subprocess.run=subprocess.Popen=subprocess.call=subprocess.check_call=subprocess.check_output=deny
os.kill=os.system=socket.socket=socket.create_connection=deny
import signal
signal.signal=signal.setitimer=deny
sys.path.insert(0,'/Users/ryanli/code/minivllm')
suite=unittest.defaultTestLoader.loadTestsFromName('bench.m5_ultra_256gb.rowwise_native_verify_cost_v1.test_owner_cpu')
result=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps(dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),forbidden=forbidden)))
raise SystemExit(0 if result.wasSuccessful() and result.testsRun==19 and not forbidden else 1)
'''
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
out=A/'c1-verifier-cost-owner-cpu-v1';out.mkdir();(out/'sources').mkdir()
sources=[P/'execute.py',P/'runner.py',P/'terminal_hold.py',P/'test_owner_cpu.py',P/'screen.py',P.parent/'gdn_batched_device_v1/execute.py',P.parent/'gdn_batched_device_v1/runner.py',P.parent/'concurrency_config_v2/execute.py',P.parent/'concurrency_config_v2/runner.py',P.parent/'glm_flash/physical_guard.py']
before={str(p):sha(p) for p in sources};write(out/'sources-before.json',before)
for i,p in enumerate(sources):(out/'sources'/f'{i}-{p.name}').write_bytes(p.read_bytes())
(out/'runner.py').write_bytes(Path(__file__).read_bytes());cmd=[str(R/'.venv/bin/python'),'-I','-B','-c',code];write(out/'command.json',cmd)
started=time.monotonic()
with (out/'stdout.txt').open('x') as stdout,(out/'stderr.txt').open('x') as stderr:result=subprocess.run(cmd,cwd=R,stdout=stdout,stderr=stderr)
after={str(p):sha(p) for p in sources};write(out/'sources-after.json',after)
write(out/'result.json',dict(returncode=result.returncode,elapsed_s=time.monotonic()-started,sources_unchanged=before==after))
print((out/'stdout.txt').read_text());print((out/'stderr.txt').read_text());print((out/'result.json').read_text())
raise SystemExit(result.returncode or int(before!=after))
