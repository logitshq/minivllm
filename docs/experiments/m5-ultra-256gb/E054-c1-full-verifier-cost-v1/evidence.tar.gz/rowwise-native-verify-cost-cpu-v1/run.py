import contextlib,hashlib,importlib.abc,json,pathlib,sys,time,unittest
R=pathlib.Path('/Users/ryanli/code/minivllm');D=pathlib.Path(__file__).resolve().parent;P=R/'bench/m5_ultra_256gb/rowwise_native_verify_cost_v1'
forbidden=[]
class Deny(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.startswith(('mlx','tutorial_code.miniengine')):
            forbidden.append(fullname);raise AssertionError('backend import forbidden '+fullname)
sys.meta_path.insert(0,Deny())
def guard(event,args):
    if event.startswith(('socket.','subprocess.','os.posix_spawn','os.system')):
        forbidden.append(event);raise AssertionError('device/network/process forbidden '+event)
sys.addaudithook(guard)
def pins():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in P.iterdir() if p.is_file()}
before=pins();start=time.monotonic()
with (D/'stdout.txt').open('x') as stdout,(D/'stderr.txt').open('x') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
    suite=unittest.defaultTestLoader.discover(str(P),pattern='test_cpu.py')
    result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
after=pins();rc=0 if result.wasSuccessful() and before==after and not forbidden else 1
receipt=dict(status='PASS' if rc==0 else 'FAIL',actual_returncode=rc,tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
    forbidden=forbidden,sources_before=before,sources_after=after,sources_unchanged=before==after,elapsed_s=time.monotonic()-start)
(D/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
(D/'command.json').write_text(json.dumps(dict(cwd=str(R),argv=[str(R/'.venv/bin/python'),'-I','-B',str(D/'run.py')]),indent=2)+'\n')
print(json.dumps(receipt));raise SystemExit(rc)
