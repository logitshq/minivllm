"""Tiny raw safetensors fixtures only. No model, backend, mmap or process imports."""
import ast
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

PATH=Path(__file__).with_name('candidate.py')
spec=importlib.util.spec_from_file_location('glm_repack_cpu_candidate',PATH)
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

class Tests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);self.root=Path(tmp.name).resolve()

    def fixture(self,experts=3):
        source=self.root/'source';source.mkdir();config=dict(model_type='glm5_next',text_config=dict(num_hidden_layers=1,n_routed_experts=experts,hidden_size=64,moe_intermediate_size=64,mlp_layer_types=['sparse']))
        q=dict(group_size=64,bits=4);q['model.layers.0.mlp.switch_mlp.down_proj']=dict(group_size=64,bits=5);q['model.layers.0.mlp.shared_experts.gate_proj']=dict(group_size=64,bits=6)
        config.update(quantization=q,quantization_config=q);(source/'config.json').write_bytes(c.encoded(config));(source/'tokenizer.json').write_bytes(b'{"fixture":"exact bytes  ","version":1}\n')
        raw={};descriptors={}
        for e in range(experts):
            for projection in ('gate_proj','up_proj','down_proj'):
                for suffix in ('weight','scales','biases'):
                    key=f'model.language_model.layers.0.mlp.experts.{e}.{projection}.{suffix}'
                    shape=[64,10 if projection=='down_proj' else 8] if suffix=='weight' else [64,1]
                    dtype='U32' if suffix=='weight' else 'F16';n=c.math.prod(shape)*c.DTYPES[dtype]
                    raw[key]=bytes([(e*17+len(raw))%256])*n;descriptors[key]=dict(dtype=dtype,shape=shape)
        extra={
            'model.language_model.layers.1.mlp.experts.0.down_proj.weight':('U32',[64,10]),
            'model.language_model.layers.0.mlp.shared_experts.gate_proj.weight':('U32',[64,12]),
            'model.language_model.norm.weight':('BF16',[64]),'lm_head.weight':('F32',[64,2])}
        for key,(dtype,shape) in extra.items():raw[key]=bytes([173])*c.math.prod(shape)*c.DTYPES[dtype];descriptors[key]=dict(dtype=dtype,shape=shape)
        keys=list(reversed(sorted(raw)));batches=[keys[::2],keys[1::2]];download=[];inventory=[];weight_map={}
        for i,keys in enumerate(batches):
            name=f'model-{i}.safetensors';header={'__metadata__':{'format':'pt'}};payload=b''
            for key in keys:header[key]=dict(**descriptors[key],data_offsets=[len(payload),len(payload)+len(raw[key])]);payload+=raw[key];weight_map[key]=name
            h=c.encoded(header);h+=b' '*((-len(h))%8);prefix=struct.pack('<Q',len(h))+h;p=source/name;p.write_bytes(prefix+payload)
            download.append(dict(name=name,bytes=p.stat().st_size,sha256=c.sha_file(p),sha256_verified=True))
            inventory.append(dict(name=name,file_bytes=p.stat().st_size,header_bytes=len(prefix),header_sha256=c.digest(prefix)))
        (source/'model.safetensors.index.json').write_bytes(c.encoded(dict(metadata={'total_size':sum(len(v) for v in raw.values())},weight_map=weight_map)))
        d=self.root/'download.json';h=self.root/'headers.json';d.write_bytes(c.encoded(dict(status='PASS_PINNED_DOWNLOAD_AND_SHA_ONLY',snapshot=str(source),shards=download)));h.write_bytes(c.encoded(dict(status='PASS_HEADER_INVENTORY_ONLY',snapshot=str(source),shards=inventory)))
        runtime=self.root/'fake-reviewed-loader.py';runtime.write_bytes(b'# explicit CPU source fixture\n')
        args=(source,c.reference(d),c.reference(h),{str(runtime):c.sha_file(runtime)})
        return args,raw,descriptors,config

    def test_default_never_reads_or_executes(self):
        with patch.object(c,'inspect',side_effect=AssertionError('read')),patch.object(c,'execute',side_effect=AssertionError('copy')),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(c.main([]),0)
            with self.assertRaises(ValueError):c.main(['--out',str(self.root/'out')])

    def test_plan_is_metadata_only_and_original_stack_order(self):
        args,raw,descriptors,config=self.fixture(experts=12)
        with patch.object(c,'sha_file',side_effect=lambda p,*a:hashlib.sha256(PATH.read_bytes()).hexdigest() if p==PATH else (_ for _ in ()).throw(AssertionError('payload hashing during inspect'))):
            plan,rows=c.inspect(*args)
        self.assertEqual(plan['summary']['stacked_tensors'],9)
        target=next(r for r in rows if r['key'].endswith('switch_mlp.down_proj.weight'))
        self.assertEqual([int(p['key'].split('.')[6]) for p in target['parts']],list(range(12)))
        self.assertEqual(target['shape'],[12,64,10])

    def test_roundtrip_multiple_shards_and_all_unmodified_tensors_sidecars(self):
        args,raw,descriptors,config=self.fixture();plan,rows=c.inspect(*args);before={p.name:c.sha_file(p) for p in args[0].iterdir()};out=self.root/'output'
        result=c.execute(plan,out,buffer=73,shard_limit=10000,reserve=0)
        self.assertEqual(result['status'],'PASS_BYTES_ONLY');self.assertFalse(result['runtime_load_executed']);self.assertGreater(len(result['files']),1)
        index=json.loads((out/'model.safetensors.index.json').read_bytes())['weight_map'];self.assertEqual(set(index),{r['key'] for r in rows})
        for row in rows:
            name=index[row['key']];head,meta=c.header(out/name);a,b=head[row['key']]['data_offsets']
            with (out/name).open('rb') as f:f.seek(meta['header_bytes']+a);actual=f.read(b-a)
            self.assertEqual(actual,b''.join(raw[p['key']] for p in row['parts']))
            self.assertEqual(head[row['key']]['shape'],row['shape']);self.assertEqual(head[row['key']]['dtype'],row['dtype'])
        for name in ('config.json','tokenizer.json'):self.assertEqual((out/name).read_bytes(),(args[0]/name).read_bytes())
        self.assertEqual(before,{p.name:c.sha_file(p) for p in args[0].iterdir()})
        self.assertIn('model.language_model.layers.1.mlp.experts.0.down_proj.weight',index)

    def test_exact_original_dsv_sanitize_ast_on_fake_bytes_agrees(self):
        args,raw,descriptors,config=self.fixture();plan,rows=c.inspect(*args)
        path=c.SITE/'mlx_lm/models/deepseek_v32.py';self.assertEqual(c.digest(path.read_bytes()),c.REVIEWED['mlx_lm/models/deepseek_v32.py'])
        tree=ast.parse(path.read_text());cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='Model');fn=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='sanitize')
        class Array:
            def __init__(self,dtype,shape,data):self.dtype,self.shape,self.data=dtype,shape,data
        def stack(values):
            self.assertTrue(all(v.dtype==values[0].dtype and v.shape==values[0].shape for v in values))
            return Array(values[0].dtype,[len(values)]+values[0].shape,b''.join(v.data for v in values))
        env={'mx':SimpleNamespace(stack=stack)};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(path),'exec'),env)
        def remap(key):
            return 'model.'+key[len('model.language_model.'):] if key.startswith('model.language_model.') else key
        before={remap(k):Array(descriptors[k]['dtype'],descriptors[k]['shape'],v) for k,v in raw.items()}
        after={remap(r['key']):Array(r['dtype'],r['shape'],b''.join(raw[p['key']] for p in r['parts'])) for r in rows}
        obj=SimpleNamespace(args=SimpleNamespace(num_hidden_layers=1,n_routed_experts=3))
        a=env['sanitize'](obj,before);b=env['sanitize'](obj,after)
        self.assertEqual(set(a),set(b))
        for k in a:self.assertEqual((a[k].dtype,a[k].shape,a[k].data),(b[k].dtype,b[k].shape,b[k].data))

    def test_missing_expert_and_mismatched_dtype_reject(self):
        args,raw,desc,config=self.fixture();plan,rows=c.inspect(*args);tensors={p['key']:{k:v for k,v in p.items() if k!='key'} for r in rows for p in r['parts']}
        key=next(k for k in tensors if '.experts.1.' in k)
        missing=dict(tensors);missing.pop(key)
        with self.assertRaisesRegex(ValueError,'missing/out-of-range'):c.outputs_for(missing,config)
        wrong=dict(tensors);wrong[key]={**wrong[key],'dtype':'BF16'}
        with self.assertRaisesRegex(ValueError,'mixed expert'):c.outputs_for(wrong,config)

    def test_wrong_mixed_quantization_rejects(self):
        args,raw,desc,config=self.fixture();plan,rows=c.inspect(*args);tensors={p['key']:{k:v for k,v in p.items() if k!='key'} for r in rows for p in r['parts']}
        config['quantization']['model.layers.0.mlp.switch_mlp.down_proj']['bits']=4
        with self.assertRaisesRegex(ValueError,'mixed expert quantization'):c.outputs_for(tensors,config)

    def test_stale_sidecar_or_repacker_plan_rejects_before_output(self):
        args,*_=self.fixture();plan,_=c.inspect(*args);(args[0]/'tokenizer.json').write_bytes(b'changed');out=self.root/'out'
        with self.assertRaisesRegex(ValueError,'unchanged plan'):c.execute(plan,out,reserve=0)
        self.assertFalse(out.exists())

    def test_full_payload_hash_catches_header_preserving_corruption(self):
        args,*_=self.fixture();path=args[0]/'model-0.safetensors'
        with path.open('r+b') as f:f.seek(-1,2);old=f.read(1);f.seek(-1,2);f.write(bytes([old[0]^1]))
        plan,_=c.inspect(*args);out=self.root/'out'
        with self.assertRaisesRegex(ValueError,'original full payload SHA'):c.execute(plan,out,reserve=0)
        self.assertFalse(out.exists())

    def test_existing_output_and_disk_reserve_reject_before_copy(self):
        args,*_=self.fixture();plan,_=c.inspect(*args);out=self.root/'out';out.mkdir()
        with self.assertRaisesRegex(ValueError,'fresh'):c.execute(plan,out,reserve=0)
        with patch.object(c.os,'statvfs',return_value=SimpleNamespace(f_bavail=1,f_frsize=1)),self.assertRaisesRegex(ValueError,'insufficient disk'):
            c.execute(plan,self.root/'new',reserve=0)
        self.assertFalse((self.root/'new').exists())

    def test_failure_keeps_partial_files_and_never_finalizes_index(self):
        args,*_=self.fixture();plan,_=c.inspect(*args);out=self.root/'out'
        with patch.object(Path,'rename',side_effect=OSError('CPU injected rename failure')),self.assertRaisesRegex(OSError,'CPU injected'):
            c.execute(plan,out,buffer=53,shard_limit=10000,reserve=0)
        self.assertTrue((out/'failure.json').is_file());self.assertTrue(list(out.glob('*.partial')))
        self.assertFalse((out/'model.safetensors.index.json').exists());self.assertFalse((out/'complete.json').exists())

    def test_invalid_header_overlap_and_duplicate_key_reject(self):
        path=self.root/'bad.safetensors';h={'a':dict(dtype='U32',shape=[1],data_offsets=[0,4]),'b':dict(dtype='U32',shape=[1],data_offsets=[0,4])};raw=c.encoded(h);path.write_bytes(struct.pack('<Q',len(raw))+raw+b'1234')
        with self.assertRaisesRegex(ValueError,'gap/overlap'):c.header(path)
        with self.assertRaisesRegex(ValueError,'duplicate JSON'):c.loads(b'{"a":1,"a":2}')

if __name__=='__main__':unittest.main()
