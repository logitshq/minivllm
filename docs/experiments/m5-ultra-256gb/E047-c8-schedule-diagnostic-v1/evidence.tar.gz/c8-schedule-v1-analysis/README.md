# E047 observed C8 schedules

Both waves used MB50, GDN OFF and graph ON. The raw join checked all 16 requests and 1,030 steps. Observation can alter scheduling; these are diagnostic results, not performance points.

| Fixture | Warm scheduled prefill chunks | Screen scheduled prefill chunks | First different output index (0-based) | Warm / screen token IDs |
|---|---|---|---:|---|
| D01-ttl-lru | [978] | [978] | None | None / None |
| D02-dag-scheduler | [886] | [352, 534] | None | None / None |
| D03-event-rollup | [926] | [926] | None | None / None |
| D04-frame-parser | [257, 664] | [921] | 92 | 18 / 19 |
| D05-retry-budget | [454, 500] | [552, 402] | None | None / None |
| D06-interval-booking | [935] | [935] | 46 | 24959 / 52883 |
| D07-versioned-store | [903] | [144, 759] | 35 | 791 / 2243 |
| D08-sliding-limit | [958] | [958] | 209 | 687 / 554 |

D06 receives all 935 prompt tokens in one scheduled prefill in both waves. Its first decode outputs follow B2→B4→B6→B8 at row 1 in warm, versus B4→B6→B8 at row 3 in screen. Output index 46 differs at global steps 47/563: 24959 versus 52883. Thus this D06 observation is not explained by a changed prefill split alone. Batch shape, row placement, and retained process history still differ.

The exact D06 prefix recipes stop after global steps 49 and 565 (output index 48). All jobs, original max_tokens=512 and actual arrivals/schedules remain unchanged. The screen recipe starts at global step 1 and therefore preserves the preceding warm history. An isolated screen replay would be a different experiment.

Next test: replay each fixed history with the existing independent eager/graph engines and full logit/state/ID checks, stopping explicitly at the registered prefix. A successful prefix is incomplete by design; it is never a complete-model or full-history qualification. E024 full 16-request replay took 512.49 s with a reported MLX allocator peak of 68.55 GiB; prefix peak physical memory is not known. Existing resource gates remain mandatory.

Files: analysis.json retains every per-output batch/row trajectory plus raw timing and input SHAs; d06-prefix-recipes.json holds the two exact diagnostic stop descriptors. No model was run for this analysis.
