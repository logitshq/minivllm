"""One explicit post-formal CPU check; default describes, never waits or runs GPU."""
import argparse,contextlib,hashlib,importlib.abc,importlib.util,json,os,signal,socket,subprocess,sys,time,traceback,unittest,unittest.mock
from pathlib import Path
ROOT=Path('/Users/ryanli/code/minivllm'); BASE=ROOT/'bench/m5_ultra_256gb'
OUT=ROOT/'.artifacts/m5-ultra-256gb/glm-text-facade-cpu-v1'
MODULES=[('glm_text_facade/test_facade_cpu.py',11)]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
 with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
 if not args.run:print('DESCRIPTION ONLY: focused fake CPU suites after actual E033 RESTORED closure.');return 0
 final=ROOT/'.artifacts/m5-ultra-256gb/gdn-graph-combined-formal-v2-execution/final.json'
 audit=ROOT/'docs/experiments/m5-ultra-256gb/E033-gdn-graph-combined-formal-v2/restoration-audit.json'
 result=json.loads(final.read_bytes());proof=json.loads(audit.read_bytes())
 assert result['journal_state']=='RESTORED' and result['recovery_returncode']==0 and proof['status']=='PASS' and proof['qualified'] is True
 OUT.mkdir(exist_ok=False);(OUT/'sources').mkdir();sys.path.insert(0,str(ROOT))
 dirs={str(Path(x).parent) for x,n in MODULES}

 paths=sorted({p for d in dirs for p in (BASE/d).glob('*.py')}|set((ROOT/'tutorial_code/miniengine').rglob('*.py'))|{Path(__file__).resolve()})
 before={str(p):sha(p) for p in paths}
 for index,p in enumerate(paths):(OUT/'sources'/f'{index:03}-{p.name}').write_bytes(p.read_bytes())
 write(OUT/'source-before.json',before);write(OUT/'invocation.json',dict(argv=[sys.executable,'-I','-B',str(Path(__file__).resolve()),'--run'],formal_final=dict(path=str(final),sha256=sha(final)),restoration_audit=dict(path=str(audit),sha256=sha(audit))))
 forbidden=[];signal_fakes=[];began=time.monotonic();result=None;error=None;discovered=[]
 def deny(label):
  def fail(*args,**kw):forbidden.append(label);raise AssertionError('forbidden '+label)
  return fail
 class Guard(importlib.abc.MetaPathFinder):
  def find_spec(self,name,path=None,target=None):
   if name.split('.')[0] in ('mlx','mlx_lm','mlx_vlm','torch','transformers','safetensors','omlx','monolith'):deny('backend '+name)()
 guard=Guard();sys.meta_path.insert(0,guard);getsignal=signal.getsignal
 def asyncio_signal(signum,handler):
  caller=sys._getframe(1);path=Path(caller.f_code.co_filename)
  if signum==signal.SIGINT and path.name=='runners.py' and path.parent.name=='asyncio' and caller.f_code.co_name=='run':
   signal_fakes.append(dict(signal=int(signum),caller=str(path),effect='suppressed OS handler mutation'));return getsignal(signum)
  return deny('signal')(signum,handler)
 try:
  with contextlib.ExitStack() as stack:
   for obj,name in ((subprocess,'Popen'),(os,'kill'),(os,'killpg'),(os,'system'),(socket.socket,'connect'),(socket.socket,'bind'),(socket,'create_connection'),(signal,'setitimer')):stack.enter_context(unittest.mock.patch.object(obj,name,deny(name)))
   stack.enter_context(unittest.mock.patch.object(signal,'signal',asyncio_signal))
   with (OUT/'stdout.txt').open('x') as stdout,(OUT/'stderr.txt').open('x') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
    suite=unittest.TestSuite()
    for rel,count in MODULES:
     name='bench.m5_ultra_256gb.'+rel.replace('/','.').removesuffix('.py');spec=importlib.util.spec_from_file_location(name,BASE/rel);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
     tests=unittest.defaultTestLoader.loadTestsFromModule(module);discovered.append(dict(path=rel,expected=count,discovered=tests.countTestCases()))
     if tests.countTestCases()!=count:raise AssertionError(discovered[-1])
     suite.addTests(tests)
    result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
 except BaseException as exc:error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
 finally:sys.meta_path.remove(guard)
 after={str(p):sha(p) for p in paths};write(OUT/'source-after.json',after)
 expected=sum(count for rel,count in MODULES)
 ok=bool(result and result.wasSuccessful() and result.testsRun==expected and not result.skipped and not forbidden and before==after and error is None)
 row=dict(schema='Next-candidate-CPU-v1',status='PASS' if ok else 'FAIL',expected=expected,modules=discovered,tests_run=result.testsRun if result else 0,failures=[(x.id(),v) for x,v in result.failures] if result else [],errors=[(x.id(),v) for x,v in result.errors] if result else [],skipped=[(x.id(),v) for x,v in result.skipped] if result else [],exception=error,forbidden=forbidden,asyncio_sigint_fakes=signal_fakes,source_unchanged=before==after,elapsed_seconds=time.monotonic()-began,scope='CPU fake/control and tiny NumPy scheduler tests only; no model/backend/process/service operations; no device or performance qualification')
 write(OUT/'result.json',row);print(json.dumps({k:row[k] for k in ('status','expected','tests_run','exception','forbidden','source_unchanged','elapsed_seconds')}));return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
