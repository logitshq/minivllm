"""One recorded fake-only GLM owner CPU run; no extra GPU work or service action.

No real subprocess/network/process signals or model/backend imports. Module
names and expected counts are explicit command arguments, never auto-skipped.
"""
import argparse,contextlib,datetime,hashlib,importlib.abc,importlib.metadata,json,os
from pathlib import Path
import socket,subprocess,sys,time,traceback,unittest
from unittest.mock import patch
ROOT=Path('/Users/ryanli/code/minivllm'); ART=ROOT/'.artifacts/m5-ultra-256gb'
PYTHON=ROOT/'.artifacts/omlx-baseline/.venv/bin/python'
SUITES={'bench.m5_ultra_256gb.glm_flash_cycle.test_owner_cpu':12}

FORBIDDEN={'mlx','omlx','mlx_lm','mlx_vlm','torch','numpy','tutorial_code','monolith'}
SOURCE_DIRS=('glm_flash','glm_flash_cycle','pareto_realistic','omlx_cold_restart','cold_cycle','cold_cycle_v2','cold_cycle_v3')

def need(ok,msg):
 if not ok:raise AssertionError(msg)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--suite',action='append',required=True);parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
 need(Path(sys.executable)==PYTHON and Path(sys.prefix)==PYTHON.parent.parent and sys.flags.isolated==1 and sys.dont_write_bytecode is True,'actual vendor Python -I -B required')
 need(args.out.is_absolute() and args.out.parent==ART and not args.out.exists(),'fresh artifact output')
 suites=[]
 for item in args.suite:
  name,n=item.rsplit(':',1);need(name in SUITES and int(n)==SUITES[name] and len(name.split('.'))==4 and (ROOT/Path(*name.split('.'))).with_suffix('.py').is_file(),'whole registered test module and exact expected count required')
  suites.append(dict(module=name,expected_tests=int(n)))
 need(len({r['module'] for r in suites})==len(suites),'unique suite list')
 final=ART/'route-http-v1-execution/final.json';journal=ART/'route-http-v1-cold-journal/journal.json';audit=ART/'route-http-v1-analysis/restoration-audit.json'
 f,j,a=map(read,(final,journal,audit));need(f['journal_state']==j['state']=='RESTORED' and f['recovery_returncode']==0 and a['status']=='PASS' and a['qualified'] is True and a['journal_sha256']==sha(journal.read_bytes()),'closed restored independent gate')
 args.out.mkdir();(args.out/'runner.py').write_bytes(Path(__file__).read_bytes())
 rec=dict(schema='GLM-owner-prepared-cpu-v1',status='RUNNING',started_at=now(),argv=[str(PYTHON),'-I','-B',str(Path(__file__).resolve()),*sys.argv[1:]],suites=suites,expected_tests=sum(r['expected_tests'] for r in suites),python_executable=sys.executable,python_resolved=str(Path(sys.executable).resolve()),python_version=sys.version,tests=0,failures=0,errors=0,skipped=0,denied_operations=[],test_outcomes=[],source_before={},source_after={},scope='Fake CPU wiring/validator tests only. No GPU/model/service/physical-capacity/numerical/performance qualification.')
 for name,p in [('execution-final.json',final),('restored-journal.json',journal),('restoration-audit.json',audit)]:
  raw=p.read_bytes();(args.out/name).write_bytes(raw);rec.setdefault('restoration_gate',{})[name]=dict(path=str(p),sha256=sha(raw))
 paths={Path(__file__).resolve()};base=ROOT/'bench/m5_ultra_256gb'
 for name in SOURCE_DIRS:paths.update((base/name).glob('*.py'))
 paths.update((ROOT/'tutorial_code/miniengine').rglob('*.py'))
 paths.update(base/n for n in ('resources.py','resources_v2.py','resource_base.py','cold_cycle/lifecycle.json','cold_cycle_v2/lifecycle.json','cold_cycle_v3/lifecycle.json'))
 def save():write(args.out/'result.json',rec)
 def deny(kind,detail):
  rec['denied_operations'].append(dict(kind=kind,detail=str(detail)));raise AssertionError('forbidden real operation: '+kind)
 def hook(event,args):
  if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','os.exec','os.spawn','os.kill','os.killpg','socket.connect','socket.bind'):deny(event,args)
 class Imports(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0] in FORBIDDEN:deny('backend import',fullname)
   return None
 class Result(unittest.TextTestResult):
  def startTest(self,test):rec['test_outcomes'].append(dict(id=test.id(),status='RUNNING'));super().startTest(test)
  def addSuccess(self,test):rec['test_outcomes'][-1]['status']='PASS';super().addSuccess(test)
  def addFailure(self,test,error):rec['test_outcomes'][-1].update(status='FAIL',detail=self._exc_info_to_string(error,test));super().addFailure(test,error)
  def addError(self,test,error):rec['test_outcomes'][-1].update(status='ERROR',detail=self._exc_info_to_string(error,test));super().addError(test,error)
  def addSkip(self,test,reason):rec['test_outcomes'][-1].update(status='SKIP',reason=reason);super().addSkip(test,reason)
  def addExpectedFailure(self,test,error):rec['test_outcomes'][-1]['status']='EXPECTED_FAILURE';super().addExpectedFailure(test,error)
  def addUnexpectedSuccess(self,test):rec['test_outcomes'][-1]['status']='UNEXPECTED_SUCCESS';super().addUnexpectedSuccess(test)
  def addSubTest(self,test,subtest,error):
   if error is not None:rec['test_outcomes'][-1].update(status='FAIL',subtest=str(subtest),detail=self._exc_info_to_string(error,test))
   super().addSubTest(test,subtest,error)
 guard=None;start=time.monotonic();save()
 try:
  for p in sorted(paths):
   raw=p.read_bytes();rec['source_before'][str(p)]=dict(sha256=sha(raw),bytes=len(raw));dest=args.out/'frozen-source'/str(p).lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
  os.chdir(ROOT);sys.path.insert(0,str(ROOT));guard=Imports();sys.meta_path.insert(0,guard);sys.addaudithook(hook);save()
  with (args.out/'stdout.txt').open('x') as out,(args.out/'stderr.txt').open('x') as err,contextlib.redirect_stdout(out),contextlib.redirect_stderr(err),patch.object(subprocess,'Popen',side_effect=lambda *a,**k:deny('Popen',a)),patch.object(subprocess,'run',side_effect=lambda *a,**k:deny('subprocess.run',a)),patch.object(socket.socket,'connect',side_effect=lambda *a,**k:deny('socket.connect',a)),patch.object(socket.socket,'connect_ex',side_effect=lambda *a,**k:deny('socket.connect_ex',a)),patch.object(socket.socket,'bind',side_effect=lambda *a,**k:deny('socket.bind',a)):
   loaded=[]
   for row in suites:
    suite=unittest.defaultTestLoader.loadTestsFromName(row['module']);row['discovered_tests']=suite.countTestCases();loaded.append(suite)
   result=unittest.TextTestRunner(stream=err,verbosity=2,resultclass=Result).run(unittest.TestSuite(loaded))
  rec.update(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),expected_failures=len(result.expectedFailures),unexpected_successes=len(result.unexpectedSuccesses),loader_errors=unittest.defaultTestLoader.errors,failures_detail=[dict(test=t.id(),traceback=s) for t,s in result.failures],errors_detail=[dict(test=t.id(),traceback=s) for t,s in result.errors])
  rec['status']='PASS' if result.wasSuccessful() and result.testsRun==rec['expected_tests'] and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses and not rec['loader_errors'] and not rec['denied_operations'] and all(r['discovered_tests']==r['expected_tests'] for r in suites) else 'FAIL'
 except BaseException as exc:rec.update(status='FAIL',error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc()))
 finally:
  if guard in sys.meta_path:sys.meta_path.remove(guard)
  for p in sorted(paths):
   try:
    raw=p.read_bytes();rec['source_after'][str(p)]=dict(sha256=sha(raw),bytes=len(raw))
   except BaseException as exc:rec['source_after'][str(p)]=dict(error=str(exc))
  rec['source_unchanged']=bool(rec['source_before']) and rec['source_before']==rec['source_after'];rec['forbidden_modules_loaded']=sorted(n for n in sys.modules if n.split('.')[0] in FORBIDDEN)
  if not rec['source_unchanged'] or rec['forbidden_modules_loaded']:rec['status']='FAIL'
  rec.update(ended_at=now(),elapsed_seconds=time.monotonic()-start);save()
  files={str(p.relative_to(args.out)):dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in args.out.rglob('*') if p.is_file()}
  write(args.out/'artifact-manifest.json',dict(schema='cpu-artifact-inventory-v1',files=files))
 print(json.dumps({k:rec[k] for k in ('status','tests','failures','errors','skipped','source_unchanged')}));return 0 if rec['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
