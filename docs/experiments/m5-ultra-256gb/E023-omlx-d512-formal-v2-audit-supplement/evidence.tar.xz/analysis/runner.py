import datetime,hashlib,json,subprocess,time
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';S=R/'bench/m5_ultra_256gb/omlx_d512_formal_retry';O=A/'omlx-d512-formal-v2-analysis-postrun-v2'
OWNER=A/'omlx-d512-formal-v2-owner';JOURNAL=A/'omlx-d512-formal-v2-cold-journal';PY=R/'.venv/bin/python'
assert not O.exists();O.mkdir();(O/'runner.py').write_bytes(Path(__file__).read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
rec=dict(schema='omlx-formal-postrun-audit-execution-v2',scope='Offline parser correction only; original failed audits and all frozen measured sources remain untouched.',source_pins={},jobs={},original_failures={})
for n in ('audit_resources_v2.py','audit_formal_v2.py','test_audits_v2_cpu.py'):
 p=S/n;(O/n).write_bytes(p.read_bytes());rec['source_pins'][str(p)]=sha(p)
for n in ('resource-summary.json','independent-formal.json','restoration-audit.json'):
 p=A/'omlx-d512-formal-v2-analysis'/n;rec['original_failures'][n]={'path':str(p),'sha256':sha(p)}
plan=sha(OWNER/'owner-plan.json');assert plan=='3d2d1c5880fd3bc32900a84611097d50277a226b9fdb88d04dfa1d37330aa45b'
rec['owner_plan_sha256']=plan
for name,source,argv,filename in [('resources','audit_resources_v2.py',['--owner',str(OWNER)],'resource-summary.json'),('formal','audit_formal_v2.py',['--owner',str(OWNER),'--journal',str(JOURNAL),'--plan-sha256',plan],'independent-formal.json')]:
 cmd=[str(PY),'-I','-B',str(S/source),*argv,'--out',str(O/filename)]
 row={'command':cmd,'cwd':str(R),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':300};save(O/(name+'-command.json'),row);start=time.monotonic()
 try:
  with (O/(name+'.stdout')).open('x') as out,(O/(name+'.stderr')).open('x') as err:
   r=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=300,check=False)
  row['returncode']=r.returncode
 except BaseException as exc:row['error']={'type':type(exc).__name__,'message':str(exc)}
 row['elapsed_seconds']=time.monotonic()-start
 if (O/filename).exists():
  value=json.loads((O/filename).read_bytes());row.update(status=value.get('status'),result_sha256=sha(O/filename))
 save(O/(name+'-execution.json'),row);rec['jobs'][name]=row
 print(json.dumps({'name':name,**row}),flush=True)
rec['sources_unchanged']=all(sha(Path(p))==h for p,h in rec['source_pins'].items())
rec['original_failures_unchanged']=all(sha(Path(v['path']))==v['sha256'] for v in rec['original_failures'].values())
rec['status']='PASS' if all(v.get('returncode')==0 and v.get('status')=='PASS' for v in rec['jobs'].values()) and rec['sources_unchanged'] and rec['original_failures_unchanged'] else 'FAIL'
save(O/'execution-summary.json',rec)
save(O/'manifest.json',{str(p.relative_to(O)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in O.rglob('*') if p.is_file()})
raise SystemExit(0 if rec['status']=='PASS' else 1)
