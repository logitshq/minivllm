import contextlib,datetime,hashlib,importlib.abc,json,os
from pathlib import Path
import socket,subprocess,sys,unittest
R=Path('/Users/ryanli/code/minivllm');P=R/'bench/m5_ultra_256gb/omlx_d512_formal_retry'
O=R/'.artifacts/m5-ultra-256gb/omlx-formal-postrun-audit-cpu-v1'
assert not O.exists() and sys.flags.isolated==1 and sys.dont_write_bytecode
O.mkdir();(O/'runner.py').write_bytes(Path(__file__).read_bytes())
rec=dict(schema='omlx-postrun-audit-cpu-v1',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=[sys.executable,'-I','-B',str(Path(__file__).resolve())],tests=0,status='RUNNING',denied=[],source_pins={},scope='Six focused stdlib tests only, actual closed receipt regression; no model/service/runtime/GPU or performance qualification.')
paths=[P/n for n in ('audit_resources_v2.py','audit_formal_v2.py','test_audits_v2_cpu.py','audit_resources.py','audit_formal.py','owner.py','formal.py')]
paths += [P.parent/n for n in ('omlx_d512/audit_qualification.py','omlx_d512/join_v2.py','lithos_d512_formal/audit_resources.py','pareto_realistic/audit_native_formal.py','pareto_realistic/qualify_absent_owner.py')]
for path in paths:
 raw=path.read_bytes();name=str(path.relative_to(R));dest=O/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 rec['source_pins'][str(path)]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
def deny(event,args):
 rec['denied'].append({'event':event,'args':str(args)});raise AssertionError('forbidden: '+event)
def hook(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.kill','os.killpg','socket.connect','socket.bind'):deny(event,args)
class Imports(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in ('mlx','omlx','mlx_lm','mlx_vlm','torch','numpy','tutorial_code'):deny('import',fullname)
sys.addaudithook(hook);sys.meta_path.insert(0,Imports());sys.path.insert(0,str(R))
try:
 with (O/'stdout.txt').open('x') as out,(O/'stderr.txt').open('x') as err,contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
  suite=unittest.defaultTestLoader.loadTestsFromName('bench.m5_ultra_256gb.omlx_d512_formal_retry.test_audits_v2_cpu')
  rec['discovered_tests']=suite.countTestCases();result=unittest.TextTestRunner(stream=err,verbosity=2).run(suite)
 rec.update(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),failures_detail=[{'test':t.id(),'traceback':x} for t,x in result.failures],errors_detail=[{'test':t.id(),'traceback':x} for t,x in result.errors])
 rec['status']='PASS' if result.wasSuccessful() and result.testsRun==6 and not result.skipped and not rec['denied'] else 'FAIL'
except BaseException as exc:rec.update(status='FAIL',error={'type':type(exc).__name__,'message':str(exc)})
finally:
 rec['source_unchanged']=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v['sha256'] for p,v in rec['source_pins'].items())
 if not rec['source_unchanged']:rec['status']='FAIL'
 rec['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'result.json').write_text(json.dumps(rec,indent=2)+'\n')
 files={str(p.relative_to(O)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in O.rglob('*') if p.is_file()}
 (O/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
print(json.dumps({k:rec.get(k) for k in ('status','tests','failures','errors','skipped','source_unchanged')}))
raise SystemExit(0 if rec['status']=='PASS' else 1)
