"""Retain a CLOSED post-run oMLX formal audit supplement; never replace v1 FAIL.

Default is description only. --run packages new small source/test/audit records,
binds the original immutable archive, and checks the unchanged original inputs.
No audit, process, service, model import or model/runtime payload is executed.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import shutil
import tarfile

ROOT = Path('/Users/ryanli/code/minivllm')
ART = ROOT / '.artifacts/m5-ultra-256gb'
SOURCE = ROOT / 'bench/m5_ultra_256gb/omlx_d512_formal_retry'
OLD = ROOT / 'docs/experiments/m5-ultra-256gb/E023-omlx-d512-formal-v2'
OUT = ROOT / 'docs/experiments/m5-ultra-256gb/E023-omlx-d512-formal-v2-audit-supplement'
CPU = ART / 'omlx-formal-postrun-audit-cpu-v1'
ANALYSIS = ART / 'omlx-d512-formal-v2-analysis-postrun-v2'
OWNER = ART / 'omlx-d512-formal-v2-owner'
JOURNAL = ART / 'omlx-d512-formal-v2-cold-journal'
PLAN_SHA = '3d2d1c5880fd3bc32900a84611097d50277a226b9fdb88d04dfa1d37330aa45b'
PHASES = ['r1-c1', 'r1-c8', 'r2-c8', 'r2-c1', 'r3-c1', 'r3-c8']
OLD_PINS = {
    'archive-verification.json': 'e3e45750ba7edfeffa7347cfeb40ff6a395de6001dacf116cad92b6efee398b1',
    'manifest.json': '86577f2e9ec0021674a7b5bb8b577731d32bd8b83253a7cb7eaf482b7700f421',
    'independent-formal.json': '4b6f610dda24d0c4d52ae7ec22452709491a84bcd460f36814ae9ca1e416530f',
    'resource-summary.json': 'b290cd4d89608a41c3de76916dc65df63cef8157aaf10a7d53c6929408cd8018',
    'restoration-audit.json': '9aaf59b6482f22c24268b36e3ee8b661510d924b2a2ae3b4b43e204b5a934aca',
    'restored-journal.json': 'a4cea1bb7c8a8491a0474cbfbb939eead5de81723ee445c4bf2f2a88e0d71e06',
}
ARCHIVE = dict(sha256='c465243dc4b1547af1d5307193c7861fe169ef05a79ee31fdeb3e7eda1de87ac', bytes=7064844)
NEW_PINS = {
    'audit_resources_v2.py': 'd488e30a1cef33663657a45ab74269753e821b21f1539b078c097be35ee206c5',
    'audit_formal_v2.py': 'a34a01882225ab1166fc8c4742c419c9ce2e697ed2e4931d49f7af65ae24232a',
    'test_audits_v2_cpu.py': '7405612280521e2a166937954a1b54a6b38ca30823548a92dc99f258c3e9f8a6',
}
FORBIDDEN = ('.safetensors', '.so', '.dylib', '.bin', '.pack')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def info(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'regular file required: ' + str(path))
    key = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns)
    before = path.stat(); digest = hashlib.sha256(); size = 0
    with path.open('rb') as stream:
        need(key(os.fstat(stream.fileno())) == key(before), 'file replaced before read')
        while chunk := stream.read(1 << 20):
            digest.update(chunk); size += len(chunk)
        need(key(os.fstat(stream.fileno())) == key(before), 'open file changed')
    need(key(path.stat()) == key(before) and size == before.st_size, 'file changed after read')
    return dict(sha256=digest.hexdigest(), bytes=size)


def files(root):
    need(root.is_dir() and not root.is_symlink(), 'real closed directory required: ' + str(root))
    result = []
    for folder, dirs, names in os.walk(root, followlinks=False):
        for name in dirs + names:
            path = Path(folder) / name
            need(not path.is_symlink(), 'supplement cannot contain symlinks: ' + str(path))
            if path.is_file():
                need(not path.name.endswith(FORBIDDEN) and path.stat().st_size <= 32 * (1 << 20),
                     'only small metadata/source evidence: ' + str(path))
                result.append(path)
            else:
                need(path.is_dir(), 'special filesystem object')
    return sorted(result)


def manifest_check(root):
    actual = files(root); declared = read(root / 'manifest.json')
    need(set(declared) == {p.relative_to(root).as_posix() for p in actual if p.name != 'manifest.json'},
         'closed small evidence manifest membership')
    for name, pin in declared.items():
        p = PurePosixPath(name)
        need(not p.is_absolute() and '..' not in p.parts and str(p) == name, 'unsafe manifest name')
        need(info(root / name) == pin, 'small evidence manifest hash/size: ' + name)
    return actual


def archive():
    need(not OUT.exists(), 'fresh supplement directory required; preserve previous attempts')
    for name, digest in OLD_PINS.items():
        need(info(OLD / name)['sha256'] == digest, 'original immutable sidecar: ' + name)
    old_verification = read(OLD / 'archive-verification.json')
    need(old_verification['status'] == 'PASS' and old_verification['archive'] == ARCHIVE
         and old_verification['members'] == 1707 and old_verification['all_member_hashes_verified'] is True,
         'original independently verified archive binding')
    need(info(OLD / 'evidence.tar.xz') == ARCHIVE, 'original archive digest/size')
    old_files = read(OLD / 'manifest.json')['files']
    # Reparse input identity is checked against the original archive manifest.
    # These bytes remain in that archive; this supplement does not copy them.
    for name, item in old_files.items():
        if name.startswith(('raw/', 'preregistration/', 'registered-source/')):
            path = Path(item['path'])
            need(path.is_absolute() and path.is_relative_to(ROOT) and not path.name.endswith(FORBIDDEN),
                 'original input file scope')
            need(info(path) == {k: item[k] for k in ('sha256', 'bytes')}, 'original reparse input changed: ' + name)
    old_formal, old_resource, restore, journal = [read(OLD / name) for name in
        ('independent-formal.json', 'resource-summary.json', 'restoration-audit.json', 'restored-journal.json')]
    need(old_formal['status'] == old_resource['status'] == 'FAIL'
         and old_formal['raw_requests_opened'] is False and old_formal['performance_qualified'] is False
         and old_resource['error_type'] == 'KeyError' and old_resource['error'] == "'stderr'",
         'original parser failure remains immutable')
    need(restore['status'] == 'PASS' and restore['qualified'] is True and journal['state'] == 'RESTORED'
         and restore['journal_sha256'] == OLD_PINS['restored-journal.json']
         and restore['owner_plan_sha256'] == PLAN_SHA and restore['service_restore']['replacement'] == journal['replacement'],
         'original independent restoration PASS')
    cpu_files, analysis_files = manifest_check(CPU), manifest_check(ANALYSIS)
    cpu = read(CPU / 'result.json'); execution = read(ANALYSIS / 'execution-summary.json')
    need(cpu['schema'] == 'omlx-postrun-audit-cpu-v1' and cpu['status'] == 'PASS'
         and cpu['tests'] == cpu['discovered_tests'] == 6 and cpu['failures'] == cpu['errors'] == cpu['skipped'] == 0
         and cpu['denied'] == [] and cpu['source_unchanged'] is True, 'actual six focused CPU regression results')
    need(execution['schema'] == 'omlx-formal-postrun-audit-execution-v2'
         and execution['owner_plan_sha256'] == PLAN_SHA and set(execution['jobs']) == {'resources', 'formal'}
         and execution['sources_unchanged'] is execution['original_failures_unchanged'] is True,
         'closed actual post-run audit execution')
    expected_new_sources = {str(SOURCE / name): digest for name, digest in NEW_PINS.items()}
    need(execution['source_pins'] == expected_new_sources, 'exact new auditor sources')
    for name, digest in NEW_PINS.items():
        source = SOURCE / name
        need(info(source)['sha256'] == digest == cpu['source_pins'][str(source)]['sha256'], 'actual auditor CPU/source binding')
        need(info(ANALYSIS / name) == info(source)
             and info(CPU / 'source' / source.relative_to(ROOT)) == info(source), 'source snapshots differ')
    for path, pin in cpu['source_pins'].items():
        source = Path(path)
        need(source.is_relative_to(ROOT) and info(source) == pin
             and info(CPU / 'source' / source.relative_to(ROOT)) == pin, 'CPU frozen dependency differs')
    need(set(execution['original_failures']) == {'resource-summary.json', 'independent-formal.json', 'restoration-audit.json'},
         'exact original audit receipt map')
    for name, ref in execution['original_failures'].items():
        need(ref == dict(path=str(ART / 'omlx-d512-formal-v2-analysis' / name), sha256=OLD_PINS[name]),
             'post-run audit original receipt binding')
    resource, formal = read(ANALYSIS / 'resource-summary.json'), read(ANALYSIS / 'independent-formal.json')
    for label, result, module, filename, extra in (
        ('resources', resource, 'audit_resources_v2.py', 'resource-summary.json', []),
        ('formal', formal, 'audit_formal_v2.py', 'independent-formal.json',
         ['--journal', str(JOURNAL), '--plan-sha256', PLAN_SHA])):
        row = execution['jobs'][label]
        expected = [str(ROOT / '.venv/bin/python'), '-I', '-B', str(SOURCE / module),
                    '--owner', str(OWNER), *extra, '--out', str(ANALYSIS / filename)]
        command = read(ANALYSIS / (label + '-command.json'))
        need(row == read(ANALYSIS / (label + '-execution.json')) and row['command'] == expected
             and row['cwd'] == str(ROOT) and all(row.get(k) == v for k, v in command.items())
             and row['result_sha256'] == info(ANALYSIS / filename)['sha256']
             and row['status'] == result['status'] and type(row['returncode']) is int
             and row['returncode'] == {'PASS': 0, 'FAIL': 1, 'INCOMPLETE': 1 if label == 'resources' else 2}[result['status']]
             and type(row['elapsed_seconds']) in (float, int) and math.isfinite(row['elapsed_seconds'])
             and row['elapsed_seconds'] >= 0 and 'error' not in row, 'actual audit command/result/termination: ' + label)
        need(result['audit_source_sha256'] == NEW_PINS[module] and result['owner_directory'] == str(OWNER), 'new audit source/input binding')
    need(resource['schema'] == 'oMLX-D512-formal-resource-audit-v2'
         and formal['schema'] == 'E023-omlx-D512-formal-independent-audit-v2'
         and resource['frozen_v1_source_sha256'] == old_resource['audit_source_sha256']
         and formal['frozen_v1_source_sha256'] == old_formal['audit_source_sha256'], 'explicit versioned correction provenance')
    success = formal['status'] == resource['status'] == 'PASS'
    need(execution['status'] == ('PASS' if success else 'FAIL'), 'execution result scope')
    if success:
        need(formal['qualified'] is formal['performance_qualified'] is formal['raw_requests_opened'] is True
             and resource['independent_resource_verified'] is True and formal['owner_plan_sha256'] == resource['owner_plan_sha256'] == PLAN_SHA
             and formal['formal_requests'] == 384 and formal['warm_requests'] == 48
             and formal['resources'] == resource and formal['restoration']['journal_sha256'] == OLD_PINS['restored-journal.json']
             and formal['restoration']['status'] == 'PASS', 'new independent full audit PASS gates')
        need([p['phase'] for p in formal['points']] == PHASES and
             [p['concurrency'] for p in formal['points']] == [1, 8, 8, 1, 1, 8], 'all six process points')
        for point in formal['points']:
            need(point['requests'] == 64 and point['warm_requests_checked'] == 8, 'full point request counts')
            refs = [point['point_receipt'], point['formal_raw_group'], *point['retained_logs'].values()]
            for ref in refs:
                path = Path(ref['path']); key = 'raw/owner/' + path.relative_to(OWNER).as_posix()
                need(old_files[key]['path'] == str(path) and old_files[key]['sha256'] == ref['sha256'],
                     'new point is not bound to original archived raw')
    else:
        need(formal['performance_qualified'] is False, 'failed supplement cannot qualify')
    need(formal['full_state_qualified'] is formal['output_quality_qualified'] is False, 'formal scope must remain limited')
    inputs = {'original-archive/' + name: OLD / name for name in OLD_PINS}
    inputs.update({'cpu/' + p.relative_to(CPU).as_posix(): p for p in cpu_files})
    inputs.update({'analysis/' + p.relative_to(ANALYSIS).as_posix(): p for p in analysis_files})
    inputs['archive-source/archive.py'] = Path(__file__).resolve()
    manifest = {name: dict(path=str(path), **info(path)) for name, path in inputs.items()}
    OUT.mkdir()
    for name in ('resource-summary.json', 'independent-formal.json'):
        shutil.copyfile(ANALYSIS / name, OUT / name)
        need(info(ANALYSIS / name) == info(OUT / name), 'new sidecar exact copy')
    for name in ('restoration-audit.json', 'restored-journal.json'):
        shutil.copyfile(OLD / name, OUT / name)
    target = OUT / 'evidence.tar.xz'
    with tarfile.open(target, 'w:xz', dereference=True) as tar:
        for name, path in inputs.items():
            tar.add(path, arcname=name, recursive=False)
    actual = {}
    with tarfile.open(target, 'r:xz') as tar:
        for member in tar:
            p = PurePosixPath(member.name)
            need(member.isfile() and not p.is_absolute() and '..' not in p.parts and member.name not in actual, 'invalid archive member')
            stream = tar.extractfile(member); digest = hashlib.sha256(); size = 0
            while chunk := stream.read(1 << 20):
                digest.update(chunk); size += len(chunk)
            actual[member.name] = dict(sha256=digest.hexdigest(), bytes=size)
    need(set(actual) == set(manifest) and all(actual[k] == {f: manifest[k][f] for f in ('sha256', 'bytes')} for k in actual), 'all supplement members verified')
    need(all(info(path) == actual[name] for name, path in inputs.items()), 'supplement sources changed during archive')
    need(files(CPU) == cpu_files and files(ANALYSIS) == analysis_files, 'closed input membership changed')
    write(OUT / 'manifest.json', dict(schema='E023-omlx-formal-audit-supplement-manifest-v1', files=manifest))
    origin = dict(directory=str(OLD), archive=ARCHIVE, sidecar_sha256=OLD_PINS,
                  original_resource_status='FAIL', original_formal_status='FAIL', original_restore_status='PASS')
    write(OUT / 'summary.json', dict(schema='E023-omlx-formal-audit-supplement-summary-v1', original=origin,
        owner_plan_sha256=PLAN_SHA, resource_status=resource['status'], formal_status=formal['status'],
        restoration_status='PASS', performance_qualified=success, full_state_qualified=False,
        output_quality_qualified=False, warm_requests=formal.get('warm_requests'), formal_requests=formal.get('formal_requests'),
        points=formal.get('points'), process_metric_medians=formal.get('process_metric_medians'),
        audit_source_sha256=NEW_PINS, post_run_parser_correction=True, packaging_grants_qualification=False))
    verification = dict(schema='E023-omlx-formal-audit-supplement-verification-v1', status='PASS', archive=info(target),
        members=len(actual), logical_file_bytes=sum(p['bytes'] for p in actual.values()), original=origin,
        audit_receipts={name: dict(path=str(OUT / name), **info(OUT / name)) for name in
                        ('independent-formal.json', 'resource-summary.json', 'restoration-audit.json')},
        audit_source_sha256=NEW_PINS,
        all_member_hashes_verified=True, all_supplement_sources_rechecked=True, original_reparse_inputs_rehashed=True,
        original_raw_payloads_repackaged=False, model_payloads_rehashed=False, runtime_payloads_rehashed=False,
        packaging_grants_qualification=False)
    write(OUT / 'archive-verification.json', verification)
    (OUT / 'README.md').write_text('# oMLX D512 formal v2 audit supplement\n\n'
        'The original archive and both original FAIL receipts remain unchanged. The frozen outer reader retained only command, returncode and stdout. '
        'New versioned auditors check that exact schema and independently check the earlier inner receipts that really retained stderr; no missing field is fabricated. '
        'Resource thresholds and formal timing/count mathematics are unchanged. These auditors were written after the run, and are not presented as preregistered.\n\n'
        f'New resource audit: {resource["status"]}; new formal audit: {formal["status"]}. Original restoration: PASS. '
        'Only a new complete independent PASS qualifies the measured observer-OFF protocol, count and timing; it does not establish cross-engine full-state/output-quality equality, generator EOF, full background-task health or warm-KV restoration. '
        'The process medians are medians of three process metrics per concurrency, not pooled percentiles, paired native comparisons or confidence intervals.\n\n'
        'This small supplement preserves the new source snapshots, six CPU regressions, actual commands/stdout/stderr and audit receipts, plus the original manifest and FAIL/restoration sidecars. '
        'All supplement members are hash-verified. The original archive is bound by SHA and its original reparse input files are checked against its manifest; large raw data remains only in the original archive. '
        'Packaging grants no qualification.\n')
    print(json.dumps(verification))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run:
        archive()
    else:
        print(json.dumps(dict(status='DESCRIPTION_ONLY', writes=False, output=str(OUT), cpu=str(CPU), analysis=str(ANALYSIS))))
