"""Run exactly the four fake-only oMLX outer suites after recorded recovery.

This launcher is intentionally not a service/runtime/model qualification. Its
only real subprocess exception is the original controller test's exact isolated
Python --help command, once, at that test's call site. All other subprocesses,
network connects/listeners, process signals and device/vendor imports are denied.
No test/result is retried, skipped, rewritten or replayed by this launcher.
"""
import argparse
import ast
import contextlib
import datetime
import hashlib
import importlib.abc
import importlib.metadata
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import textwrap
import time
import traceback
import unittest
from unittest.mock import patch

ROOT = Path('/Users/ryanli/code/minivllm')
PYTHON = ROOT / '.artifacts/omlx-baseline/.venv/bin/python'
DEFAULT_OUT = ROOT / '.artifacts/m5-ultra-256gb/omlx-outer-prepared-cpu-v1'
TESTS = (
    ('bench.m5_ultra_256gb.omlx_d512.test_controller_cpu', 20),
    ('bench.m5_ultra_256gb.omlx_d512.test_audits_cpu', 12),
    ('bench.m5_ultra_256gb.omlx_d512.test_owner_cpu', 13),
    ('bench.m5_ultra_256gb.omlx_d512.test_execute_cpu', 12),
)
FORBIDDEN = {'mlx', 'omlx', 'mlx_lm', 'mlx_vlm', 'torch', 'numpy', 'tutorial_code', 'monolith'}
HERE = ROOT / 'bench/m5_ultra_256gb/omlx_d512'


def need(value, message):
    if not value:
        raise AssertionError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def source_paths():
    # An explicit source-only superset of dynamic frozen helper loads. This is
    # not a binary/runtime dependency inventory and never scans model folders.
    root = ROOT / 'bench/m5_ultra_256gb'
    paths = {Path(__file__).resolve()}
    for name in ('omlx_d512', 'pareto_realistic', 'omlx_cold_restart', 'cold_cycle',
                 'cold_cycle_v2', 'lithos_d512_retry', 'lithos_d512_formal'):
        paths.update((root / name).glob('*.py'))
    paths.update(root / name for name in ('resource_base.py', 'resources.py', 'resources_v2.py'))
    paths.update(root / name / 'lifecycle.json' for name in ('cold_cycle', 'cold_cycle_v2'))
    paths.add(PYTHON.parent.parent / 'lib/python3.13/site-packages/omlx/api/openai_models.py')
    return sorted(paths, key=str)


def exact_help_command():
    tree = ast.parse((HERE / 'test_controller_cpu.py').read_text())
    methods = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)
               and node.name == 'test_help_safe_without_runtime_network_or_subprocess']
    need(len(methods) == 1, 'exact original help test missing/duplicated')
    values = [node.value.value for node in methods[0].body if isinstance(node, ast.Assign)
              and any(isinstance(t, ast.Name) and t.id == 'script' for t in node.targets)
              and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)]
    need(len(values) == 1, 'help test no longer has the reviewed literal script')
    script = textwrap.dedent(values[0])
    need("m.main(['--help'])" in script and 'subprocess.Popen=lambda' in script
         and 'socket.socket=lambda' in script, 'help child guards changed')
    return [str(PYTHON), '-I', '-B', '-c', script, str(HERE / 'controller.py')]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execution-final', type=Path, required=True)
    parser.add_argument('--journal', type=Path, required=True, help='closed journal.json')
    parser.add_argument('--out', type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    need(Path(sys.executable) == PYTHON and Path(sys.prefix) == PYTHON.parent.parent,
         'run with the existing dedicated oMLX vendor Python -I -B')
    need(args.out.is_absolute() and not args.out.exists() and args.out.parent.is_dir(),
         'fresh absolute output directory in an existing parent required')
    args.out.mkdir()
    runner_copy = args.out / 'run_cpu.py'
    runner_copy.write_bytes(Path(__file__).read_bytes())
    record = dict(schema='omlx-outer-prepared-cpu-v1', status='RUNNING', started_at=now(),
        command=[str(PYTHON), '-I', '-B', str(Path(__file__).resolve()), *sys.argv[1:]],
        cwd=str(Path.cwd()), python_executable=sys.executable,
        python_resolved=str(Path(sys.executable).resolve()), prefix=sys.prefix,
        python_version=sys.version, runner_sha256=sha(runner_copy.read_bytes()),
        suites=[dict(module=name, expected_tests=count) for name, count in TESTS],
        expected_tests=57, tests=0, failures=0, errors=0, skipped=0,
        expected_failures=0, unexpected_successes=0, source_pins_before={},
        source_pins_after={}, source_pins_unchanged=False, help_calls=[],
        subprocess_audit_events=[], denied_operations=[], test_outcomes=[],
        forbidden_modules_loaded=[],
        scope='Fake lifecycle and offline validator CPU tests only. One exact guarded help child; no model/GPU/service/runtime qualification.',
        source_inventory_scope='Explicit source-only superset; not a complete binary or recursive runtime closure.')
    started = time.monotonic()
    paths, guard, active_help, help_popen = [], None, False, 0
    help_child_pid = None
    actual_run, actual_popen = subprocess.run, subprocess.Popen
    help_argv = None

    def save():
        write(args.out / 'result.json', record)

    def denied(kind, detail):
        record['denied_operations'].append(dict(kind=kind, detail=str(detail)))
        raise AssertionError('forbidden real operation: ' + kind + ': ' + str(detail))

    def audit_hook(event, values):
        nonlocal help_popen
        if event == 'subprocess.Popen':
            executable, argv, cwd, env = values
            permitted = (active_help and help_popen == 0 and executable == str(PYTHON)
                         and list(argv) == help_argv and cwd is None and env is None
                         and Path.cwd() == ROOT)
            record['subprocess_audit_events'].append(dict(executable=str(executable),
                argv=list(argv) if isinstance(argv, (list, tuple)) else str(argv),
                cwd=cwd, inherited_environment=env is None, permitted=permitted))
            if not permitted:
                denied(event, executable)
            help_popen += 1
        elif event == 'os.posix_spawn' and active_help and help_popen == 1 \
                and help_child_pid is None and values[0] == str(PYTHON) \
                and list(values[1]) == help_argv and values[2] == dict(os.environ) \
                and not record.get('help_posix_spawn_backend'):
            # Some Python/macOS combinations implement that same allowed Popen
            # via posix_spawn. This is not an additional child exception.
            record['help_posix_spawn_backend'] = True
        elif event == 'os.kill' and active_help and help_child_pid is not None \
                and values[0] == help_child_pid and values[1] in (9, 15):
            # subprocess.run's own timeout cleanup may kill only this returned
            # help Popen before wait/reap; no service/model PID can pass.
            record.setdefault('help_cleanup_signals', []).append(dict(pid=values[0], signal=values[1]))
        elif event in ('os.system', 'os.fork', 'os.forkpty', 'os.posix_spawn', 'os.exec',
                       'os.spawn', 'os.kill', 'os.killpg', 'socket.connect', 'socket.bind'):
            denied(event, values)

    def guarded_popen(argv, *positional, **kwargs):
        nonlocal help_child_pid
        if not active_help or positional or list(argv) != help_argv:
            denied('Popen', argv)
        child = actual_popen(argv, **kwargs)  # audit hook checks cwd/env/once
        help_child_pid = child.pid
        record['help_calls'][-1]['pid'] = child.pid
        return child

    def guarded_run(argv, *positional, **kwargs):
        nonlocal active_help
        allowed = (not active_help and not record['help_calls'] and not positional
                   and list(argv) == help_argv
                   and kwargs == dict(capture_output=True, text=True, timeout=5))
        if not allowed:
            denied('subprocess.run', argv)
        row = dict(argv=list(argv), kwargs=kwargs, started_at=now(), actual_execution=True)
        record['help_calls'].append(row)
        active_help = True
        try:
            result = actual_run(argv, **kwargs)
            row.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
            return result
        except BaseException as exc:
            row['error'] = dict(type=type(exc).__name__, message=str(exc))
            raise
        finally:
            active_help = False
            row['ended_at'] = now()
            write(args.out / 'help-call.json', row)

    class DenyImports(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname.split('.')[0] in FORBIDDEN:
                denied('runtime import', fullname)
            return None

    class RecordedResult(unittest.TextTestResult):
        def startTest(self, test):
            record['test_outcomes'].append(dict(id=test.id(), status='RUNNING'))
            super().startTest(test)
        def addSuccess(self, test):
            record['test_outcomes'][-1]['status'] = 'PASS'; super().addSuccess(test)
        def addFailure(self, test, error):
            record['test_outcomes'][-1].update(status='FAIL', detail=self._exc_info_to_string(error, test)); super().addFailure(test, error)
        def addError(self, test, error):
            record['test_outcomes'][-1].update(status='ERROR', detail=self._exc_info_to_string(error, test)); super().addError(test, error)
        def addSkip(self, test, reason):
            record['test_outcomes'][-1].update(status='SKIP', reason=reason); super().addSkip(test, reason)
        def addExpectedFailure(self, test, error):
            record['test_outcomes'][-1].update(status='EXPECTED_FAILURE', detail=self._exc_info_to_string(error, test)); super().addExpectedFailure(test, error)
        def addUnexpectedSuccess(self, test):
            record['test_outcomes'][-1]['status'] = 'UNEXPECTED_SUCCESS'; super().addUnexpectedSuccess(test)
        def addSubTest(self, test, subtest, error):
            if error is not None:
                record['test_outcomes'][-1].update(status='FAIL', subtest=str(subtest), detail=self._exc_info_to_string(error, test))
            super().addSubTest(test, subtest, error)

    save()
    try:
        need(args.execution_final.is_absolute() and args.journal.is_absolute(), 'absolute recovery receipts')
        final_path, journal_path = args.execution_final.resolve(), args.journal.resolve()
        need(final_path.name == 'final.json' and journal_path.name == 'journal.json'
             and final_path.parent.name.endswith('-execution')
             and journal_path.parent.name == final_path.parent.name.removesuffix('-execution') + '-cold-journal'
             and final_path.parent.parent == journal_path.parent.parent == DEFAULT_OUT.parent,
             'execution final and journal must be the same artifact cycle')
        final_raw, journal_raw = final_path.read_bytes(), journal_path.read_bytes()
        final, journal = json.loads(final_raw), json.loads(journal_raw)
        record['recovery_gate'] = dict(execution_final=dict(path=str(final_path), sha256=sha(final_raw)),
            journal=dict(path=str(journal_path), sha256=sha(journal_raw)),
            execution_journal_state=final.get('journal_state'), journal_state=journal.get('state'),
            recovery_returncode=final.get('recovery_returncode'),
            scope='Closed persisted receipts only; no new live service or model observation.')
        (args.out / 'execution-final.json').write_bytes(final_raw)
        (args.out / 'restored-journal.json').write_bytes(journal_raw)
        need(final.get('journal_state') == journal.get('state') == 'RESTORED'
             and type(final.get('recovery_returncode')) is int and final['recovery_returncode'] == 0,
             'wait for actual RESTORED plus recovery returncode zero')
        os.chdir(ROOT)
        sys.path.insert(0, str(ROOT))
        paths = source_paths()
        for path in paths:
            raw = path.read_bytes()
            record['source_pins_before'][str(path)] = dict(sha256=sha(raw), bytes=len(raw))
            dest = args.out / 'frozen-source' / str(path).lstrip('/')
            dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        record['versions'] = {name:importlib.metadata.version(name) for name in ('pydantic', 'httpx')}
        help_argv = exact_help_command()
        record['exact_help_argv'] = help_argv
        guard = DenyImports(); sys.meta_path.insert(0, guard)
        sys.addaudithook(audit_hook)
        save()
        with (args.out / 'stdout.txt').open('x') as stdout, (args.out / 'stderr.txt').open('x') as stderr, \
             contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr), \
             patch.object(subprocess, 'Popen', side_effect=guarded_popen), \
             patch.object(subprocess, 'run', side_effect=guarded_run), \
             patch.object(socket.socket, 'connect', side_effect=lambda *a, **k:denied('socket.connect', a)), \
             patch.object(socket.socket, 'connect_ex', side_effect=lambda *a, **k:denied('socket.connect_ex', a)), \
             patch.object(socket.socket, 'bind', side_effect=lambda *a, **k:denied('socket.bind', a)):
            suites = []
            for row in record['suites']:
                suite = unittest.defaultTestLoader.loadTestsFromName(row['module'])
                row['discovered_tests'] = suite.countTestCases(); suites.append(suite)
            result = unittest.TextTestRunner(stream=stderr, verbosity=2, resultclass=RecordedResult).run(unittest.TestSuite(suites))
        record.update(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
            skipped=len(result.skipped), expected_failures=len(result.expectedFailures),
            unexpected_successes=len(result.unexpectedSuccesses), loader_errors=unittest.defaultTestLoader.errors,
            failures_detail=[dict(test=t.id(), traceback=detail) for t,detail in result.failures],
            errors_detail=[dict(test=t.id(), traceback=detail) for t,detail in result.errors],
            skipped_detail=[dict(test=t.id(), reason=why) for t,why in result.skipped])
        record['status'] = 'PASS' if (result.wasSuccessful() and result.testsRun == 57
            and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses
            and not unittest.defaultTestLoader.errors
            and all(r['discovered_tests'] == r['expected_tests'] for r in record['suites'])
            and len(record['help_calls']) == help_popen == 1
            and record['help_calls'][0].get('returncode') == 0) else 'FAIL'
    except BaseException as exc:
        record.update(status='FAIL', error=dict(type=type(exc).__name__, message=str(exc), traceback=traceback.format_exc()))
    finally:
        if guard is not None and guard in sys.meta_path:
            sys.meta_path.remove(guard)
        for path in paths:
            try:
                raw = path.read_bytes(); record['source_pins_after'][str(path)] = dict(sha256=sha(raw), bytes=len(raw))
            except BaseException as exc:
                record['source_pins_after'][str(path)] = dict(error=type(exc).__name__ + ': ' + str(exc))
        record['source_pins_unchanged'] = bool(paths) and record['source_pins_before'] == record['source_pins_after']
        record['forbidden_modules_loaded'] = sorted(n for n in sys.modules if n.split('.')[0] in FORBIDDEN)
        record['actual_help_process_count'] = help_popen
        if not record['source_pins_unchanged'] or record['forbidden_modules_loaded']:
            record['status'] = 'FAIL'
        record.update(ended_at=now(), elapsed_seconds=time.monotonic()-started)
        save()
        inventory = {str(p.relative_to(args.out)):dict(bytes=p.stat().st_size, sha256=sha(p.read_bytes()))
                     for p in sorted(args.out.rglob('*')) if p.is_file() and p.name != 'artifact-manifest.json'}
        write(args.out / 'artifact-manifest.json', dict(schema='omlx-outer-cpu-artifacts-v1', files=inventory))
    print(json.dumps({k:record[k] for k in ('status', 'tests', 'failures', 'errors', 'skipped', 'source_pins_unchanged', 'actual_help_process_count')}))
    return 0 if record['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
