"""Retain the actual failed and repaired fake-only GLM CPU attempts."""
from pathlib import Path
import hashlib,json,tarfile,difflib
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb'
D=R/'docs/experiments/m5-ultra-256gb/glm-cycle-prepared-cpu-v2'
S=R/'bench/m5_ultra_256gb/glm_flash_cycle'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def main():
 assert not D.exists();D.mkdir()
 v1=A/'glm-cycle-prepared-cpu-v1';v2=A/'glm-cycle-prepared-cpu-v2';q=A/'glm-cycle-prepared-cpu-v1-queue'
 x,y=(json.loads((p/'result.json').read_bytes()) for p in (v1,v2))
 assert (x['status'],x['tests'],x['failures'],x['errors'],x['skipped'])==('FAIL',33,0,1,0)
 assert (y['status'],y['tests'],y['failures'],y['errors'],y['skipped'])==('PASS',33,0,0,0)
 assert sha(v1/'result.json')=='89db7a2348d4dd5fdc751cb190e420f5fd2101e84aaa4fb874d581387b4dbd6d'
 assert sha(v2/'result.json')=='53637bfc4114386decca0aafa2eee8837f051aecd12584eb2568fda8eab41258'
 for row in (x,y):
  assert all(row[k] is True for k in ('source_unchanged','closure_unchanged','gdn_sequence_unchanged'))
  assert not row['denied_operations'] and not row['forbidden_modules_loaded']
 fixture=S/'test_controller_cpu.py';original=v1/'frozen-source'/str(fixture).lstrip('/')
 changes=''.join(difflib.unified_diff(original.read_text().splitlines(True),fixture.read_text().splitlines(True),fromfile='v1/test_controller_cpu.py',tofile='v2/test_controller_cpu.py'))
 (D/'fixture-fix.patch').write_text(changes)
 unchanged={}
 for name in ('controller.py','audit_restore.py','audit_closed.py','prepare_inputs.py','preregister.py','execute.py','owner.py'):
  p=S/name;assert sha(p)==sha(v1/'frozen-source'/str(p).lstrip('/'))==sha(v2/'frozen-source'/str(p).lstrip('/'));unchanged[name]=sha(p)
 sources={}
 for prefix,folder in (('v1',v1),('v1-queue',q),('v2',v2)):
  for p in sorted(folder.rglob('*')):
   assert not p.is_symlink()
   if p.is_file():sources[prefix+'/'+str(p.relative_to(folder))]=p
 for name in ('prepared-source-v1.json','prepared-source-v2.json'):
  sources['source-preparation/'+name]=S/name
 sources['source-preparation/test_controller_cpu.py']=fixture
 sources['source-preparation/fixture-fix.patch']=D/'fixture-fix.patch'
 sources['source-preparation/archive.py']=Path(__file__)
 files={n:dict(source=str(p),bytes=p.stat().st_size,sha256=sha(p)) for n,p in sources.items()}
 archive=D/'raw-evidence.tar.xz'
 with tarfile.open(archive,'x:xz',preset=3) as t:
  for n,p in sorted(sources.items()):t.add(p,arcname=n,recursive=False)
 assert all(sha(p)==files[n]['sha256'] and p.stat().st_size==files[n]['bytes'] for n,p in sources.items())
 manifest=dict(schema='GLM-cycle-cpu-archive-manifest-v1',archive=dict(filename=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),files=files)
 write(D/'manifest.json',manifest)
 summary=dict(schema='GLM-cycle-prepared-cpu-v2-summary',status='PASS_FAKE_CPU_RETRY',
  attempts=[dict(name='v1',status='FAIL',tests=33,passed=32,errors=1,failures=0,skipped=0,result_sha256=sha(v1/'result.json')),
            dict(name='v2',status='PASS',tests=33,passed=33,errors=0,failures=0,skipped=0,result_sha256=sha(v2/'result.json'))],
  root_cause='Fixture named an external registered owner-plan.json without creating it; a module-level patch did not replace the already-copied dependency dictionary used by reaped(). Production correctly required the external registration.',
  fix='Write and bind the external registration, STOPPED snapshot and attempt; keep the real registered_trials/owner_plan route, absent owner-local copy assertion and corrupt-external-bytes rejection.',
  production_source_unchanged=unchanged,source_guards_unchanged=True,all_original_files_rehashed=True,
  archived_files=len(files),raw_bytes=sum(v['bytes'] for v in files.values()),archive=manifest['archive'],
  scope='Fake-only CPU protocol/registration/audit/driver tests. No actual GLM preparation, service action, model load, physical-capacity validation, numerical/model/HTTP/performance qualification.',
  device_executed=False,model_loaded=False,performance_qualified=False)
 write(D/'summary.json',summary)
 print(json.dumps({'path':str(D),'files':len(files),'raw_bytes':summary['raw_bytes'],'archive':manifest['archive']}))
if __name__=='__main__':main()
