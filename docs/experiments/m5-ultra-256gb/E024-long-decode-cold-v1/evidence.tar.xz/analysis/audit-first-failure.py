"""Narrow offline E024 first-matrix failure audit, original bytes never changed.

Only stdlib and the SHA-pinned E025 safetensors byte parser are used. No MLX,
model/runtime load, device, subprocess, network, service or lifecycle assertion.
An audit PASS supports rejection; candidate/numerical/performance qualification
remain false. Earlier tensor PASS flags are retained producer records, not an
independent re-comparison of unavailable successful tensor payloads.
"""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import struct

ROOT=Path('/Users/ryanli/code/minivllm')
HELPER=ROOT/'bench/m5_ultra_256gb/prefill_nax_same_split/audit_failure_v2.py'
HELPER_SHA='994c3f1a138b8246f3b858403a56a8c11751da98377d3e54ef1c40a4cce08223'
QUALIFIER=ROOT/'bench/m5_ultra_256gb/long_decode_graph/qualify.py'
QUALIFIER_SHA='c24219f431b08502a26a4f7a83c002214bddd7ea3962d6b1869b313e4c13faf7'
CANDIDATE_SHA='eb14b671a66764fe677219762090acb495b89d384cf078f3f63b918a40aa2b84'
SUPPORT_SHA='26964fcbed9a2e5dcefaee4888244987897f3138d4a2b7add59bf63a7461b7bf'

def need(ok,message):
    if not ok:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def record(path):return dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)

def audit(child):
    plan=read(child/'plan.json');complete=read(child/'complete.json');failure=read(child/'failure.json')
    need(plan['schema']=='E024-diagnostic-qualification-v1' and plan['deadline_s']==1800,'fixed diagnostic plan')
    need(plan['qualifier_sha256']==QUALIFIER_SHA==sha(QUALIFIER),'qualifier pin')
    need(plan['candidate']['sha256']==CANDIDATE_SHA==sha(plan['candidate']['path']),'candidate pin')
    need(plan['e023_qualifier']['sha256']==SUPPORT_SHA==sha(plan['e023_qualifier']['path']),'Comparator source pin')
    need(plan['e023_plan']['sha256']==sha(plan['e023_plan']['path'])==sha(child/'inherited-plan.json'),'inherited plan exact bytes')
    need(complete['status']=='FAIL' and complete['matrix']==[] and complete['parameter_replacements']==[], 'first point failure scope')
    need(complete['error']['type']=='QualificationFailure' and complete['error']['message']=='matrix-B1-used257/logits/root','exact failed comparison')
    need(all(complete[k] is False for k in ('gates_compile','norm_reuse','fuse_decode')),'fixed OFF configuration')
    need(complete.get('source_model_pins_rechecked') is not True and not (child/'steps.jsonl').exists(),'unexpected postcheck/lifecycle evidence')
    need(failure['label']=='matrix-B1-used257/logits/root' and failure['details']==dict(name='root',shape=[1,248320],
        dtype='mlx.core.bfloat16',reference_finite=True,candidate_finite=True,bit_equal=False),'failure metadata')
    path=child/'failure-arrays.safetensors'
    need(failure['array_artifact']==dict(path=path.name,sha256=sha(path)),'failure payload pin')
    need(sha(HELPER)==HELPER_SHA,'CPU safetensors parser source pin')
    spec=importlib.util.spec_from_file_location('_e024_raw_parser',HELPER)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    pair=helper.tensors(path)
    need(set(pair)=={'reference','candidate'},'two original tensors')
    a,b=pair['reference'],pair['candidate']
    need(all(x['dtype']=='BF16' and x['shape']==[1,248320] and x['bytes']==496640 and x['finite'] is True for x in (a,b)),
        'original finite BF16 shape/size')
    aw,bw=([v[0] for v in struct.iter_unpack('<H',x['raw'])] for x in (a,b))
    indices=[i for i,(x,y) in enumerate(zip(aw,bw)) if x!=y]
    byte_indices=[i for i,(x,y) in enumerate(zip(a['raw'],b['raw'])) if x!=y]
    need(indices and byte_indices,'actual unequal raw tensor bytes required')
    def difference(i):
        x,y=aw[i],bw[i]
        return dict(element_index=i,coordinates=[0,i],reference_word_hex=f'{x:04x}',candidate_word_hex=f'{y:04x}',
            xor_word_hex=f'{x^y:04x}',different_bit_positions_lsb0=[j for j in range(16) if (x^y)&(1<<j)],
            reference_value=helper.bf16(x),candidate_value=helper.bf16(y),
            absolute_difference=abs(helper.bf16(x)-helper.bf16(y)))
    max_i=max(indices,key=lambda i:abs(helper.bf16(aw[i])-helper.bf16(bw[i])))
    raw=(child/'events.jsonl').read_bytes();need(raw.endswith(b'\n'),'complete event line')
    events=[json.loads(line) for line in raw.splitlines()]
    expected=['fixed-diagnostic-contract','load-model','load-model','loaded-weights']+[f'prefill-256-{i}' for i in range(8)]+['graph-call']
    need([x['event'] for x in events]==expected,'exact closed first-point prefix')
    need([events[1]['arm'],events[2]['arm']]==['reference','candidate'],'two independent model loads')
    need(all(events[i]['elapsed_wall_s']<=events[i+1]['elapsed_wall_s'] for i in range(len(events)-1)),'event time order')
    contract=events[0]
    need(contract['matrix']==[[B,u] for u in (257,1024,1280,1536) for B in range(1,9)]
         and contract['direct_graph_backing']==1536 and contract['configuration']['gates_compile'] is False
         and contract['configuration']['fuse_decode'] is False,'registered matrix/flags')
    weight_rows=events[3]['arrays'];need(len(weight_rows)==1349 and len({x['name'] for x in weight_rows})==1349,'all retained weight records')
    need(all(x['check']=='independent-loaded-weights' for x in weight_rows),'weight check labels')
    for row in events[3:12]:
        need(all(all(x[k] is True for k in ('reference_finite','candidate_finite','bit_equal')) for x in row['arrays']),
            'earlier recorded finite/bit checks')
    for i,row in enumerate(events[4:12]):
        expected_rows=[dict(check=f'prefill-256-{i}/logits',name='root',shape=[1,248320],dtype='mlx.core.bfloat16')]
        for layer in range(64):
            items=(('keys',[1,4,256,256],'mlx.core.bfloat16'),('values',[1,4,256,256],'mlx.core.bfloat16')) if layer%4==3 else (
                ('conv_state',[3,10240],'mlx.core.bfloat16'),('S',[48,128,128],'mlx.core.float32'))
            expected_rows.extend(dict(check=f'prefill-256-{i}/state',name=f'root/{layer}/{name}',shape=shape,dtype=dtype) for name,shape,dtype in items)
        need([{k:x[k] for k in ('check','name','shape','dtype')} for x in row['arrays']]==expected_rows,'complete64-layer/128array prefill records')
    witness=events[-1]
    need(witness['phase']=='matrix-B1-used257' and witness['status']=='SUBMITTED' and witness['batch']==1 and witness['used']==257
         and witness['positions']==[256] and witness['lens']==[257] and witness['tokens']==[524]
         and witness['KV_backing_lengths']==[[1536,1536]]*16 and witness['invocation']==witness['compiled_function_count']==1,
         'one actual eligible compiled callable submission')
    objects=witness['actual_compile_objects']
    need(len(objects)==1 and objects[0]['key']==repr((1536,((False,False),)*48))
         and objects[0]['type']=='gc_func' and type(objects[0]['id']) is int and objects[0]['id']>0,'real compiled object receipt')
    inputs=read(child/'diagnostic-inputs.json');inherited=read(child/'inherited-plan.json')
    fixtures=read(inherited['fixtures']['path'])['fixtures']
    need(sha(inherited['fixtures']['path'])==inherited['fixtures']['sha256'] and len(inputs)==len(fixtures)==8,'fixed diagnostic fixture source')
    for d,f in zip(inputs,fixtures):
        ids=f['prompt_ids'];wanted=(ids*((1535+len(ids)-1)//len(ids)))[:1535]
        need(d['source_fixture_id']==f['fixture_id'] and d['prompt_ids']==wanted and d['diagnostic_only'] is True,
             'diagnostic input repeats frozen D IDs only')
    tensor_result=dict(shape=[1,248320],dtype='BF16',finite=True,elements=248320,
        reference=helper.meta(a),candidate=helper.meta(b),differing_elements=len(indices),differing_bytes=len(byte_indices),
        first_differing_byte_index=byte_indices[0],first_difference=difference(indices[0]),maximum_difference=difference(max_i),
        mismatch_element_indices_sha256=hashlib.sha256(b''.join(struct.pack('<I',i) for i in indices)).hexdigest())
    return dict(schema='E024-first-matrix-failure-audit-v1',status='PASS',candidate_qualified=False,numerical_qualified=False,
        performance_qualified=False,conclusion='REJECT exact graph substitution at the first registered point; native eager is not declared erroneous.',
        audit_source=record(Path(__file__).resolve()),parser_source=record(HELPER),
        qualifier_source=record(QUALIFIER),candidate_source=record(Path(plan['candidate']['path'])),
        comparator_source=record(Path(plan['e023_qualifier']['path'])),
        raw_inputs={p.name:record(p) for p in sorted(child.iterdir()) if p.is_file()},tensor_pair=tensor_result,
        graph_witness=witness,graph_witness_scope='Actual compiled callable invoked once; SUBMITTED is not a passing graph point. Saved compared output is materialized.',
        prefix=dict(recorded_weight_array_checks=1349,prefill_requests=8,prefill_tokens_each=256,
            prefill_array_checks=8*129,total_recorded_pass_array_checks=1349+8*129,
            note='Earlier successful tensors were not saved; flags, names/shapes/dtypes and complete128cache coverage audited, not independently recomputed.'),
        coverage=dict(matrix_points_passed=0,matrix_points_registered=32,parameter_decode_calls_executed=0,parameter_decode_calls_registered=21,
            parameter_replacements_passed=0,lifecycle_started=False,all_cache_after_failed_graph_checked=False,
            source_model_postrecheck_executed=False,full_D512_HTTP_qualified=False),
        limits=['Failure precedes logits argmax and post-graph cache comparison. No layer-level numerical root cause is established.',
            'No final model/source recheck happened in failed child; current small source SHA verification does not replace it.',
            'No performance measurement, owner/resource/restoration qualification, or GPU execution is performed by this audit.'])

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--child',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    args=p.parse_args();need(not args.out.exists(),'fresh audit output required')
    result=audit(args.child.resolve())
    with args.out.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(status=result['status'],qualified=False,tensor_pair=result['tensor_pair'])))

if __name__=='__main__':main()
