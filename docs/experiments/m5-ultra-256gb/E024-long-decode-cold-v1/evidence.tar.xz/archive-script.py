"""Archive the rejected E024 first-point diagnostic and its complete recovery evidence."""
from pathlib import Path
import hashlib,json,tarfile
R=Path('/Users/ryanli/code/minivllm'); A=R/'.artifacts/m5-ultra-256gb'; O=R/'docs/experiments/m5-ultra-256gb/E024-long-decode-cold-v1'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(8<<20):h.update(b)
 return h.hexdigest()
def write(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2);f.write('\n')
def read(p):return json.loads(p.read_bytes())
J=A/'long-decode-cold-v1-cold-journal/journal.json'; owner=A/'long-decode-cold-v1-owner';analysis=A/'long-decode-cold-v1-analysis'
j=read(J);assert j['state']=='RESTORED'
rest=analysis/'restoration-audit.json'; ra=read(rest)
assert ra['status']=='PASS' and ra['journal_sha256']==sha(J)
assert read(A/'long-decode-cold-v1-execution/final.json')['journal_state']=='RESTORED'
O.mkdir(exist_ok=False)
for name,p in [('restored-journal.json',J),('restoration-audit.json',rest)]:
 (O/name).write_bytes(p.read_bytes());assert sha(O/name)==sha(p)
roots={ 'raw/owner':owner, 'raw/cold-journal':J.parent,'raw/execution':A/'long-decode-cold-v1-execution','cpu-prepare':A/'long-decode-cold-v1-cpu-prepare','analysis':analysis,'preregistration':R/'bench/m5_ultra_256gb/long_decode_graph/prereg-cold-v1'}
inputs={}; trees={}
for prefix,root in roots.items():
 paths=sorted(root.rglob('*')); assert not any(p.is_symlink() for p in paths)
 files=[p for p in paths if p.is_file()];trees[prefix]=[str(p.relative_to(root)) for p in files]
 for p in files:inputs[prefix+'/'+str(p.relative_to(root))]=p
for name in ['long_decode_graph/cold_owner.py', 'long_decode_graph/test_cold_owner_cpu.py', 'long_decode_graph/owner.py', 'long_decode_graph/qualify.py', 'long_decode_graph/candidate.py', 'long_decode_graph/model-source-pins.json', 'omlx_cold_restart/controller_v5.py', 'omlx_cold_restart/test_v5_cpu.py', 'omlx_cold_restart/audit_restore_v5.py', 'omlx_cold_restart/test_audit_restore_v5_cpu.py', 'pareto_realistic/qualify_native.py', 'prefill_nax_same_split/audit_failure_v2.py']:
 p=R/"bench/m5_ultra_256gb"/name
 assert p.is_file();inputs["audit-source/"+str(p.relative_to(R))]=p
inputs['archive-script.py']=Path(__file__).resolve()
records={name:dict(source=str(p),bytes=p.stat().st_size,sha256=sha(p),mtime_ns=p.stat().st_mtime_ns) for name,p in inputs.items()}
write(O/'manifest.json',dict(schema='E024-long-decode-cold-v1-archive-manifest-v1',members=records,members_count=len(records),raw_bytes=sum(r['bytes'] for r in records.values())))
package=O/'evidence.tar.xz'
with tarfile.open(package,'w:xz',preset=6) as tar:
 for name,p in inputs.items():tar.add(p,arcname=name,recursive=False)
seen=set()
with tarfile.open(package,'r:xz') as tar:
 for m in tar:
  assert m.isfile() and m.name in records and m.name not in seen
  seen.add(m.name);h=hashlib.sha256();size=0
  with tar.extractfile(m) as f:
   while b:=f.read(8<<20):h.update(b);size+=len(b)
  assert h.hexdigest()==records[m.name]['sha256'] and size==records[m.name]['bytes']
assert seen==set(records)
for name,p in inputs.items():assert sha(p)==records[name]['sha256'] and p.stat().st_size==records[name]['bytes'] and p.stat().st_mtime_ns==records[name]['mtime_ns']
for prefix,root in roots.items():assert trees[prefix]==[str(p.relative_to(root)) for p in sorted(root.rglob('*')) if p.is_file()]
write(O/'archive-verification.json',dict(schema='E024-long-decode-cold-v1-archive-verification-v1',status='PASS',archive_sha256=sha(package),archive_bytes=package.stat().st_size,manifest_sha256=sha(O/'manifest.json'),members_count=len(records),all_decompressed_member_hashes_verified=True,all_original_files_rehashed=True,all_tree_members_rechecked=True,exact_restoration_sidecars=True,qualification_source='Separate independent audit receipts; archival verification grants no numerical or performance qualification.'))
print((O/'archive-verification.json').read_text())
