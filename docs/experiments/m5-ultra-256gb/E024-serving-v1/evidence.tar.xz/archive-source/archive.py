"""Closed E024 serving-v1 evidence packaging; explicit --run only, no runtime imports."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import tarfile

ROOT=Path('/Users/ryanli/code/minivllm')
ART=ROOT/'.artifacts/m5-ultra-256gb'
NAME='route-decode-serving-v1'
PREREG=ROOT/'bench/m5_ultra_256gb/route_decode_graph/prereg-serving-v1'
PLAN_SHA='5161400cdfcd2b91610383f0776fc8483003d7b9bc3962c3a6728948004b5298'
CHILD_SHA='e85f92aa1402025a669de4c2426460c1eced29f0145f128480f1fa9e66349c56'
OUT=ROOT/'docs/experiments/m5-ultra-256gb/E024-serving-v1'
FORBIDDEN=('.safetensors','.dylib','.so','.pack','.bin')

def need(ok,message):
    if not ok:raise ValueError(message)
def read(path):return json.loads(Path(path).read_bytes())
def write(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def info(path):
    path=Path(path);need(path.is_file() and not path.is_symlink(),'regular file required: '+str(path))
    key=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    before=path.stat();h=hashlib.sha256();n=0
    with path.open('rb') as f:
        need(key(os.fstat(f.fileno()))==key(before),'file replaced before read')
        while data:=f.read(1<<20):h.update(data);n+=len(data)
        need(key(os.fstat(f.fileno()))==key(before),'open file changed')
    need(key(path.stat())==key(before) and n==before.st_size,'file changed after read')
    return dict(sha256=h.hexdigest(),bytes=n)
def files(root):
    need(root.is_dir() and not root.is_symlink(),'real directory required')
    result=[]
    for p in sorted(root.rglob('*')):
        need(not p.is_symlink() and (p.is_file() or p.is_dir()),'special evidence entry')
        if p.is_file():
            if p.name.endswith(FORBIDDEN):
                diagnostic=ART/(NAME+'-owner')/'phases/e024-route-serving/qualification/base/failure-arrays.safetensors'
                need(p==diagnostic,'unexpected binary model/runtime payload: '+str(p))
                failure=read(p.with_name('failure.json'));artifact=failure.get('array_artifact',{})
                need(artifact==dict(path=p.name,sha256=info(p)['sha256']), 'unbound first-failure diagnostic arrays')
            result.append(p)
    return result

def archive():
    need(not OUT.exists() and OUT.parent.is_dir(),'fresh archive directory required')
    trees={'raw/'+key:ART/(NAME+'-'+key) for key in ('owner','cold-journal','execution','analysis','cpu-prepare')}
    trees['preregistration']=PREREG
    owner=trees['raw/owner'];cold=trees['raw/cold-journal'];analysis=trees['raw/analysis']
    final=read(trees['raw/execution']/'final.json');journal=read(cold/'journal.json')
    complete=read(owner/'complete.json');plan=read(PREREG/'owner-plan.json');receipt=read(PREREG/'receipt.json')
    need(info(PREREG/'owner-plan.json')['sha256']==info(owner/'owner-plan.json')['sha256']==PLAN_SHA==receipt['owner_plan_sha256'],'registered owner plan')
    need(info(PREREG/'serving-plan.json')['sha256']==CHILD_SHA==plan['experiment']['plan']['sha256'],'registered child plan')
    need(complete['schema']=='cold-single-child-owner-result-v1' and complete['status'] in ('PASS','FAIL')
         and complete['owner_plan_sha256']==PLAN_SHA and complete['planned_trials']==['e024-route-serving'],'closed actual owner')
    need(journal['schema']=='cold-single-child-journal-v2' and journal['state']==final['journal_state']=='RESTORED'
         and type(final['recovery_returncode']) is int and final['recovery_returncode']==0,'actual terminal restoration')
    restore=read(analysis/'restoration-audit.json');numeric=read(analysis/'independent-numerical.json');resource=read(analysis/'independent-resources.json')
    pins=dict(receipt['source_pins'])
    need(all(info(p)['sha256']==h for p,h in pins.items()),'frozen source/plan/predecessor changed')
    lifecycle=read(plan['lifecycle']['path'])
    need(restore['schema']=='cold-service-restoration-audit-v1' and restore['status']=='PASS' and restore['qualified'] is True
         and restore['journal_sha256']==info(cold/'journal.json')['sha256'] and restore['owner_plan_sha256']==PLAN_SHA
         and restore['audit_source_sha256']==lifecycle['sources']['audit_restore']['sha256']
         and restore['controller_sha256']==lifecycle['sources']['controller']['sha256']
         and restore['service_restore']['replacement']==journal['replacement'],'bound independent restoration required')
    need(numeric['schema']=='E024-serving-independent-audit-v1' and numeric['status'] in ('PASS','FAIL','INCOMPLETE')
         and numeric['audit_source_sha256']==pins[str(ROOT/'bench/m5_ultra_256gb/route_decode_graph/audit_serving.py')]
         and numeric['http_qualified'] is False and numeric['performance_qualified'] is False,'independent numerical source/scope')
    need(resource['schema']=='cold-single-child-resource-reparse-v1' and resource['status'] in ('PASS','FAIL','REJECT')
         and resource['source_sha256']==pins[str(ROOT/'bench/m5_ultra_256gb/resource_reparse.py')]
         and Path(resource['owner_directory']).resolve()==owner,'independent resource source/owner')
    if numeric['status']=='PASS':
        need(numeric['qualified'] is True and numeric['plan_sha256']==CHILD_SHA and complete['status']=='PASS','numeric PASS binding')
    else:need(numeric['qualified'] is False,'failed numerical audit cannot qualify')
    inputs={};snapshots={}
    for prefix,path in trees.items():
        found=files(path);snapshots[prefix]=[p.relative_to(path).as_posix() for p in found]
        inputs.update({prefix+'/'+p.relative_to(path).as_posix():p for p in found})
    for path,h in pins.items():
        p=Path(path);need(p.is_relative_to(ROOT) and p.resolve()==p and not p.name.endswith(FORBIDDEN),'source scope')
        inputs['registered-source/'+p.relative_to(ROOT).as_posix()]=p
    inputs['archive-source/archive.py']=Path(__file__).resolve()
    manifest={name:dict(path=str(path),**info(path)) for name,path in inputs.items()}
    def bound(prefix,name,expected):
        path=PurePosixPath(name)
        need(not path.is_absolute() and '..' not in path.parts,'safe audit relative path')
        key=prefix+'/'+name;need(key in manifest,'audited raw file absent: '+key)
        need(all(manifest[key].get(k)==v for k,v in expected.items()),'audit/raw hash or size mismatch: '+key)
    if numeric['status']=='PASS':
        prefix='raw/owner/phases/e024-route-serving/qualification'
        need(set(numeric['terminal_sha256'])=={'plan.json','complete.json','base/plan.json','base/complete.json'},'exact numerical terminal binding')
        for name,h in numeric['terminal_sha256'].items():bound(prefix,name,dict(sha256=h))
        for name,key in (('base/steps.jsonl','ledger'),('route-events.jsonl','route_events')):
            bound(prefix,name,{k:numeric[key][k] for k in ('sha256','bytes')})
    if resource['status'] in ('PASS','REJECT'):
        need(type(resource['raw_file_pins']) is dict and resource['raw_file_pins'],'resource input pins required')
        for name,row in resource['raw_file_pins'].items():
            need(set(row)=={'sha256','bytes'},'exact resource raw pin fields');bound('raw/owner',name,row)
    OUT.mkdir()
    for name,path in {'restored-journal.json':cold/'journal.json','restoration-audit.json':analysis/'restoration-audit.json',
                      'independent-numerical.json':analysis/'independent-numerical.json','independent-resources.json':analysis/'independent-resources.json'}.items():
        shutil.copyfile(path,OUT/name);need(info(path)==info(OUT/name),'sidecar copy mismatch')
    target=OUT/'evidence.tar.xz'
    with tarfile.open(target,'w:xz',dereference=True) as tar:
        for name,path in inputs.items():tar.add(path,arcname=name,recursive=False)
    actual={}
    with tarfile.open(target,'r:xz') as tar:
        for member in tar:
            p=PurePosixPath(member.name)
            need(member.isfile() and not p.is_absolute() and '..' not in p.parts and member.name not in actual,'unsafe/duplicate archive member')
            f=tar.extractfile(member);h=hashlib.sha256();n=0
            while data:=f.read(1<<20):h.update(data);n+=len(data)
            actual[member.name]=dict(sha256=h.hexdigest(),bytes=n)
    need(set(actual)==set(manifest),'exact archive member set')
    need(all(actual[n]=={k:manifest[n][k] for k in ('sha256','bytes')} for n in actual),'archive member mismatch')
    need(all(info(path)==actual[name] for name,path in inputs.items()),'original source changed during packaging')
    need(all([p.relative_to(root).as_posix() for p in files(root)]==snapshots[prefix] for prefix,root in trees.items()),'evidence tree changed')
    write(OUT/'manifest.json',dict(schema='E024-serving-archive-manifest-v1',files=manifest))
    qualified=numeric['status']==resource['status']=='PASS'
    summary=dict(schema='E024-serving-archive-summary-v1',owner_status=complete['status'],owner_plan_sha256=PLAN_SHA,
        child_plan_sha256=CHILD_SHA,numerical_status=numeric['status'],resource_status=resource['status'],restoration_status='PASS',
        same_schedule_qualified=qualified,http_qualified=False,performance_qualified=False,
        restored_identity=journal['replacement'],coverage=numeric.get('coverage'),observed_eos_requests=numeric.get('observed_eos_requests'),
        discarded_ahead_observed=numeric.get('discarded_ahead_observed'),resource_samples=resource.get('samples'),
        scope='Qualification copied only from separate independent numerical/resource/recovery receipts. Successful tensor bytes are not retained for offline arithmetic recomputation. No HTTP or performance evidence and no unobserved invalidation/cancellation/combined E028 qualification.')
    write(OUT/'summary.json',summary)
    check=dict(schema='E024-serving-archive-verification-v1',status='PASS',archive=info(target),members=len(actual),
        all_member_hashes_verified=True,all_original_files_rehashed=True,all_tree_members_rechecked=True,
        model_payloads_rehashed=False,packaging_grants_qualification=False)
    write(OUT/'archive-verification.json',check)
    (OUT/'ARCHIVE.md').write_text('# Closed E024 serving archive\n\nRaw owner, journal, execution, analysis, read-only preparation, preregistration and exact source pins are preserved in evidence.tar.xz. Sidecars are byte-identical copies of actual final receipts. All member hashes and original tree membership were rechecked. No service/runtime imports or model-payload reads occurred in packaging. A numerical FAIL remains FAIL; packaging never supplies qualification.\n')
    print(json.dumps(check))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',action='store_true');a=p.parse_args()
    if a.run:archive()
    else:print(json.dumps(dict(status='DESCRIPTION_ONLY',writes=False,out=str(OUT))))
