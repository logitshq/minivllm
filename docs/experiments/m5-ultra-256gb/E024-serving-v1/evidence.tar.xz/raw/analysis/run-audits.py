import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time
r=Path('/Users/ryanli/code/minivllm');a=r/'.artifacts/m5-ultra-256gb';p=r/'bench/m5_ultra_256gb/route_decode_graph/prereg-serving-v1'
final=json.loads((a/'route-decode-serving-v1-execution/final.json').read_bytes())
journal=json.loads((a/'route-decode-serving-v1-cold-journal/journal.json').read_bytes())
assert final['journal_state']==journal['state']=='RESTORED' and final['recovery_returncode']==0
v=json.loads((p/'plan-build.json').read_bytes());receipt=json.loads((p/'receipt.json').read_bytes())
assert all(hashlib.sha256(Path(k).read_bytes()).hexdigest()==h for k,h in receipt['source_pins'].items())
out=Path(v['analysis_directory']);out.mkdir(exist_ok=False)
commands={name:v['commands'][name] for name in ('restoration_audit','numerical_audit','resource_audit')}
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(out/'run-audits.py').write_bytes(Path(__file__).read_bytes())
def run(item):
 name,cmd=item;start=time.monotonic();record=dict(argv=cmd,start=datetime.datetime.now(datetime.timezone.utc).isoformat())
 try:
  with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
   result=subprocess.run(cmd,cwd=r,stdout=stdout,stderr=stderr,check=False,timeout=180)
  record['returncode']=result.returncode
  path=Path(cmd[cmd.index('--out')+1]);record['result_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
  value=json.loads(path.read_bytes());record['status']=value['status']
 except Exception as exc:record.update(status='EXECUTION_ERROR',error_type=type(exc).__name__,error=str(exc))
 record['elapsed_seconds']=time.monotonic()-start
 (out/(name+'-command.json')).write_text(json.dumps(record,indent=2)+'\n')
 return name,record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(run,commands.items()))
print(json.dumps({k:{x:y for x,y in row.items() if x!='argv'} for k,row in results.items()}))
raise SystemExit(int(any(x.get('returncode')!=0 for x in results.values())))
