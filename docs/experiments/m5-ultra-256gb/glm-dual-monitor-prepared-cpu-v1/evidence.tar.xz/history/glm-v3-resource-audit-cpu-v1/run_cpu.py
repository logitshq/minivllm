import contextlib, hashlib, importlib.util, io, json, os, pathlib, shutil, sys, time, unittest
ROOT=pathlib.Path('/Users/ryanli/code/minivllm')
OUT=ROOT/'.artifacts/m5-ultra-256gb/glm-v3-resource-audit-cpu-v1'
FILES=['bench/m5_ultra_256gb/glm_flash_cycle_v3/owner.py','bench/m5_ultra_256gb/glm_flash_cycle_v3/test_audit_closed_cpu.py','bench/m5_ultra_256gb/glm_flash_cycle_v2/_reuse.py','bench/m5_ultra_256gb/glm_flash/live_monitor.py','bench/m5_ultra_256gb/glm_flash/physical_guard.py','bench/m5_ultra_256gb/glm_flash/load_probe.py','bench/m5_ultra_256gb/pareto_realistic/qualify_absent_owner.py']+['bench/m5_ultra_256gb/glm_flash_cycle/'+p for p in ['owner.py','controller.py','audit_restore.py','audit_closed.py','preregister.py','execute.py','prepare_inputs.py']]
FILES += ['bench/m5_ultra_256gb/glm_flash_cycle_v3/'+p for p in ('controller.py','audit_restore.py','predecessor-manifest.json','audit_closed.py')]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,obj): p.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
OUT.mkdir(parents=False,exist_ok=False)
(OUT/'sources').mkdir()
pre={p:sha(ROOT/p) for p in FILES}
for p in FILES:
 dst=OUT/'sources'/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,dst)
shutil.copyfile(__file__,OUT/'run_cpu.py')
blocked=[]
def hook(event,args):
 bad=event in ('subprocess.Popen','os.system','os.kill','os.killpg','os.posix_spawn','os.fork') or event.startswith(('socket.connect','socket.bind','socket.getaddrinfo'))
 if event=='import' and str(args[0]).split('.')[0] in ('mlx','mlx_lm','mlx_vlm','torch','omlx','monolith','transformers'): bad=True
 if bad:
  blocked.append({'event':event,'subject':str(args[0]) if args else ''});raise AssertionError('Forbidden backend operation: '+event)
sys.addaudithook(hook)
stdout=io.StringIO();stderr=io.StringIO();began=time.monotonic();result=None;failure=None;discovered=None
with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
 try:
  spec=importlib.util.spec_from_file_location('glm_dual_monitor_cpu',ROOT/FILES[1]);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  suite=unittest.defaultTestLoader.loadTestsFromModule(module);discovered=suite.countTestCases()
  if discovered!=8:raise AssertionError(('whole-module expected8',discovered))
  result=unittest.TextTestRunner(verbosity=2,stream=sys.stderr).run(suite)
 except BaseException as exc:
  import traceback;traceback.print_exc();failure={'type':type(exc).__name__,'message':str(exc)}
(OUT/'stdout.txt').write_text(stdout.getvalue());(OUT/'stderr.txt').write_text(stderr.getvalue())
post={p:sha(ROOT/p) for p in FILES}
row=dict(schema='GLM-v3-resource-audit-CPU-v1',status='PASS' if result is not None and result.wasSuccessful() and result.testsRun==8 and not result.skipped and not blocked and pre==post else 'FAIL',expected=8,discovered=discovered,tests_run=None if result is None else result.testsRun,failures=None if result is None else result.failures,errors=None if result is None else result.errors,skips=None if result is None else result.skipped,exception=failure,blocked=blocked,source_pre=pre,source_post=post,sources_unchanged=pre==post,elapsed_seconds=time.monotonic()-began,command=[sys.executable,'-I','-B',str(pathlib.Path(__file__).resolve())],interpreter=sys.executable,scope='Fake CPU threads and fake subprocess handles only; no actual physical/model/service validation.')
# unittest failure IDs/traces are strings, never serialized test instances.
for key in ('failures','errors','skips'):
 if row[key] is not None:row[key]=[(test.id(),detail) for test,detail in row[key]]
write(OUT/'result.json',row)
write(OUT/'artifact-manifest.json',{str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.rglob('*')) if p.is_file()})
print(json.dumps({k:row[k] for k in ('status','expected','discovered','tests_run','elapsed_seconds','blocked','sources_unchanged')}));print(OUT)
sys.exit(0 if row['status']=='PASS' else 1)
