"""One bounded in-turn continuation: close this actual registered cycle after driver restoration."""
from pathlib import Path
import hashlib,json,subprocess,time
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';D=A/'gdn-graph-combined-formal-v2-execution';J=A/'gdn-graph-combined-formal-v2-cold-journal/journal.json'
close=Path('/tmp/close-combined-formal-v2.py');closed_bytes=close.read_bytes();closed_sha=hashlib.sha256(closed_bytes).hexdigest()
with (D/'closure-continuation.py').open('xb') as f:f.write(Path(__file__).read_bytes())
with (D/'future-close.py').open('xb') as f:f.write(closed_bytes)
started=time.monotonic();deadline=45924
while not (D/'final.json').exists():
 if time.monotonic()-started>deadline:raise TimeoutError('registered experiment/recovery continuation deadline')
 time.sleep(30)
final=json.loads((D/'final.json').read_text());journal=json.loads(J.read_text())
assert final['journal_state']==journal['state']=='RESTORED','driver did not prove restoration; no formal closure claim'
assert final['prepare_returncode']==0
assert hashlib.sha256(close.read_bytes()).hexdigest()==closed_sha
print('Driver ended and journal RESTORED; running exact independent closure.',flush=True)
result=subprocess.run([str(R/'.venv/bin/python'),'-I','-B',str(close)],cwd=R,check=False)
print('Closure returned '+str(result.returncode),flush=True)
raise SystemExit(result.returncode)
