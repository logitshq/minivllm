"""Record actual registration; never launches stop, owner, or recovery."""
import datetime,hashlib,json,subprocess,time
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');H=R/'bench/m5_ultra_256gb/gdn_prework_formal'
A=R/'docs/experiments/m5-ultra-256gb/E029-gdn-prework-http-v1'
OUT=R/'.artifacts/m5-ultra-256gb/gdn-http-formal-v1-registration'
PY=str(R/'.venv/bin/python')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
def run(label,cmd):
 record=dict(argv=cmd,started_at=now(),cwd=str(R));save(label+'-command.json',record)
 start=time.monotonic()
 with (OUT/(label+'.stdout')).open('xb') as o,(OUT/(label+'.stderr')).open('xb') as e:
  result=subprocess.run(cmd,cwd=R,stdout=o,stderr=e,timeout=900,check=False)
 record.update(returncode=result.returncode,ended_at=now(),elapsed_seconds=time.monotonic()-start);save(label+'-command.json',record)
 print(label+' rc='+str(result.returncode),flush=True)
 if result.returncode:raise RuntimeError(label+' failed; first output retained')
OUT.mkdir();(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
try:
 run('build',[PY,'-I','-B',str(H/'preregister.py'),'--prepare','--predecessor',str(A/'restored-journal.json'),'--predecessor-sha256',sha(A/'restored-journal.json'),'--restoration-audit',str(A/'restoration-audit.json'),'--restoration-audit-sha256',sha(A/'restoration-audit.json')])
 cmds=json.loads((H/'prereg-formal-v1/commands.json').read_bytes())
 for label in ('cpu_prepare','readonly_service_prepare','seal_receipt'):run(label,cmds[label])
 save('result.json',dict(status='PASS',service_stopped=False,device_run=False,receipt_sha256=sha(H/'prereg-formal-v1/receipt.json'),owner_plan_sha256=sha(H/'prereg-formal-v1/owner-plan.json')))
except BaseException as exc:
 save('result.json',dict(status='FAIL',error=dict(type=type(exc).__name__,message=str(exc))));raise
