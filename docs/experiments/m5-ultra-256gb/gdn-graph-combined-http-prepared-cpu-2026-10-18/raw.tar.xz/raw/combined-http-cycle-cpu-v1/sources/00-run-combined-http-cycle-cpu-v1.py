import argparse,builtins,contextlib,hashlib,importlib.abc,importlib.util,json,os,signal,socket,ssl,subprocess,sys,time,unittest,unittest.mock
from pathlib import Path
ROOT=Path('/Users/ryanli/code/minivllm');HERE=ROOT/'bench/m5_ultra_256gb/gdn_graph_combined_http_cycle';OUT=ROOT/'.artifacts/m5-ultra-256gb/combined-http-cycle-cpu-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
 p=argparse.ArgumentParser();p.add_argument('--run',action='store_true')
 if not p.parse_args().run:print('DESCRIPTION_ONLY fake CPU14');return 0
 OUT.mkdir(exist_ok=False);(OUT/'sources').mkdir();started=time.time()
 paths=[Path(__file__).resolve(),*(HERE/n for n in ('owner.py','controller.py','audit_restore.py','test_owner_cpu.py','test_contract_cpu.py'))]
 before={str(p):sha(p) for p in paths}
 for i,p in enumerate(paths):(OUT/'sources'/f'{i:02}-{p.name}').write_bytes(p.read_bytes())
 save(OUT/'source-before.json',before);save(OUT/'command.json',{'argv':[sys.executable,'-I','-B',str(Path(__file__).resolve()),'--run'],'started_at':started})
 denied=[]
 def deny(label):
  def fail(*a,**kw):denied.append(label);raise AssertionError('forbidden '+label)
  return fail
 class Guard(importlib.abc.MetaPathFinder):
  def find_spec(self,name,path=None,target=None):
   if name.split('.')[0] in ('mlx','mlx_lm','numpy','torch','transformers','safetensors','omlx','monolith'):return deny('backend '+name)()
 guard=Guard();sys.meta_path.insert(0,guard);result=None;error=None
 try:
  with contextlib.ExitStack() as stack:
   for obj,name in ((subprocess,'Popen'),(os,'kill'),(os,'killpg'),(os,'system'),(socket.socket,'connect'),(socket.socket,'bind'),(socket,'create_connection'),(signal,'signal'),(signal,'setitimer')):stack.enter_context(unittest.mock.patch.object(obj,name,deny(name)))
   with (OUT/'stdout.txt').open('x') as stdout,(OUT/'stderr.txt').open('x') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
    suite=unittest.TestSuite()
    for name in ('test_owner_cpu','test_contract_cpu'):
     sp=importlib.util.spec_from_file_location(name,HERE/(name+'.py'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(m))
    assert suite.countTestCases()==14
    result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
 except BaseException as e:error={'type':type(e).__name__,'message':str(e)}
 finally:sys.meta_path.remove(guard)
 after={str(p):sha(p) for p in paths};save(OUT/'source-after.json',after)
 ok=bool(result and result.wasSuccessful() and result.testsRun==14 and not result.skipped and not denied and before==after and error is None)
 row={'schema':'combined-http-cycle-cpu-v1','status':'PASS' if ok else 'FAIL','tests_run':result.testsRun if result else 0,'failures':len(result.failures) if result else 0,'errors':len(result.errors) if result else 0,'skipped':len(result.skipped) if result else 0,'error':error,'denied':denied,'source_unchanged':before==after,'started_at':started,'ended_at':time.time(),'scope':'fake control flow/source contracts; no service/model/GPU','qualified':False}
 save(OUT/'result.json',row);print(json.dumps(row));return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
