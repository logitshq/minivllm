"""One small fake-only test attempt; no model/runtime/service operations."""
import argparse
import contextlib
import hashlib
import json
from pathlib import Path
import sys
import socket
import time
import unittest

ROOT = Path('/Users/ryanli/code/minivllm')
NAME = 'bench.m5_ultra_256gb.gdn_graph_combined.test_http_audit_cpu'


def main():
    p = argparse.ArgumentParser(); p.add_argument('--run', action='store_true'); p.add_argument('--out', type=Path)
    args = p.parse_args()
    if not args.run:
        print(json.dumps({'scope': '9 independent combined HTTP evidence tests', 'run': False})); return 0
    assert sys.flags.isolated == 1 and sys.dont_write_bytecode
    out = args.out.resolve(); out.mkdir(parents=True, exist_ok=False)
    files = [Path(__file__), *sorted((ROOT/'bench/m5_ultra_256gb/gdn_graph_combined').glob('*.py')),
        *sorted((ROOT/'bench/m5_ultra_256gb/route_decode_graph').glob('*.py')),
        *sorted((ROOT/'bench/m5_ultra_256gb/pareto_realistic').glob('*.py')),
        *[ROOT/'bench/m5_ultra_256gb'/name for name in (
            'gdn_prework_unbound/candidate.py', 'gdn_prework_unbound/test_candidate_cpu.py',
            'identity_refill/test_integration_cpu.py', 'identity_refill/integration.py',
            'long_decode_graph/candidate.py', 'long_decode_graph/qualify.py',
            'long_decode_graph/model-source-pins.json')],
        *[ROOT/'tutorial_code/miniengine'/name for name in
            ('cache.py','engine/model_runner.py','engine/compiled_decode.py')]]
    pins = {}
    for index, path in enumerate(files):
        raw = path.read_bytes(); copy = out/'sources'/f'{index:02d}-{path.name}'
        copy.parent.mkdir(exist_ok=True); copy.write_bytes(raw)
        pins[str(path)] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), copy=str(copy.relative_to(out)))
    (out/'source-pins.json').write_text(json.dumps(pins, indent=2)+'\n')
    (out/'command.json').write_text(json.dumps([sys.executable, '-I', '-B', str(Path(__file__)), *sys.argv[1:]], indent=2)+'\n')
    denied = []; local_asyncio_sockets = []
    def guard(event, data):
        if event == 'socket.__new__' and data[1] == socket.AF_UNIX and data[2] == socket.SOCK_STREAM:
            local_asyncio_sockets.append('AF_UNIX/SOCK_STREAM'); return
        if event in ('subprocess.Popen', 'os.system', 'os.kill', 'os.killpg', 'os.posix_spawn') or event.startswith('socket.'):
            denied.append(event); raise AssertionError('forbidden operation: '+event)
        if event == 'import' and data[0].split('.')[0] in ('mlx', 'mlx_lm', 'mlx_vlm', 'torch', 'numpy', 'tutorial_code') and data[0] not in sys.modules:
            denied.append('import '+data[0]); raise AssertionError('forbidden runtime import: '+data[0])
    assert not any(x.split('.')[0] in ('mlx', 'mlx_lm', 'mlx_vlm', 'torch', 'numpy', 'tutorial_code') for x in sys.modules)
    sys.addaudithook(guard); sys.path.insert(0, str(ROOT))
    start = time.time(); result = None; error = None
    with (out/'stdout.txt').open('x') as stdout, (out/'stderr.txt').open('x') as stderr:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                suite = unittest.defaultTestLoader.loadTestsFromName(NAME)
                assert suite.countTestCases() == 9
                result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
            except BaseException as exc:
                import traceback
                traceback.print_exc(); error = dict(type=type(exc).__name__, message=str(exc))
    unchanged = all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == pin['sha256'] for path, pin in pins.items())
    passed = result is not None and result.wasSuccessful() and not result.skipped and unchanged and not denied and error is None
    receipt = dict(schema='GDN-graph-combined-http-audit-cpu-v1', status='PASS' if passed else 'FAIL',
        tests_run=result.testsRun if result else 0, failures=len(result.failures) if result else None,
        errors=len(result.errors) if result else None, skipped=len(result.skipped) if result else None,
        source_unchanged=unchanged, local_asyncio_sockets=local_asyncio_sockets, denied=denied, error=error, started_at=start, ended_at=time.time(),
        numerical_qualified=False, http_qualified=False, performance_qualified=False)
    (out/'result.json').write_text(json.dumps(receipt, indent=2)+'\n'); print(json.dumps(receipt)); return 0 if passed else 1


if __name__ == '__main__': raise SystemExit(main())
