"""Package only CLOSED oMLX D512 formal v1 evidence. Explicit --run; stdlib only.

RESTORED plus the actual independent restoration PASS is mandatory. Experiment
and qualification/resource failures remain failures. This is a hash/retention
check, not another qualification audit. No model/runtime payloads are opened.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import tarfile

ROOT = Path('/Users/ryanli/code/minivllm')
ART = ROOT / '.artifacts/m5-ultra-256gb'
NAME = 'omlx-d512-formal-v1'
SOURCE = ROOT / 'bench/m5_ultra_256gb/omlx_d512_formal'
PREREG = SOURCE / 'prereg-formal-v1'
OUT = ROOT / 'docs/experiments/m5-ultra-256gb/E023-omlx-d512-formal-v1'
PLAN_SHA = '02242e5de79fce33e67cc83d28d5f7c0f5f89436b0debeabe110a1f00c57785e'
PREPARED_SHA = '78013391b574e7875a5865b2c96e1b5792923d3ea00670aed2e862b6f2e5d569'
PHASES = ['r1-c1','r1-c8','r2-c8','r2-c1','r3-c1','r3-c8']
FORBIDDEN = ('.safetensors', '.dylib', '.so', '.pack', '.bin')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def info(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'regular file required: ' + str(path))
    key = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns)
    before = path.stat(); digest = hashlib.sha256(); size = 0
    with path.open('rb') as stream:
        need(key(os.fstat(stream.fileno())) == key(before), 'file replaced before read')
        while chunk := stream.read(1 << 20):
            digest.update(chunk); size += len(chunk)
        need(key(os.fstat(stream.fileno())) == key(before), 'open file changed')
    need(key(path.stat()) == key(before) and size == before.st_size, 'file changed after read')
    return dict(sha256=digest.hexdigest(), bytes=size)


def entries(root, allowed_links):
    """Do not follow even the explicitly registered model directory links."""
    need(root.is_dir() and not root.is_symlink(), 'real evidence directory required: ' + str(root))
    files = []; links = {}
    for folder, dirs, names in os.walk(root, followlinks=False):
        for name in sorted(dirs + names):
            path = Path(folder) / name
            if path.is_symlink():
                target = os.readlink(path)
                need(str(path) in allowed_links and target == allowed_links[str(path)],
                     'unexpected symlink or model target: ' + str(path))
                # The exact source materialization record is retained; never stat the target.
                trial = path.parent.parent
                materialized = trial / 'materialized-inputs.json'
                if materialized.exists():
                    record = read(materialized)['files'][str(path)]
                    need(record == dict(symlink_target=target, resolved=target), 'model link materialization differs')
                links[path.relative_to(root).as_posix()] = dict(target=target,
                    materialization_receipt_present=materialized.exists(),
                    reason='Registered model-directory link; link target payload intentionally not opened or archived.')
            elif path.is_file():
                need(not path.name.endswith(FORBIDDEN), 'unexpected model/runtime binary: ' + str(path))
                files.append(path)
            else:
                need(path.is_dir(), 'special evidence entry: ' + str(path))
    return sorted(files), links


def archive():
    need(not OUT.exists() and OUT.parent.is_dir(), 'fresh archive directory required')
    trees = {'raw/' + key: ART / (NAME + '-' + key)
             for key in ('owner', 'cold-journal', 'execution', 'analysis', 'cpu-prepare')}
    trees['preregistration'] = PREREG
    owner, cold, execution, analysis = [trees['raw/' + key]
                                      for key in ('owner', 'cold-journal', 'execution', 'analysis')]
    final = read(execution / 'final.json'); journal = read(cold / 'journal.json')
    plan = read(PREREG / 'owner-plan.json'); receipt = read(PREREG / 'receipt.json')
    pins = receipt['source_pins']
    need(receipt['schema'] == 'oMLX-D512-formal-execution-receipt-v1'
         and type(pins) is dict and len(pins) == receipt['source_count'] == 48
         and pins == read(PREREG / 'source-manifest.json')['source_pins'], 'exact 48 registered source pins')
    need(info(PREREG / 'owner-plan.json')['sha256'] == PLAN_SHA == receipt['owner_plan_sha256']
         and plan['schema'] == 'E023-omlx-D512-formal-owner-plan-v1' and plan['trials'] == PHASES,
         'registered owner plan')
    need(info(execution / 'prepared-journal.json')['sha256'] == PREPARED_SHA == receipt['prepared_journal_sha256']
         and info(execution / 'execution-receipt.json') == info(PREREG / 'receipt.json'), 'actual execution preregistration binding')
    need(journal['schema'] == 'E023-omlx-D512-formal-cold-journal-v1'
         and journal['state'] == final['journal_state'] == 'RESTORED'
         and type(final['recovery_returncode']) is int and final['recovery_returncode'] == 0,
         'actual terminal restoration required; running evidence is not packaged')
    restore = read(analysis / 'restoration-audit.json')
    qualification = read(analysis / 'independent-formal.json')
    resource = read(analysis / 'resource-summary.json')
    for path, digest in pins.items():
        p = Path(path)
        need(p.is_absolute() and p.is_relative_to(ROOT) and p.resolve() == p
             and not p.name.endswith(FORBIDDEN) and p.stat().st_size <= 32 * (1 << 20), 'small registered source scope')
        need(info(p)['sha256'] == digest, 'registered source changed: ' + path)
    need(restore['schema'] == 'cold-service-restoration-audit-v1' and restore['status'] == 'PASS'
         and restore['qualified'] is True and restore['performance_qualified'] is False
         and restore['numerical_qualified'] is False
         and restore['journal_sha256'] == info(cold / 'journal.json')['sha256']
         and restore['owner_plan_sha256'] == PLAN_SHA
         and restore['audit_source_sha256'] == pins[str(SOURCE / 'audit_restore.py')]
         and restore['controller_sha256'] == pins[str(SOURCE / 'controller.py')]
         and restore['service_restore']['replacement'] == journal['replacement'], 'bound independent restoration PASS')
    complete = None
    if owner.exists():
        complete = read(owner / 'complete.json')
        need(info(owner / 'owner-plan.json')['sha256'] == PLAN_SHA
             and complete['schema'] == 'E023-omlx-D512-formal-owner-result-v1'
             and complete['status'] in ('PASS', 'FAIL') and complete['owner_plan_sha256'] == PLAN_SHA
             and complete['planned_trials'] == PHASES and complete['performance_qualified'] is False
             and complete['full_state_qualified'] is False, 'closed actual owner')
        need(restore['owner_reap']['owner_status'] == complete['status'], 'restoration/owner status mismatch')
    else:
        need(restore['owner_reap']['status'] == 'NO_EXPERIMENT' and journal['reap'] == {'no_experiment': True},
             'missing owner needs actual NO_EXPERIMENT recovery evidence')
    need(qualification['schema'] == 'E023-omlx-D512-formal-independent-audit-v1'
         and qualification['status'] in ('PASS', 'FAIL', 'INCOMPLETE')
         and qualification['audit_source_sha256'] == pins[str(SOURCE / 'audit_formal.py')]
         and qualification['owner_directory'] == str(owner)
         and qualification['full_state_qualified'] is False
         and qualification['output_quality_qualified'] is False
         and qualification['performance_qualified'] is (qualification['status']=='PASS'),
         'actual independent qualification source/scope')
    need(resource['schema'] == 'oMLX-D512-formal-resource-audit-v1'
         and resource['status'] in ('PASS', 'FAIL', 'INCOMPLETE')
         and resource['performance_qualified'] is False, 'actual resource audit scope')
    if resource['status'] == 'PASS':
        need(resource['independent_resource_verified'] is True and resource['owner_directory'] == str(owner)
             and resource['owner_plan_sha256'] == PLAN_SHA
             and resource['owner_complete_sha256'] == info(owner / 'complete.json')['sha256']
             and resource['audit_source_sha256'] == pins[str(SOURCE / 'audit_resources.py')], 'resource PASS binding')
    else:
        need(resource['independent_resource_verified'] is False, 'failed resource audit cannot qualify')
    specs = read(PREREG / 'trial-specs.json')
    need(type(specs) is list and [s['concurrency'] for s in specs] == [1,8,8,1,1,8], 'registered exact trial specs')
    allowed_links = {}
    for phase, spec in zip(PHASES, specs):
        folder = owner / 'phases' / phase / 'trial'
        expected_link = str(folder / 'models/Qwen3.8-27B-nvfp4')
        need(spec['output_directory'] == str(folder) and spec['served_model'] == 'Qwen3.8-27B-nvfp4'
             and spec['symlinks'] == {expected_link: spec['model_directory']}
             and Path(spec['model_directory']).is_absolute(), 'exact model-link spec')
        allowed_links.update(spec['symlinks'])
    inputs = {}; snapshots = {}; omitted_links = {}; missing_trees = []
    for prefix, root in trees.items():
        if root == owner and complete is None:
            missing_trees.append(prefix); continue
        found, links = entries(root, allowed_links)
        snapshots[prefix] = ([p.relative_to(root).as_posix() for p in found], links)
        inputs.update({prefix + '/' + p.relative_to(root).as_posix(): p for p in found})
        omitted_links.update({prefix + '/' + name: value for name, value in links.items()})
    for path in pins:
        inputs['registered-source/' + Path(path).relative_to(ROOT).as_posix()] = Path(path)
    inputs['archive-source/archive.py'] = Path(__file__).resolve()
    manifest = {name: dict(path=str(path), **info(path)) for name, path in inputs.items()}

    def bound(prefix, name, expected):
        p = PurePosixPath(name)
        need(not p.is_absolute() and p.as_posix() == name and '..' not in p.parts, 'unsafe evidence reference')
        key = prefix + '/' + name
        need(key in manifest and all(manifest[key].get(k) == v for k, v in expected.items()),
             'receipt/archive file binding differs: ' + key)

    if qualification['status'] == 'PASS':
        need(complete is not None and complete['status']=='PASS' and qualification['qualified'] is True
             and qualification['performance_qualified'] is True and qualification['formal_requests']==384
             and qualification['warm_requests']==48 and qualification['owner_plan_sha256']==PLAN_SHA
             and [r['phase'] for r in qualification['points']]==PHASES
             and [r['concurrency'] for r in qualification['points']]==[1,8,8,1,1,8]
             and all(r['requests']==64 and r['warm_requests_checked']==8 for r in qualification['points']),
             'formal PASS binding/coverage')
        for phase,row in zip(PHASES,qualification['points']):
            folder=owner/'phases'/phase/'trial';prefix='raw/owner/phases/'+phase+'/trial'
            for field,name in [('point_receipt','point.json'),('formal_raw_group','formal-group.json')]:
                item=row[field];need(item['path']==str(folder/name),'exact formal evidence path')
                bound(prefix,name,dict(sha256=item['sha256']))
            for name,item in row['retained_logs'].items():
                need(name in ('server.stdout','server.stderr') and item['path']==str(folder/name),'exact closed log path')
                bound(prefix,name,dict(sha256=item['sha256']))
            trial=read(folder/'complete.json')
            need(trial['status']=='PASS' and trial['count_eligible'] is True
                 and trial['server_reaped'] is True and trial['performance_qualified'] is False,'actual closed trial PASS')
            actual={key[len(prefix)+1:] for key in manifest if key.startswith(prefix+'/') and key!=prefix+'/complete.json'}
            need(set(trial['artifacts'])==actual,'exact closed trial artifact set')
            for name,pin in trial['artifacts'].items():
                need(set(pin)=={'sha256','bytes'},'exact trial artifact pin fields');bound(prefix,name,pin)
    else:
        need(qualification['qualified'] is False and qualification['performance_qualified'] is False,
             'failed formal audit cannot qualify')
    OUT.mkdir()
    sidecars = {'restored-journal.json': cold / 'journal.json', 'restoration-audit.json': analysis / 'restoration-audit.json',
                'independent-formal.json': analysis / 'independent-formal.json', 'resource-summary.json': analysis / 'resource-summary.json'}
    for name, path in sidecars.items():
        shutil.copyfile(path, OUT / name); need(info(path) == info(OUT / name), 'sidecar mismatch')
    write(OUT / 'model-links.json', dict(schema='oMLX-archive-excluded-model-links-v1', links=omitted_links,
        targets_opened=False, targets_archived=False))
    inputs['archive-metadata/model-links.json'] = OUT / 'model-links.json'
    manifest['archive-metadata/model-links.json'] = dict(path=str(OUT / 'model-links.json'), **info(OUT / 'model-links.json'))
    target = OUT / 'evidence.tar.xz'
    with tarfile.open(target, 'w:xz', dereference=True) as tar:
        for name, path in inputs.items():
            tar.add(path, arcname=name, recursive=False)
    actual = {}
    with tarfile.open(target, 'r:xz') as tar:
        for member in tar:
            p = PurePosixPath(member.name)
            need(member.isfile() and not p.is_absolute() and '..' not in p.parts and member.name not in actual,
                 'unsafe or duplicate archive member')
            stream = tar.extractfile(member); digest = hashlib.sha256(); size = 0
            while chunk := stream.read(1 << 20):
                digest.update(chunk); size += len(chunk)
            actual[member.name] = dict(sha256=digest.hexdigest(), bytes=size)
    need(set(actual) == set(manifest), 'exact archive member set')
    need(all(actual[name] == {k: manifest[name][k] for k in ('sha256', 'bytes')} for name in actual), 'archive hash/size mismatch')
    need(all(info(path) == actual[name] for name, path in inputs.items()), 'original changed during archive')
    for prefix, root in trees.items():
        if prefix in missing_trees:
            need(not root.exists(), 'unstarted owner appeared during archive'); continue
        found, links = entries(root, allowed_links)
        need(([p.relative_to(root).as_posix() for p in found], links) == snapshots[prefix], 'evidence membership or model link changed')
    write(OUT / 'manifest.json', dict(schema='E023-omlx-D512-formal-archive-manifest-v1', files=manifest,
        excluded_model_links=omitted_links, missing_unstarted_trees=missing_trees, registered_source_count=len(pins)))
    summary = dict(schema='E023-omlx-D512-formal-archive-summary-v1',owner_plan_sha256=PLAN_SHA,
        owner_status=complete['status'] if complete else 'NOT_STARTED',formal_status=qualification['status'],
        resource_status=resource['status'],restoration_status='PASS',
        performance_qualified=qualification['status']==resource['status']=='PASS',
        formal_requests=qualification.get('formal_requests'),warm_requests=qualification.get('warm_requests'),
        points=qualification.get('points'),process_metric_medians=qualification.get('process_metric_medians'),
        resource_summary=resource.get('resource_summary'),
        original_identity=journal['original'],restored_identity=journal['replacement'],
        full_state_qualified=False,output_quality_qualified=False,packaging_grants_qualification=False,
        scope='Exact already-produced formal/resource/restoration receipts; failed attempts remain failed. '
              'POST-to-DONE committed count from unobserved official CLI. No cross-engine full-state/quality equality, '
              'generator EOF, full lifespan-log health, recursive runtime closure, warm-KV restoration or global frontier claim.')
    write(OUT / 'summary.json', summary)
    verification = dict(schema='E023-omlx-D512-formal-archive-verification-v1', status='PASS', archive=info(target),
        members=len(actual), logical_file_bytes=sum(row['bytes'] for row in actual.values()),
        registered_source_count=len(pins), excluded_model_links=len(omitted_links), missing_unstarted_trees=missing_trees,
        all_member_hashes_verified=True, all_original_files_rehashed=True, all_tree_members_rechecked=True,
        model_payloads_rehashed=False, runtime_payloads_rehashed=False, packaging_grants_qualification=False)
    write(OUT / 'archive-verification.json', verification)
    (OUT / 'ARCHIVE.md').write_text('# Closed oMLX D512 formal archive\n\n'
        'evidence.tar.xz preserves regular files from the actual owner, cold journal, execution, analysis and CPU preparation trees, '
        'preregistration, all 48 registered small sources, and this packer. A legitimately unstarted owner is explicitly listed. '
        'Only exact preregistered model-directory links are omitted as filesystem objects; their targets and materialization evidence are retained in model-links.json. '
        'No model or runtime binary payload is followed or copied. Every member, original file and tree membership was rechecked.\n\n'
        'Sidecars are exact copies of actual final receipts. Restoration PASS is mandatory; qualification and resource FAIL/INCOMPLETE remain unchanged. '
        'When formal PASS exists, its exact point/group/closed-log hashes and the full actual trial artifact inventory are bound to the archive. '
        'Packaging copies existing independent results; it grants no new qualification or global Pareto claim.\n')
    print(json.dumps(verification))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run:
        archive()
    else:
        print(json.dumps(dict(status='DESCRIPTION_ONLY', writes=False, out=str(OUT))))
