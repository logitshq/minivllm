import argparse,builtins,contextlib,hashlib,importlib.abc,importlib.util,json,os,signal,socket,ssl,subprocess,sys,time,unittest,unittest.mock
from pathlib import Path
ROOT=Path('/Users/ryanli/code/minivllm');HERE=ROOT/'bench/m5_ultra_256gb/gdn_graph_combined_formal';OUT=ROOT/'.artifacts/m5-ultra-256gb/combined-formal-lifecycle-cpu-v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
 p=argparse.ArgumentParser();p.add_argument('--run',action='store_true')
 if not p.parse_args().run:print('DESCRIPTION_ONLY fake CPU58');return 0
 sys.path.insert(0,str(ROOT)); OUT.mkdir(exist_ok=False);(OUT/'sources').mkdir();started=time.time()
 paths=[Path(__file__).resolve(),*(HERE/n for n in ('owner.py','controller.py','audit_restore.py','formal.py','audit_formal.py','test_owner_cpu.py','test_controller_cpu.py','test_audit_restore_cpu.py','test_audit_formal_cpu.py'))]
 before={str(p):sha(p) for p in paths}
 for i,p in enumerate(paths):(OUT/'sources'/f'{i:02}-{p.name}').write_bytes(p.read_bytes())
 save(OUT/'source-before.json',before);save(OUT/'command.json',{'argv':[sys.executable,'-I','-B',str(Path(__file__).resolve()),'--run'],'started_at':started})
 denied=[]; asyncio_sigint_fakes=[]
 real_getsignal=signal.getsignal
 def fake_asyncio_signal(signum,handler):
  caller=sys._getframe(1)
  if signum==signal.SIGINT and Path(caller.f_code.co_filename).name=='runners.py' and Path(caller.f_code.co_filename).parent.name=='asyncio' and caller.f_code.co_name=='run':
   asyncio_sigint_fakes.append({'signal':int(signum),'caller':caller.f_code.co_filename,'effect':'suppressed OS handler mutation'});return real_getsignal(signum)
  return deny('signal')(signum,handler)
 def deny(label):
  def fail(*a,**kw):denied.append(label);raise AssertionError('forbidden '+label)
  return fail
 class Guard(importlib.abc.MetaPathFinder):
  def find_spec(self,name,path=None,target=None):
   if name.split('.')[0] in ('mlx','mlx_lm','numpy','torch','transformers','safetensors','omlx','monolith'):return deny('backend '+name)()
 guard=Guard();sys.meta_path.insert(0,guard);result=None;error=None;modules=[]
 try:
  with contextlib.ExitStack() as stack:
   for obj,name in ((subprocess,'Popen'),(os,'kill'),(os,'killpg'),(os,'system'),(socket.socket,'connect'),(socket.socket,'bind'),(socket,'create_connection'),(signal,'setitimer')):stack.enter_context(unittest.mock.patch.object(obj,name,deny(name)))
   stack.enter_context(unittest.mock.patch.object(signal,'signal',fake_asyncio_signal))
   with (OUT/'stdout.txt').open('x') as stdout,(OUT/'stderr.txt').open('x') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
    suite=unittest.TestSuite(); modules=[]
    for name in ('test_owner_cpu','test_controller_cpu','test_audit_restore_cpu','test_audit_formal_cpu'):
     sp=importlib.util.spec_from_file_location(name,HERE/(name+'.py'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);tests=unittest.defaultTestLoader.loadTestsFromModule(m);modules.append({'name':name,'tests':tests.countTestCases()});suite.addTests(tests)
    assert suite.countTestCases()==58
    result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
 except BaseException as e:error={'type':type(e).__name__,'message':str(e)}
 finally:sys.meta_path.remove(guard)
 after={str(p):sha(p) for p in paths};save(OUT/'source-after.json',after)
 ok=bool(result and result.wasSuccessful() and result.testsRun==58 and not result.skipped and not denied and before==after and error is None)
 row={'schema':'combined-formal-lifecycle-cpu-v2','status':'PASS' if ok else 'FAIL','modules':modules,'tests_run':result.testsRun if result else 0,'failures':len(result.failures) if result else 0,'errors':len(result.errors) if result else 0,'skipped':len(result.skipped) if result else 0,'error':error,'denied':denied,'asyncio_sigint_fakes':asyncio_sigint_fakes,'source_unchanged':before==after,'started_at':started,'ended_at':time.time(),'scope':'fake control flow/source contracts; no service/model/GPU','qualified':False}
 save(OUT/'result.json',row);print(json.dumps(row));return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
