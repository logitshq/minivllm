"""Small source-only closure check, no device or model payload imports."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path('/Users/ryanli/code/minivllm')
OUT=ROOT/'.artifacts/m5-ultra-256gb/gdn-graph-combined-formal-source-seal-v1'
assert sys.flags.isolated==1 and sys.dont_write_bytecode
denied=[]
def guard(event,args):
    if event in ('subprocess.Popen','os.system','os.kill','os.killpg','os.posix_spawn') or event.startswith('socket.'):
        denied.append(event);raise AssertionError(event)
    if event=='import' and args[0].split('.')[0] in ('mlx','mlx_lm','mlx_vlm','torch','numpy','tutorial_code'):
        denied.append(args[0]);raise AssertionError(args[0])
sys.addaudithook(guard);sys.path.insert(0,str(ROOT))
from bench.m5_ultra_256gb.gdn_graph_combined_formal import formal as m
pins=m.source_pins()
result=dict(schema='GDN-graph-combined-formal-source-closure-v1',status='PASS',source_sha256=m.sha(m.__file__),source_pins=pins,denied=denied,
    actual_http_prerequisites_available=False,device_run=False,performance_qualified=False)
with (OUT/'source-closure.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
with (OUT/'check.py').open('xb') as f:f.write(Path(__file__).read_bytes())
with (OUT/'command.json').open('x') as f:json.dump([sys.executable,'-I','-B',str(Path(__file__))],f);f.write('\n')
print(json.dumps(dict(status='PASS',sources=len(pins),source_sha256=result['source_sha256'],denied=denied)))
