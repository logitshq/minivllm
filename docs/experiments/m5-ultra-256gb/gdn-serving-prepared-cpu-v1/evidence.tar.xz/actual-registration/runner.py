"""Guarded actual GDN37 CPU registration, only with explicit --run.

Requires source-matching focused CPU PASS and actual closed canary evidence.
The inherited owner preparation may read/hash its real runtime/model files;
this is not a device run. Subprocesses, network, signals and backend imports
are denied. No service preparation or execution is performed. Root separately
uses commands.json to prepare the service read-only, seal, commit and execute.
"""
import argparse
import contextlib
import datetime
import hashlib
import importlib.abc
import importlib.util
import json
from pathlib import Path
import sys
import traceback

R=Path('/Users/ryanli/code/minivllm');B=R/'bench/m5_ultra_256gb';A=R/'.artifacts/m5-ultra-256gb'
HERE=B/'gdn_prework_unbound';SOURCE=HERE/'register_serving.py'
DEFAULT_OUT=A/'gdn-prework-serving-v1-registration'
FORBIDDEN={'mlx','omlx','mlx_lm','mlx_vlm','torch','numpy','tutorial_code','monolith'}
CPU_RUNNER=Path('/tmp/run-gdn-serving-prepared-cpu-v2.py').resolve()
CPU_RUNNER_SHA='d733ad168595e6eb81510533fa8cf7f8125ddf046422e30994dcca23e945e3e6'
FIRST= A/'gdn-serving-prepared-cpu-v1/result.json'
FIRST_SHA='6e4d82a2363e2f9331ba6cb46aa8460ee1972e1d79b0646b8805b17677a3bba5'
SUITES={'bench.m5_ultra_256gb.gdn_prework_unbound.test_serving_cpu':12,
        'bench.m5_ultra_256gb.gdn_prework_unbound.test_audit_serving_cpu':12,
        'bench.m5_ultra_256gb.gdn_prework_unbound.test_execute_serving_cpu':16}

def need(ok,message):
    if not ok:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')

def run(args):
    out=args.out.resolve();need(out.parent==A and not out.exists(),'fresh registration evidence directory')
    need(args.cpu_receipt is not None and args.cpu_receipt.is_absolute(),'explicit closed CPU receipt')
    out.mkdir();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
    record=dict(schema='GDN-prework-serving-guarded-registration-v2',status='RUNNING',started_at=now(),
        argv=[sys.executable,*sys.argv],gpu_executed=False,service_changed=False,
        numerical_qualified=False,http_qualified=False,performance_qualified=False,
        denied_operations=[],source_before={},source_after={})
    guard=None
    def deny(kind,args):
        record['denied_operations'].append(dict(kind=kind,detail=str(args)))
        raise RuntimeError('forbidden registration operation: '+kind)
    def hook(event,args):
        if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','os.exec',
                     'os.spawn','os.kill','os.killpg','socket.connect','socket.bind'):
            deny(event,args)
    class Imports(importlib.abc.MetaPathFinder):
        def find_spec(self,fullname,path=None,target=None):
            if fullname.split('.')[0] in FORBIDDEN:deny('backend import',fullname)
            return None
    save(out/'result.json',record)
    try:
        cpu=read(args.cpu_receipt);(out/'cpu-result.json').write_bytes(args.cpu_receipt.read_bytes())
        need(cpu['schema']=='GDN-prework-serving-prepared-cpu-v2' and cpu['status']=='PASS'
             and cpu['tests']==40 and cpu['failures']==cpu['errors']==cpu['skipped']==0
             and cpu['source_unchanged'] is True and cpu['denied_operations']==[]
             and cpu['forbidden_modules_loaded']==[],'complete guarded 40-test CPU PASS required')
        need({r['module']:r['expected_tests'] for r in cpu['suites']}==SUITES
             and all(r['expected_tests']==r['discovered_tests'] for r in cpu['suites']), 'exact full modules')
        need(sha(CPU_RUNNER)==CPU_RUNNER_SHA==cpu['source_before'][str(CPU_RUNNER)]['sha256']
             ==cpu['source_after'][str(CPU_RUNNER)]['sha256']
             and sha(args.cpu_receipt.parent/'runner.py')==CPU_RUNNER_SHA,
             'exact reviewed v2 CPU guard and its retained source')
        need(cpu['allowed_cpu_imports_unchanged'] is True
             and set(cpu['allowed_cpu_modules_loaded'])=={'tutorial_code','tutorial_code.miniengine',
               'tutorial_code.miniengine.engine','tutorial_code.miniengine.engine.request',
               'tutorial_code.miniengine.engine.scheduler','tutorial_code.miniengine.sampling_params'},
             'only the six pinned pure CPU imports were admitted')
        need(sha(FIRST)==FIRST_SHA and cpu['previous_attempt']==dict(path=str(FIRST),sha256=FIRST_SHA,status='FAIL',tests=0)
             and sha(args.cpu_receipt.parent/'first-attempt-result.json')==FIRST_SHA,
             'first rejected attempt remains exact and retained')
        record['previous_attempt']=cpu['previous_attempt']
        record['cpu_guard']=dict(path=str(CPU_RUNNER),sha256=CPU_RUNNER_SHA)
        record['cpu_receipt']=dict(path=str(args.cpu_receipt),sha256=sha(args.cpu_receipt))
        guard=Imports();sys.meta_path.insert(0,guard);sys.addaudithook(hook)
        spec=importlib.util.spec_from_file_location('_guarded_gdn_serving_registration',SOURCE)
        reg=importlib.util.module_from_spec(spec);spec.loader.exec_module(reg)
        paths={B/name for name in reg.FIXED}
        paths.update(HERE/name for name in ('register_serving.py','execute_serving.py','test_execute_serving_cpu.py',
                                          'test_serving_cpu.py','test_audit_serving_cpu.py'))
        for path in sorted(paths):
            digest=sha(path)
            need(cpu['source_before'][str(path)]['sha256']==cpu['source_after'][str(path)]['sha256']==digest,
                 'CPU receipt source changed: '+str(path))
            raw=path.read_bytes();record['source_before'][str(path)]=dict(sha256=digest,bytes=len(raw))
            dest=out/'frozen-source'/str(path).lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
        save(out/'result.json',record)
        with (out/'stdout.txt').open('x') as stdout,(out/'stderr.txt').open('x') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
            reg.prepare()
        preparation=read(reg.P/'preparation.json');commands=read(reg.P/'commands.json')
        need(preparation['status']=='CPU_PREPARED' and preparation['service_prepared'] is False
             and preparation['expected_total_requests']==37,'actual CPU-only registration complete')
        record.update(status='PASS',owner_plan_sha256=preparation['owner_plan_sha256'],
            child_plan_sha256=preparation['child_plan_sha256'],preparation=dict(path=str(reg.P/'preparation.json'),sha256=sha(reg.P/'preparation.json')),
            commands=commands,service_prepared=False,scope='Original inherited CPU preflight only; no process or service operation.')
        for name in ('preparation.json','commands.json','child-plan.json','owner-plan.json'):
            (out/name).write_bytes((reg.P/name).read_bytes())
    except BaseException as exc:
        record.update(status='FAIL',error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc()))
    finally:
        if guard in sys.meta_path:sys.meta_path.remove(guard)
        for path in record['source_before']:
            try:record['source_after'][path]=dict(sha256=sha(path),bytes=Path(path).stat().st_size)
            except BaseException as exc:record['source_after'][path]=dict(error=str(exc))
        record['source_unchanged']=bool(record['source_before']) and record['source_before']==record['source_after']
        record['forbidden_modules_loaded']=sorted(n for n in sys.modules if n.split('.')[0] in FORBIDDEN)
        if not record['source_unchanged'] or record['denied_operations'] or record['forbidden_modules_loaded']:record['status']='FAIL'
        record['ended_at']=now();save(out/'result.json',record)
        files={str(p.relative_to(out)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(out.rglob('*')) if p.is_file()}
        save(out/'artifact-manifest.json',dict(schema='cpu-registration-artifact-manifest-v1',files=files))
    print(json.dumps({k:record.get(k) for k in ('status','owner_plan_sha256','child_plan_sha256','error')}))
    return int(record['status']!='PASS')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',action='store_true')
    p.add_argument('--cpu-receipt',type=Path);p.add_argument('--out',type=Path,default=DEFAULT_OUT);args=p.parse_args()
    if not args.run:
        print('DESCRIPTION_ONLY: --run --cpu-receipt ABS_RESULT prepares original CPU preflight; no services/device.');return 0
    return run(args)

if __name__=='__main__':raise SystemExit(main())
