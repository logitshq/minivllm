"""Offline packaging only, after the owned experiment and recovery terminate."""
from pathlib import Path
import hashlib,json,tarfile,time
R=Path('/Users/ryanli/code/minivllm')
A=R/'.artifacts/m5-ultra-256gb'
D=R/'docs/experiments/m5-ultra-256gb/E028-identity-refill-model-v1'
roots={k:A/('identity-refill-model-v1-'+v) for k,v in [('owner','owner'),('journal','cold-journal'),('execution','execution')]}
def read(p):return json.loads(p.read_text())
def digest(stream):
 h=hashlib.sha256()
 while block:=stream.read(1<<20):h.update(block)
 return h.hexdigest()
assert read(roots['execution']/'final.json')['journal_state']=='RESTORED'
assert read(roots['owner']/'release.json')['waited_reaped'] is True
assert read(roots['journal']/'load-worker/release.json')['waited_reaped'] is True
D.mkdir(exist_ok=True,parents=True)
archive=D/'raw-evidence.tar.xz'
assert not archive.exists() and not (D/'manifest.json').exists()
files={}
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():
   with p.open('rb') as f:sha=digest(f)
   files[prefix+'/'+str(p.relative_to(root))]={'path':p,'bytes':p.stat().st_size,'sha256':sha}
print('hashed',len(files),'members',sum(v['bytes'] for v in files.values()),'bytes',flush=True)
with tarfile.open(archive,'w:xz',preset=3) as tar:
 for name,v in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=v['bytes'];info.mode=0o644;info.mtime=0
  with v['path'].open('rb') as f:tar.addfile(info,f)
print('archive-written',archive.stat().st_size,flush=True)
seen=set()
with tarfile.open(archive,'r:xz') as tar:
 for member in tar:
  assert member.isfile() and member.name in files and member.name not in seen
  with tar.extractfile(member) as f:sha=digest(f)
  v=files[member.name];assert (member.size,sha)==(v['bytes'],v['sha256']),member.name
  seen.add(member.name)
assert seen==set(files)
for v in files.values():
 with v['path'].open('rb') as f:assert digest(f)==v['sha256'],'source changed during archive'
with archive.open('rb') as f:archive_sha=digest(f)
manifest={'schema':'E028-model-v1-complete-evidence-archive-v1','archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':archive_sha,'members':{k:{x:y for x,y in v.items() if x!='path'} for k,v in sorted(files.items())},'all_members_rehashed':True,'sources_rechecked_after_archive':True,'scope':'Complete frozen experiment, recovery and execution receipts. Instrumented numerical run; not HTTP/performance.'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('verified',len(seen),'members',archive_sha,flush=True)
