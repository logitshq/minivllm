from pathlib import Path
import datetime, hashlib, json, subprocess, time
R=Path('/Users/ryanli/code/minivllm')
D=Path(__file__).resolve().parent
J=R/'.artifacts/m5-ultra-256gb/identity-refill-model-v1-cold-journal'
O=R/'.artifacts/m5-ultra-256gb/identity-refill-model-v1-owner'
PY=str(R/'.venv/bin/python')
C=R/'bench/m5_ultra_256gb/omlx_cold_restart/controller_v2.py'
A=['--journal',str(J),'--approved-contract','cold-restart-persisted-visible-v1','--plan-sha256','e96a4a4d5be6f6a69d597387bbc566eadedae81065bfa879445352d986515cb8']
def save(name,data):
    (D/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name,args):
    record={'phase':name,'argv':args,'start':now(),'started_monotonic':time.monotonic()}
    save(name+'-command.json',record)
    print(name+' START '+record['start'],flush=True)
    with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
        result=subprocess.run(args,cwd=R,stdout=out,stderr=err,check=False)
    record.update(returncode=result.returncode,end=now(),elapsed_seconds=time.monotonic()-record['started_monotonic'])
    save(name+'-command.json',record)
    print(name+' END rc='+str(result.returncode)+' '+record['end'],flush=True)
    return result.returncode
raw=(J/'journal.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='8408a8e2d6c486e42c6e7732d92366d30592f9d850828056bc6bc848fe03eacb'
assert json.loads(raw)['state']=='PREPARED' and not O.exists()
(D/'prepared-journal.json').write_bytes(raw)
save('authorization.json',{'received':now(),'source':'human user reply in current thread','answer':'允许停止、实验后恢复','contract':'cold-restart-persisted-visible-v1','scope':'prepared cold stop, E028 model v1, then recovery of original persisted-visible MTP/resident PLE model'})
try:
    rc=run('stop',[PY,'-I','-B',str(C),'stop',*A])
    if rc==0 and json.loads((J/'journal.json').read_text())['state']=='STOPPED':
        run('model-owner',[PY,'-I','-B',str(R/'bench/m5_ultra_256gb/identity_refill/model_owner.py'),'--plan',str(R/'bench/m5_ultra_256gb/identity_refill/prereg-model-v1/owner-plan.json'),'--plan-sha256','02a2cc98d068d037c6ddd5cda24fe2c5be13152013b919b5a94ddcdfdd0290f2','--out',str(O)])
finally:
    state=json.loads((J/'journal.json').read_text())['state']
    if state!='PREPARED':
        args=[PY,'-I','-B',str(C),'recover',*A,'--watchdog-seconds','3600']
        if not O.exists():args.append('--no-experiment')
        run('recover',args)
    save('final.json',{'time':now(),'journal_state':json.loads((J/'journal.json').read_text())['state'],'owner_directory_exists':O.exists()})
