import contextlib, hashlib, importlib, importlib.abc, json, pathlib, shutil, subprocess, sys, time, traceback, unittest
ROOT=pathlib.Path('/Users/ryanli/code/minivllm');OUT=ROOT/'.artifacts/m5-ultra-256gb/concurrency-config-owner-cpu-v1'
OUT.mkdir(parents=True,exist_ok=False)
class Block(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in ('mlx','numpy','torch'):raise RuntimeError('CPU-only import guard: '+fullname)
sys.meta_path.insert(0,Block());sys.path.insert(0,str(ROOT))
allow_metadata=False
metadata_code="import sys,json;sys.path.insert(0,sys.argv[1]);import resources_v2 as r;print(json.dumps(r.snapshot(sys.argv[2],None if sys.argv[3]=='None' else int(sys.argv[3]),suspended_pids=(int(sys.argv[4]),))))"
metadata=[str(ROOT/'.venv/bin/python'),'-I','-B','-c',metadata_code,str(ROOT/'bench/m5_ultra_256gb'),'cpu-read-only-metadata',str(__import__('os').getpid()),'52818']
def guard(event,args):
    if event=='subprocess.Popen':
        if not allow_metadata or list(args[1])!=metadata:raise RuntimeError('CPU-only subprocess guard')
    if event in ('os.system','os.fork','os.kill','socket.connect','socket.bind'):raise RuntimeError('CPU-only operation guard: '+event)
sys.addaudithook(guard)
files=[ROOT/'bench/m5_ultra_256gb/concurrency_config_v1'/name for name in ('trial.py','runner.py','execute.py','test_owner_cpu.py')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
before={str(p):sha(p) for p in files};(OUT/'sources').mkdir()
for p in files:shutil.copyfile(p,OUT/'sources'/p.name)
shutil.copyfile(__file__,OUT/'runner.py')
write(OUT/'command.json',{'argv':[sys.executable,'-I','-B',__file__],'source_sha256_before':before,'CPU_only':True})
started=time.monotonic();status='FAIL';detail={}
with (OUT/'stdout.txt').open('w') as stdout,(OUT/'stderr.txt').open('w') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
    try:
        mod=importlib.import_module('bench.m5_ultra_256gb.concurrency_config_v1.test_owner_cpu')
        result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(mod))
        detail=dict(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors))
        if result.wasSuccessful():
            allow_metadata=True;began=time.monotonic()
            probe=subprocess.run(metadata,capture_output=True,text=True,timeout=5)
            elapsed=time.monotonic()-began
            write(OUT/'metadata-command.json',dict(argv=metadata,timeout=5,returncode=probe.returncode,elapsed_s=elapsed))
            (OUT/'metadata.stdout').write_text(probe.stdout);(OUT/'metadata.stderr').write_text(probe.stderr)
            assert probe.returncode==0 and not probe.stderr.strip(),'read-only metadata command failed'
            observed=json.loads(probe.stdout);write(OUT/'metadata.json',observed)
            assert observed['native_process_inventory_ok'] and observed['power_metadata']['source']=='AC Power'
            assert observed['processinfo_thermal_metadata']['code'] in (0,1)
            detail['actual_read_only_metadata_seconds']=elapsed;detail['metadata_is_not_service_admission']=True;status='PASS'
    except BaseException as exc:detail['exception']=repr(exc);traceback.print_exc()
after={str(p):sha(p) for p in files}
if before!=after:status='FAIL';detail['source_changed']=True
write(OUT/'result.json',dict(status=status,elapsed_s=time.monotonic()-started,source_sha256_after=after,**detail))
print(json.dumps(dict(out=str(OUT),status=status,**detail)));sys.exit(0 if status=='PASS' else 1)
