import builtins, contextlib, hashlib, importlib.util, io, json, pathlib, shutil, socket, subprocess, sys, time, unittest
from unittest.mock import patch
ROOT=pathlib.Path('/Users/ryanli/code/minivllm')
SOURCE=ROOT/'bench/m5_ultra_256gb/concurrency_config_v1/audit.py'
OUT=ROOT/'.artifacts/m5-ultra-256gb/concurrency-config-audit-cpu-v1'
OUT.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
before=sha(SOURCE);shutil.copyfile(SOURCE,OUT/'audit.py');shutil.copyfile(__file__,OUT/'tests.py')
(OUT/'command.json').write_text(json.dumps(dict(argv=[sys.executable,'-I','-B',str(pathlib.Path(__file__).resolve())],source=str(SOURCE),sha256=before,scope='CPU pure checks only; no actual screen audit or backend'),indent=2)+'\n')
forbidden=[];original_import=builtins.__import__
def guarded_import(name,*args,**kwargs):
    if name.split('.')[0] in ('mlx','mlx_lm','miniengine','torch','numpy','requests','httpx'):
        forbidden.append('import:'+name);raise AssertionError('forbidden backend/network import')
    return original_import(name,*args,**kwargs)
def denied(*args,**kwargs):
    forbidden.append('process/socket');raise AssertionError('forbidden process or socket operation')
class Tests(unittest.TestCase):
    def test_exact_full_ids_and_first_mismatch(self):
        a={'f1':[1,2,3,4],'f2':[8,9]}
        self.assertEqual(m.compare_tokens(a,a),[])
        bad=m.compare_tokens(a,{'f1':[1,2,7,4],'f2':[8,9]})
        self.assertEqual(bad,[dict(fixture_id='f1',expected_length=4,actual_length=4,first_index=2,expected_id=3,actual_id=7)])
    def test_truncation_and_missing_fixture_rejected(self):
        self.assertEqual(m.compare_tokens({'f':[1,2,3]},{'f':[1,2]})[0]['first_index'],2)
        with self.assertRaisesRegex(ValueError,'same fixture set'):m.compare_tokens({'f':[1]}, {})
    def test_request_count_rejects_seven_and_nine(self):
        spec=dict(jobs={'formal':[{} for _ in range(8)]},fixtures=[dict(fixture_id=str(i)) for i in range(8)])
        for n in (7,9):
            with self.subTest(n=n),self.assertRaisesRegex(ValueError,'exact eight requests'):
                m.group_check(dict(requests=[None]*n),spec,'formal',None,None)
    def points(self):
        return {n:dict(aggregate_output_tok_s=100.,e2e_p50_s=100.) for n in m.LABELS}
    def test_stable_both_bookends_and_both_metrics_required(self):
        p=self.points();t=dict.fromkeys(m.LABELS,True)
        p['c1-end50']['aggregate_output_tok_s']=101.
        p['c1-mb200']=dict(aggregate_output_tok_s=106.,e2e_p50_s=94.)
        self.assertEqual(m.rank(p,t)['1']['ranked_for_confirmation'],['c1-mb200'])
        self.assertEqual(m.rank(p,t)['8']['ranked_for_confirmation'],[])
    def test_drift_rejects_even_fast_candidate(self):
        p=self.points();t=dict.fromkeys(m.LABELS,True)
        p['c1-end50']['aggregate_output_tok_s']=103.
        p['c1-mb200']=dict(aggregate_output_tok_s=120.,e2e_p50_s=80.)
        self.assertFalse(m.rank(p,t)['1']['bookends_stable'])
        self.assertEqual(m.rank(p,t)['1']['ranked_for_confirmation'],[])
    def test_gain_against_only_one_anchor_rejected(self):
        p=self.points();t=dict.fromkeys(m.LABELS,True)
        p['c1-end50']['aggregate_output_tok_s']=101.
        p['c1-mb200']=dict(aggregate_output_tok_s=103.,e2e_p50_s=94.)
        self.assertEqual(m.rank(p,t)['1']['ranked_for_confirmation'],[])
    def test_latency_regression_and_token_mismatch_disqualify(self):
        p=self.points();t=dict.fromkeys(m.LABELS,True)
        p['c8-mb800']=dict(aggregate_output_tok_s=120.,e2e_p50_s=101.)
        self.assertEqual(m.rank(p,t)['8']['ranked_for_confirmation'],[])
        p['c8-mb800']['e2e_p50_s']=80.;t['c8-mb800']=False
        self.assertEqual(m.rank(p,t)['8']['ranked_for_confirmation'],[])
    def test_default_inert_description(self):
        out=io.StringIO()
        with contextlib.redirect_stdout(out):self.assertEqual(m.main([]),0)
        self.assertIs(json.loads(out.getvalue())['performance_qualified'],False)
started=time.time()
with (OUT/'stdout.txt').open('x') as stdout,(OUT/'stderr.txt').open('x') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr),patch('builtins.__import__',guarded_import),patch.object(subprocess,'Popen',denied),patch.object(socket,'socket',denied),patch.object(socket,'create_connection',denied):
    spec=importlib.util.spec_from_file_location('e045_independent_audit_cpu',SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    result=unittest.TextTestRunner(verbosity=2,stream=stderr).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
code=0 if result.wasSuccessful() and not forbidden and sha(SOURCE)==before else 1
receipt=dict(status='PASS' if code==0 else 'FAIL',tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),returncode=code,forbidden=forbidden,source_before=before,source_after=sha(SOURCE),elapsed_seconds=time.time()-started)
(OUT/'result.json').write_text(json.dumps(receipt,indent=2)+'\n');(OUT/'returncode.txt').write_text(str(code)+'\n')
print(json.dumps(receipt));raise SystemExit(code)
