import contextlib, hashlib, importlib, importlib.abc, io, json, pathlib, shutil, sys, time, traceback, unittest
ROOT=pathlib.Path('/Users/ryanli/code/minivllm')
OUT=ROOT/'.artifacts/m5-ultra-256gb/concurrency-config-cpu-v2'
OUT.mkdir(parents=True,exist_ok=False)
class Block(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in ('mlx','numpy','torch'): raise RuntimeError('CPU-only import guard: '+fullname)
sys.meta_path.insert(0,Block())
def guard(event,args):
    if event in ('subprocess.Popen','os.system','os.fork','os.kill','socket.connect','socket.bind'): raise RuntimeError('CPU-only operation guard: '+event)
sys.addaudithook(guard)
sys.path.insert(0,str(ROOT))
files=[ROOT/'bench/m5_ultra_256gb/concurrency_config_v1'/name for name in ('trial.py','test_trial_cpu.py')]
files += [ROOT/'bench/m5_ultra_256gb'/name for name in ('pareto_realistic/native_formal.py','gdn_graph_combined_formal/formal.py')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
before={str(p):sha(p) for p in files}
(OUT/'sources').mkdir()
for p in files:shutil.copyfile(p,OUT/'sources'/(p.parent.name+'-'+p.name))
shutil.copyfile(__file__,OUT/'runner.py')
write(OUT/'command.json',{'argv':[sys.executable,'-I','-B',__file__],'started_at':time.time(),'source_sha256_before':before,'CPU_only':True})
started=time.monotonic(); status='FAIL'; detail={}
with (OUT/'stdout.txt').open('w') as stdout,(OUT/'stderr.txt').open('w') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
    try:
        mod=importlib.import_module('bench.m5_ultra_256gb.concurrency_config_v1.test_trial_cpu')
        result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(mod))
        detail={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors)}
        if result.wasSuccessful():
            trial=importlib.import_module('bench.m5_ultra_256gb.concurrency_config_v1.trial')
            prepared=[]
            for C,arm in ((1,'on'),(8,'off')):
                p=ROOT/f'.artifacts/m5-ultra-256gb/gdn-graph-combined-formal-prepare-v1/specs/r1-c{C}-{arm}.json'
                spec=trial.prepare({'path':str(p),'sha256':sha(p)},200,f'cpu-actual-c{C}-mb200')
                trial.validate(spec);write(OUT/f'actual-c{C}-derived-spec.json',spec)
                prepared.append({'concurrency':C,'mb':200,'warm':len(spec['jobs']['warm']),'screen':len(spec['jobs']['formal']),'validated':True})
            detail['actual_E033_preparation']=prepared;status='PASS'
    except BaseException as e:detail['exception']=repr(e);traceback.print_exc()
after={str(p):sha(p) for p in files}
if before!=after:status='FAIL';detail['source_changed']=True
write(OUT/'result.json',{'status':status,'elapsed_s':time.monotonic()-started,'source_sha256_after':after,**detail})
print(json.dumps({'out':str(OUT),'status':status,**detail}))
sys.exit(0 if status=='PASS' else 1)
