import hashlib,json,subprocess,time
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';G=A/'glm-stacked-registration-v1';E=A/'glm-stacked-execution-v1';O=A/'glm-stacked-analysis-v1'
def read(p):return json.loads(p.read_bytes())
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
final=read(E/'final.json');assert final['journal_state']=='RESTORED'
commands=read(G/'commands.json');rows=[]
receipt=O/'audit-execution-v1.json';assert not receipt.exists()
for key in ('restoration_audit','closed_audit'):
 command=commands[key];target=Path(command[-1]);assert target.parent==O and not target.exists()
 started=time.time()
 with (O/(key+'.stdout')).open('x') as out,(O/(key+'.stderr')).open('x') as err:
  p=subprocess.run(command,cwd=R,stdout=out,stderr=err)
 rows.append(dict(name=key,command=command,started_at=started,ended_at=time.time(),returncode=p.returncode,output=str(target),output_sha256=sha(target) if target.exists() else None,status=read(target).get('status') if target.exists() else 'MISSING'))
write(receipt,dict(schema='GLM-stacked-saved-audit-execution-v1',driver_final_sha256=sha(E/'final.json'),commands_sha256=sha(G/'commands.json'),audits=rows,scope='Actual saved offline audit commands and exit codes; no service or GPU action.'))
print(json.dumps(rows));raise SystemExit(0 if all(x['returncode']==0 for x in rows) else 1)
