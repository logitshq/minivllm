"""Local M5 Ultra 80-core support using shared Apple10 kernels."""
