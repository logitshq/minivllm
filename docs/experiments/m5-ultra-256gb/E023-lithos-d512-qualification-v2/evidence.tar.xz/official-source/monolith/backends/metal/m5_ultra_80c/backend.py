from ..base import MetalBackend


class Backend(MetalBackend):
    """80-core native backend; no borrowed Max fusion or measured cost tables."""
    id = "m5_ultra_80c"
