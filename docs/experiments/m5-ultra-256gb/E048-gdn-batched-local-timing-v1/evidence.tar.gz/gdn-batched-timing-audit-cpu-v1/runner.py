from pathlib import Path
import hashlib,json,subprocess,time
R=Path('/Users/ryanli/code/minivllm'); A=R/'.artifacts/m5-ultra-256gb'; P=R/'bench/m5_ultra_256gb/gdn_batched_timing_v1'; PY=R/'.venv/bin/python'
code=r'''
import importlib.abc,json,os,socket,subprocess,sys,unittest
from pathlib import Path
forbidden=[]
class NoBackend(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in ('mlx','numpy','torch','jax','tensorflow','safetensors'):
            forbidden.append(fullname);raise AssertionError('forbidden backend '+fullname)
sys.meta_path.insert(0,NoBackend())
def deny(*args,**kw): forbidden.append('external operation');raise AssertionError('forbidden external operation')
subprocess.run=subprocess.Popen=subprocess.call=subprocess.check_call=subprocess.check_output=deny
os.kill=os.system=socket.socket=socket.create_connection=deny
sys.path.insert(0,'/Users/ryanli/code/minivllm')
suite=unittest.defaultTestLoader.loadTestsFromName('bench.m5_ultra_256gb.gdn_batched_timing_v1.test_audit_cpu')
result=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps(dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),forbidden=forbidden)))
raise SystemExit(0 if result.wasSuccessful() and result.testsRun==5 and not forbidden else 1)
'''
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
cpu=A/'gdn-batched-timing-audit-cpu-v1';cpu.mkdir();(cpu/'sources').mkdir()
sources=[P/'audit.py',P/'test_audit_cpu.py',R/'bench/m5_ultra_256gb/gdn_prework_batched/audit.py',R/'bench/m5_ultra_256gb/gdn_prework_unbound/audit.py']
before={str(p):sha(p) for p in sources};write(cpu/'sources-before.json',before)
for i,p in enumerate(sources):(cpu/'sources'/f'{i}-{p.name}').write_bytes(p.read_bytes())
(cpu/'runner.py').write_bytes(Path(__file__).read_bytes());cmd=[str(PY),'-I','-B','-c',code];write(cpu/'command.json',cmd)
start=time.monotonic()
with (cpu/'stdout.txt').open('x') as out,(cpu/'stderr.txt').open('x') as err:value=subprocess.run(cmd,cwd=R,stdout=out,stderr=err)
after={str(p):sha(p) for p in sources};write(cpu/'sources-after.json',after)
write(cpu/'result.json',dict(returncode=value.returncode,elapsed_s=time.monotonic()-start,sources_unchanged=before==after))
print(json.dumps(dict(stage='CPU',returncode=value.returncode,sources_unchanged=before==after)),flush=True)
if value.returncode or before!=after:raise SystemExit(1)
execution=A/'gdn-batched-timing-audit-execution-v1';execution.mkdir();(execution/'runner.py').write_bytes(Path(__file__).read_bytes())
output=A/'gdn-batched-timing-v1-independent.json'
cmd=[str(PY),'-I','-B',str(P/'audit.py'),'--child',str(A/'gdn-batched-timing-v1-numerical'),'--parent-plan',str(P/'prereg-v1/plan.json'),'--parent-plan-sha256','8c1fdfe2bcaa5d45e49b87120650949b879eef616ec1aaf881e49a00a381386a','--out',str(output)]
write(execution/'command.json',cmd);write(execution/'sources-before.json',before);start=time.monotonic()
with (execution/'stdout.txt').open('x') as out,(execution/'stderr.txt').open('x') as err:value=subprocess.run(cmd,cwd=R,stdout=out,stderr=err)
after={str(p):sha(p) for p in sources};write(execution/'sources-after.json',after)
write(execution/'result.json',dict(returncode=value.returncode,elapsed_s=time.monotonic()-start,sources_unchanged=before==after,output=str(output),output_sha256=sha(output) if output.exists() else None))
print(json.dumps(dict(stage='actual-audit',returncode=value.returncode,sources_unchanged=before==after,output=str(output))),flush=True)
raise SystemExit(value.returncode or int(before!=after))
