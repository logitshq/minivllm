import importlib.abc,importlib.util,json,sys,unittest
from pathlib import Path
D=Path(__file__).resolve().parent
forbidden=[]
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'mlx','mlx_lm','torch','miniengine','tutorial_code','requests','httpx'}:
   forbidden.append('import:'+fullname);raise RuntimeError('forbidden backend/network import:'+fullname)
sys.meta_path.insert(0,Block())
def guard(event,args):
 if event in {'subprocess.Popen','os.system','os.posix_spawn','os.kill','socket.connect','socket.bind'}:
  forbidden.append(event);raise RuntimeError('forbidden real operation:'+event)
sys.addaudithook(guard)
p=Path('/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/gdn_batched_timing_v1/test_owner_cpu.py')
spec=importlib.util.spec_from_file_location('_e048_owner_tests',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
result=unittest.TextTestRunner(verbosity=2).run(suite)
value=dict(status='PASS_CPU_ONLY' if result.wasSuccessful() and not forbidden else 'FAIL',tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),forbidden_operations=forbidden)
with (D/'test-result.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value));raise SystemExit(0 if value['status']=='PASS_CPU_ONLY' else 1)
