"""Run fixed offline GDN37 serving audits only after actual driver recovery has closed.

Default description only. --run exclusively creates the analysis directory,
retains every command/output/failure, and audits restoration before opening any
numerical or resource evidence. No service, model, MLX, process probe or GPU
operation is implemented. The only subprocesses are three source-pinned
stdlib-only offline auditors. Never reruns or overwrites an audit attempt.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time
import traceback

R = Path('/Users/ryanli/code/minivllm')
B = R / 'bench/m5_ultra_256gb'
A = R / '.artifacts/m5-ultra-256gb'
P = B / 'gdn_prework_unbound/prereg-serving-v1'
OWNER = A / 'gdn-prework-serving-v1-owner'
JOURNAL = A / 'gdn-prework-serving-v1-cold-journal'
EXECUTION = A / 'gdn-prework-serving-v1-execution'
OUT = A / 'gdn-prework-serving-v1-analysis'
PHASE = 'gdn-prework-serving'
CHILD = OWNER / 'phases' / PHASE / 'qualification'
PY = str(R / '.venv/bin/python')
NUMERIC = B / 'gdn_prework_unbound/audit_serving.py'
RESOURCE = B / 'resource_reparse.py'
RESTORE = B / 'cold_cycle_v3/audit_restore.py'
FIXED = {
    str(NUMERIC): '268cc336417a3d31dffc30c749701d132da610fbb41d9b0f4c85ad6adaa2f2bc',
    str(RESOURCE): '5948ccbf7baeb21d1e71d9e8f7169b1bd9f84e65eb492746aba86fe377806c23',
    str(RESTORE): '34d608b54ed5779b97e85a0463c17f8796876be731f6f0aafcbe804ffc7b15ca',
}


def need(ok, message):
    if not ok: raise ValueError(message)


def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_bytes())
def ref(path): return dict(path=str(path), sha256=sha(path), bytes=Path(path).stat().st_size)


def write(name, value):
    # One runner owns each record, allowing STARTED -> completed/error updates.
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def invoke(name, source, argv, output):
    record = dict(status='STARTED', argv=[PY, '-I', '-B', str(source), *argv, '--out', str(output)],
                  source=ref(source), started_at=now(), timeout_seconds=300)
    write(name + '-execution.json', record); start = time.monotonic()
    try:
        with (OUT / (name + '.stdout')).open('xb') as out, (OUT / (name + '.stderr')).open('xb') as err:
            result = subprocess.run(record['argv'], cwd=R, stdout=out, stderr=err, timeout=300, check=False)
        record.update(status='RETURNED', returncode=result.returncode)
    except BaseException as error:
        record.update(status='ERROR', error=dict(type=type(error).__name__, message=str(error),
                                                traceback=traceback.format_exc()))
    finally:
        record.update(ended_at=now(), elapsed_seconds=time.monotonic() - start)
        if output.is_file():
            record['output'] = ref(output)
            try: record['audit_status'] = read(output).get('status')
            except BaseException as error: record['output_error'] = dict(type=type(error).__name__, message=str(error))
        write(name + '-execution.json', record)
    return record


def run():
    need(not OUT.exists(), 'fresh analysis directory required; retain any earlier attempt')
    OUT.mkdir(exist_ok=False)
    (OUT / 'runner.py').write_bytes(Path(__file__).read_bytes())
    summary = dict(schema='GDN-prework-serving-closed-audits-v1', status='INCOMPLETE', started_at=now(),
        source_pins={}, inputs={}, jobs={}, execution_pass=False, restoration_qualified=False, same_schedule_qualified=False,
        resources_qualified=False, full_model_qualified=False, http_qualified=False, performance_qualified=False,
        scope='One closed original37 same-schedule serving run. Restoration, observed resources and full-state numerical receipts have independent gates; success tensor payloads are not re-evaluated offline.')
    write('execution-summary.json', summary)
    try:
        final = read(EXECUTION / 'final.json'); journal = read(JOURNAL / 'journal.json')
        need(final['journal_state'] == journal['state'] == 'RESTORED' and final['recovery_returncode'] == 0,
             'actual finally-recovery has not closed; no offline numerical/resource audit starts')
        receipt = read(P / 'receipt.json'); plan = read(P / 'owner-plan.json')
        need(receipt['schema'] == 'GDN-prework-serving-prereg-receipt-v1' and receipt['status'] == 'PREPARED'
             and sha(P / 'owner-plan.json') == receipt['owner_plan_sha256'], 'actual registered owner plan')
        need(plan['schema'] == 'cold-single-child-run-plan-v3' and plan['experiment']['phase'] == PHASE
             and plan['outputs'] == dict(journal=str(JOURNAL), out=str(OWNER))
             and plan['experiment']['plan'] == dict(path=str(P / 'child-plan.json'), sha256=receipt['child_plan_sha256'])
             and sha(P / 'child-plan.json') == receipt['child_plan_sha256'], 'fixed actual child/output binding')
        child_plan = read(P / 'child-plan.json')
        need(child_plan['schema'] == 'GDN-prework-serving-plan-v1' and child_plan['deadline_s'] == 1800,
             'original37 serving child contract')
        need(journal['owner_plan'] == dict(path=str(P / 'owner-plan.json'), sha256=receipt['owner_plan_sha256'])
             and journal['owner_directory'] == str(OWNER) and journal['lifecycle'] == plan['lifecycle'],
             'actual restored journal/owner/lifecycle binding')
        lifecycle = read(plan['lifecycle']['path'])
        need(sha(plan['lifecycle']['path']) == plan['lifecycle']['sha256']
             and lifecycle['sources']['audit_restore'] == dict(path=str(RESTORE), sha256=FIXED[str(RESTORE)]),
             'actual v3 restoration auditor')
        pins = dict(receipt['source_pins']); pins.update(FIXED)
        for name, digest in FIXED.items():
            need(name not in receipt['source_pins'] or receipt['source_pins'][name] == digest,
                 'offline auditor differs from registered source')
        pins[str(Path(__file__).resolve())] = sha(__file__)
        target = OUT / 'frozen-source'; target.mkdir()
        for name, digest in pins.items():
            path = Path(name); raw = path.read_bytes()
            need(path.suffix in ('.py', '.json', '.jsonl', '.md', '.metal', '.h')
                 and hashlib.sha256(raw).hexdigest() == digest, 'registered small source changed: ' + name)
            dest = target / name.lstrip('/'); dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open('xb') as stream: stream.write(raw)
        summary['source_pins'] = pins
        summary['owner_plan_sha256'] = receipt['owner_plan_sha256']
        summary['child_plan_sha256'] = receipt['child_plan_sha256']
        for name, path in (('driver-final.json', EXECUTION / 'final.json'),
                           ('restored-journal.json', JOURNAL / 'journal.json'),
                           ('registration-receipt.json', P / 'receipt.json')):
            summary['inputs'][name] = ref(path); (OUT / name).write_bytes(path.read_bytes())
        restore_path = OUT / 'restoration-audit.json'
        job = invoke('restoration', RESTORE, ['--journal', str(JOURNAL)], restore_path)
        summary['jobs']['restoration'] = job; write('execution-summary.json', summary)
        need(job.get('returncode') == 0 and job.get('audit_status') == 'PASS',
             'independent restoration audit failed; retain failure and reconcile original service')
        restore = read(restore_path)
        need(restore['qualified'] is True and restore['journal_sha256'] == sha(JOURNAL / 'journal.json')
             and restore['owner_plan_sha256'] == receipt['owner_plan_sha256'], 'independent restoration binding')
        summary['restoration_qualified'] = True
        # A stopped-but-never-started experiment is not synthesized into a run.
        if not OWNER.exists():
            summary['jobs'].update(resources=dict(status='NOT_RUN', reason='actual owner never created'),
                                   numerical=dict(status='NOT_RUN', reason='actual qualifier never started'))
        else:
            terminal = read(OWNER / 'complete.json')
            need(terminal['owner_plan_sha256'] == receipt['owner_plan_sha256']
                 and terminal['planned_trials'] == [PHASE], 'actual owner terminal binding')
            summary['inputs']['owner-complete.json'] = ref(OWNER / 'complete.json')
            summary['execution_pass'] = (final['stop_returncode'] == 0 and final['owner_returncode'] == 0
                and terminal['status'] == 'PASS' and terminal['child_returncode'] == 0
                and terminal['all_children_reaped'] is True)
            resources = invoke('resources', RESOURCE, ['--owner', str(OWNER)], OUT / 'resource-summary.json')
            summary['jobs']['resources'] = resources
            summary['resources_qualified'] = resources.get('returncode') == 0 and resources.get('audit_status') == 'PASS'
            if CHILD.exists():
                numeric = invoke('numerical', NUMERIC, ['--child', str(CHILD), '--plan-sha256', receipt['child_plan_sha256']],
                                 OUT / 'independent-numerical.json')
                summary['jobs']['numerical'] = numeric
                if numeric.get('returncode') == 0 and numeric.get('audit_status') == 'PASS':
                    value = read(OUT / 'independent-numerical.json')
                    need(value['schema'] == 'GDN-prework-serving-independent-v1'
                         and value['qualified'] is True and value['same_schedule_qualified'] is True
                         and value['audit_source_sha256'] == FIXED[str(NUMERIC)]
                         and value['plan_sha256'] == receipt['child_plan_sha256']
                         and value['http_qualified'] is False and value['performance_qualified'] is False,
                         'independent original37 numerical binding/scope')
                    summary['same_schedule_qualified'] = True
            else:
                summary['jobs']['numerical'] = dict(status='NOT_RUN', reason='no actual qualifier directory; no model evidence invented')
        summary['status'] = 'PASS' if summary['execution_pass'] and summary['same_schedule_qualified'] and summary['resources_qualified'] else 'FAIL'
    except BaseException as error:
        summary.update(status='FAIL', error=dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
    finally:
        if summary['source_pins']:
            summary['sources_unchanged'] = True
            for path, digest in summary['source_pins'].items():
                try: same = sha(path) == digest
                except BaseException as error:
                    summary.setdefault('source_recheck_errors', []).append(dict(path=path, error=str(error))); same = False
                summary['sources_unchanged'] = summary['sources_unchanged'] and same
            if not summary['sources_unchanged']: summary['status'] = 'FAIL'
        summary['ended_at'] = now(); write('execution-summary.json', summary)
        files = {str(p.relative_to(OUT)): dict(sha256=sha(p), bytes=p.stat().st_size)
                 for p in OUT.rglob('*') if p.is_file()}
        write('manifest.json', files)
    print(json.dumps({k: summary[k] for k in ('status', 'restoration_qualified', 'same_schedule_qualified', 'resources_qualified')}))
    return int(summary['status'] != 'PASS')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run: raise SystemExit(run())
    print('DESCRIPTION_ONLY: no audit launched; actual RESTORED cycle required.')
