"""One explicit guarded 16-test CPU attempt. Default inert; no service/model work."""
import argparse
import contextlib
import datetime
import hashlib
import importlib.abc
import json
import os
from pathlib import Path
import signal
import socket
import ssl
import subprocess
import sys
import time
import traceback
import unittest
from unittest.mock import patch

ROOT=Path('/Users/ryanli/code/minivllm')
BENCH=ROOT/'bench/m5_ultra_256gb'
NEW=BENCH/'glm_flash_cycle_v2';OLD=BENCH/'glm_flash_cycle'
OUT=ROOT/'.artifacts/m5-ultra-256gb/glm-cycle-v2-prepared-cpu-v1'
MODULE='bench.m5_ultra_256gb.glm_flash_cycle_v2.test_adapter_cpu'
FORBIDDEN={'mlx','omlx','mlx_lm','mlx_vlm','numpy','torch','tokenizers','minivllm','tutorial_code','monolith'}
SEALED={'/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash/load_probe.py': 'cd9df050384af83d92f0321d95f5bba70dca349defbedf0bb7d1d1e8b57385fc', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash/physical_guard.py': '908e0dc74812fd82b65c63a22e03ed8c5692e812bdbf3d6957e219aa52b14166', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/README.md': '7e200208dbc83aa08102d136b87bc088f72740764e9424c066189a029b9e799f', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/audit_closed.py': '0158be373f614c55ed03393320337b7cca4c1525360fd850f5081a5462694d48', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/audit_restore.py': '732c60870b9400d1d7b6bfb9c303bce19b9c92032bc06bc9db193b66ace3bf6d', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/controller.py': '98bc920d97b529c07f9af0a64213e47e73728b63caee2e867e496f1ac30bde88', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/execute.py': 'cbc28848a124c74fabd9aede971b57b8fb9162051031e9a720dde5f87029635a', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/owner.py': '37f47300c14d8da721d6c30fcc71f52325132bad3dc3ba902c1cc08af4326b40', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/prepare_inputs.py': 'da10a83b826150b88f44e1442423660b9e7edd990114e368fe2fea98032207fb', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/prepared-source-v1.json': 'fd86ae72adcae023b4595c1a4a416106a1761c611733d35dde98dc303d1e73ee', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/prepared-source-v2.json': '72f87c59a011dcb131989fa6765a3067bc041c6cb2cb3d61d77ea79e319ec37e', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/preregister.py': '7f937f709b0c6806a0dfca7606122e1178b2c495b4574665e7df1eea2862e842', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/test_audits_cpu.py': '6717572506b87c9c502763445f24f05e83d3c12e1478df2791bbd9d3c086832f', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/test_controller_cpu.py': '46ebe98250d7c21c83592a5f545319f2f9ba30770eb6356eca78c1e9b2748c36', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/test_execute_cpu.py': 'fc6a36bf99d48d17873c5ba58b57512e22030297900d5562d59c51dcbf5b2ad2', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/test_owner_cpu.py': 'e24d842f6a15c0c90bfb9adf59fdbae39b5fbc8613732746906e8367dee9116d', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle/test_preparation_cpu.py': '8798d44237059a4c5260cd5902826cdbb12211a59760cde8173289c30ed44452', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/README.md': '8e68037877aaf1ba5746e77a7f76294364b49084d73a707636acf52888e13c43', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/_reuse.py': 'fbf523c586629ce6e5e2030d629b00c9f1cd99dfec9edef6c35ac8e054468f97', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/audit_closed.py': '44a8598512271ec11aa646182f761d30f5f1956391b7b57cd418a64eb9cef904', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/audit_restore.py': 'de1674780f5d3de7cdcf0cd4d54c6b9136f086120bb827d7bcd2f25377084996', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/controller.py': 'bdb5afac1febec8be8b2e10d70b77bbbc150aac76416385ac0c89f5ce48c6579', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/execute.py': '2d2c9a5ba266a3491ee1704e224aad8f32618cb5c6f0c1a3848b241a0620376a', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/owner.py': 'f8e32b6532ed0d22b21b27ef83231ae7a1d7423a4269ea32b5e4aa20ff2a0657', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/prepare_inputs.py': '9f28d336f44346fb8310b69fc1d17cd6e2717b8c7ac1e0c218e72cf1caa2317c', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/preregister.py': 'b6eeeda7489028ef1d28db1cb1c291b66941b621c1c554c24ba30e49e41b610f', '/Users/ryanli/code/minivllm/bench/m5_ultra_256gb/glm_flash_cycle_v2/test_adapter_cpu.py': '5409ee2f3277a199b21a48ff9e69ca6570f028936ddd3f709a1a5399ddbe79b4'}

def sha(raw):return hashlib.sha256(raw).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def need(ok,message):
    if not ok:raise AssertionError(message)
def tree(folder):
    return sorted(str(p.resolve()) for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true')
    a=parser.parse_args(argv)
    if not a.run:print('DESCRIPTION_ONLY: 16 whole-module fake CPU tests, no backend/process/socket/signals/model payload.');return 0
    need(bool(SEALED) and not OUT.exists(),'sealed sources and fresh output required')
    OUT.mkdir();(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
    result=dict(schema='GLM-cycle-v2-prepared-cpu-v1',status='RUNNING',started_at=now(),
        argv=[sys.executable,'-I','-B',str(Path(__file__).resolve()),*sys.argv[1:]],
        module=MODULE,expected_tests=16,tests=0,failures=0,errors=0,skipped=0,
        source_before={},source_after={},tree_before={},tree_after={},denied_operations=[],
        original_source_seals=SEALED,device_executed=False,service_actions=False,
        performance_qualified=False,model_loaded=False,
        scope='Actual fake CPU adapter tests only; no registration, preparation, service, model, numerical or performance qualification.')
    start=time.monotonic();finder=None
    def record_source(path):
        path=Path(path).resolve();key=str(path)
        if key in result['source_before']:return
        need(path.is_file() and not path.is_symlink() and path.stat().st_size<=2<<20,'bounded source: '+key)
        raw=path.read_bytes();result['source_before'][key]=dict(bytes=len(raw),sha256=sha(raw))
        dest=OUT/'frozen-source'/key.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    def deny(kind,detail):
        result['denied_operations'].append(dict(kind=kind,detail=str(detail)))
        raise AssertionError('forbidden real operation: '+kind)
    def forbidden(name):return name.split('.')[0] in FORBIDDEN
    def hook(event,args):
        if event in ('subprocess.Popen','os.system','os.fork','os.forkpty','os.posix_spawn','os.exec','os.spawn',
            'os.kill','os.killpg','signal.pthread_kill','socket.__new__','socket.connect','socket.bind',
            'socket.getaddrinfo','socket.sendto'):deny(event,args)
        if event=='import' and forbidden(args[0]):deny('backend import',args[0])
        if event=='exec':
            filename=getattr(args[0],'co_filename','')
            if filename.startswith((str(ROOT/'tutorial_code')+'/',str(ROOT/'minivllm')+'/')):
                deny('backend source execution',filename)
            if filename.startswith(str(BENCH)+'/') and filename.endswith('.py'):record_source(filename)
        if event=='open' and isinstance(args[0],(str,bytes)):
            path=Path(os.fsdecode(args[0]))
            if path.suffix in ('.safetensors','.pack','.bin','.metallib'):deny('model/device payload open',str(path))
    class Imports(importlib.abc.MetaPathFinder):
        def find_spec(self,fullname,path=None,target=None):
            if forbidden(fullname):deny('backend import',fullname)
            return None
    save(OUT/'result.json',result)
    try:
        with (OUT/'stdout.txt').open('x') as stdout,(OUT/'stderr.txt').open('x') as stderr, \
            contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
            for folder in (OLD,NEW):
                result['tree_before'][str(folder)]=tree(folder)
                for path in result['tree_before'][str(folder)]:record_source(path)
            for path,digest in SEALED.items():
                record_source(path);need(result['source_before'][path]['sha256']==digest,'reviewed source changed: '+path)
            for name in ('load_probe.py','physical_guard.py'):record_source(BENCH/'glm_flash'/name)
            need(not any(forbidden(n) for n in sys.modules),'preloaded backend')
            os.chdir(ROOT);sys.path.insert(0,str(ROOT));finder=Imports();sys.meta_path.insert(0,finder);sys.addaudithook(hook)
            with contextlib.ExitStack() as stack:
                def block(name):return lambda *a,**kw:deny(name,(a,kw))
                for obj,name in ((subprocess,'run'),(subprocess,'Popen'),(os,'system'),(os,'kill'),(os,'killpg'),
                    (socket,'getaddrinfo'),(signal,'signal'),(signal,'alarm'),(signal,'setitimer'),
                    (signal,'raise_signal'),(signal,'pthread_kill')):
                    if hasattr(obj,name):stack.enter_context(patch.object(obj,name,side_effect=block(name)))
                suite=unittest.defaultTestLoader.loadTestsFromName(MODULE)
                result['discovered_tests']=suite.countTestCases();save(OUT/'result.json',result)
                run=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
            result.update(tests=run.testsRun,failures=len(run.failures),errors=len(run.errors),skipped=len(run.skipped),
                expected_failures=len(run.expectedFailures),unexpected_successes=len(run.unexpectedSuccesses),
                failures_detail=[dict(test=t.id(),traceback=s) for t,s in run.failures],
                errors_detail=[dict(test=t.id(),traceback=s) for t,s in run.errors],loader_errors=unittest.defaultTestLoader.errors)
            result['status']='PASS' if (run.wasSuccessful() and run.testsRun==result['discovered_tests']==16
                and not any((run.skipped,run.expectedFailures,run.unexpectedSuccesses,unittest.defaultTestLoader.errors,
                             result['denied_operations']))) else 'FAIL'
    except BaseException as error:
        result.update(status='FAIL',exception=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
    finally:
        if finder in sys.meta_path:sys.meta_path.remove(finder)
        for path in result['source_before']:
            try:
                raw=Path(path).read_bytes();result['source_after'][path]=dict(bytes=len(raw),sha256=sha(raw))
            except BaseException as error:result['source_after'][path]=dict(error=str(error))
        result['tree_after']={str(folder):tree(folder) for folder in (OLD,NEW)}
        result['source_unchanged']=result['source_before']==result['source_after']
        result['tree_membership_unchanged']=result['tree_before']==result['tree_after']
        result['forbidden_modules_loaded']=sorted(n for n in sys.modules if forbidden(n))
        if not result['source_unchanged'] or not result['tree_membership_unchanged'] or result['forbidden_modules_loaded']:result['status']='FAIL'
        result.update(ended_at=now(),elapsed_s=time.monotonic()-start);save(OUT/'result.json',result)
        files={str(p.relative_to(OUT)):dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
            for p in sorted(OUT.rglob('*')) if p.is_file()}
        save(OUT/'artifact-manifest.json',dict(schema='cpu-artifact-inventory-v1',files=files))
    print(json.dumps({k:result[k] for k in ('status','tests','failures','errors','skipped','source_unchanged','tree_membership_unchanged')}))
    return int(result['status']!='PASS')

if __name__=='__main__':raise SystemExit(main())
