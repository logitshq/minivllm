"""One retained CPU registration + read-only service prepare + actual seal.
No stop, recover, owner, inference, model import or model payload operation.
"""
import ast,datetime,hashlib,http.client,json,re,subprocess,sys,time,traceback
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');B=R/'bench/m5_ultra_256gb';A=R/'.artifacts/m5-ultra-256gb'
H=B/'glm_flash_cycle_v2';P=H/'prereg-load-v1';E=A/'glm-flash-load-v1-preparation-execution'
OWNER=A/'glm-flash-load-v1-owner';JOURNAL=A/'glm-flash-load-v1-cold-journal';ANALYSIS=A/'glm-flash-load-v1-analysis'
ARCH=R/'docs/experiments/m5-ultra-256gb/E029-gdn-http-formal-v1';I=A/'glm-flash-inputs-v1';PY=R/'.venv/bin/python'
JP=ARCH/'restored-journal.json';AP=ARCH/'restoration-audit.json'
JH='259cc48d5b3f9398417518223c000083a235477c0e2d475aadf2ffb3b0b39ba7'
AH='f7a66228b89bebbab57e3355b764a0177a36979983707b0d4cf33082be7d5518'
QH='700f0a785138a75ebb4554d6eddee7dfbd1375c5b92bd596f8bd2e3e16f9be87'
IH='bdf025b9fdfd5cb22eb1991c9b3e7c20c73b962a3e86e4306a0af9c33aca58be'
CHILD_LIMIT=220*(1<<30)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def save(name,value):
 (E/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def need(v,msg):
 if not v:raise ValueError(msg)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def step(label,command,timeout):
 row=dict(label=label,command=[str(x) for x in command],started_at=now(),outcome='UNKNOWN');result['steps'].append(row);save('result.json',result)
 try:
  with (E/(label+'.stdout')).open('xb') as out,(E/(label+'.stderr')).open('xb') as err:
   rc=subprocess.run(row['command'],cwd=R,stdout=out,stderr=err,timeout=timeout,check=False).returncode
  row.update(returncode=rc,outcome='WAITED');need(rc==0,label+' returned nonzero; retained without retry')
 finally:row['ended_at']=now();save('result.json',result)

def readonly_identity(prior):
 pid=prior['replacement']['pid'];argv=['/bin/ps','-p',str(pid),'-o','pid=,ppid=,lstart=,comm=']
 raw=subprocess.run(argv,capture_output=True,text=True,timeout=5,check=False)
 row=dict(command=argv,returncode=raw.returncode,stdout=raw.stdout,stderr=raw.stderr);save('identity-ps.json',row)
 m=re.fullmatch(r'\s*(\d+)\s+(\d+)\s+([A-Za-z]{3} [A-Za-z]{3}\s+\d+ \d\d:\d\d:\d\d \d{4})\s+(.+?)\s*',raw.stdout)
 need(raw.returncode==0 and not raw.stderr.strip() and m,'actual service identity unreadable')
 actual=dict(pid=int(m[1]),ppid=int(m[2]),start=' '.join(m[3].split()),comm=m[4]);need(actual==prior['replacement'],'service identity changed since archived restoration')
 responses={}
 for path in ('/api/status','/v1/models/status'):
  label='api-status' if path=='/api/status' else 'model-status';conn=http.client.HTTPConnection('127.0.0.1',8001,timeout=5)
  try:
   conn.request('GET',path,headers={'Connection':'close'});response=conn.getresponse();body=response.read((2<<20)+1)
   (E/(label+'.raw.json')).write_bytes(body);save(label+'-http.json',dict(method='GET',path=path,status=response.status,bytes=len(body),sha256=hashlib.sha256(body).hexdigest()))
   need(response.status==200 and len(body)<2<<20,'readonly HTTP response not bounded 200');responses[path]=json.loads(body)
  finally:conn.close()
 status=responses['/api/status'];models=responses['/v1/models/status'];expected=prior['final_status']
 need(status['active_requests']==status['waiting_requests']==status['models_loading']==0,'service not idle')
 rows=[m for m in models['models'] if m['id']==expected['default_model']];need(len(rows)==1,'service target ambiguous');t=rows[0]
 normalized=dict(version=status['version'],default_model=status['default_model'],loaded=status['loaded_models'],loading=status['models_loading'],target_loading=t['is_loading'],path=t['model_path'],pinned=t['pinned'],engine_type=t['engine_type'],config_model_type=t['config_model_type'])
 need(normalized==expected,'readonly persisted service status changed')
 save('readonly-precheck.json',dict(status='PASS',identity=actual,service_status=normalized,service_mutations=False));return actual

need(len(sys.argv)==2 and sys.argv[1]=='--run','explicit --run required; only CPU/read-only preparation')
need(not any(p.exists() for p in (P,E,OWNER,JOURNAL,ANALYSIS)),'all v1 outputs must be fresh')
E.mkdir();(E/'runner.py').write_bytes(Path(__file__).read_bytes())
result=dict(schema='GLM-cpu-registration-readonly-prepare-v1',status='RUNNING',started_at=now(),steps=[],source_before={},source_after={},
 model_loaded=False,service_mutations=False,owner_started=False,performance_qualified=False,child_limit_bytes=CHILD_LIMIT,
 policy_basis='Explicit observation stop threshold 220 GiB, 20 GiB below independent system240 GiB ceiling; no prediction from weight bytes, no hard allocation or inter-sample peak bound.')
save('result.json',result)
try:
 need(sha(JP)==JH and sha(AP)==AH and sha(I/'probe-plan.json')==QH and sha(I/'model-runtime-inventory.json')==IH,'actual archived/input reference mismatch')
 prior=read(JP);proof=read(AP)
 need(prior['state']=='RESTORED' and proof['status']=='PASS' and proof['qualified'] is True and proof['journal_sha256']==JH,'closed actual restoration required')
 prepared=read(H/'prepared-source-v1.json')
 for name,row in prepared['files'].items():
  p=H/name;need(sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],'prepared adapter changed: '+name)
 files=[H/name for name in prepared['files']]+[H/'prepared-source-v1.json',JP,AP,I/'probe-plan.json',I/'model-runtime-inventory.json']
 tree=ast.parse((H/'_reuse.py').read_text());fixed=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FIXED' for t in n.targets))
 for name,digest in fixed.items():
  p=B/'glm_flash_cycle'/name;need(sha(p)==digest,'frozen GLM source changed');files.append(p)
 for path in files:
  result['source_before'][str(path)]=sha(path);dest=E/'sources'/str(path).lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(path.read_bytes())
 result['precheck_identity']=readonly_identity(prior)
 ANALYSIS.mkdir()
 command=[str(PY),'-I','-B',str(H/'preregister.py'),'--run','--probe-plan',str(I/'probe-plan.json'),'--probe-plan-sha256',QH,
  '--verification',str(I/'model-runtime-inventory.json'),'--verification-sha256',IH,'--predecessor-journal',str(JP),'--predecessor-journal-sha256',JH,
  '--predecessor-audit',str(AP),'--predecessor-audit-sha256',AH,'--python',str(PY),'--out',str(P),'--owner',str(OWNER),'--journal',str(JOURNAL),
  '--analysis',str(ANALYSIS/'independent-closed.json'),'--child-limit-bytes',str(CHILD_LIMIT),'--interval-seconds','1','--probe-seconds','5']
 save('registration-command.json',dict(command=command));step('register',command,300)
 commands=read(P/'commands.json');plan=read(P/'owner-plan.json');digest=sha(P/'owner-plan.json')
 need(read(P/'plan-build.json')['owner_plan_sha256']==digest,'saved plan SHA mismatch')
 prep=commands['controller_prepare']
 need(prep[:5]==[str(PY),'-I','-B',str(H/'controller.py'),'prepare'],'only exact readonly prepare may run')
 need(prep[prep.index('--owner-plan-sha256')+1]==digest,'readonly prepare actual plan SHA')
 step('controller-prepare',prep,120)
 data=read(JOURNAL/'journal.json');need(data['state']=='PREPARED' and data['original']==prior['replacement'],'actual readonly prepared service identity')
 step('seal',[str(PY),'-I','-B',str(H/'preregister.py'),'--seal-prepared',str(P)],300)
 receipt=read(P/'receipt.json');need(receipt['owner_plan_sha256']==digest and receipt['prepared_journal_sha256']==sha(JOURNAL/'journal.json'),'actual sealed receipt')
 need(not OWNER.exists(),'no owner may have started')
 result.update(status='PASS_CPU_REGISTERED_READONLY_PREPARED',owner_plan_sha256=digest,prepared_journal_sha256=receipt['prepared_journal_sha256'],receipt_sha256=sha(P/'receipt.json'),registration=str(P),journal=str(JOURNAL),identity=data['original'],outputs=dict(owner=str(OWNER),analysis=str(ANALYSIS)),exact_commands_path=str(P/'commands.json'))
except BaseException as error:
 result.update(status='FAIL',error=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
finally:
 for path in result['source_before']:
  try:result['source_after'][path]=sha(path)
  except Exception as error:result['source_after'][path]=dict(error=str(error))
 result['sources_unchanged']=result['source_before']==result['source_after']
 if not result['sources_unchanged']:result['status']='FAIL'
 result['ended_at']=now();save('result.json',result)
 inventory={str(p.relative_to(E)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(E.rglob('*')) if p.is_file()}
 save('manifest.json',dict(files=inventory,model_loaded=False,service_mutations=False))
print(json.dumps({k:result.get(k) for k in ('status','error','owner_plan_sha256','prepared_journal_sha256','identity','sources_unchanged')}))
raise SystemExit(0 if result['status']=='PASS_CPU_REGISTERED_READONLY_PREPARED' else 1)
