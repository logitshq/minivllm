"""One explicitly requested read-only operational check; never resumes controller.
Original LOAD_INTENT/monitor failure remains immutable. No POST or service mutation.
"""
import argparse, hashlib, http.client, importlib.util, json, os, pathlib, subprocess, sys, time, traceback
from types import SimpleNamespace
R=pathlib.Path('/Users/ryanli/code/minivllm')
P=R/'bench/m5_ultra_256gb/glm_flash_cycle_v2'
J=R/'.artifacts/m5-ultra-256gb/glm-flash-load-v1-cold-journal'
E=R/'.artifacts/m5-ultra-256gb/glm-flash-load-v1-execution'
O=R/'.artifacts/m5-ultra-256gb/glm-flash-load-v1-analysis/operational-recovery-v1'
CONTROLLER='bdb5afac1febec8be8b2e10d70b77bbbc150aac76416385ac0c89f5ce48c6579'
PLAN='b842f85f04b32ed84cb0903d943ac86b04f1cf7ae6ef2c1f3df4f5848e59af01'
def need(x,m):
    if not x: raise ValueError(m)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_bytes())
def save(p,v):
    with pathlib.Path(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def ref(p):return dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--run',action='store_true');x=a.parse_args()
    if not x.run:print(json.dumps(dict(output=str(O),read_only=True,original_journal_unchanged=True)));return 0
    O.mkdir(exist_ok=False)
    (O/'tool.py').write_bytes(pathlib.Path(__file__).read_bytes())
    result=dict(schema='GLM-independent-operational-restoration-v1',status='FAIL',started_at=time.time(),
        tool_sha256=sha(__file__),controller_sha256=CONTROLLER,owner_plan_sha256=PLAN,
        recovery_command_succeeded=False,original_monitored_recovery_passed=False,
        observed_diagnostic_complete=False,full_model_correctness_qualified=False,
        performance_qualified=False,physical_resource_safety_qualified=False,
        exact_runtime_signature_restored=False,warm_kv_restored=False)
    frozen={}
    try:
        for name,p in [('original-journal.json',J/'journal.json'),('original-driver-final.json',E/'final.json'),
                       ('original-worker-release.json',J/'load-worker/release.json')]:
            raw=p.read_bytes();frozen[p]=raw;(O/name).write_bytes(raw)
        jdata=json.loads(frozen[J/'journal.json']);final=json.loads(frozen[E/'final.json'])
        need(jdata['state']=='LOAD_INTENT' and jdata['post_monitor_failed'] is True and
             jdata['recovery_complete'] is False and final['journal_state']=='LOAD_INTENT' and
             final['recovery_returncode']==1 and final['owner_returncode']==1 and
             final['owner_plan_sha256']==PLAN,'actual original failure contract changed')
        worker=read(J/'load-worker/release.json')
        need(worker['pid']==jdata['post_worker_pid'] and worker['returncode']==-15 and
             worker['waited_reaped'] is True and worker['strict_absence'] is True,'actual cancelled HTTP worker receipt')
        path=P/'controller.py';need(sha(path)==CONTROLLER,'controller source changed')
        sp=importlib.util.spec_from_file_location('glm_operational_frozen_controller',path)
        c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
        calls=[]
        class ReadOnly(c.System):
            def run(self,argv,timeout=10):
                need((argv[:2]==['/bin/ps','-p']) or argv==['/bin/launchctl','print',c.b.JOB] or
                     argv==['/usr/sbin/lsof','-nP','-a','-iTCP:8001','-sTCP:LISTEN','-Fpn'],
                     'unapproved read command')
                row=dict(command=argv,started_at=time.time());calls.append(row)
                try:
                    p=subprocess.run(argv,capture_output=True,text=True,timeout=timeout)
                    row.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
                    need(not p.stderr.strip(),'read command stderr')
                    return p.returncode,p.stdout
                finally:
                    row['ended_at']=time.time();save(O/f'os-{len(calls):03d}.json',row)
            def mutate(self,*args,**kwargs):raise AssertionError('service mutation prohibited')
            def http(self,method,path,timeout=2):
                need(method=='GET' and path in ('/api/status','/v1/models/status'),'only fixed read-only GET')
                row=dict(method=method,path=path,started_at=time.time());calls.append(row)
                connection=http.client.HTTPConnection('127.0.0.1',8001,timeout=timeout)
                try:
                    connection.request('GET',path,headers={'Connection':'close'})
                    response=connection.getresponse();raw=response.read(2<<20)
                    name=f'http-{len(calls):03d}.raw.json';(O/name).write_bytes(raw)
                    row.update(status=response.status,raw=ref(O/name))
                    need(response.status==200 and len(raw)<2<<20,'bounded successful GET')
                    return json.loads(raw)
                finally:
                    connection.close();row['ended_at']=time.time();save(O/f'http-{len(calls):03d}.json',row)
        system=ReadOnly(O)
        # This object points at the original location for receipt validation only;
        # it deliberately offers no save method. No recovered state is synthesized.
        original=SimpleNamespace(directory=J,data=jdata)
        c.authorize(original,c.CONTRACT,c.PLAN_SHA)
        result['owner_reap']=c.reaped(original,system)
        for pid in (jdata['original']['pid'],jdata['post_worker_pid'],jdata['load_worker']['parent_identity']['pid']):
            need(system.process(pid) is None,'prior PID still exists (including reuse)')
        identity=c.replacement(system,jdata['original'])
        need(identity==jdata['replacement'],'actual replacement differs from failed controller receipt')
        status=c.b.service_status(system,[c.b.TARGET]);need(status==jdata['original_status'],'persisted-visible variant changed')
        lines,log=system.log_window(jdata['recovery_log_start']);markers=c.b.verify_logs(lines)
        result.update(replacement=identity,observed_status_before=status,log_window=log,log_markers=markers)
        class IndependentSamples:
            def __init__(self):self.data={'resource_samples':[],'events':[]}
            def save(self,event,**values):
                self.data.update(values);self.data['events'].append(dict(event=event,time=time.time(),monotonic=time.monotonic()))
                save(O/f'resource-events-{len(self.data["events"]):02d}.json',self.data)
        evidence=IndependentSamples()
        c.resource_gate(evidence,system,loaded=True)
        result['current_resource_samples']=evidence.data['resource_samples']
        result['current_resource_scope']='Two fresh loaded-stability samples; no historical POST/swap failure erased; no hard cap.'
        c.authorize(original,c.CONTRACT,c.PLAN_SHA)
        need(c.replacement(system,jdata['original'])==identity,'replacement changed during observation')
        status_after=c.b.service_status(system,[c.b.TARGET]);need(status_after==status,'status changed during observation')
        result['owner_reap_after']=c.reaped(original,system)
        need(system.process(jdata['post_worker_pid']) is None,'HTTP worker reappeared')
        result.update(status='OPERATIONALLY_RESTORED_WITH_MONITOR_FAILURE',observed_status_after=status_after,
            independent_current_observation_passed=True,original_journal_state='LOAD_INTENT',
            scope='Current persisted-visible service and strict old-child absence verified using retained raw reads. Original recovery command/HTTP outcome and historical monitor remain failed; no experiment qualification.')
    except BaseException as error:
        result.update(error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        changed=[str(p) for p,raw in frozen.items() if p.read_bytes()!=raw]
        result['original_evidence_unchanged']=not changed
        result['original_evidence']={str(p):dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)) for p,raw in frozen.items()}
        if changed:result.update(status='FAIL',error='original evidence changed',changed=changed)
        result['ended_at']=time.time();save(O/'result.json',result)
    print(json.dumps(result,indent=2))
    return 0 if result['status']=='OPERATIONALLY_RESTORED_WITH_MONITOR_FAILURE' else 1
if __name__=='__main__':raise SystemExit(main())
