"""Run frozen independent audits only after actual GDN HTTP recovery is closed."""
import argparse,datetime,hashlib,json,subprocess,sys,time,traceback
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');B=R/'bench/m5_ultra_256gb';A=R/'.artifacts/m5-ultra-256gb'
P=B/'gdn_prework_http_cycle/prereg-http-v1';O=A/'gdn-http-v1-owner';J=A/'gdn-http-v1-cold-journal';E=A/'gdn-http-v1-execution';OUT=A/'gdn-http-v1-analysis'
PLAN='5d7bf34bec68dca784ebc449e660d14bcc63a6ecd2ffd7cae63981c22ebe3024'
RESTORE=B/'gdn_prework_http_cycle/audit_restore.py';NUMERIC=B/'gdn_prework_http/audit.py';CYCLE=B/'gdn_prework_http_cycle/audit_cycle.py'
PINS={str(RESTORE):'40d07aabef5d3588b4eac57a2acadf4278eee2328a3304da2a041a234f66ff5e',str(NUMERIC):'5ccb357e1f6a1296ab8673a604c48f2e183d01d83671e8d7857edc85cded7cd0',str(CYCLE):'086500e1a63edaea05e325039ec422b6383d553fd944632f3d41f59868990253'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return dict(path=str(p),sha256=sha(p),bytes=Path(p).stat().st_size)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def job(label,source,args,filename):
 row=dict(argv=[str(R/'.venv/bin/python'),'-I','-B',str(source),*args,'--out',str(OUT/filename)],source=ref(source),started_at=now(),status='RUNNING')
 save(label+'-execution.json',row);start=time.monotonic()
 try:
  with (OUT/(label+'.stdout')).open('xb') as out,(OUT/(label+'.stderr')).open('xb') as err:
   result=subprocess.run(row['argv'],cwd=R,stdout=out,stderr=err,timeout=1800,check=False)
  row.update(status='RETURNED',returncode=result.returncode)
 except BaseException as error:row.update(status='ERROR',error=dict(type=type(error).__name__,message=str(error)))
 finally:
  row.update(ended_at=now(),elapsed_seconds=time.monotonic()-start)
  if (OUT/filename).exists():row.update(output=ref(OUT/filename),audit_status=read(OUT/filename).get('status'))
  save(label+'-execution.json',row)
 print(label+' '+str(row.get('audit_status',row['status'])),flush=True);return row

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true');args=parser.parse_args()
 if not args.run:print('DESCRIPTION_ONLY: closed restoration then separate C1/C8 and cycle audits.');return 0
 final=read(E/'final.json');journal=read(J/'journal.json')
 need(final['journal_state']==journal['state']=='RESTORED' and final['recovery_returncode']==0,'actual driver finally-recovery must already be closed')
 need(sha(P/'owner-plan.json')==PLAN and journal['owner_plan']==dict(path=str(P/'owner-plan.json'),sha256=PLAN),'actual plan/journal')
 receipt=read(P/'receipt.json')
 need(all(sha(p)==h==receipt['source_pins'][p] for p,h in PINS.items()),'frozen registered audit sources')
 OUT.mkdir();(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
 result=dict(schema='GDN-http-closed-audits-v1',status='INCOMPLETE',started_at=now(),owner_plan_sha256=PLAN,source_pins=PINS,jobs={},restoration_qualified=False,numerical_qualified=False,http_history_qualified=False,performance_qualified=False)
 save('execution-summary.json',result)
 try:
  for name,path in [('restored-journal.json',J/'journal.json'),('driver-final.json',E/'final.json'),('registration-receipt.json',P/'receipt.json')]:
   (OUT/name).write_bytes(path.read_bytes());result.setdefault('inputs',{})[name]=ref(path)
  result['jobs']['restoration']=job('restoration',RESTORE,['--journal',str(J)],'restoration-audit.json');save('execution-summary.json',result)
  r=result['jobs']['restoration'];need(r.get('returncode')==0 and r.get('audit_status')=='PASS','independent restoration failed')
  restored=read(OUT/'restoration-audit.json');need(restored['qualified'] is True and restored['journal_sha256']==sha(J/'journal.json') and restored['owner_plan_sha256']==PLAN,'restoration actual evidence')
  result['restoration_qualified']=True;save('execution-summary.json',result)
  for C in (1,8):
   target=O/f'phases/c{C}-replay/qualification';plan=target/'plan.json'
   if not plan.exists():
    result['jobs'][f'c{C}']=dict(status='NOT_RUN',reason='actual replay plan missing');continue
   result['jobs'][f'c{C}']=job(f'c{C}',NUMERIC,['--child',str(target),'--plan-sha256',sha(plan)],f'independent-c{C}.json');save('execution-summary.json',result)
  if all(result['jobs'][f'c{C}'].get('returncode')==0 and result['jobs'][f'c{C}'].get('audit_status')=='PASS' for C in (1,8)):
   result['numerical_qualified']=True
   extra=[]
   for C in (1,8):extra += [f'--c{C}-audit',str(OUT/f'independent-c{C}.json'),f'--c{C}-audit-sha256',sha(OUT/f'independent-c{C}.json')]
   result['jobs']['cycle']=job('cycle',CYCLE,['--owner',str(O),'--journal',str(J),'--plan-sha256',PLAN,*extra],'independent-cycle.json')
   if result['jobs']['cycle'].get('returncode')==0 and result['jobs']['cycle'].get('audit_status')=='PASS':
    cycle=read(OUT/'independent-cycle.json');need(cycle['qualified'] is cycle['http_history_qualified'] is True and cycle['restoration']==restored,'cycle independent closure')
    result['http_history_qualified']=True
  result['status']='PASS' if result['http_history_qualified'] else 'FAIL'
 except BaseException as error:result.update(status='FAIL',error=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
 finally:
  result['sources_unchanged']=all(sha(p)==h for p,h in PINS.items())
  result['inputs_unchanged']=all(ref(v['path'])==v for v in result.get('inputs',{}).values())
  if not result['sources_unchanged'] or not result['inputs_unchanged']:result.update(status='FAIL',http_history_qualified=False)
  result['ended_at']=now();save('execution-summary.json',result)
 print(json.dumps({k:result[k] for k in ('status','restoration_qualified','http_history_qualified','performance_qualified')}));return int(result['status']!='PASS')
if __name__=='__main__':raise SystemExit(main())
