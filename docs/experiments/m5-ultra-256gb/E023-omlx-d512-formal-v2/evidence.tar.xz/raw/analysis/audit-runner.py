from pathlib import Path
import concurrent.futures,datetime,hashlib,json,subprocess,time
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';P=R/'bench/m5_ultra_256gb/omlx_d512_formal_retry/prereg-formal-v2';D=A/'omlx-d512-formal-v2-analysis'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def main():
 final=read(A/'omlx-d512-formal-v2-execution/final.json');journal=read(A/'omlx-d512-formal-v2-cold-journal/journal.json');receipt=read(P/'receipt.json')
 assert final['journal_state']==journal['state']=='RESTORED' and final['recovery_returncode']==0
 assert all(sha(p)==s for p,s in receipt['source_pins'].items())
 D.mkdir();(D/'audit-runner.py').write_bytes(Path(__file__).read_bytes());commands=read(P/'commands.json')
 jobs={'restoration_audit':'restoration-audit.json','resource_audit':'resource-summary.json','formal_audit':'independent-formal.json'}
 def run(name):
  cmd=commands[name];start=time.monotonic();row={'argv':cmd,'start':datetime.datetime.now(datetime.timezone.utc).isoformat()};save(D/(name+'-command.json'),row)
  with (D/(name+'.stdout')).open('xb') as out,(D/(name+'.stderr')).open('xb') as err:
   result=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=300,check=False)
  p=D/jobs[name];row.update(returncode=result.returncode,elapsed_seconds=time.monotonic()-start,result_sha256=sha(p) if p.exists() else None,status=read(p).get('status') if p.exists() else None)
  save(D/(name+'-execution.json'),row);return row
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  futures={name:pool.submit(run,name) for name in jobs};results={name:f.result() for name,f in futures.items()}
 save(D/'execution-summary.json',results)
 print(json.dumps({name:{k:v for k,v in row.items() if k!='argv'} for name,row in results.items()}))
if __name__=='__main__':main()
