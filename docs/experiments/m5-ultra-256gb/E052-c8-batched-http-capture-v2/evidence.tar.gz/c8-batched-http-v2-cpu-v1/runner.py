from pathlib import Path
import hashlib,json,subprocess,time
R=Path('/Users/ryanli/code/minivllm'); A=R/'.artifacts/m5-ultra-256gb'; P=R/'bench/m5_ultra_256gb/c8_batched_http_v2'
code=r'''
import importlib.abc,json,os,socket,subprocess,sys,unittest,unittest.mock
forbidden=[]
class NoBackend(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in ('mlx','numpy','torch','jax','tensorflow','safetensors'):
   forbidden.append(fullname);raise AssertionError('forbidden backend '+fullname)
sys.meta_path.insert(0,NoBackend())
def deny(*a,**kw): forbidden.append('external operation');raise AssertionError('forbidden external operation')
subprocess.run=subprocess.Popen=subprocess.call=subprocess.check_call=subprocess.check_output=deny
os.kill=os.system=socket.create_connection=deny
local_loop_sockets=[]
original_socket=socket.socket
class LoopSocketOnly(original_socket):
 def __init__(self,family=socket.AF_INET,type=socket.SOCK_STREAM,proto=0,fileno=None):
  if family!=socket.AF_UNIX:deny()
  local_loop_sockets.append('AF_UNIX event-loop self-pipe')
  super().__init__(family,type,proto,fileno)
 def connect(self,*a,**kw):deny()
 def connect_ex(self,*a,**kw):deny()
 def bind(self,*a,**kw):deny()
 def listen(self,*a,**kw):deny()
 def accept(self,*a,**kw):deny()
socket.socket=LoopSocketOnly
sys.path.insert(0,'/Users/ryanli/code/minivllm')
suite=unittest.defaultTestLoader.loadTestsFromName('bench.m5_ultra_256gb.c8_batched_http_v2.test_cpu')
result=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps(dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),forbidden=forbidden,local_event_loop_socket_creations=len(local_loop_sockets))))
raise SystemExit(0 if result.wasSuccessful() and result.testsRun==7 and not forbidden else 1)
'''
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
out=A/'c8-batched-http-v2-cpu-v1';out.mkdir();(out/'sources').mkdir()
actual=A/'c8-batched-http-v1-screen/trials/c8-batched-mb50-two-waves'
sources=[P/'trial.py',P/'test_cpu.py',P.parent/'c8_batched_http_v1/server.py',P.parent/'c8_batched_http_v1/trial.py',P.parent/'c8_schedule_diagnostic_v1/trial.py',P.parent/'gdn_graph_combined/http_server.py',P.parent/'gdn_graph_combined/qualify.py',P.parent/'gdn_batched_graph/integration.py',P.parent/'route_decode_graph/http_capture.py',actual/'spec.json',actual/'trace.jsonl',actual/'complete.json']
before={str(p):sha(p) for p in sources};write(out/'sources-before.json',before)
for i,p in enumerate(sources):(out/'sources'/f'{i}-{p.name}').write_bytes(p.read_bytes())
(out/'runner.py').write_bytes(Path(__file__).read_bytes());cmd=[str(R/'.venv/bin/python'),'-I','-B','-c',code];write(out/'command.json',cmd)
started=time.monotonic()
with (out/'stdout.txt').open('x') as stdout,(out/'stderr.txt').open('x') as stderr: result=subprocess.run(cmd,cwd=R,stdout=stdout,stderr=stderr)
after={str(p):sha(p) for p in sources};write(out/'sources-after.json',after)
write(out/'result.json',dict(returncode=result.returncode,elapsed_s=time.monotonic()-started,sources_unchanged=before==after))
print((out/'stdout.txt').read_text());print((out/'stderr.txt').read_text());print((out/'result.json').read_text())
raise SystemExit(result.returncode or int(before!=after))
