"""One fresh, fake-only test attempt; never invokes a service or backend."""
import argparse
import builtins
import contextlib
import hashlib
import importlib.abc
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import unittest
import unittest.mock

ROOT = Path('/Users/ryanli/code/minivllm')
HERE = ROOT / 'bench/m5_ultra_256gb/cold_observed_cycle'
OUT = ROOT / '.artifacts/m5-ultra-256gb/combined-driver-v2-cpu-v1'
SOURCES = [Path(__file__).resolve(), HERE/'execute_combined_v1.py', HERE/'execute_combined_v2.py', HERE/'test_execute_combined_v2_cpu.py']

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value):
    with path.open('x') as f: json.dump(value, f, indent=2); f.write('\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run', action='store_true')
    if not p.parse_args().run:
        print('DESCRIPTION_ONLY: 3 fake CPU tests, no service/model actions.'); return 0
    OUT.mkdir(exist_ok=False)
    (OUT/'sources').mkdir()
    started = time.time()
    before = {str(p): digest(p) for p in SOURCES}
    for i, path in enumerate(SOURCES): (OUT/'sources'/f'{i:02}-{path.name}').write_bytes(path.read_bytes())
    save(OUT/'source-before.json', before)
    save(OUT/'command.json', {'argv':[sys.executable, '-I', '-B', str(Path(__file__).resolve()), '--run'], 'pid':os.getpid(), 'started_at':started})
    denied = []
    def deny(label):
        def fail(*args, **kwargs):
            denied.append(label); raise AssertionError('Forbidden real operation: '+label)
        return fail
    class Imports(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname.split('.')[0] in {'mlx','mlx_lm','numpy','torch','transformers','safetensors','requests','httpx','omlx','monolith'}:
                return deny('import '+fullname)()
    finder=Imports(); sys.meta_path.insert(0, finder)
    patches=[unittest.mock.patch.object(subprocess,'Popen',deny('subprocess.Popen')),
             unittest.mock.patch.object(socket,'socket',deny('socket.socket')),
             unittest.mock.patch.object(socket,'create_connection',deny('socket.create_connection')),
             unittest.mock.patch.object(os,'kill',deny('os.kill')),
             unittest.mock.patch.object(os,'killpg',deny('os.killpg')),
             unittest.mock.patch.object(os,'system',deny('os.system')),
             unittest.mock.patch.object(signal,'signal',deny('signal.signal'))]
    result=None; error=None
    try:
        with contextlib.ExitStack() as stack:
            for patch in patches: stack.enter_context(patch)
            with (OUT/'stdout.txt').open('x') as stdout, (OUT/'stderr.txt').open('x') as stderr, contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                spec=importlib.util.spec_from_file_location('_combined_driver_tests',SOURCES[-1])
                module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
                suite=unittest.defaultTestLoader.loadTestsFromModule(module)
                if suite.countTestCases()!=3: raise AssertionError('Expected exactly three tests')
                result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
    except BaseException as exc:
        error={'type':type(exc).__name__,'message':str(exc)}
    finally:
        sys.meta_path.remove(finder)
        after={str(p):digest(p) for p in SOURCES}
        save(OUT/'source-after.json',after)
    passed=bool(result and result.wasSuccessful() and result.testsRun==3 and not result.skipped and before==after and not denied and error is None)
    receipt={'schema':'combined-driver-v2-cpu-v1','status':'PASS' if passed else 'FAIL','tests_run':result.testsRun if result else 0,
             'failures':len(result.failures) if result else 0,'errors':len(result.errors) if result else 0,'skipped':len(result.skipped) if result else 0,
             'error':error,'denied':denied,'source_unchanged':before==after,'started_at':started,'ended_at':time.time(),
             'scope':'Fake control-flow only; no service/model/GPU action','numerical_qualified':False,'http_qualified':False,'performance_qualified':False}
    save(OUT/'result.json',receipt)
    save(OUT/'artifact-manifest.json',{str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(OUT.rglob('*')) if p.is_file()})
    print(json.dumps(receipt,sort_keys=True))
    return 0 if passed else 1

if __name__=='__main__': raise SystemExit(main())
