from pathlib import Path
import hashlib,json,re
R=Path('/Users/ryanli/code/minivllm');P=R/'.artifacts/m5-ultra-256gb/route-decode-canary-v1-owner';A=Path(__file__).resolve().parent
rows=[];pins={};pressure=[];swaps=[];vm=[]
for path in sorted(P.glob('resource-*.json')):
 raw=path.read_bytes();pins[path.name]=hashlib.sha256(raw).hexdigest();d=json.loads(raw);rows.append(d)
 for k in ('pressure_level','swap','vm_stat'):assert d[k]['returncode']==0 and not d[k]['error']
 level=int(d['pressure_level']['text'].strip());assert level==d['pressure_level_value']==1;pressure.append(level)
 swap=float(re.search(r'used = ([0-9.]+)M',d['swap']['text'])[1]);assert swap==d['swap_used_mb'];swaps.append(swap)
 counters={k:int(re.search(r'^'+k+r':\s+(\d+)\.',d['vm_stat']['text'],re.M)[1]) for k in ('Swapouts','Swapins','Pageouts','Compressions','Decompressions')}
 assert counters==d['vm_counters'];vm.append(counters)
 power=d['power_metadata'];assert power['source']=='AC Power' and power['raw']['returncode']==0 and "Now drawing from 'AC Power'" in power['raw']['stdout']
 thermal=d['processinfo_thermal_metadata'];assert thermal['raw']['returncode']==0 and int(thermal['raw']['stdout'].strip())==thermal['code'] and thermal['code'] in (0,1)
 assert d['native_process_inventory_ok'] and d['process_inventory_ok'] and d['authorized_suspended_pids']==[]
 assert all(x['owned'] and x['pid']==d['owned_model_pid']==13629 and not x['authorized_suspended'] for x in d['native_inference_processes'])
assert len(rows)==json.loads((P/'complete.json').read_bytes())['samples']
assert all(rows[i]['monotonic_s']<rows[i+1]['monotonic_s'] for i in range(len(rows)-1))
out=dict(schema='E024-route-canary-resource-reparse-v1',status='PASS',samples=len(rows),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),raw_sample_sha256=pins,
 pressure_values=sorted(set(pressure)),swap_delta_mib=swaps[-1]-swaps[0],max_swap_growth_mib=max(swaps)-swaps[0],
 vm_delta={k:vm[-1][k]-vm[0][k] for k in vm[0]},
 scope='Reparsed raw pressure/swap/VM/power/thermal; known-process inventory checked as source-pinned receipts. No claim to exclude unrecognized runtime or GUI GPU activity.',performance_qualified=False)
with (A/'resource-summary.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in out.items() if k!='raw_sample_sha256'}))
