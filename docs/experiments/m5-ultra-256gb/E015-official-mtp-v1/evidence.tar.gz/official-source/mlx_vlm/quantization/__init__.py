"""Weight quantization backends."""
