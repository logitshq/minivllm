from functools import partial
from typing import Optional, Tuple

import mlx.core as mx
import mlx.nn as nn

# --- Vendored from mlx_lm.models.gated_delta (mlx-lm 0.31.3) to drop the
# --- module-level mlx_lm import so qwen3_5 loads without mlx-lm (and under
# --- transformers>=5.13). Pure mlx.core/mlx.nn; behaviour is identical.
# --- The packed Dk=128 kernel is synced from mlx-lm (ml-explore/mlx-lm#1559).
# --- gated_delta_kernel uses it for multi-token calls (prefill, multi-token
# --- recurrent updates) with no mask, a scalar gate, Dv % 8 == 0 and fp32 gate
# --- and state; one-token decode keeps the generic kernel. On the Apple GPUs
# --- tested its output is bitwise-identical to the generic simd_sum kernel.


def _make_gated_delta_kernel(has_mask=False, vectorized=False):
    if not mx.metal.is_available():
        return None
    mask_source = "mask[b_idx * T + t]" if has_mask else "true"

    # Configure g indexing based on whether gating is vectorized
    if vectorized:
        g_comment = "// g: [B, T, Hv, Dk]"
        g_setup = "auto g_ = g + (b_idx * T * Hv + hv_idx) * Dk;"
        g_access = "g_[s_idx]"
        g_advance = "g_ += Hv * Dk;"
    else:
        g_comment = "// g: [B, T, Hv]"
        g_setup = "auto g_ = g + b_idx * T * Hv;"
        g_access = "g_[hv_idx]"
        g_advance = "g_ += Hv;"

    source = f"""
        auto n = thread_position_in_grid.z;
        auto b_idx = n / Hv;
        auto hv_idx = n % Hv;
        auto hk_idx = hv_idx / (Hv / Hk);
        constexpr int n_per_t = Dk / 32;

        // q, k: [B, T, Hk, Dk]
        auto q_ = q + b_idx * T * Hk * Dk + hk_idx * Dk;
        auto k_ = k + b_idx * T * Hk * Dk + hk_idx * Dk;

        // v, y: [B, T, Hv, Dv]
        auto v_ = v + b_idx * T * Hv * Dv + hv_idx * Dv;
        y += b_idx * T * Hv * Dv + hv_idx * Dv;

        auto dk_idx = thread_position_in_threadgroup.x;
        auto dv_idx = thread_position_in_grid.y;

        // state_in, state_out: [B, Hv, Dv, Dk]
        auto i_state = state_in + (n * Dv + dv_idx) * Dk;
        auto o_state = state_out + (n * Dv + dv_idx) * Dk;

        float state[n_per_t];
        for (int i = 0; i < n_per_t; ++i) {{
          auto s_idx = n_per_t * dk_idx + i;
          state[i] = static_cast<float>(i_state[s_idx]);
        }}

        {g_comment}
        {g_setup}
        auto beta_ = beta + b_idx * T * Hv;

        for (int t = 0; t < T; ++t) {{
          if ({mask_source}) {{
            float kv_mem = 0.0f;
            for (int i = 0; i < n_per_t; ++i) {{
              auto s_idx = n_per_t * dk_idx + i;
              state[i] = state[i] * {g_access};
              kv_mem += state[i] * k_[s_idx];
            }}
            kv_mem = simd_sum(kv_mem);

            auto delta = (v_[dv_idx] - kv_mem) * beta_[hv_idx];

            float out = 0.0f;
            for (int i = 0; i < n_per_t; ++i) {{
              auto s_idx = n_per_t * dk_idx + i;
              state[i] = state[i] + k_[s_idx] * delta;
              out += state[i] * q_[s_idx];
            }}
            out = simd_sum(out);
            if (thread_index_in_simdgroup == 0) {{
              y[dv_idx] = static_cast<InT>(out);
            }}
          }} else {{
            y[dv_idx] = static_cast<InT>(0);
          }}
          // Increment data pointers to next time step
          q_ += Hk * Dk;
          k_ += Hk * Dk;
          v_ += Hv * Dv;
          y += Hv * Dv;
          {g_advance}
          beta_ += Hv;
        }}
        for (int i = 0; i < n_per_t; ++i) {{
          auto s_idx = n_per_t * dk_idx + i;
          o_state[s_idx] = static_cast<StT>(state[i]);
        }}
    """
    inputs = ["q", "k", "v", "g", "beta", "state_in", "T"]
    if has_mask:
        inputs.append("mask")

    suffix = ""
    if vectorized:
        suffix += "_vec"
    if has_mask:
        suffix += "_mask"

    return mx.fast.metal_kernel(
        name=f"gated_delta_step{suffix}",
        input_names=inputs,
        output_names=["y", "state_out"],
        source=source,
    )


def _make_gated_delta_packed_kernel():
    """Make the scalar-gate Dk=128 prefill specialization.

    The generic kernel assigns one 32-lane SIMD-group to each value row. For
    Dk=128 that leaves every lane with only four state elements and performs
    two full-SIMD reductions per row and token. This kernel instead packs
    eight independent value rows into a SIMD-group: four lanes own each row
    and each lane keeps 32 contiguous state elements in registers.

    The reduction is an explicitly written ascending butterfly (shuffle_xor
    1,2,4 inside a packed lane, then 1,2 across the four-lane row group), the
    order simd_sum lowers to on current Apple GPUs, so y and the state are
    bit-identical to the generic kernel there (tests/test_gated_delta.py).
    Synced from mlx-lm (ml-explore/mlx-lm#1559), which also pins it against an
    explicit-tree comparator kernel.
    """
    if not mx.metal.is_available():
        return None

    source = r"""
        constexpr int lanes_per_row = 4;
        constexpr int rows_per_simdgroup = 32 / lanes_per_row;
        constexpr int values_per_lane = Dk / lanes_per_row;
        constexpr int partials_per_lane = values_per_lane / 4;

        auto n = thread_position_in_grid.z;
        auto b_idx = n / Hv;
        auto hv_idx = n % Hv;
        auto hk_idx = hv_idx / (Hv / Hk);

        auto lane = thread_index_in_simdgroup;
        auto row_in_simdgroup = lane / lanes_per_row;
        auto lane_in_row = lane & (lanes_per_row - 1);
        auto row_group = thread_position_in_grid.y;
        auto dv_idx = row_group * rows_per_simdgroup + row_in_simdgroup;

        // q, k: [B, T, Hk, Dk]
        auto q_ = q + (b_idx * T * Hk + hk_idx) * Dk + lane_in_row * values_per_lane;
        auto k_ = k + (b_idx * T * Hk + hk_idx) * Dk + lane_in_row * values_per_lane;

        // v, y: [B, T, Hv, Dv]
        auto v_ = v + (b_idx * T * Hv + hv_idx) * Dv;
        y += (b_idx * T * Hv + hv_idx) * Dv;

        // state_in, state_out: [B, Hv, Dv, Dk]
        auto i_state = state_in + (n * Dv + dv_idx) * Dk + lane_in_row * values_per_lane;
        auto o_state = state_out + (n * Dv + dv_idx) * Dk + lane_in_row * values_per_lane;

        float state[values_per_lane];
        for (int i = 0; i < values_per_lane; ++i) {
          state[i] = static_cast<float>(i_state[i]);
        }

        // g, beta: [B, T, Hv]
        auto g_ = g + b_idx * T * Hv;
        auto beta_ = beta + b_idx * T * Hv;

        for (int t = 0; t < T; ++t) {
          float gt = static_cast<float>(g_[hv_idx]);

          // Partials mirror the generic kernel: each 4-element chain is one
          // original lane's sequential accumulation.
          float part[partials_per_lane];
          for (int pb = 0; pb < partials_per_lane; ++pb) {
            float acc = 0.0f;
            for (int i = 0; i < 4; ++i) {
              int e = pb * 4 + i;
              state[e] = state[e] * gt;
              acc += state[e] * static_cast<float>(k_[e]);
            }
            part[pb] = acc;
          }
          // Butterfly levels xor 1,2,4 stay inside this lane (commutative
          // pairwise tree); levels xor 8,16 become the row-group shuffles.
          float kv_mem =
              ((part[0] + part[1]) + (part[2] + part[3])) +
              ((part[4] + part[5]) + (part[6] + part[7]));
          kv_mem += simd_shuffle_xor(kv_mem, 1);
          kv_mem += simd_shuffle_xor(kv_mem, 2);

          auto delta =
              (static_cast<float>(v_[dv_idx]) - kv_mem) *
              static_cast<float>(beta_[hv_idx]);

          for (int pb = 0; pb < partials_per_lane; ++pb) {
            float acc = 0.0f;
            for (int i = 0; i < 4; ++i) {
              int e = pb * 4 + i;
              state[e] = state[e] + static_cast<float>(k_[e]) * delta;
              acc += state[e] * static_cast<float>(q_[e]);
            }
            part[pb] = acc;
          }
          float out =
              ((part[0] + part[1]) + (part[2] + part[3])) +
              ((part[4] + part[5]) + (part[6] + part[7]));
          out += simd_shuffle_xor(out, 1);
          out += simd_shuffle_xor(out, 2);
          if (lane_in_row == 0) {
            y[dv_idx] = static_cast<InT>(out);
          }

          q_ += Hk * Dk;
          k_ += Hk * Dk;
          v_ += Hv * Dv;
          y += Hv * Dv;
          g_ += Hv;
          beta_ += Hv;
        }

        for (int i = 0; i < values_per_lane; ++i) {
          o_state[i] = static_cast<StT>(state[i]);
        }
    """
    return mx.fast.metal_kernel(
        name="gated_delta_step_packed_btree",
        input_names=["q", "k", "v", "g", "beta", "state_in", "T"],
        output_names=["y", "state_out"],
        source=source,
    )


_gated_delta_kernel = _make_gated_delta_kernel(has_mask=False, vectorized=False)
_gated_delta_kernel_masked = _make_gated_delta_kernel(has_mask=True, vectorized=False)
_gated_delta_kernel_vec = _make_gated_delta_kernel(has_mask=False, vectorized=True)
_gated_delta_kernel_vec_masked = _make_gated_delta_kernel(
    has_mask=True, vectorized=True
)
_gated_delta_kernel_packed = _make_gated_delta_packed_kernel()


@mx.compile
def _gated_delta_step_ops(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    g: mx.array,
    beta: mx.array,
    state: mx.array,
    mask: Optional[mx.array] = None,
) -> Tuple[mx.array, mx.array]:
    """
    Ops-based reference implementation for a single recurrent step.

    Shapes:
      - q, k: [B, H, Dk]
      - v: [B, H, Dv]
      - g: [B, H] or [B, H, Dk]
      - beta: [B, H]
      - state: [B, H, Dv, Dk]
    Returns:
      - y: [B, H, Dv]
      - new_state: [B, H, Dv, Dk]
    """

    # Decay
    old_state = state
    if g.ndim == 2:
        decay = g[..., None, None]
    elif g.ndim == 3:
        decay = g[..., None, :]
    else:
        raise ValueError(f"Unsupported gating shape {g.shape}")
    state = state * decay
    kv_mem = (state * k[..., None, :]).sum(axis=-1)  # [B, H, Dv]
    delta = (v - kv_mem) * beta[..., None]  # [B, H, Dv]
    state = state + k[..., None, :] * delta[..., None]
    # Output projection along key dim with q
    y = (state * q[..., None, :]).sum(axis=-1)  # [B, H, Dv]

    if mask is not None:
        mask = mx.expand_dims(mask, axis=(1, 2, 3))
        state = mx.where(mask, state, old_state)
    return y.astype(q.dtype), state


def gated_delta_kernel(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    g: mx.array,
    beta: mx.array,
    state: mx.array,
    mask: Optional[mx.array] = None,
) -> Tuple[mx.array, mx.array]:
    B, T, Hk, Dk = k.shape
    Hv, Dv = v.shape[2:]
    input_type = q.dtype
    state_type = state.dtype
    grid = (32, Dv, B * Hv)
    threadgroup = (32, 4, 1)
    if (
        _gated_delta_kernel_packed is not None
        and T > 1  # one-token decode stays on the generic kernel
        and mask is None
        and g.ndim == 3
        and Dk == 128
        and Dv % 8 == 0
        and g.dtype == mx.float32
        and state.dtype == mx.float32
    ):
        # Eight value rows per SIMD-group, four lanes per row (see
        # _make_gated_delta_packed_kernel).
        kernel = _gated_delta_kernel_packed
        inputs = [q, k, v, g, beta, state, T]
        grid = (32, Dv // 8, B * Hv)
        threadgroup = (32, 2, 1)
    elif g.ndim == 4:
        kernel = _gated_delta_kernel_vec
        inputs = [q, k, v, g, beta, state, T]
        if mask is not None:
            kernel = _gated_delta_kernel_vec_masked
            inputs.append(mask)
    else:
        kernel = _gated_delta_kernel
        inputs = [q, k, v, g, beta, state, T]
        if mask is not None:
            kernel = _gated_delta_kernel_masked
            inputs.append(mask)

    return kernel(
        inputs=inputs,
        template=[
            ("InT", input_type),
            ("StT", state_type),
            ("Dk", Dk),
            ("Dv", Dv),
            ("Hk", Hk),
            ("Hv", Hv),
        ],
        grid=grid,
        threadgroup=threadgroup,
        output_shapes=[(B, T, Hv, Dv), state.shape],
        output_dtypes=[input_type, state_type],
    )


def gated_delta_ops(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    g: mx.array,
    beta: mx.array,
    state: Optional[mx.array] = None,
    mask: Optional[mx.array] = None,
) -> Tuple[mx.array, mx.array]:
    """
    Ops-based reference implementation for prompt prefill (sequential loop).
    Supports both scalar and vectorized gating.

    Shapes:
      - q, k: [B, T, Hk, Dk]
      - v: [B, T, Hv, Dv]
      - g: [B, T, Hv] (scalar) or [B, T, Hv, Dk] (vectorized)
      - beta: [B, T, Hv]
      - state: [B, Hv, Dv, Dk]
    Returns:
      - y: [B, T, Hv, Dv]
      - state: [B, Hv, Dv, Dk]
    """
    B, T, Hk, Dk = q.shape
    Hv, Dv = v.shape[-2:]
    if state is None:
        state = mx.zeros((B, Hv, Dv, Dk), dtype=mx.float32)

    if (repeat_factor := Hv // Hk) > 1:
        q = mx.repeat(q, repeat_factor, -2)
        k = mx.repeat(k, repeat_factor, -2)

    ys = []
    for t in range(T):
        y, state = _gated_delta_step_ops(
            q[:, t],
            k[:, t],
            v[:, t],
            g[:, t],
            beta[:, t],
            state,
            None if mask is None else mask[:, t],
        )
        ys.append(y)
    y = mx.stack(ys, axis=1)
    return y, state


@partial(mx.compile, shapeless=True)
def compute_g(A_log, a, dt_bias):
    return mx.exp(-mx.exp(A_log.astype(mx.float32)) * nn.softplus(a + dt_bias))


@partial(mx.compile, shapeless=True)
def _compute_g_beta(A_log, a, b, dt_bias):
    return compute_g(A_log, a, dt_bias), mx.sigmoid(b)


def _invert_unit_lower(Tmat: mx.array, C: int) -> mx.array:
    """Inverse of a batched unit lower-triangular matrix ``Tmat`` (``[..., C, C]``,
    unit diagonal) via forward substitution, batched over all chunks/heads.

    Sequential in C (small, fixed) but numerically stable. A log-depth
    repeated-squaring (Neumann) inverse is faster but overflows when N has
    O(1) entries — exactly the regime here, since correlated keys give KK
    off-diagonals ~1."""
    X = mx.broadcast_to(mx.eye(C, dtype=mx.float32), Tmat.shape) + mx.zeros_like(Tmat)
    rows = [X[..., 0:1, :]]
    for i in range(1, C):
        Tij = Tmat[..., i : i + 1, :i]
        Xj = mx.concatenate(rows, axis=-2)
        rows.append(X[..., i : i + 1, :] - Tij @ Xj)
    return mx.concatenate(rows, axis=-2)


def gated_delta_chunked(q, k, v, g, beta, state, mask=None, C: int = 64):
    """Chunked parallel gated-delta-rule prefill (scalar per-head gating).

    Mathematically equivalent to the sequential ``gated_delta_ops`` recurrence
    but replaces the per-token loop (O(T) sequential ops) with a chunked scan:
    parallel intra-chunk matmuls + a C-length triangular solve + a T/C-step
    inter-chunk state scan. ~20x faster than the per-token loop on CUDA, where
    no fused Metal kernel is available. Validated to rel-err < 1e-3 (fp32) vs
    the reference, well within bf16 precision.
    """
    B, T, Hk, Dk = q.shape
    Hv, Dv = v.shape[-2:]
    in_dtype = v.dtype
    if (rf := Hv // Hk) > 1:
        q = mx.repeat(q, rf, -2)
        k = mx.repeat(k, rf, -2)
    # masked (padding) positions: no decay, no update -> g=1, beta=0
    if mask is not None:
        m = mask[..., None]
        g = mx.where(m, g, 1.0)
        beta = mx.where(m, beta, 0.0)

    pad = (C - T % C) % C
    if pad:
        q = mx.concatenate([q, mx.zeros((B, pad, Hv, Dk), q.dtype)], axis=1)
        k = mx.concatenate([k, mx.zeros((B, pad, Hv, Dk), k.dtype)], axis=1)
        v = mx.concatenate([v, mx.zeros((B, pad, Hv, Dv), v.dtype)], axis=1)
        g = mx.concatenate([g, mx.ones((B, pad, Hv), g.dtype)], axis=1)
        beta = mx.concatenate([beta, mx.zeros((B, pad, Hv), beta.dtype)], axis=1)
    Tp = T + pad
    nC = Tp // C

    def rc(x, D):
        return x.reshape(B, nC, C, Hv, D).transpose(0, 3, 1, 2, 4).astype(mx.float32)

    q, k, v = rc(q, Dk), rc(k, Dk), rc(v, Dv)  # [B,Hv,nC,C,D]
    g = g.reshape(B, nC, C, Hv).transpose(0, 3, 1, 2)  # [B,Hv,nC,C]
    beta = beta.reshape(B, nC, C, Hv).transpose(0, 3, 1, 2)

    # clip g off 0: compute_g can underflow to exactly 0.0 in fp32, and
    # log(0)=-inf would poison the decay ratios with NaN.
    lcg = mx.cumsum(mx.log(mx.clip(g, 1e-6, 1.0)), axis=-1)  # log cumulative decay
    cumg = mx.exp(lcg)
    lower_incl = mx.tril(mx.ones((C, C), mx.float32), 0)
    strict_lower = mx.tril(mx.ones((C, C), mx.float32), -1)
    # decay_ratio[i,j]=cumg_i/cumg_j; mask exponent to lower triangle BEFORE exp
    # (upper triangle would overflow since g<1, and inf*0=nan).
    diff = mx.where(lower_incl > 0, lcg[..., :, None] - lcg[..., None, :], -1e30)
    dr = mx.exp(diff)

    KK = k @ mx.swapaxes(k, -1, -2)
    A = beta[..., :, None] * dr * KK * strict_lower
    Tinv = _invert_unit_lower(mx.eye(C, dtype=mx.float32) + A, C)

    kbeta = (beta * cumg)[..., :, None] * k
    U0 = Tinv @ (beta[..., :, None] * v)  # [B,Hv,nC,C,Dv]
    Kt = Tinv @ kbeta  # [B,Hv,nC,C,Dk]
    M = dr * (q @ mx.swapaxes(k, -1, -2)) * lower_incl
    Qeff = cumg[..., :, None] * q - M @ Kt
    MU0 = M @ U0
    cumg_last = cumg[..., -1]
    ratio_last = mx.exp(lcg[..., -1, None] - lcg)  # cumg_last/cumg_i

    S = (
        state.astype(mx.float32)
        if state is not None
        else mx.zeros((B, Hv, Dv, Dk), mx.float32)
    )
    ys = []
    for c in range(nC):
        St = mx.swapaxes(S, -1, -2)  # [B,Hv,Dk,Dv]
        ys.append(MU0[:, :, c] + Qeff[:, :, c] @ St)  # [B,Hv,C,Dv]
        Uc = U0[:, :, c] - Kt[:, :, c] @ St
        Uscaled = ratio_last[:, :, c][..., None] * Uc
        S = (
            cumg_last[:, :, c][..., None, None] * S
            + mx.swapaxes(Uscaled, -1, -2) @ k[:, :, c]
        )
    Y = mx.stack(ys, axis=2).transpose(0, 2, 3, 1, 4).reshape(B, Tp, Hv, Dv)[:, :T]
    Y = Y.astype(in_dtype)
    # Schedule this (large, dynamically-shaped) prefill subgraph for evaluation
    # so it is NOT folded into the server's captured CUDA graph — that capture
    # chokes on it (cudaGraphAddDependencies). async_eval breaks the graph at
    # this boundary without blocking the Python thread, letting graph-building
    # for the next layer overlap with GPU compute. Decode (T==1) never calls
    # this path, so its CUDA graphs stay intact.
    try:
        mx.async_eval(Y, S)
    except ValueError as exc:
        if "Not allowed inside a graph transformation" not in str(exc):
            raise
    return Y, S


def gated_delta_update(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    a: mx.array,
    b: mx.array,
    A_log: mx.array,
    dt_bias: mx.array,
    state: Optional[mx.array] = None,
    mask: Optional[mx.array] = None,
    use_kernel: bool = True,
    state_steps: Optional[int] = None,
    cache=None,
    cache_index: int = 1,
):
    if cache is not None:
        if state is not None or state_steps is not None:
            raise ValueError("The cache owns recurrent state and history retention.")
        return cache.update_recurrent(
            cache_index,
            q.shape[1],
            lambda initial, steps: gated_delta_update(
                q,
                k,
                v,
                a,
                b,
                A_log,
                dt_bias,
                state=(
                    initial
                    if initial is None or initial.shape[0] == q.shape[0]
                    else None
                ),
                mask=mask,
                use_kernel=use_kernel,
                state_steps=steps,
            ),
        )
    if state_steps is not None:
        return gated_delta_update_with_states(
            q,
            k,
            v,
            a,
            b,
            A_log,
            dt_bias,
            state,
            mask,
            use_kernel=use_kernel,
            state_steps=state_steps,
        )
    g, beta = _compute_g_beta(A_log, a, b, dt_bias)
    if state is None:
        B, _, _Hk, Dk = q.shape
        Hv, Dv = v.shape[-2:]
        state = mx.zeros((B, Hv, Dv, Dk), dtype=mx.float32)

    if not use_kernel or mx.default_device() != mx.gpu or not mx.metal.is_available():
        # Prefill (T>1) with scalar gating: use the chunked parallel scan, which
        # is ~20x faster than the per-token loop on backends without a fused
        # kernel (e.g. CUDA). Decode (T==1) and vectorized gating fall back to
        # the reference ops.
        if q.shape[1] > 1 and g.ndim == 3:
            return gated_delta_chunked(q, k, v, g, beta, state, mask)
        return gated_delta_ops(q, k, v, g, beta, state, mask)
    return gated_delta_kernel(q, k, v, g, beta, state, mask)


def _make_gated_delta_with_states_kernel(has_mask: bool = False):
    if not mx.metal.is_available():
        return None

    mask_source = "mask[b_idx * T + t]" if has_mask else "true"
    source = f"""
        auto n = thread_position_in_grid.z;
        auto b_idx = n / Hv;
        auto hv_idx = n % Hv;
        auto hk_idx = hv_idx / (Hv / Hk);
        constexpr int n_per_t = Dk / 32;

        auto q_ = q + b_idx * T * Hk * Dk + hk_idx * Dk;
        auto k_ = k + b_idx * T * Hk * Dk + hk_idx * Dk;

        auto v_ = v + b_idx * T * Hv * Dv + hv_idx * Dv;
        y += b_idx * T * Hv * Dv + hv_idx * Dv;
        states += ((b_idx * StateT * Hv + hv_idx) * Dv) * Dk;

        auto dk_idx = thread_position_in_threadgroup.x;
        auto dv_idx = thread_position_in_grid.y;

        auto i_state = state_in + (n * Dv + dv_idx) * Dk;
        auto o_state = state_out + (n * Dv + dv_idx) * Dk;
        auto states_ = states + dv_idx * Dk;

        float state[n_per_t];
        for (int i = 0; i < n_per_t; ++i) {{
            auto s_idx = n_per_t * dk_idx + i;
            state[i] = static_cast<float>(i_state[s_idx]);
        }}

        auto g_ = g + b_idx * T * Hv;
        auto beta_ = beta + b_idx * T * Hv;

        for (int t = 0; t < T; ++t) {{
            if ({mask_source}) {{
                float kv_mem = 0.0f;
                for (int i = 0; i < n_per_t; ++i) {{
                    auto s_idx = n_per_t * dk_idx + i;
                    state[i] = state[i] * g_[hv_idx];
                    kv_mem += state[i] * k_[s_idx];
                }}
                kv_mem = simd_sum(kv_mem);

                auto delta = (v_[dv_idx] - kv_mem) * beta_[hv_idx];

                float out = 0.0f;
                for (int i = 0; i < n_per_t; ++i) {{
                    auto s_idx = n_per_t * dk_idx + i;
                    state[i] = state[i] + k_[s_idx] * delta;
                    out += state[i] * q_[s_idx];
                }}
                out = simd_sum(out);
                if (thread_index_in_simdgroup == 0) {{
                    y[dv_idx] = static_cast<InT>(out);
                }}
            }} else {{
                y[dv_idx] = static_cast<InT>(0);
            }}

            if (t < StateT) {{
                for (int i = 0; i < n_per_t; ++i) {{
                    auto s_idx = n_per_t * dk_idx + i;
                    states_[s_idx] = static_cast<StT>(state[i]);
                }}
            }}

            q_ += Hk * Dk;
            k_ += Hk * Dk;
            v_ += Hv * Dv;
            y += Hv * Dv;
            if (t < StateT) {{
                states_ += Hv * Dv * Dk;
            }}
            g_ += Hv;
            beta_ += Hv;
        }}

        for (int i = 0; i < n_per_t; ++i) {{
            auto s_idx = n_per_t * dk_idx + i;
            o_state[s_idx] = static_cast<StT>(state[i]);
        }}
    """
    inputs = ["q", "k", "v", "g", "beta", "state_in", "T"]
    if has_mask:
        inputs.append("mask")
    suffix = "_mask" if has_mask else ""
    return mx.fast.metal_kernel(
        name=f"qwen3_5_gated_delta_with_states{suffix}",
        input_names=inputs,
        output_names=["y", "state_out", "states"],
        source=source,
    )


_gated_delta_with_states_kernel = _make_gated_delta_with_states_kernel(False)
_gated_delta_with_states_kernel_masked = _make_gated_delta_with_states_kernel(True)


def _gated_delta_with_states_ops(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    g: mx.array,
    beta: mx.array,
    state: mx.array,
    mask: Optional[mx.array] = None,
    state_steps: Optional[int] = None,
):
    B, T, Hk, _Dk = q.shape
    Hv = v.shape[-2]
    state_steps = T if state_steps is None else int(state_steps)
    if (repeat_factor := Hv // Hk) > 1:
        q = mx.repeat(q, repeat_factor, -2)
        k = mx.repeat(k, repeat_factor, -2)

    ys = []
    states = []
    for t in range(T):
        old_state = state
        decay = g[:, t, :, None, None]
        state = state * decay
        kv_mem = (state * k[:, t, :, None, :]).sum(axis=-1)
        delta = (v[:, t] - kv_mem) * beta[:, t, :, None]
        state = state + k[:, t, :, None, :] * delta[..., None]
        y = (state * q[:, t, :, None, :]).sum(axis=-1)

        if mask is not None:
            valid = mask[:, t]
            state = mx.where(valid[:, None, None, None], state, old_state)
            y = mx.where(valid[:, None, None], y, 0)

        ys.append(y.astype(q.dtype))
        if t < state_steps:
            states.append(state)
    if states:
        stacked_states = mx.stack(states, axis=1)
    else:
        stacked_states = mx.zeros((B, 0, *state.shape[1:]), dtype=state.dtype)
    return mx.stack(ys, axis=1), state, stacked_states


def gated_delta_update_with_states(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    a: mx.array,
    b: mx.array,
    A_log: mx.array,
    dt_bias: mx.array,
    state: Optional[mx.array] = None,
    mask: Optional[mx.array] = None,
    use_kernel: bool = True,
    state_steps: Optional[int] = None,
):
    g, beta = _compute_g_beta(A_log, a, b, dt_bias)
    B, T, Hk, Dk = k.shape
    state_steps = T if state_steps is None else int(state_steps)
    if not 0 <= state_steps <= T:
        raise ValueError("state_steps must be between zero and the sequence length.")
    if state is None:
        Hv, Dv = v.shape[-2:]
        state = mx.zeros((B, Hv, Dv, Dk), dtype=mx.float32)

    if (
        g.ndim != 3
        or not use_kernel
        or mx.default_device() != mx.gpu
        or not mx.metal.is_available()
    ):
        return _gated_delta_with_states_ops(q, k, v, g, beta, state, mask, state_steps)

    Hv, Dv = v.shape[2:]

    input_type = q.dtype
    state_type = state.dtype
    kernel = _gated_delta_with_states_kernel
    inputs = [q, k, v, g, beta, state, T]
    if mask is not None:
        kernel = _gated_delta_with_states_kernel_masked
        inputs.append(mask)
    if kernel is None:
        return _gated_delta_with_states_ops(q, k, v, g, beta, state, mask, state_steps)

    return kernel(
        inputs=inputs,
        template=[
            ("InT", input_type),
            ("StT", state_type),
            ("Dk", Dk),
            ("Dv", Dv),
            ("Hk", Hk),
            ("Hv", Hv),
            ("StateT", state_steps),
        ],
        grid=(32, Dv, B * Hv),
        threadgroup=(32, 4, 1),
        output_shapes=[(B, T, Hv, Dv), state.shape, (B, state_steps, Hv, Dv, Dk)],
        output_dtypes=[input_type, state_type, state_type],
    )
