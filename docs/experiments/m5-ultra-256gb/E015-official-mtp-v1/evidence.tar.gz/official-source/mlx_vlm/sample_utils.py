# Copyright 2023-2024 Apple Inc.

import math
from functools import partial
from typing import Callable, Dict, List, Optional

import mlx.core as mx

MIN_SAMPLING_TEMPERATURE = 0.01


def clamp_temperature(temperature: float) -> float:
    """Clamp positive sampling temperatures, preserving zero for greedy decoding."""
    if 0 < temperature < MIN_SAMPLING_TEMPERATURE:
        return MIN_SAMPLING_TEMPERATURE
    return temperature


def make_sampler(
    temp: float = 0.0,
    top_p: float = 0.0,
    min_p: float = 0.0,
    min_tokens_to_keep: int = 1,
    top_k: int = 0,
    top_n_sigma: float = 0.0,
    p_less: bool = False,
    typical_p: float = 1.0,
    xtc_probability: float = 0.0,
    xtc_threshold: float = 0.0,
    xtc_special_tokens: Optional[List[int]] = None,
) -> Callable[[mx.array], mx.array]:
    """
    Make a sampler function for use with ``generate_step``.

    Args:
        temp (float): The temperature for sampling, if 0 the argmax is used.
          Positive values below 0.01 are clamped to 0.01. Default: ``0``.
        top_p (float, optional): Nucleus sampling, higher means model considers
          more less likely words.
        min_p (float, optional): The minimum value (scaled by the top token's
          probability) that a token probability must have to be considered.
        min_tokens_to_keep (int, optional): Minimum number of tokens that cannot
          be filtered by min_p sampling.
        top_k (int, optional): The top k tokens ranked by probability to constrain
          the sampling to.
        top_n_sigma (float, optional): Top-nσ sampling. Keeps only tokens whose
          logit is within ``top_n_sigma`` standard deviations of the max logit
          (``logit >= max - top_n_sigma * std``), computed on the raw logits.
          ``0`` disables it. Typical values ~0.5-2.0; smaller is more selective.
        p_less (bool, optional): Hyperparameter-free p-less sampling. Keeps
          tokens whose probability is at least the collision probability
          (sum of squared probabilities) of the temperature-scaled
          distribution. Default: ``False``.
        typical_p (float, optional): Locally typical sampling. Keeps the most
          typical tokens (surprisal closest to the distribution entropy) until
          their cumulative probability reaches ``typical_p``. ``1.0`` disables.
        xtc_probability (float, optional): The probability of applying XTC
            sampling.
        xtc_threshold (float, optional): The threshold the probs need to reach
            for being sampled.
        xtc_special_tokens (list(int), optional): List of special tokens IDs to
            be excluded from XTC sampling.


    Returns:
        Callable[mx.array, mx.array]:
            A sampler which takes log-probabilities and returns tokens.
    """
    if xtc_special_tokens is None:
        xtc_special_tokens = []

    if temp == 0:
        return lambda x: mx.argmax(x, axis=-1)

    temp = clamp_temperature(temp)
    sampling_methods = []
    if top_n_sigma > 0.0:
        sampling_methods.append(lambda x: apply_top_n_sigma(x, top_n_sigma))
    if p_less:
        sampling_methods.append(lambda x: apply_p_less(x, temp))
    if typical_p > 0.0 and typical_p < 1.0:
        sampling_methods.append(lambda x: apply_typical_p(x, typical_p))
    if top_p > 0 and top_p < 1.0:
        sampling_methods.append(lambda x: apply_top_p(x, top_p))
    if min_p != 0.0:
        sampling_methods.append(lambda x: apply_min_p(x, min_p, min_tokens_to_keep))
    if xtc_probability > 0.0:
        sampling_methods.append(
            lambda x: apply_xtc(x, xtc_probability, xtc_threshold, xtc_special_tokens)
        )
    if top_k > 0:
        sampling_methods.append(lambda x: apply_top_k(x, top_k))

    def sampler(logprobs):
        for method in sampling_methods:
            logprobs = method(logprobs)
        return categorical_sampling(logprobs, temp)

    return sampler


def make_logits_processors(
    logit_bias: Optional[Dict[int, float]] = None,
    repetition_penalty: Optional[float] = None,
    repetition_context_size: Optional[int] = 20,
    presence_penalty: Optional[float] = None,
    presence_context_size: Optional[int] = 20,
    frequency_penalty: Optional[float] = None,
    frequency_context_size: Optional[int] = 20,
):
    """
    Make logits processors for use with ``generate_step``.

    Args:
        repetition_penalty (float, optional): A (sign-aware) multiplicative
          penalty for repeating tokens.
        repetition_context_size (int, optional): The number of tokens to
          consider for repetition penalty. Default: ``20``.
        presence_penalty (float, optional): An additive penalty to reduce
          repeating tokens.
        presence_context_size (int, optional): The number of tokens to consider
          for the presence penalty. Default: ``20``.
        frequency_penalty (float, optional): An additive penalty to reduce
          repeating tokens. The tokens are penalized proportionally to their
          frequency.
        frequency_context_size (int, optional): The number of tokens to consider
          for the frequency penalty. Default: ``20``.
        logit_bias (dictionary, optional): Additive logit bias.

    Returns:
        List[Callable[[mx.array, mx.array], mx.array]]:
            A list of logits processors. Each processor in the list is a
            callable which takes an array of tokens and an array of logits
            and returns the updated logits.
    """
    logits_processors = []
    if logit_bias:
        indices = mx.array(list(logit_bias.keys()))
        values = mx.array(list(logit_bias.values()))

        def logit_bias_processor(_, logits):
            return logits.at[:, indices].add(values)

        logits_processors.append(logit_bias_processor)

    repetition_penalties = [
        (make_repetition_penalty, repetition_penalty, repetition_context_size),
        (make_presence_penalty, presence_penalty, presence_context_size),
        (make_frequency_penalty, frequency_penalty, frequency_context_size),
    ]

    for make_penalty, penalty, context_size in repetition_penalties:
        if penalty is not None and penalty != 0:
            logits_processors.append(make_penalty(penalty, context_size))

    return logits_processors


def apply_top_k(
    logprobs: mx.array,
    top_k: int,
) -> mx.array:
    """
    Sample from only the top K tokens ranked by probability.

    Args:
        logprobs: A vector of log probabilities.
        top_k (int): Top k tokens to sample from.
    """
    vocab_size = logprobs.shape[-1]
    if not isinstance(top_k, int) or not (0 < top_k < vocab_size):
        raise ValueError(
            f"`top_k` has to be an integer in the (0, {vocab_size}] interval,"
            f" but is {top_k}."
        )
    return _apply_top_k(logprobs, top_k)


@partial(mx.compile, inputs=mx.random.state, outputs=mx.random.state)
def _apply_top_k(logprobs: mx.array, top_k: int) -> mx.array:
    mask_idx = mx.argpartition(-logprobs, kth=top_k - 1, axis=-1)[..., top_k:]
    masked_logprobs = mx.put_along_axis(
        logprobs, mask_idx, mx.array(-float("inf"), logprobs.dtype), axis=-1
    )
    return masked_logprobs


def apply_top_n_sigma(logits: mx.array, n_sigma: float) -> mx.array:
    """
    Apply top-nσ sampling to the logits.

    Keeps only tokens whose logit lies within ``n_sigma`` standard deviations of
    the maximum logit, i.e. ``logit >= max - n_sigma * std``, where ``max`` and
    ``std`` are taken over the raw (pre-softmax) logits. Because it thresholds
    the logits directly, it is invariant to temperature scaling.

    Paper: "Top-nσ: Not All Logits Are You Need" (https://arxiv.org/abs/2411.07641).

    Args:
        logits: A vector of logits.
        n_sigma (float): Number of standard deviations below the max logit to
            keep. Must be non-negative. Smaller is more selective; typical
            values are in the ~0.5-2.0 range.
    """
    if n_sigma < 0:
        raise ValueError(
            f"`top_n_sigma` has to be a non-negative float, but is {n_sigma}"
        )
    return _top_n_sigma(logits, n_sigma)


@mx.compile
def _top_n_sigma(logits: mx.array, n_sigma: float) -> mx.array:
    f = logits.astype(mx.float32)
    top_logit = mx.max(f, axis=-1, keepdims=True)
    std = mx.std(f, axis=-1, keepdims=True)
    threshold = top_logit - n_sigma * std
    return mx.where(f < threshold, -float("inf"), logits)


@mx.compile
def apply_p_less(logits: mx.array, temp: float) -> mx.array:
    """
    Apply hyperparameter-free p-less sampling to the logits.

    Keeps tokens whose probability is at least the collision probability
    ``L = sum_v p(v)**2`` of the temperature-scaled distribution ``p``, i.e.
    ``exp(-H2(p))`` where ``H2`` is the order-2 Renyi (collision) entropy. Since
    ``L <= max_v p(v)``, the most likely token always survives.

    Paper: "p-less Sampling: A Robust Hyperparameter-Free Approach for LLM
    Decoding" (https://arxiv.org/abs/2509.23234).

    Args:
        logits: A vector of logits.
        temp (float): Sampling temperature applied before forming the
            distribution used to compute the threshold.
    """
    probs = mx.softmax(logits * (1.0 / temp), axis=-1)
    threshold = mx.sum(probs * probs, axis=-1, keepdims=True)
    return mx.where(probs < threshold, -float("inf"), logits)


def apply_min_p(
    logprobs: mx.array,
    min_p: float,
    min_tokens_to_keep: int = 1,
) -> mx.array:
    """
    Apply min-p sampling to the logprobs.

    Min-p keeps all tokens that are above a minimum probability, scaled by the
    probability of the most likely token. As a result, the filter is more
    aggressive given a very high-probability token.

    Args:
        logprobs: A vector of log probabilities.
        min_p (float): Minimum token probability. Typical values are in the
            0.01-0.2 range, comparably selective as setting `top_p` in the
            0.99-0.8 range.
        min_tokens_to_keep (int, optional): Minimum number of tokens that cannot
            be filtered. Default: ``1``.

    """
    if not (0 <= min_p <= 1.0):
        raise ValueError(
            f"`min_p` has to be a float in the [0, 1] interval, but is {min_p}"
        )
    if not isinstance(min_tokens_to_keep, int) or (min_tokens_to_keep < 1):
        raise ValueError(
            f"`min_tokens_to_keep` has to be a positive integer, but is {min_tokens_to_keep}"
        )
    return _apply_min_p(logprobs, min_p, min_tokens_to_keep)


@partial(mx.compile, inputs=mx.random.state, outputs=mx.random.state)
def _apply_min_p(
    logprobs: mx.array,
    min_p: float,
    min_tokens_to_keep: int = 1,
) -> mx.array:
    top_logprobs = mx.max(logprobs, axis=-1, keepdims=True)
    scaled_min_p = top_logprobs + math.log(min_p)
    tokens_to_remove = logprobs < scaled_min_p

    if min_tokens_to_keep > 1:
        top_indices = mx.argpartition(logprobs, kth=-min_tokens_to_keep, axis=-1)
        top_indices = top_indices[..., -min_tokens_to_keep:]
        tokens_to_remove = mx.put_along_axis(
            tokens_to_remove,
            top_indices,
            False,
            axis=-1,
        )

    return mx.where(tokens_to_remove, -float("inf"), logprobs)


@partial(mx.compile, inputs=mx.random.state, outputs=mx.random.state)
def apply_top_p(logprobs: mx.array, top_p: float) -> mx.array:
    """
    Apply top-p (nucleus) sampling to logits.

    Args:
        logprobs: A vector of log probabilities.
        top_p: The cumulative probability threshold for top-p filtering.
    Returns:
        Log probabilities with tokens outside the nucleus masked to -inf.
    """
    # An exclusive reverse scan keeps the maximum for any
    # positive top_p without subtracting a tiny probability from 1.
    sorted_logprobs = mx.sort(logprobs, axis=-1)
    sorted_probs = mx.exp(sorted_logprobs.astype(mx.float32))
    mass_above = mx.cumsum(sorted_probs, axis=-1, reverse=True, inclusive=False)
    total_mass = mass_above[..., :1] + sorted_probs[..., :1]
    num_dropped = (mass_above >= top_p * total_mass).sum(axis=-1, keepdims=True)
    threshold = mx.take_along_axis(sorted_logprobs, num_dropped, axis=-1)
    return mx.where(logprobs < threshold, -float("inf"), logprobs)


def apply_typical_p(logprobs: mx.array, typical_p: float) -> mx.array:
    """Locally typical sampling (https://arxiv.org/abs/2202.00666)."""
    if not (0.0 < typical_p <= 1.0):
        raise ValueError(
            f"`typical_p` has to be a float in the (0, 1] interval, but is {typical_p}"
        )
    return _typical_p(logprobs, typical_p)


@partial(mx.compile, inputs=mx.random.state, outputs=mx.random.state)
def _typical_p(logprobs: mx.array, typical_p: float) -> mx.array:
    # Sum in float32: a float16/bfloat16 running sum stops growing once the
    # remaining probabilities are below its precision.
    f = logprobs.astype(mx.float32)
    p = mx.exp(f)
    ent = -mx.sum(p * f, axis=-1, keepdims=True)
    shifted = mx.abs(-f - ent)
    sorted_indices = mx.argsort(shifted, axis=-1)
    sorted_probs = mx.take_along_axis(p, sorted_indices, axis=-1)
    cumulative_probs = mx.cumsum(sorted_probs, axis=-1)
    inverse_indices = mx.put_along_axis(
        mx.zeros_like(sorted_indices),
        sorted_indices,
        mx.arange(sorted_indices.shape[-1], dtype=sorted_indices.dtype),
        axis=-1,
    )
    cumulative_probs = mx.take_along_axis(cumulative_probs, inverse_indices, axis=-1)
    return mx.where(cumulative_probs - p < typical_p, logprobs, -float("inf"))


@partial(mx.compile, inputs=mx.random.state, outputs=mx.random.state)
def apply_xtc(
    logits: mx.array,
    xtc_probability: float,
    xtc_threshold: float,
    xtc_special_tokens: List[int],
) -> mx.array:
    """
    Apply XTC sampling to the logits.

    Args:
        logits: The logits from the model's output.
        xtc_probability (float): Probability of XTC sampling to happen for each token.
        xtc_threshold (float): The threshold the probs need to reach for being sampled.
        xtc_special_tokens (list(int)): List of special token IDs to exclude from XTC sampling.
    """
    if not (0 <= xtc_threshold <= 0.5):
        raise ValueError(
            f"`threshold` has to be a float in the [0, 0.5] interval, but is {xtc_threshold}"
        )
    if not (0 <= xtc_probability <= 1.0):
        raise ValueError(
            f"`probability` has to be a float in the [0, 1] interval, but is {xtc_probability}"
        )

    probs = mx.softmax(logits, -1)
    mask = probs > mx.where(probs > xtc_threshold, probs, mx.inf).min()
    if xtc_special_tokens:
        mask[..., xtc_special_tokens] = False

    return mx.where(
        mx.random.uniform(0, 1) > xtc_probability,
        logits,
        mx.where(mask, -mx.inf, logits),
    )


@partial(mx.compile, inputs=mx.random.state, outputs=mx.random.state)
def categorical_sampling(logits, temp):
    return mx.random.categorical(logits * (1 / temp))


def make_repetition_penalty(penalty: float, context_size: int = 20):
    """
    Make repetition penalty processor.

    Paper: https://arxiv.org/abs/1909.05858

    Args:
        penalty (float): The repetition penalty factor to be applied.
        context_size (int): The number of previous tokens to use.
            Default: ``20``.

    Returns:
        Callable[[mx.array, List[int]], mx.array]:
            The repetition penalty processor.
    """
    if penalty < 0 or not isinstance(penalty, (int, float)):
        raise ValueError(f"penalty must be a non-negative float, got {penalty}")

    def repetition_penalty_processor(tokens, logits):
        if len(tokens) > 0:
            tokens = tokens[-context_size:]
            selected_logits = logits[:, tokens]
            selected_logits = mx.where(
                selected_logits < 0,
                selected_logits * penalty,
                selected_logits / penalty,
            )
            logits[:, tokens] = selected_logits
        return logits

    return repetition_penalty_processor


def make_presence_penalty(penalty: float, context_size: int = 20):
    """
    Make a presence penalty processor.

    Corresponds to the OpenAI option with the same name. Namely, subtracts
    ``penalty`` from a logit if the token has occurred at least once in the
    ``context_size`` previous tokens.

    Args:
        penalty (float): The presence penalty to be applied.
        context_size (int): The number of previous tokens to use.
            Default: ``20``.

    Returns:
        Callable[[mx.array, List[int]], mx.array]
    """

    def presence_penalty_processor(tokens, logits):
        if len(tokens) > 0:
            tokens = tokens[-context_size:]
            logits[:, tokens] -= penalty
        return logits

    return presence_penalty_processor


def make_frequency_penalty(penalty: float, context_size: int = 20):
    """
    Make a frequency penalty processor.

    Corresponds to the OpenAI option with the same name. Namely, subtracts
    ``penalty`` from a logit for every time that the token has occurred in the
    ``context_size`` previous tokens.

    The difference with the presence penalty is that the more often a token
    occurs the more it will be penalized.

    Args:
        penalty (float): The frequency penalty to be applied.
        context_size (int): The number of previous tokens to use.
            Default: ``20``.

    Returns:
        Callable[[mx.array, List[int]], mx.array]
    """

    def frequency_penalty_processor(tokens, logits):
        if len(tokens) > 0:
            tokens = tokens[-context_size:]
            logits = logits.at[:, tokens].subtract(penalty)
        return logits

    return frequency_penalty_processor


def top_p_sampling(
    logits: mx.array,
    top_p: float,
    temperature: float,
    *,
    key: Optional[mx.array] = None,
) -> mx.array:
    """
    Apply top-p (nucleus) sampling to logits.

    Args:
        logits: The logits from the model's output. Shape [..., vocab];
            commonly [vocab], [B, vocab], or [B, T, vocab] (e.g. MTP
            speculative verify output).
        top_p: The cumulative probability threshold for top-p filtering.
        temperature: Temperature parameter for softmax distribution reshaping.
            Positive values below 0.01 are clamped to 0.01; zero is greedy.
        key: Optional PRNG key for position-dependent sampling.
    Returns:
        token selected based on the top-p criterion. Shape matches logits
        with the trailing vocab axis removed (e.g. [], [B], or [B, T]).
    """
    if temperature == 0:
        return mx.argmax(logits, axis=-1)
    logits = logits.astype(mx.float32) / clamp_temperature(temperature)
    logprobs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)
    if 0 < top_p < 1:
        logprobs = apply_top_p(logprobs, top_p)
    return mx.random.categorical(logprobs, key=key)
