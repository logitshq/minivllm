import re
from dataclasses import replace
from typing import Any, List, Optional

import mlx.core as mx
import mlx.nn as nn

from ....models.base import create_attention_mask
from ....models.cache import BatchKVCache, KVCache
from ....models.qwen3_5.language import Qwen3_5DecoderLayer
from ....models.qwen3_5_moe.language import Qwen3_5MoeDecoderLayer
from ...common import _prepare_ragged_mtp_replay
from .config import Qwen3_5MTPConfig


class Qwen3_5MTPDraftModel(nn.Module):
    supports_greedy_draft_argmax = True
    prefer_requested_block_size = True
    requires_uniform_batch_acceptance = False
    supports_ragged_batch_acceptance = True

    def __init__(self, config: Qwen3_5MTPConfig):
        super().__init__()
        self.config = config
        text_config = config.text_config
        if text_config is None:
            raise ValueError("Qwen3_5MTPConfig.text_config must be set")

        hidden_size = text_config.hidden_size
        mtp_layers = int(getattr(text_config, "mtp_num_hidden_layers", 1))
        layer_config = replace(
            text_config,
            num_hidden_layers=mtp_layers,
            full_attention_interval=1,
        )
        self.fc = nn.Linear(2 * hidden_size, hidden_size, bias=False)
        self.pre_fc_norm_embedding = nn.RMSNorm(
            hidden_size, eps=text_config.rms_norm_eps
        )
        self.pre_fc_norm_hidden = nn.RMSNorm(hidden_size, eps=text_config.rms_norm_eps)
        layer_cls = (
            Qwen3_5MoeDecoderLayer
            if "moe" in getattr(text_config, "model_type", "")
            else Qwen3_5DecoderLayer
        )
        self.layers = [
            layer_cls(args=layer_config, layer_idx=0) for _ in range(mtp_layers)
        ]
        self.norm = nn.RMSNorm(hidden_size, eps=text_config.rms_norm_eps)

        self._input_embed = None
        self._input_embed_scale: float = 1.0
        self._lm_head_fn = None
        self._greedy_argmax_fn = None
        self._cache: List[KVCache] = []
        self._seed_token: Optional[mx.array] = None
        self._seed_hidden: Optional[mx.array] = None
        self._next_position: Any = 0
        self._round_appended = 0
        self._kv_valid_len: Any = 0
        self._position: Any = 0
        self._draft_round = 0

        self.accept_lens: List[int] = []
        self.draft_lens: List[int] = []

    def bind(self, target_model) -> "Qwen3_5MTPDraftModel":
        inner = None
        if hasattr(target_model, "embed_tokens"):
            inner = target_model
        elif hasattr(target_model, "model") and hasattr(
            target_model.model, "embed_tokens"
        ):
            inner = target_model.model
        elif (
            hasattr(target_model, "language_model")
            and hasattr(target_model.language_model, "model")
            and hasattr(target_model.language_model.model, "embed_tokens")
        ):
            inner = target_model.language_model.model
        if inner is None:
            raise AttributeError(
                f"Cannot find embed_tokens in {type(target_model).__name__}"
            )

        self._input_embed = inner.embed_tokens
        self._input_embed_scale = float(getattr(inner, "embed_scale", 1.0))

        lm = getattr(target_model, "language_model", target_model)
        self._lm_head_fn = (
            getattr(target_model, "lm_head", None)
            or getattr(lm, "lm_head", None)
            or self._input_embed.as_linear
        )
        self._greedy_argmax_fn = getattr(lm, "speculative_argmax_from_hidden", None)
        return self

    def make_cache(self, left_padding: Optional[List[int]] = None) -> List[KVCache]:
        if left_padding is not None:
            return [BatchKVCache(left_padding) for _ in self.layers]
        return [KVCache() for _ in self.layers]

    def reset(
        self, target_model, left_padding: Optional[List[int]] = None
    ) -> List[KVCache]:
        self.bind(target_model)
        self.accept_lens = []
        self.draft_lens = []
        self._draft_round = 0
        self._cache = self.make_cache(left_padding)
        self._seed_token = None
        self._seed_hidden = None
        self._next_position = 0
        self._round_appended = 0
        return self._cache

    def draft_eval_state(self):
        state = [self._seed_token, self._seed_hidden]
        for cache in self._cache:
            state.append(cache.state)
        return state

    def set_shared_kv(
        self,
        shared_kv_states: dict,
        kv_offset,
        position=None,
        kv_valid_len=None,
        left_padding=None,
    ) -> None:
        del shared_kv_states, left_padding
        if kv_valid_len is None:
            kv_valid_len = kv_offset
        if position is None:
            position = kv_valid_len
        self._kv_valid_len = kv_valid_len
        self._position = position
        cache_empty = not self._cache or all(cache.empty() for cache in self._cache)
        if cache_empty:
            self._next_position = kv_valid_len

    def _draft_start_position(self):
        return self._next_position

    def _position_ids(self, step: int = 0, length: int = 1) -> mx.array:
        start = self._draft_start_position()
        pos = mx.arange(length, dtype=mx.int32) + step
        if isinstance(start, int):
            return (pos + start)[None, :]
        if isinstance(start, mx.array):
            return start.astype(mx.int32)[:, None] + pos[None, :]
        return mx.array(start, dtype=mx.int32)[:, None] + pos[None, :]

    def _forward_hidden(
        self,
        token_embed: mx.array,
        hidden: mx.array,
        cache: Optional[List[KVCache]],
        position_ids: mx.array,
    ) -> mx.array:
        h = mx.concatenate(
            [
                self.pre_fc_norm_embedding(token_embed),
                self.pre_fc_norm_hidden(hidden),
            ],
            axis=-1,
        )
        h = self.fc(h)
        if cache is None:
            cache = [None] * len(self.layers)
        for layer, layer_cache in zip(self.layers, cache):
            mask = (
                create_attention_mask(h, layer_cache)
                if layer_cache is not None
                else ("causal" if h.shape[1] > 1 else None)
            )
            h = layer(h, mask=mask, cache=layer_cache, position_ids=position_ids)
        return self.norm(h)

    def _forward_tokens(
        self,
        tokens: mx.array,
        hidden: mx.array,
        token_dtype: mx.Dtype,
    ) -> mx.array:
        token_embed = (
            self._input_embed(tokens.astype(token_dtype)) * self._input_embed_scale
        )
        steps = int(tokens.shape[1])
        position_ids = self._position_ids(length=steps)
        h = self._forward_hidden(token_embed, hidden, self._cache, position_ids)
        self._next_position = (
            self._next_position + steps
            if isinstance(self._next_position, int)
            else self._next_position + steps
        )
        return h

    def _forward_token(
        self,
        tok: mx.array,
        hidden: mx.array,
        token_dtype: mx.Dtype,
    ) -> mx.array:
        return self._forward_tokens(tok, hidden, token_dtype)

    def _greedy_token(self, hidden: mx.array) -> mx.array:
        if self._greedy_argmax_fn is not None:
            token = self._greedy_argmax_fn(hidden)
            if token is not None:
                return token
        return mx.argmax(self._lm_head_fn(hidden), axis=-1)

    def _set_seed_from_hidden(self, hidden: mx.array, sampler, greedy: bool) -> None:
        if greedy:
            self._seed_token = self._greedy_token(hidden)
        else:
            self._seed_token = sampler(self._lm_head_fn(hidden))
        self._seed_hidden = hidden

    def prefill_from_target_hidden(
        self,
        input_ids: mx.array,
        hidden: mx.array,
        bonus_token,
        sampler,
        token_dtype: mx.Dtype = mx.int32,
        greedy: bool = False,
    ) -> None:
        if input_ids.shape[1] == 0:
            return
        if isinstance(bonus_token, int):
            bonus = mx.array([[bonus_token]], dtype=token_dtype)
        else:
            bonus = bonus_token[:, None].astype(token_dtype)

        shifted = mx.concatenate([input_ids[:, 1:].astype(token_dtype), bonus], axis=1)
        self._next_position = 0
        h = self._forward_tokens(
            shifted,
            hidden[:, : shifted.shape[1], :],
            token_dtype,
        )
        self._set_seed_from_hidden(h[:, -1:, :], sampler, greedy)

    def accept_verified_tokens(
        self,
        verify_hidden: mx.array,
        draft_tokens: mx.array,
        accepted: int,
        new_tokens: List[int],
        sampler,
        token_dtype: mx.Dtype = mx.int32,
        greedy: bool = False,
    ) -> None:
        keep_appended = min(int(accepted), self._round_appended)
        trim = self._round_appended - keep_appended
        if trim > 0:
            for cache in self._cache:
                cache.trim(trim)
            self._next_position = (
                self._next_position - trim
                if isinstance(self._next_position, int)
                else self._next_position - trim
            )

        token_chunks = []
        hidden_chunks = []
        for draft_idx in range(keep_appended, int(accepted)):
            token_chunks.append(draft_tokens[:, draft_idx : draft_idx + 1])
            hidden_chunks.append(verify_hidden[:, draft_idx : draft_idx + 1, :])

        if new_tokens:
            token_chunks.append(mx.array([[int(new_tokens[-1])]], dtype=token_dtype))
            hidden_chunks.append(verify_hidden[:, int(accepted) : int(accepted) + 1, :])

        if token_chunks:
            tokens = mx.concatenate(token_chunks, axis=1).astype(token_dtype)
            hiddens = mx.concatenate(hidden_chunks, axis=1)
            h = self._forward_tokens(tokens, hiddens, token_dtype)
            self._set_seed_from_hidden(h[:, -1:, :], sampler, greedy)
        self._round_appended = 0

    def accept_verified_tokens_batch(
        self,
        verify_hidden: mx.array,
        draft_tokens: mx.array,
        accepted: List[int],
        new_tokens: List[List[int]],
        sampler,
        token_dtype: mx.Dtype = mx.int32,
        greedy: bool = False,
    ) -> None:
        """Extend the Qwen MTP drafter cache after a batched verify step."""
        if len(accepted) <= 1:
            self.accept_verified_tokens(
                verify_hidden,
                draft_tokens,
                int(accepted[0]),
                new_tokens[0],
                sampler,
                token_dtype,
                greedy,
            )
            return

        accepted = [int(a) for a in accepted]
        keep_appended = [min(a, self._round_appended) for a in accepted]
        trims = [self._round_appended - keep for keep in keep_appended]
        if any(trims):
            if len(set(trims)) == 1:
                trim = trims[0]
                for cache in self._cache:
                    cache.trim(trim)
                self._next_position = (
                    self._next_position - trim
                    if isinstance(self._next_position, int)
                    else self._next_position - trim
                )
            elif all(hasattr(cache, "prepare") for cache in self._cache) and all(
                hasattr(cache, "finalize") for cache in self._cache
            ):
                for cache in self._cache:
                    cache.prepare(right_padding=trims)
                for cache in self._cache:
                    cache.finalize()
                if isinstance(self._next_position, mx.array):
                    self._next_position = self._next_position - mx.array(
                        trims, dtype=mx.int32
                    )
                else:
                    self._next_position = mx.full(
                        (len(accepted),), self._next_position, dtype=mx.int32
                    ) - mx.array(trims, dtype=mx.int32)
            else:
                raise ValueError(
                    "Qwen MTP ragged batch acceptance requires a batch-aware cache."
                )

        tokens, hiddens, lengths, right_padding = _prepare_ragged_mtp_replay(
            verify_hidden,
            draft_tokens,
            accepted,
            new_tokens,
            keep_appended,
            token_dtype,
        )
        if tokens is not None:
            if any(right_padding):
                for cache in self._cache:
                    prepare = getattr(cache, "prepare", None)
                    if callable(prepare):
                        prepare(right_padding=right_padding, lengths=lengths)

            h = self._forward_tokens(tokens, hiddens, token_dtype)

            if any(right_padding):
                for cache in self._cache:
                    finalize = getattr(cache, "finalize", None)
                    if callable(finalize):
                        finalize()
                if isinstance(self._next_position, mx.array):
                    self._next_position = self._next_position - mx.array(
                        right_padding, dtype=mx.int32
                    )

            last_idx = mx.array([length - 1 for length in lengths], dtype=mx.int32)
            last_hidden = mx.take_along_axis(h, last_idx[:, None, None], axis=1)
            self._set_seed_from_hidden(last_hidden, sampler, greedy)
        self._round_appended = 0

    def filter_batch(self, keep) -> None:
        """Keep only active rows in Qwen MTP's internal drafter state."""
        if not isinstance(keep, mx.array):
            keep = mx.array(keep, dtype=mx.int32)

        for cache in self._cache:
            cache_filter = getattr(cache, "filter", None)
            if callable(cache_filter):
                cache_filter(keep)
            elif cache.keys is not None:
                cache.keys = cache.keys[keep]
                cache.values = cache.values[keep]

        if self._seed_token is not None:
            self._seed_token = self._seed_token[keep]
        if self._seed_hidden is not None:
            self._seed_hidden = self._seed_hidden[keep]

        for attr in ("_next_position", "_kv_valid_len", "_position"):
            value = getattr(self, attr)
            if isinstance(value, mx.array) and value.ndim > 0 and value.size > 1:
                setattr(self, attr, value[keep])

    def draft_block(
        self,
        last_bonus,
        hidden: mx.array,
        cache,
        block_size: int,
        sampler,
        token_dtype: mx.Dtype = mx.int32,
        greedy: bool = False,
    ) -> mx.array:
        del cache
        if self._input_embed is None or self._lm_head_fn is None:
            raise RuntimeError(
                "bind(target_model) must be called before draft_block() "
                "so the drafter can use the target embeddings and LM head."
            )

        if isinstance(last_bonus, int):
            tok = mx.array([[last_bonus]], dtype=token_dtype)
        else:
            tok = last_bonus[:, None].astype(token_dtype)

        h_prev = hidden
        tokens: List[mx.array] = []
        self._round_appended = 0

        if self._seed_token is not None and self._seed_hidden is not None:
            tok = self._seed_token.astype(token_dtype)
            h_prev = self._seed_hidden
            tokens.append(tok)
            self._seed_token = None
            self._seed_hidden = None

        while len(tokens) < block_size - 1:
            h_prev = self._forward_token(tok, h_prev, token_dtype)
            self._round_appended += 1
            if greedy:
                tok = self._greedy_token(h_prev)
            else:
                tok = sampler(self._lm_head_fn(h_prev))
            tokens.append(tok)

        self._draft_round += 1
        return mx.concatenate(tokens, axis=1)

    def sanitize(self, weights: dict) -> dict:
        out = {}
        norm_suffixes = (
            ".input_layernorm.weight",
            ".post_attention_layernorm.weight",
            ".q_norm.weight",
            ".k_norm.weight",
            "norm.weight",
            "pre_fc_norm_embedding.weight",
            "pre_fc_norm_hidden.weight",
        )
        for key, value in weights.items():
            is_hf_layout = key.startswith("mtp.")
            if is_hf_layout:
                key = key[len("mtp.") :]
            if is_hf_layout and any(key.endswith(suffix) for suffix in norm_suffixes):
                if value.ndim == 1 and mx.issubdtype(value.dtype, mx.floating):
                    value = value + 1.0
            out[key] = value
        expert_prefixes = [
            key[: -len(".experts.gate_up_proj")]
            for key in out
            if key.endswith(".experts.gate_up_proj")
        ]
        for prefix in expert_prefixes:
            gate_up_key = f"{prefix}.experts.gate_up_proj"
            gate_up_weight = out.pop(gate_up_key)
            gate_weight, up_weight = mx.split(gate_up_weight, 2, axis=-2)
            out[f"{prefix}.switch_mlp.gate_proj.weight"] = gate_weight
            out[f"{prefix}.switch_mlp.up_proj.weight"] = up_weight

            gate_up_scales_key = f"{gate_up_key}_scales"
            if gate_up_scales_key in out:
                gate_scales, up_scales = mx.split(
                    out.pop(gate_up_scales_key), 2, axis=-2
                )
                out[f"{prefix}.switch_mlp.gate_proj.scales"] = gate_scales
                out[f"{prefix}.switch_mlp.up_proj.scales"] = up_scales

            down_key = f"{prefix}.experts.down_proj"
            out[f"{prefix}.switch_mlp.down_proj.weight"] = out.pop(down_key)
            if f"{down_key}_scales" in out:
                out[f"{prefix}.switch_mlp.down_proj.scales"] = out.pop(
                    f"{down_key}_scales"
                )

        pattern = re.compile(
            r"(.*\.experts)\.(\d+)\.(gate_proj|up_proj|down_proj)\."
            r"(weight|scales|biases)$"
        )
        groups = {}
        for key in out:
            if match := pattern.fullmatch(key):
                expert_prefix, expert, projection, suffix = match.groups()
                groups.setdefault((expert_prefix, projection, suffix), {})[
                    int(expert)
                ] = key

        for (expert_prefix, projection, suffix), expert_keys in groups.items():
            experts = sorted(expert_keys)
            if experts != list(range(len(experts))):
                raise ValueError(
                    f"Qwen MTP expert indexes are not contiguous for {expert_prefix}: "
                    f"{experts}."
                )
            base = expert_prefix[: -len(".experts")]
            out[f"{base}.switch_mlp.{projection}.{suffix}"] = mx.stack(
                [out.pop(expert_keys[expert]) for expert in experts]
            )

        return out
