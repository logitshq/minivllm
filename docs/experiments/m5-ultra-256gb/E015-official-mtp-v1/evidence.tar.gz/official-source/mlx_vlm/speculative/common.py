from typing import Any, Callable, List, Optional, Tuple

import mlx.core as mx
import mlx.nn as nn

from ..models.base import LanguageModelOutput
from ..models.linear import DECODE_BLOCK_SIZE
from .cache_state import start_speculative_cache

generation_stream = mx.new_thread_local_stream(mx.default_device())


def verify_forward(model, inputs, cache, **kwargs):
    """Run ordinary short-block forwards inside one cache transaction."""
    transaction = start_speculative_cache(cache, inputs.shape[1])
    try:
        outputs = [
            model(inputs[:, start : start + DECODE_BLOCK_SIZE], cache=cache, **kwargs)
            for start in range(0, inputs.shape[1], DECODE_BLOCK_SIZE)
        ]
        if len(outputs) == 1:
            return outputs[0], transaction
        return (
            LanguageModelOutput(
                logits=(
                    None
                    if outputs[0].logits is None
                    else mx.concatenate([out.logits for out in outputs], axis=1)
                ),
                hidden_states=(
                    None
                    if outputs[0].hidden_states is None
                    else [
                        mx.concatenate(parts, axis=1)
                        for parts in zip(*(out.hidden_states for out in outputs))
                    ]
                ),
                shared_kv_states=outputs[-1].shared_kv_states,
            ),
            transaction,
        )
    except BaseException:
        transaction.abort()
        raise


def _copy_rng_state() -> List[mx.array]:
    return [mx.array(state) for state in mx.random.state]


def _restore_rng_state(state: List[mx.array]) -> None:
    for i, value in enumerate(state):
        mx.random.state[i][:] = value


def _append_arrays(value: Any, arrays: List[mx.array]) -> None:
    if isinstance(value, mx.array):
        arrays.append(value)
    elif isinstance(value, dict):
        for item in value.values():
            _append_arrays(item, arrays)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _append_arrays(item, arrays)


def _draft_sampler_state_arrays(draft_model: nn.Module) -> List[mx.array]:
    state_fn = getattr(draft_model, "draft_eval_state", None)
    if callable(state_fn):
        arrays: List[mx.array] = []
        _append_arrays(state_fn(), arrays)
        return arrays

    attrs = getattr(draft_model, "sampler_state_attrs", ("_seed_token",))
    if isinstance(attrs, str):
        attrs = (attrs,)

    arrays = []
    for attr in attrs:
        _append_arrays(getattr(draft_model, attr, None), arrays)
    return arrays


class _SpeculativeSamplerRNG:
    """Keep target and drafter sampler RNG streams independent."""

    def __init__(self, draft_model: nn.Module, *, enabled: bool):
        self.draft_model = draft_model
        self.enabled = bool(enabled)
        self._target_rng_state = _copy_rng_state() if self.enabled else None
        self._draft_rng_state = _copy_rng_state() if self.enabled else None

    def draft_call(
        self,
        fn: Callable,
        *args,
        **kwargs,
    ):
        if not self.enabled:
            result = fn(*args, **kwargs)
            arrays = []
            _append_arrays(result, arrays)
            arrays.extend(_draft_sampler_state_arrays(self.draft_model))
            if arrays:
                mx.async_eval(*arrays)
            return result

        self._target_rng_state = _copy_rng_state()
        _restore_rng_state(self._draft_rng_state)
        result = fn(*args, **kwargs)

        arrays = _draft_sampler_state_arrays(self.draft_model)
        arrays.extend(mx.random.state)
        if arrays:
            mx.async_eval(*arrays)

        self._draft_rng_state = _copy_rng_state()
        _restore_rng_state(self._target_rng_state)
        return result

    def draft_tokens(self, fn: Callable, *args, **kwargs):
        if not self.enabled:
            result = fn(*args, **kwargs)
            arrays: List[mx.array] = []
            _append_arrays(result, arrays)
            if arrays:
                mx.async_eval(*arrays)
            return result

        self._target_rng_state = _copy_rng_state()
        _restore_rng_state(self._draft_rng_state)
        result = fn(*args, **kwargs)

        arrays = []
        _append_arrays(result, arrays)
        arrays.extend(_draft_sampler_state_arrays(self.draft_model))
        arrays.extend(mx.random.state)
        if arrays:
            mx.async_eval(*arrays)

        self._draft_rng_state = _copy_rng_state()
        _restore_rng_state(self._target_rng_state)
        return result

    def target_sampled(self, *, sync_draft: bool = False) -> None:
        if self.enabled:
            self._target_rng_state = _copy_rng_state()
            if sync_draft:
                self._draft_rng_state = _copy_rng_state()

    def sync_draft_to_target(self) -> None:
        if self.enabled:
            self._draft_rng_state = _copy_rng_state()

    def target_eval(self, *values: Any) -> None:
        if not self.enabled:
            arrays: List[mx.array] = []
            for value in values:
                _append_arrays(value, arrays)
            if arrays:
                mx.async_eval(*arrays)
            return

        arrays = []
        for value in values:
            _append_arrays(value, arrays)
        arrays.extend(mx.random.state)
        if arrays:
            mx.async_eval(*arrays)
        self._target_rng_state = _copy_rng_state()


def _speculative_walk(
    draft_tokens: mx.array,
    target_tokens: mx.array,
    budget: int,
) -> Tuple[int, List[int]]:
    """Exact-greedy speculative-decoding walk.

    Accept drafted tokens up to the first mismatch with the target's
    greedy choice, then take the target's bonus at that position.
    Returns ``(accepted_count, new_tokens)`` with ``new_tokens``
    truncated to ``budget``.
    """
    n_draft = int(draft_tokens.shape[1])
    draft_row = draft_tokens.reshape(-1).tolist()[:n_draft]
    target_row = target_tokens.reshape(-1).tolist()

    accepted = n_draft
    for i, (draft_tok, target_tok) in enumerate(zip(draft_row, target_row)):
        if draft_tok != target_tok:
            accepted = i
            break

    new_tokens = draft_row[:accepted] + target_row[accepted : accepted + 1]
    return accepted, new_tokens[:budget]


def _speculative_walk_batch(
    draft_tokens: mx.array,
    target_tokens: mx.array,
    budgets: List[int],
) -> Tuple[List[int], List[List[int]]]:
    """Per-sequence speculative walk for B > 1.

    Returns ``(accepted_list, new_tokens_list)`` where each entry
    corresponds to one sequence in the batch.
    """
    B = int(draft_tokens.shape[0])
    if len(budgets) != B:
        raise ValueError(f"expected {B} token budgets, got {len(budgets)}")
    if any(budget < 0 for budget in budgets):
        raise ValueError("token budgets must be non-negative")
    if B == 0:
        return [], []

    n_draft = int(draft_tokens.shape[1])
    mismatches = draft_tokens != target_tokens[:, :n_draft]
    mismatches = mx.concatenate([mismatches, mx.ones((B, 1), dtype=mx.bool_)], axis=1)
    accepted = mx.argmax(mismatches.astype(mx.int32), axis=1)

    bonus = mx.take_along_axis(target_tokens, accepted[:, None], axis=1)
    positions = mx.arange(n_draft + 1, dtype=mx.int32)[None]
    draft_with_pad = mx.concatenate(
        [draft_tokens, mx.zeros((B, 1), dtype=draft_tokens.dtype)], axis=1
    )
    walked = mx.where(
        positions < accepted[:, None],
        draft_with_pad,
        mx.where(positions == accepted[:, None], bonus, 0),
    )

    # Python owns ragged emission and cache rollback. Pack both decisions so
    # one conversion evaluates the complete graph and crosses that boundary.
    decision_rows = mx.concatenate(
        [accepted[:, None].astype(walked.dtype), walked], axis=1
    ).tolist()
    accepted_list = [int(row[0]) for row in decision_rows]
    new_tokens_list = [
        row[1 : 1 + min(accepted_i + 1, budget)]
        for row, accepted_i, budget in zip(decision_rows, accepted_list, budgets)
    ]
    return accepted_list, new_tokens_list


def _prepare_ragged_mtp_replay(
    verify_hidden: mx.array,
    draft_tokens: mx.array,
    accepted: List[int],
    new_tokens: List[List[int]],
    keep_appended: List[int],
    token_dtype: mx.Dtype,
) -> Tuple[Optional[mx.array], Optional[mx.array], List[int], List[int]]:
    """Pack per-row accepted drafts and verifier bonuses for one MTP replay."""
    token_rows = []
    hidden_rows = []
    lengths = []
    for row, (accepted_i, keep_i) in enumerate(zip(accepted, keep_appended)):
        token_parts = []
        hidden_parts = []
        if accepted_i > keep_i:
            token_parts.append(draft_tokens[row : row + 1, keep_i:accepted_i])
            hidden_parts.append(verify_hidden[row : row + 1, keep_i:accepted_i, ...])
        if new_tokens[row]:
            token_parts.append(
                mx.array([[int(new_tokens[row][-1])]], dtype=token_dtype)
            )
            hidden_parts.append(
                verify_hidden[row : row + 1, accepted_i : accepted_i + 1, ...]
            )

        if token_parts:
            token_row = mx.concatenate(token_parts, axis=1).astype(token_dtype)
            hidden_row = mx.concatenate(hidden_parts, axis=1)
        else:
            token_row = mx.zeros((1, 0), dtype=token_dtype)
            hidden_row = mx.zeros(
                (1, 0, *verify_hidden.shape[2:]), dtype=verify_hidden.dtype
            )
        token_rows.append(token_row)
        hidden_rows.append(hidden_row)
        lengths.append(int(token_row.shape[1]))

    max_len = max(lengths, default=0)
    if max_len == 0:
        return None, None, lengths, [0] * len(lengths)

    right_padding = [max_len - length for length in lengths]
    for row, pad in enumerate(right_padding):
        if not pad:
            continue
        token_rows[row] = mx.concatenate(
            [token_rows[row], mx.zeros((1, pad), dtype=token_dtype)], axis=1
        )
        hidden_rows[row] = mx.concatenate(
            [
                hidden_rows[row],
                mx.zeros((1, pad, *verify_hidden.shape[2:]), dtype=verify_hidden.dtype),
            ],
            axis=1,
        )

    return (
        mx.concatenate(token_rows, axis=0),
        mx.concatenate(hidden_rows, axis=0),
        lengths,
        right_padding,
    )


def _speculative_walk_batch_uniform_acceptance(
    draft_tokens: mx.array,
    target_tokens: mx.array,
    accepted_list: List[int],
    budgets: List[int],
) -> Tuple[List[int], List[List[int]]]:
    """Clamp a batch to the earliest rejection with verifier-token fallback."""
    accepted = min(accepted_list)
    new_tokens_list: List[List[int]] = []
    for i, budget in enumerate(budgets):
        accepted_prefix = draft_tokens[i : i + 1, :accepted]
        bonus = target_tokens[i : i + 1, accepted : accepted + 1]
        new = (
            mx.concatenate([accepted_prefix, bonus], axis=1)[:, :budget]
            .reshape(-1)
            .tolist()
        )
        new_tokens_list.append(new)
    return [accepted] * len(accepted_list), new_tokens_list


def _requires_uniform_batch_acceptance(
    draft_model: nn.Module, target_model: Optional[nn.Module] = None
) -> bool:
    """Whether ragged per-row acceptance must be clamped to a uniform count.

    The flag is honored on either the drafter or the target model. A target's
    dedicated drafter (e.g. qwen3_5 -> qwen3_5_mtp) may not advertise it, yet
    the target's rectangular batch KV cache (single ``_idx``) cannot represent
    ragged accepts without leaving phantom zeroed keys attended (issue #1962),
    so the target may require it independently of the drafter.
    """
    if getattr(draft_model, "requires_uniform_batch_acceptance", False):
        return True
    return bool(getattr(target_model, "requires_uniform_batch_acceptance", False))


def _record_speculative_round(
    draft_model: nn.Module, accepted: float, draft_count: int
) -> None:
    draft_model.accept_lens.append(accepted)
    if hasattr(draft_model, "draft_lens"):
        draft_model.draft_lens.append(int(draft_count))
    # Monotonic lifetime counters for per-request attribution. Unlike the
    # ``accept_lens`` history, these survive ``reset()`` between requests,
    # so callers can snapshot-and-diff across a request's lifetime.
    draft_model.speculative_total_rounds = (
        getattr(draft_model, "speculative_total_rounds", 0) + 1
    )
    draft_model.speculative_total_accepted = getattr(
        draft_model, "speculative_total_accepted", 0.0
    ) + float(accepted)
    draft_model.speculative_total_drafted = getattr(
        draft_model, "speculative_total_drafted", 0
    ) + int(draft_count)


def speculative_stats_snapshot(draft_model: nn.Module) -> Tuple[int, float, int]:
    """Capture the drafter's lifetime round counters for later diffing."""
    return (
        getattr(draft_model, "speculative_total_rounds", 0),
        getattr(draft_model, "speculative_total_accepted", 0.0),
        getattr(draft_model, "speculative_total_drafted", 0),
    )


def speculative_stats_since(
    draft_model: nn.Module, snapshot: Tuple[int, float, int]
) -> Tuple[Optional[int], Optional[int], Optional[int]]:
    """Return (rounds, accepted, drafted) recorded since ``snapshot``.

    Rounds are batch-wide, so the attribution is exact for batch size 1 and
    shared across concurrent requests otherwise.
    """
    rounds0, accepted0, drafted0 = snapshot
    rounds = getattr(draft_model, "speculative_total_rounds", 0) - rounds0
    if rounds <= 0:
        return None, None, None
    accepted = getattr(draft_model, "speculative_total_accepted", 0.0) - accepted0
    drafted = getattr(draft_model, "speculative_total_drafted", 0) - drafted0
    return rounds, int(round(accepted)), int(drafted)


def _dflash_block_total(draft_model: nn.Module, draft_block_size: Optional[int]) -> int:
    if draft_block_size is not None:
        return int(draft_block_size)

    configured = int(draft_model.config.block_size)
    runtime = getattr(draft_model.config, "runtime_block_size", None)
    if runtime is None:
        runtime = getattr(draft_model, "default_runtime_block_size", None)
        return configured if runtime is None else max(1, int(runtime))
    return min(configured, max(1, int(runtime)))


def _batch_cache_left_padding(prompt_cache: List[Any]) -> Optional[mx.array]:
    for cache_entry in prompt_cache:
        left_padding = getattr(cache_entry, "left_padding", None)
        if left_padding is not None:
            return left_padding
    return None


def _format_speculative_stats(draft_model: nn.Module) -> Optional[str]:
    accepted_lens = getattr(draft_model, "accept_lens", None) or []
    if not accepted_lens:
        return None

    rounds = len(accepted_lens)
    accepted_drafts = sum(accepted_lens)
    mean_accept = accepted_drafts / rounds
    mean_accepted_tokens = (accepted_drafts + rounds) / rounds
    draft_lens = getattr(draft_model, "draft_lens", None) or []
    if len(draft_lens) == rounds and sum(draft_lens) > 0:
        accept_rate = 100 * accepted_drafts / sum(draft_lens)
        mean_draft = sum(draft_lens) / rounds
        return (
            "Speculative decoding: "
            f"{mean_accepted_tokens:.2f} accepted tokens/round "
            f"({mean_accept:.2f} accepted drafts/round, "
            f"{accept_rate:.1f}% of drafted, "
            f"avg draft {mean_draft:.2f}) over {rounds} rounds"
        )

    return (
        "Speculative decoding: "
        f"{mean_accepted_tokens:.2f} accepted tokens over {rounds} rounds"
    )
