# SPDX-License-Identifier: Apache-2.0
"""Monkey-patch for ml-explore/mlx-lm PR #990 — Qwen3.5/3.6 Lightning MTP.

Adds an MTP head to ``mlx_lm.models.qwen3_5.TextModel`` (the language-model
half) and a pass-through on ``mlx_lm.models.qwen3_5.Model`` (the VLM-outer
wrapper). The mechanism replaces class methods on a one-shot, idempotent
basis tracked by a module flag.

Important: the class names below match what mlx-lm 0.31.x actually exports.
Earlier drafts of this patch used ``Qwen3_5GatedDeltaNet`` / ``Qwen3_5DecoderLayer``
matching the source-PR's class names; mlx-lm names them ``GatedDeltaNet`` and
``DecoderLayer``. The patch targets the runtime names.

What this patch installs (all on classes from ``mlx_lm.models.qwen3_5``):

- ``TextModelArgs``: a runtime ``mtp_num_hidden_layers`` instance attribute
  via a thin ``from_dict`` wrapper. We can't add a real dataclass field at
  runtime without rebuilding the class, so we attach the value to the
  instance after ``from_dict`` runs and rely on duck-typing in the rest of
  the code.
- ``GatedDeltaNet``: ``_process_chunk`` helper added, ``__call__`` body
  replaced to support the ``n_confirmed`` argument. When ``n_confirmed`` is
  between 1 and ``S - 1``, the prefix is processed first and the
  ``(conv_state, ssm_state)`` snapshot is stored on the cache as
  ``rollback_state`` so a rejected draft can restore it.
- ``DecoderLayer``: ``__call__`` passes ``n_confirmed`` through to the
  linear-attention sublayer.
- ``Qwen3_5TextModel``: ``__call__`` accepts ``n_confirmed`` and returns
  *pre-norm* hidden states (the MTP head needs them).
- ``TextModel``: ``__init__`` wrapped to attach a fresh ``MTPModule`` when
  the args declared one. ``__call__`` accepts ``return_hidden`` and
  ``n_confirmed`` and decouples pre- vs post-norm hidden / logits.
  ``mtp_forward`` and ``make_mtp_cache`` added. ``sanitize`` keeps the
  ``mtp.*`` keys when an MTP head exists. ``quant_predicate`` keeps the
  fusion projection in full precision.
- ``Model`` (VLM outer wrapper): ``__call__`` and ``mtp_forward`` /
  ``make_mtp_cache`` pass through to the language model. This is what lets
  ``mtp_enabled`` work for both LM (``model_type=qwen3_5``) and VLM
  (``model_type=qwen3_5_vl``) checkpoints — the VLM's ``language_model``
  is the patched ``TextModel`` instance.
- ``MTPDecoderLayer`` and ``MTPModule`` are registered as new attributes
  on ``mlx_lm.models.qwen3_5`` so the patched ``TextModel.__init__`` can
  find them.

The patch is intentionally limited to ``mlx_lm.models.qwen3_5``; mlx-vlm's
``mlx_vlm.models.qwen3_5.language`` is a separate copy and is not touched.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from ..dflash_lifecycle import get_dflash_guard_base, set_dflash_guard_base
from . import prompt_priming

logger = logging.getLogger(__name__)

def _is_our_method(cls: Any, attr: str, marker: str) -> bool:
    """True iff ``cls.<attr>`` is the function we previously installed.

    Used as a self-healing idempotency check: when another patch (e.g.
    dflash's speculative hook) overwrites ``__call__`` between two
    Lightning MTP loads in the same process, the marker disappears and the
    caller knows to re-apply. Reading from ``cls.__dict__`` instead of
    ``getattr`` avoids resolving inherited attributes — only what is
    actually defined on this class counts.
    """
    existing = cls.__dict__.get(attr)
    return getattr(existing, marker, False)


def apply() -> bool:
    """Apply PR 990 model-side patches to mlx_lm.models.qwen3_5.

    Self-healing. Each sub-patcher decides for itself whether the class
    still carries our installed method (marker-based identity check)
    and re-applies if something has clobbered it since the last call.
    No module-level "patched once" flag so dflash → mtp transitions in
    the same process re-establish ownership (issue #1388).
    """
    try:
        from mlx_lm.models import qwen3_5 as q35
    except ImportError:
        logger.debug("mlx_lm.models.qwen3_5 not importable; skipping MTP patch")
        return False

    q35.TextModel._omlx_mtp_multi_request = True
    # Skip if upstream already merged PR 990: TextModel already has mtp_forward.
    if hasattr(q35.TextModel, "mtp_forward") and not hasattr(
        q35.TextModel, "_omlx_mtp_patched"
    ):
        q35.TextModel._omlx_mtp_patched = "upstream"
        return True

    _patch_text_model_args(q35)
    _register_mtp_classes(q35)
    _patch_gated_delta_net(q35)
    _patch_decoder_layer(q35)
    _patch_qwen3_5_text_model(q35)
    _patch_text_model(q35)
    _patch_outer_model(q35)
    _patch_qwen3_5_moe()

    if not hasattr(q35.TextModel, "_omlx_mtp_patched"):
        q35.TextModel._omlx_mtp_patched = "patch"
        logger.info("Qwen3.5/3.6 MTP model patch applied (PR 990)")
    return True


# ---------------------------------------------------------------------------
# TextModelArgs.from_dict — surface mtp_num_hidden_layers as instance attr.
# ---------------------------------------------------------------------------

def _patch_text_model_args(q35: Any) -> None:
    """Wrap ``TextModelArgs.from_dict`` to retain ``mtp_num_hidden_layers``.

    We can't add a dataclass field at runtime without rebuilding the class,
    so we read the raw value from the source dict and ``setattr`` on the
    instance. Subsequent code reads ``args.mtp_num_hidden_layers`` and gets
    the right thing. ``BaseModelArgs.from_dict`` ignores unknown keys, so
    plain construction would discard the value otherwise.
    """
    args_cls = q35.TextModelArgs
    if hasattr(args_cls, "_omlx_mtp_from_dict_patched"):
        return

    original_from_dict = args_cls.from_dict.__func__  # unwrap classmethod

    def patched_from_dict(cls, params):
        instance = original_from_dict(cls, params)
        # Default to 0 when missing so the rest of the code can branch on it.
        instance.mtp_num_hidden_layers = int(
            params.get("mtp_num_hidden_layers", 0) or 0
        )
        return instance

    args_cls.from_dict = classmethod(patched_from_dict)
    args_cls._omlx_mtp_from_dict_patched = True


# ---------------------------------------------------------------------------
# MTPDecoderLayer + MTPModule — register on the qwen3_5 module.
# ---------------------------------------------------------------------------

def _register_mtp_classes(q35: Any) -> None:
    """Attach ``MTPDecoderLayer`` / ``MTPModule`` to the qwen3_5 module."""
    if hasattr(q35, "MTPModule"):
        return

    import mlx.core as mx
    import mlx.nn as nn

    # qwen3_5 imports these as module attributes via ``from .qwen3_next
    # import ... as ...`` so we can read them from the module directly.
    Attention = q35.Attention
    SparseMoeBlock = q35.SparseMoeBlock
    MLP = q35.MLP
    create_attention_mask = q35.create_attention_mask

    class MTPDecoderLayer(nn.Module):
        """Full-attention transformer layer used inside the MTP head.

        Unlike the standard ``DecoderLayer`` (which routes through
        ``GatedDeltaNet`` for "linear" layers), the MTP head only uses
        full attention. MoE config is honored when num_experts > 0.
        """

        def __init__(self, args):
            super().__init__()
            self.self_attn = Attention(args)
            self.input_layernorm = nn.RMSNorm(args.hidden_size, eps=args.rms_norm_eps)
            self.post_attention_layernorm = nn.RMSNorm(
                args.hidden_size, eps=args.rms_norm_eps
            )
            if args.num_experts > 0:
                self.mlp = SparseMoeBlock(args)
            else:
                self.mlp = MLP(args.hidden_size, args.intermediate_size)

        def __call__(self, x, mask=None, cache=None):
            r = self.self_attn(self.input_layernorm(x), mask, cache)
            h = x + r
            return h + self.mlp(self.post_attention_layernorm(h))

    class MTPModule(nn.Module):
        """Multi-Token Prediction head from PR #990.

        Predicts token t+2 by fusing the backbone's pre-norm hidden state
        at position t with the embedding of the sampled main token t+1.
        """

        def __init__(self, args):
            super().__init__()
            self.pre_fc_norm_hidden = nn.RMSNorm(
                args.hidden_size, eps=args.rms_norm_eps
            )
            self.pre_fc_norm_embedding = nn.RMSNorm(
                args.hidden_size, eps=args.rms_norm_eps
            )
            self.fc = nn.Linear(args.hidden_size * 2, args.hidden_size, bias=False)
            self.layers = [
                MTPDecoderLayer(args) for _ in range(args.mtp_num_hidden_layers)
            ]
            self.norm = nn.RMSNorm(args.hidden_size, eps=args.rms_norm_eps)

        def __call__(self, hidden_states, next_token_ids, embed_tokens, cache=None):
            embeds = embed_tokens(next_token_ids)
            e = self.pre_fc_norm_embedding(embeds)
            h = self.pre_fc_norm_hidden(hidden_states)
            fused = self.fc(mx.concatenate([e, h], axis=-1))

            if cache is None:
                cache = [None] * len(self.layers)

            mask = create_attention_mask(fused, cache[0] if cache else None)
            for layer, c in zip(self.layers, cache):
                fused = layer(fused, mask, c)

            return self.norm(fused)

    q35.MTPDecoderLayer = MTPDecoderLayer
    q35.MTPModule = MTPModule


# ---------------------------------------------------------------------------
# GatedDeltaNet — _process_chunk helper + __call__ replacement.
# ---------------------------------------------------------------------------

def _patch_gated_delta_net(q35: Any) -> None:
    """Replace ``GatedDeltaNet.__call__`` with an n_confirmed-aware body.

    The original body inlines the conv1d / gated_delta_update path against
    the full sequence. PR 990 splits that path into ``_process_chunk`` so
    the same helper can run on the prefix (n_confirmed tokens) and the
    suffix (draft tokens) separately, snapshotting the SSM/conv state in
    between for rollback on draft rejection.
    """
    cls = q35.GatedDeltaNet
    if _is_our_method(cls, "__call__", "_omlx_mtp_call_marker"):
        return

    # dflash coexistence (issue #2972): if the dflash batch-cache guard owns
    # ``cls.__call__``, do not clobber it — that silently strips the resident
    # DFlash engine's speculative hook and its generations degenerate into
    # repetition loops. Instead install our body as the guard's fallback
    # base: dflash traffic keeps its hook, MTP/batched traffic gets ours.
    dflash_base = get_dflash_guard_base(cls)
    if getattr(dflash_base, "_omlx_mtp_call_marker", False):
        return  # our body already sits under the dflash guard

    import mlx.core as mx
    import mlx.nn as nn
    from mlx.nn.layers.distributed import sum_gradients
    from mlx_lm.models.gated_delta import gated_delta_update, normalize_qk

    def _process_chunk(
        self,
        qkv_chunk,
        a_chunk,
        b_chunk,
        conv_state,
        ssm_state,
        ssm_mask=None,
        lengths=None,
    ):
        B, S_chunk = qkv_chunk.shape[:2]
        conv_in = mx.concatenate([conv_state, qkv_chunk], axis=1)
        n_keep = self.conv_kernel_size - 1
        if lengths is not None:
            ends = mx.clip(lengths, 0, S_chunk)
            positions = (ends[:, None] + mx.arange(n_keep))[..., None]
            new_conv_state = mx.take_along_axis(conv_in, positions, axis=1)
        else:
            new_conv_state = mx.contiguous(conv_in[:, -n_keep:])
        conv_out = nn.silu(self.conv1d(conv_in))

        q, k, v = [
            t.reshape(B, S_chunk, h, d)
            for t, h, d in zip(
                mx.split(conv_out, [self.key_dim, 2 * self.key_dim], -1),
                [self.num_k_heads, self.num_k_heads, self.num_v_heads],
                [self.head_k_dim, self.head_k_dim, self.head_v_dim],
            )
        ]
        q, k = normalize_qk(q, k, inv_scale=self.head_k_dim**-0.5, eps=1e-6)

        out, new_ssm_state = gated_delta_update(
            q,
            k,
            v,
            a_chunk,
            b_chunk,
            self.A_log,
            self.dt_bias,
            ssm_state,
            ssm_mask,
            use_kernel=not self.training,
        )
        return out, new_conv_state, new_ssm_state

    def __call__(
        self,
        inputs: Any,
        mask: Optional[Any] = None,
        cache: Optional[Any] = None,
        n_confirmed: int = 0,
    ):
        B, S, _ = inputs.shape

        if self.sharding_group is not None:
            inputs = sum_gradients(self.sharding_group)(inputs)

        qkv = self.in_proj_qkv(inputs)
        z = self.in_proj_z(inputs).reshape(B, S, self.num_v_heads, self.head_v_dim)
        b = self.in_proj_b(inputs)
        a = self.in_proj_a(inputs)

        if cache is not None and cache[0] is not None:
            conv_state = cache[0]
        else:
            conv_state = mx.zeros(
                (B, self.conv_kernel_size - 1, self.conv_dim),
                dtype=inputs.dtype,
            )
        ssm_state = cache[1] if cache else None

        if mask is not None:
            qkv = mx.where(mask[..., None], qkv, 0)

        if n_confirmed > 0 and n_confirmed < S:
            # MTP verify forward. Unlike PR 990 (which processes the
            # confirmed prefix and draft suffix as two chunks, snapshotting
            # in between), run the whole window as ONE chunk — measured
            # ~2.6ms/cycle cheaper across 48 linear layers on Qwen3.6-27B —
            # and keep zero-copy *pre-forward* state refs plus the projected
            # inputs. On a rejection, ``mtp_partial_rollback`` replays the
            # kept prefix (confirmed + accepted drafts) through
            # ``_process_chunk`` from those refs; on full accept the refs
            # are dropped and the verify costs nothing extra.
            out, conv_f, ssm_f = self._process_chunk(
                qkv, a, b, conv_state, ssm_state, mask
            )
            if cache is not None:
                cache.rollback_state = (conv_state, ssm_state)
                cache._mtp_draft_stash = (qkv, a, b)
        else:
            lengths = cache.lengths if cache is not None else None
            out, conv_f, ssm_f = self._process_chunk(
                qkv, a, b, conv_state, ssm_state, mask, lengths=lengths
            )

        if cache is not None:
            cache[0] = conv_f
            cache[1] = ssm_f
            cache.advance(S)

        out = self.norm(out, z)
        out = self.out_proj(out.reshape(B, S, -1))

        if self.sharding_group is not None:
            out = mx.distributed.all_sum(out, group=self.sharding_group)

        return out

    cls._process_chunk = _process_chunk
    __call__._omlx_mtp_call_marker = True
    if dflash_base is not None:
        # Compose with the armed dflash guard instead of replacing it
        # (issue #2972): our body becomes the guard's fallback base.
        set_dflash_guard_base(cls, __call__)
    else:
        cls.__call__ = __call__


# ---------------------------------------------------------------------------
# DecoderLayer — pass n_confirmed to linear attn.
# ---------------------------------------------------------------------------

def _patch_decoder_layer(q35: Any) -> None:
    cls = q35.DecoderLayer
    if _is_our_method(cls, "__call__", "_omlx_mtp_call_marker"):
        return

    def __call__(self, x, mask=None, cache=None, n_confirmed: int = 0):
        if self.is_linear:
            h_in = self.input_layernorm(x)
            # n_confirmed is an MTP draft/verify concern and is always 0 on
            # the stock and DFlash forward paths. Forward it only when it
            # actually splits the sequence, so linear_attn implementations
            # that don't accept the kwarg keep working — DFlash replaces
            # linear_attn.__call__ with a hook that has no n_confirmed param.
            # Mirrors the conditional in batch_generator._call_backbone.
            if n_confirmed:
                r = self.linear_attn(h_in, mask, cache, n_confirmed=n_confirmed)
            else:
                r = self.linear_attn(h_in, mask, cache)
        else:
            r = self.self_attn(self.input_layernorm(x), mask, cache)
        h = x + r
        out = h + self.mlp(self.post_attention_layernorm(h))
        return out

    __call__._omlx_mtp_call_marker = True
    cls.__call__ = __call__


# ---------------------------------------------------------------------------
# Qwen3_5TextModel — return pre-norm hidden, accept n_confirmed.
# ---------------------------------------------------------------------------

def _patch_qwen3_5_text_model(q35: Any) -> None:
    cls = q35.Qwen3_5TextModel
    if _is_our_method(cls, "__call__", "_omlx_mtp_call_marker"):
        return

    create_attention_mask = q35.create_attention_mask
    create_ssm_mask = q35.create_ssm_mask

    def __call__(
        self,
        inputs,
        cache=None,
        input_embeddings=None,
        n_confirmed: int = 0,
    ):
        import mlx.core as mx

        if input_embeddings is not None:
            hidden_states = input_embeddings
        else:
            hidden_states = self.embed_tokens(inputs)

        # Pipeline-aware (oMLX #3518). Under ``pipeline(group)`` each rank owns
        # ``pipeline_layers`` (``self.layers`` holds ``None`` for the other
        # ranks' layers) and hands the hidden state to its neighbour. With one
        # rank (``pipeline_rank=0``, ``pipeline_size=1``) this is exactly the
        # single-host forward.
        pipeline_rank = getattr(self, "pipeline_rank", 0)
        pipeline_size = getattr(self, "pipeline_size", 1)
        layers = self.pipeline_layers

        if cache is None:
            cache = [None] * len(layers)

        fa_mask = None
        ssm_mask = None
        if self.fa_idx is not None:
            fa_mask = create_attention_mask(hidden_states, cache[self.fa_idx])
        if self.ssm_idx is not None:
            ssm_mask = create_ssm_mask(hidden_states, cache[self.ssm_idx])

        if pipeline_rank < pipeline_size - 1:
            hidden_states = mx.distributed.recv_like(hidden_states, pipeline_rank + 1)

        for layer, c in zip(layers, cache):
            mask = ssm_mask if layer.is_linear else fa_mask
            hidden_states = layer(
                hidden_states, mask=mask, cache=c, n_confirmed=n_confirmed
            )

        if pipeline_rank != 0:
            hidden_states = mx.distributed.send(
                hidden_states, (pipeline_rank - 1) % pipeline_size
            )
            if cache and cache[-1] is not None:
                # Keep the send in the lazy graph (same device as mlx-lm).
                last = cache[-1]
                if hasattr(last, "keys"):
                    last.keys = mx.depends(last.keys, hidden_states)
                else:
                    last[0] = mx.depends(last[0], hidden_states)

        if pipeline_size > 1:
            # Every rank needs the final hidden state (norm, lm_head and the
            # MTP head run redundantly on all ranks). Rank 0 holds the LAST
            # layers, so its slice is the true output.
            hidden_states = mx.distributed.all_gather(hidden_states)[
                : hidden_states.shape[0]
            ]

        # PR 990: return pre-norm hidden so the MTP head can fuse it. The
        # wrapping ``TextModel.__call__`` applies ``self.model.norm`` on top
        # to produce logits.
        return hidden_states

    __call__._omlx_mtp_call_marker = True
    cls.__call__ = __call__


# ---------------------------------------------------------------------------
# TextModel — wrap __init__, replace __call__, add mtp_forward / make_mtp_cache,
# refresh sanitize / quant_predicate.
# ---------------------------------------------------------------------------

def _patch_text_model(q35: Any) -> None:
    cls = q35.TextModel
    # __call__ / sanitize / mtp_forward / make_mtp_cache / quant_predicate
    # are all *replacements* — safe to self-heal. __init__ is a wrap (captures
    # original_init in a closure), so re-wrapping after another patch would
    # chain wraps and cause double-init. Gate them separately:
    init_wrapped = getattr(cls, "_omlx_mtp_init_wrapped", False)
    call_owned = _is_our_method(cls, "__call__", "_omlx_mtp_call_marker")
    if init_wrapped and call_owned:
        return

    from mlx_lm.models.cache import KVCache

    original_init = cls.__init__

    def __init__(self, args):
        original_init(self, args)
        n_mtp = int(getattr(args, "mtp_num_hidden_layers", 0) or 0)
        # Only attach the MTP head when the active-flag is set. With the
        # flag off the model is indistinguishable from a stock no-MTP
        # build: ``hasattr(self, "mtp")`` is False, sanitize strips
        # ``mtp.*`` weights, and BatchGenerator's _is_mtp_eligible bails
        # out because the inner ``language_model`` has no ``mtp``.
        from . import is_mtp_active

        mtp_decode_enabled = bool(n_mtp > 0 and is_mtp_active())
        self._omlx_mtp_decode_enabled = mtp_decode_enabled
        if mtp_decode_enabled:
            self.mtp = q35.MTPModule(args)
            # Depth-k chained drafting is available on this model: the qwen
            # patch supports return_hidden mtp_forward + partial rollback.
            from . import get_mtp_depth, is_mtp_depth_fixed

            self._omlx_mtp_chain = True
            self._omlx_mtp_depth = get_mtp_depth()
            self._omlx_mtp_depth_fixed = is_mtp_depth_fixed()

    def __call__(
        self,
        inputs,
        cache=None,
        input_embeddings=None,
        return_hidden: bool = False,
        n_confirmed: int = 0,
    ):
        hidden = self.model(
            inputs,
            cache,
            input_embeddings=input_embeddings,
            n_confirmed=n_confirmed,
        )
        normed = self.model.norm(hidden)
        if not return_hidden and not n_confirmed and input_embeddings is None:
            # Prompt-priming capture rides prefill/decode forwards; verify
            # cycles (return_hidden) and confirmed-split forwards are the MTP
            # cycle's own and must not double-fold head history. A capture
            # failure must never break the forward itself.
            try:
                prompt_priming.maybe_capture(self, inputs, normed, cache)
            except Exception:
                logger.debug("MTP prompt-priming capture failed", exc_info=True)
        if self.args.tie_word_embeddings:
            out = self.model.embed_tokens.as_linear(normed)
        else:
            out = self.lm_head(normed)
        if return_hidden:
            return out, hidden
        return out

    def mtp_forward(
        self,
        hidden_states,
        next_token_ids,
        mtp_cache,
        return_hidden: bool = False,
        logits_keep: int = 0,
    ):
        """MTP-head forward.

        ``return_hidden`` returns the head's post-norm hidden alongside the
        logits so depth-k drafting can chain the head on its own output.
        ``logits_keep`` limits the lm_head projection to the last N positions
        (0 = all): the depth-k history+draft fold only needs logits at the
        final position, and the vocab is large enough (~250k) that skipping
        the other rows matters.
        """
        mtp_out = self.mtp(
            hidden_states,
            next_token_ids,
            self.model.embed_tokens,
            mtp_cache,
        )
        logits_source = mtp_out
        if logits_keep and logits_source.shape[1] > logits_keep:
            logits_source = logits_source[:, -logits_keep:, :]
        if self.args.tie_word_embeddings:
            logits = self.model.embed_tokens.as_linear(logits_source)
        else:
            logits = self.lm_head(logits_source)
        if return_hidden:
            return logits, mtp_out
        return logits

    def make_mtp_cache(self):
        if hasattr(self, "mtp"):
            return [KVCache() for _ in self.mtp.layers]
        return []

    def mtp_partial_rollback(self, cache, accepted: int, num_drafts: int) -> bool:
        """Roll the backbone cache back to ``accepted`` drafts after a depth-k
        verify forward over ``[confirmed, d1..dk]``.

        Full-attention KV layers trim ``num_drafts - accepted`` positions.
        GatedDeltaNet layers restore the zero-copy pre-forward state refs
        (``rollback_state``) and replay the kept prefix — the confirmed
        token plus the accepted drafts — through ``_process_chunk`` from the
        stashed projected inputs. One small gated-delta kernel per linear
        layer, paid only on rejections; the verify forward itself runs
        unsplit. Returns False if any layer lacks the state needed (caller
        falls back to the standard step).
        """
        layers = self.model.layers
        if len(cache) != len(layers):
            return False
        trim_n = num_drafts - accepted
        if trim_n <= 0:
            return True
        keep = 1 + accepted  # confirmed token + accepted drafts
        for layer, c in zip(layers, cache):
            if getattr(layer, "is_linear", False):
                if getattr(c, "rollback_state", None) is None:
                    return False
                if getattr(c, "_mtp_draft_stash", None) is None:
                    return False
            else:
                if not (hasattr(c, "is_trimmable") and c.is_trimmable()):
                    return False
        for layer, c in zip(layers, cache):
            if getattr(layer, "is_linear", False):
                conv_0, ssm_0 = c.rollback_state
                qkv_s, a_s, b_s = c._mtp_draft_stash
                _, conv_m, ssm_m = layer.linear_attn._process_chunk(
                    qkv_s[:, :keep],
                    a_s[:, :keep],
                    b_s[:, :keep],
                    conv_0,
                    ssm_0,
                    None,
                )
                c[0] = conv_m
                c[1] = ssm_m
                c.rollback_state = None
                c._mtp_draft_stash = None
            else:
                c.trim(trim_n)
        return True

    def sanitize(self, weights):
        # Full PR 990 replacement of TextModel.sanitize. We can't call the
        # original because mlx-lm's stock body unconditionally strips the
        # ``mtp.*`` keys (``weights = {k: v for k, v in weights.items() if
        # "mtp." not in k}``), which would defeat the whole patch. The
        # logic below mirrors PR 990's body line-for-line:
        #   - keep mtp.* when the model has an mtp head, drop otherwise
        #   - shift norm weights by +1 only on raw-HF checkpoints (detected
        #     via unsanitized conv1d shapes); already-converted MLX models
        #     must not be shifted again even when MTP weights are present
        #   - extend the norm-shift set with MTP-specific norm names so a
        #     genuine raw-HF MTP checkpoint also gets the right shift
        has_unsanitized_conv1d = any(
            "conv1d.weight" in k and getattr(v, "shape", (1,))[-1] != 1
            for k, v in weights.items()
        )
        should_shift_norm_weights = has_unsanitized_conv1d

        if not hasattr(self, "mtp"):
            weights = {k: v for k, v in weights.items() if "mtp." not in k}
        elif not any("mtp." in k for k in weights):
            raise ValueError(
                "Lightning MTP is enabled for this model but the converted "
                "weights are missing the mtp.* tensors. Default mlx-lm "
                "converters strip them; you need a converter that preserves "
                "MTP weights (or a Qwen3.6 / DeepSeek-V4 checkpoint that "
                "already preserves them). To recover without re-converting, "
                "open the model's settings in the oMLX admin UI and toggle "
                "'Lightning MTP' off, then retry."
            )

        if self.args.tie_word_embeddings:
            weights.pop("lm_head.weight", None)

        norm_keys = (
            ".input_layernorm.weight",
            ".post_attention_layernorm.weight",
            "model.norm.weight",
            ".q_norm.weight",
            ".k_norm.weight",
            # MTP-specific norms (not covered by the patterns above)
            ".pre_fc_norm_hidden.weight",
            ".pre_fc_norm_embedding.weight",
            "mtp.norm.weight",
        )
        for k, v in list(weights.items()):
            if "conv1d.weight" in k and v.shape[-1] != 1:
                weights[k] = v.moveaxis(2, 1)
            # MTP-head norms follow the backbone: a raw-HF checkpoint shifts
            # every zero-centered gamma by +1, an MLX-format checkpoint is
            # loaded as stored. Legacy mixed heads are repaired against the
            # backbone in ``norm_repair`` at load_weights time; no per-tensor
            # magnitude guess happens here (see #3742).
            if (
                should_shift_norm_weights
                and v.ndim == 1
                and any(k.endswith(sfx) for sfx in norm_keys)
            ):
                weights[k] = v + 1.0
        return weights

    def quant_predicate(self):
        def predicate(path, _):
            if path.endswith("mlp.gate") or path.endswith("shared_expert_gate"):
                return {"group_size": 64, "bits": 8}
            # Keep the MTP fusion projection in full precision.
            if path.endswith("mtp.fc"):
                return False
            return True

        if (
            self.args.num_experts <= 0
            and int(getattr(self.args, "mtp_num_hidden_layers", 0) or 0) <= 0
        ):
            return None
        return predicate

    if not init_wrapped:
        cls.__init__ = __init__
        cls._omlx_mtp_init_wrapped = True
    __call__._omlx_mtp_call_marker = True
    # Logits are lm_head(mtp(...)); draft chains may score candidates themselves.
    mtp_forward._omlx_lm_head_logits = True
    # The head reads only its own cache, so it can draft before the backbone commit.
    mtp_forward._omlx_head_cache_only = True
    cls.__call__ = __call__
    cls.mtp_forward = mtp_forward
    cls.make_mtp_cache = make_mtp_cache
    cls.mtp_partial_rollback = mtp_partial_rollback
    cls.sanitize = sanitize
    cls.quant_predicate = property(quant_predicate)


# ---------------------------------------------------------------------------
# Model (VLM-style outer wrapper) — pass-through for return_hidden, n_confirmed,
# mtp_forward, make_mtp_cache. Lets ``mtp_enabled`` work for VLM checkpoints
# too (their ``language_model`` is an instance of the patched ``TextModel``).
# ---------------------------------------------------------------------------

def _patch_outer_model(q35: Any) -> None:
    cls = q35.Model
    if _is_our_method(cls, "__call__", "_omlx_mtp_call_marker"):
        return

    def __call__(
        self,
        inputs,
        cache=None,
        input_embeddings=None,
        return_hidden: bool = False,
        n_confirmed: int = 0,
    ):
        return self.language_model(
            inputs,
            cache=cache,
            input_embeddings=input_embeddings,
            return_hidden=return_hidden,
            n_confirmed=n_confirmed,
        )

    def mtp_forward(
        self,
        hidden_states,
        next_token_ids,
        mtp_cache,
        return_hidden: bool = False,
        logits_keep: int = 0,
    ):
        return self.language_model.mtp_forward(
            hidden_states,
            next_token_ids,
            mtp_cache,
            return_hidden=return_hidden,
            logits_keep=logits_keep,
        )

    def make_mtp_cache(self):
        return self.language_model.make_mtp_cache()

    def mtp_partial_rollback(self, cache, accepted: int, num_drafts: int) -> bool:
        return self.language_model.mtp_partial_rollback(cache, accepted, num_drafts)

    __call__._omlx_mtp_call_marker = True
    cls.__call__ = __call__
    cls.mtp_forward = mtp_forward
    cls.make_mtp_cache = make_mtp_cache
    cls.mtp_partial_rollback = mtp_partial_rollback
    # Informational marker for external code that just wants to know "is
    # this class touched by the MTP patch". Idempotency itself uses the
    # function-level _omlx_mtp_call_marker above.
    cls._omlx_mtp_patched = True

    if not getattr(cls, "_omlx_mtp_norm_repair_patched", False):
        original_load_weights = cls.load_weights

        def load_weights(self, weights, strict=True):
            from .norm_repair import repair_legacy_head_norms

            try:
                weights, _ = repair_legacy_head_norms(weights)
            except Exception:
                logger.warning("MTP head-norm repair failed", exc_info=True)
            return original_load_weights(self, weights, strict=strict)

        cls.load_weights = load_weights
        cls._omlx_mtp_norm_repair_patched = True


# ---------------------------------------------------------------------------
# qwen3_5_moe.Model — sanitize replacement to handle MTP MoE weight formats.
# ---------------------------------------------------------------------------

def _patch_qwen3_5_moe() -> None:
    """Replace ``qwen3_5_moe.Model.sanitize`` to handle MTP MoE weight formats.

    PR 990 extends the MoE sanitize to detect whether MTP layers ship their
    expert weights in the fused ``gate_up_proj`` form (Qwen3.6) or as
    per-expert tensors (Qwen3.5) and convert each to the unified
    ``switch_mlp`` layout. Without this, loading a Qwen3.5/3.6 MoE
    checkpoint that has MTP weights fails on key mismatches.
    """
    try:
        from mlx_lm.models import qwen3_5_moe as moe
    except ImportError:
        # Some installs don't ship the MoE module; that's fine — dense
        # Qwen3.5 still works through the regular qwen3_5 patch.
        logger.debug("mlx_lm.models.qwen3_5_moe not importable; skipping MoE patch")
        return

    cls = moe.Model
    if _is_our_method(cls, "sanitize", "_omlx_mtp_call_marker"):
        return

    import mlx.core as mx

    def _unfuse_experts(weights, prefix):
        gate_up_key = f"{prefix}.experts.gate_up_proj"
        if gate_up_key not in weights:
            return
        gate_up = weights.pop(gate_up_key)
        mid = gate_up.shape[-2] // 2
        weights[f"{prefix}.switch_mlp.gate_proj.weight"] = gate_up[..., :mid, :]
        weights[f"{prefix}.switch_mlp.up_proj.weight"] = gate_up[..., mid:, :]
        weights[f"{prefix}.switch_mlp.down_proj.weight"] = weights.pop(
            f"{prefix}.experts.down_proj"
        )

    def _stack_per_expert(weights, prefix, num_experts):
        if f"{prefix}.experts.0.gate_proj.weight" not in weights:
            return
        # Metal-knowledge: also stack quantization metadata (.scales, .biases)
        # so oQ-quantized MoE MTP layers load correctly. Without this, only
        # .weight gets stacked and the per-expert scales/biases remain as
        # extra unwanted parameters — "Received N parameters not in model".
        for n in ("gate_proj", "up_proj", "down_proj"):
            for suffix in ("weight", "scales", "biases"):
                first_key = f"{prefix}.experts.0.{n}.{suffix}"
                if first_key not in weights:
                    continue
                weights[f"{prefix}.switch_mlp.{n}.{suffix}"] = mx.stack(
                    [
                        weights.pop(f"{prefix}.experts.{e}.{n}.{suffix}")
                        for e in range(num_experts)
                    ]
                )

    def sanitize(self, weights):
        new_weights = {}
        for key, value in weights.items():
            if key.startswith("vision_tower") or key.startswith("model.visual"):
                continue
            if key.startswith("model.language_model"):
                key = key.replace("model.language_model", "language_model.model")
            elif not key.startswith("language_model."):
                key = "language_model." + key
            new_weights[key] = value

        num_experts = int(
            getattr(self.language_model.args, "num_experts", 0) or 0
        )

        # Backbone MoE layers: fused gate_up_proj (Qwen3.6) or per-expert
        # tensors (Ornith / raw Qwen3.5 MoE). Try fused first; fall back to
        # per-expert stacking when fused keys are absent.
        for l in range(self.language_model.args.num_hidden_layers):
            prefix = f"language_model.model.layers.{l}.mlp"
            if f"{prefix}.switch_mlp.gate_proj.weight" in new_weights:
                continue  # already in SwitchLinear form
            _unfuse_experts(new_weights, prefix)
            if (
                f"{prefix}.switch_mlp.gate_proj.weight" not in new_weights
                and num_experts > 0
            ):
                _stack_per_expert(new_weights, prefix, num_experts)

        # MTP layers: fused (Qwen3.6), per-expert (Qwen3.5), or dense (MTPLX).
        mtp_num = int(
            getattr(self.language_model.args, "mtp_num_hidden_layers", 0) or 0
        )
        if mtp_num > 0:
            has_any_mtp = any(
                k.startswith("language_model.mtp.") for k in new_weights
            )
            if not has_any_mtp:
                logger.debug(
                    "mtp_num_hidden_layers=%d but no MTP weights found; "
                    "model may have been quantized without preserve_mtp",
                    mtp_num,
                )
            else:
                mtp_is_fused = (
                    "language_model.mtp.layers.0.mlp.experts.gate_up_proj"
                    in new_weights
                )
                for layer_idx in range(mtp_num):
                    prefix = f"language_model.mtp.layers.{layer_idx}.mlp"
                    # Idempotent: oQ outputs already store experts in
                    # switch_mlp form (mlx-vlm sanitize patch unfuses MTP
                    # experts before quantization). Skip the load-time
                    # unfuse/stack in that case.
                    if f"{prefix}.switch_mlp.gate_proj.weight" in new_weights:
                        continue
                    # MTPLX (lightning-mlx convert) layout: MTP layer is dense
                    # — no per-expert tensors to stack/unfuse. The router/gate
                    # and shared_expert weights are passed through unchanged.
                    # Probe by layout sentinel (O(1)) rather than scanning all
                    # weight keys — matters on multi-thousand-tensor checkpoints.
                    sentinel = (
                        f"{prefix}.experts.gate_up_proj"
                        if mtp_is_fused
                        else f"{prefix}.experts.0.gate_proj.weight"
                    )
                    if sentinel not in new_weights:
                        continue
                    if mtp_is_fused:
                        _unfuse_experts(new_weights, prefix)
                    else:
                        _stack_per_expert(new_weights, prefix, num_experts)

        return self.language_model.sanitize(new_weights)

    sanitize._omlx_mtp_call_marker = True
    cls.sanitize = sanitize
