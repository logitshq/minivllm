# SPDX-License-Identifier: Apache-2.0
"""Native MTP monkey-patches for mlx-vlm.

mlx-vlm ships its own ``Model.sanitize`` for VLM checkpoints
(Qwen3_5ForConditionalGeneration etc). The stock body unconditionally
strips ``mtp.*`` weights and only shifts a fixed set of backbone norm
keys by +1 — the MTP head's own norms (``mtp.norm.weight``,
``mtp.pre_fc_norm_*.weight`` and the per-block layernorms) miss the
shift, so MTP layers run with raw RMSNorm weights after quantization.

This package patches the affected mlx-vlm Model classes so the sanitize
output keeps ``mtp.*`` and applies the +1 norm shift to every MTP norm,
matching what mlx-lm PR 990 does on the LLM side.

Activation: oQ quantization invokes ``apply_mlx_vlm_mtp_patch`` before
building the VLM sanitizer. The patches are idempotent.
"""

from __future__ import annotations

import importlib
import logging

logger = logging.getLogger(__name__)


# Process-wide gate read by ``LanguageModel.__init__`` (in both
# ``qwen35_moe_vlm_runtime`` and ``qwen35_vlm_runtime``) to decide whether
# to attach ``MTPModule`` when the config declares ``mtp_num_hidden_layers
# > 0``. Default True preserves PR #1404 behavior: VLM checkpoints that
# actually ship persisted ``mtp.*`` weights need the head bound even with
# ``mtp_enabled=False`` so strict ``load_weights`` succeeds.
#
# Caller (``utils/model_loading.py::maybe_apply_pre_load_patches``) flips
# this to False right before ``mlx_vlm.utils.load()`` runs when the
# checkpoint declares MTP heads in config but ships no ``mtp.*`` weights
# (e.g. unsloth Qwen3.6 UD MLX builds, issue #1426). Without the gate,
# strict load fails with "Missing N parameters" and the engine silently
# falls back to LLM, dropping vision.
#
# Single-thread MLX executor serializes loads, so this is race-free.
_MTP_ATTACH_ENABLED = True


def set_mtp_attach_enabled(enabled: bool) -> None:
    """Toggle whether subsequent ``mlx_vlm.utils.load()`` calls attach the
    VLM MTPModule.

    Independent of ``mlx_lm_mtp.set_mtp_active``: attach controls module
    presence so strict load can bind persisted ``mtp.*`` weights, active
    controls whether BatchGenerator actually invokes the MTP head during
    decode.
    """
    global _MTP_ATTACH_ENABLED
    _MTP_ATTACH_ENABLED = bool(enabled)


def is_mtp_attach_enabled() -> bool:
    return _MTP_ATTACH_ENABLED


def apply_mlx_vlm_mtp_patch() -> bool:
    """Apply the mlx-vlm MTP sanitize monkey-patches.

    Returns True on success (or if already applied), False if the
    sub-step refused (mlx-vlm not importable, etc.). Idempotency is
    handled by each sub-patcher via class-level flags — no module-wide
    cache flag, keeping behavior consistent with mlx_lm_mtp.
    """
    from . import inkling_vlm_runtime, qwen35_moe_vlm_model, qwen35_vlm_model

    if not qwen35_vlm_model.apply():
        logger.debug("Qwen3.5 VLM MTP sanitize patch did not apply")
    if not qwen35_moe_vlm_model.apply():
        logger.debug("Qwen3.5 MoE VLM MTP sanitize patch did not apply")
    if not inkling_vlm_runtime.apply_sanitize():
        logger.debug("Inkling MTP sanitize hook did not apply")

    return True


# The unscoped sweep, in the order it has always run. Every entry in
# ``_RUNTIME_PATCHES_BY_TYPE`` below is drawn from this tuple.
_RUNTIME_PATCHES: tuple[str, ...] = (
    "qwen35_moe_vlm_runtime",
    "qwen35_vlm_runtime",
    "gemma4_vlm_runtime",
    "inkling_vlm_runtime",
    "glm5_next_vlm_runtime",
)

# Which runtime sub-patch belongs to which ``model_type``. These patches
# rebind methods on shared parent classes and other architectures subclass
# them, so applying all of them reaches models this load has nothing to do
# with. An empty tuple means the architecture manages its own MTP and must
# never receive the sweep. A model_type that is not listed keeps the
# historical apply-everything behaviour.
_RUNTIME_PATCHES_BY_TYPE: dict[str, tuple[str, ...]] = {
    "qwen3_5": ("qwen35_vlm_runtime",),
    "qwen3_5_moe": ("qwen35_moe_vlm_runtime", "qwen35_vlm_runtime"),
    "gemma4": ("gemma4_vlm_runtime",),
    "gemma4_unified": ("gemma4_vlm_runtime",),
    "inkling": ("inkling_vlm_runtime",),
    "inkling_mm_model": ("inkling_vlm_runtime",),
    "glm5_next": ("glm5_next_vlm_runtime",),
    "qwen4_exp": (),
}


def _patches_for(
    model_type: str | None,
    table: dict[str, tuple[str, ...]],
    kind: str,
) -> tuple[str, ...] | None:
    """Sub-patches owning ``model_type``, or None to keep the historical sweep.

    Exact match first, then the longest declared prefix: family variants
    (``qwen3_5_moe_*`` and friends, which ``_is_mtp_compatible`` admits by
    prefix) subclass the same shared parents as the family they extend, so
    the family's entry owns them. Without the prefix step such a variant
    falls through to the apply-everything sweep and rebinds architectures
    this load has nothing to do with, which is the failure the table exists
    to prevent.
    """
    if not model_type:
        return None
    if model_type in table:
        return table[model_type]
    family = max(
        (k for k in table if model_type.startswith(k)), key=len, default=None
    )
    if family is not None:
        return table[family]
    # _is_mtp_compatible admits model_type prefixes (qwen3_5*, qwen3_6*), so a
    # variant can reach this with no entry and no declared family, and fall
    # back to the unscoped sweep. Say so rather than doing it silently.
    logger.debug(
        "mlx-vlm MTP %s patch: no entry for model_type=%s, applying every "
        "architecture's patch",
        kind,
        model_type,
    )
    return None


def apply_mlx_vlm_mtp_runtime_patch(model_type: str | None = None) -> bool:
    """Apply the mlx-vlm runtime MTP patches (attach MTPModule, mtp_forward).

    Distinct from ``apply_mlx_vlm_mtp_patch``: that one only patches
    ``sanitize`` for conversion-time MTP preservation. This one builds
    the runtime infrastructure so VLMBatchedEngine can actually invoke
    the MTP head at inference time.

    Covers Qwen3.5-MoE (qwen3_5_moe), dense Qwen3.5/3.6 (qwen3_5), Gemma 4
    merged-assistant (gemma4 and gemma4_unified) and GLM-5.3-Flash
    (glm5_next) VLM families. Each sub-patch tracks its own ``_APPLIED``
    flag, so calling repeatedly is cheap once all have settled. Returns True if at least one sub-patch applied
    successfully — a given model only needs whichever matches its
    model_type.

    Should be called *before* ``mlx_vlm.utils.load(...)`` so the
    instantiated LanguageModel picks up the patched ``__init__``.

    ``model_type`` scopes the sweep to the architecture being loaded.
    qwen4_exp's LanguageModel, gated delta net and attention all subclass
    qwen3_5's, so applying the qwen3_5 runtime while a qwen4_exp model is
    resident rewrites that live model's trunk ``__call__`` and its next
    request fails with "Qwen4 Lightning MTP expects hidden shape
    [batch, tokens, hc_count * hidden_size]" until the server restarts.
    """
    scoped = _patches_for(model_type, _RUNTIME_PATCHES_BY_TYPE, "runtime")
    if scoped is not None:
        logger.debug(
            "mlx-vlm MTP runtime patch scoped to model_type=%s", model_type
        )

    applied = False
    for name in _RUNTIME_PATCHES if scoped is None else scoped:
        if importlib.import_module(f".{name}", __name__).apply():
            applied = True
        else:
            logger.debug("%s MTP runtime patch did not apply", name)

    return applied


def apply_external_mtp_runtime_patch() -> None:
    """Commit external MTP cache state on the verifier stream."""
    from functools import wraps

    import mlx.core as mx
    from mlx_vlm.speculative import mtp

    original = mtp._MTPVerifyResult.commit
    if getattr(original, "_omlx_generation_stream", False):
        return

    @wraps(original)
    def commit(*args, **kwargs):
        with mx.stream(mtp.generation_stream):
            return original(*args, **kwargs)

    commit._omlx_generation_stream = True
    mtp._MTPVerifyResult.commit = commit
