# SPDX-License-Identifier: Apache-2.0
"""Lightning MTP dispatch for mlx-lm continuous batching.

Qwen and GLM adapters share compatible verification forwards; DeepSeek V4.1
verifies each request independently. Other adapters retain singleton MTP.
Draft history, acceptance, processors and termination belong to each UID.

Activation starts from the committed post-prefill cache. Batch reshaping
preserves owned histories or reconciles them before standard decoding resumes.
Auto depth and parking use the measured cost of the whole active batch.
"""

from __future__ import annotations

import contextlib
import functools
import inspect
import logging
import math
import time
import weakref
from collections import deque
from dataclasses import dataclass, field
from statistics import median
from types import SimpleNamespace
from typing import Any, Deque, Dict, List, Optional, Tuple

from omlx.prefill_progress import get_prefill_tracker

from . import cache_rollback as _rollback_mod
from . import context_copy as _context_copy
from . import prompt_priming as _prompt_priming

logger = logging.getLogger(__name__)


def _set_verify_qmm_armed(flag: bool, *, row_exact: bool = False) -> None:
    """Arm the verify-shape qmm routing for the duration of an MTP forward.

    ``row_exact`` arms the row-exact mode instead (see
    ``_row_exact_verify``). Import is deferred and failure-tolerant: the
    kernel module is optional and its absence must not affect the MTP path.
    """
    try:
        from ..qwen35_verify_qmm import set_verify_qmm_armed

        set_verify_qmm_armed(flag, row_exact=row_exact)
    except Exception:
        pass


def _row_exact_verify(model: Any) -> bool:
    """Whether the target's verify rows must reproduce its one-row decode.

    Models opt in with ``_omlx_mtp_row_exact_verify`` (Qwen4-Exp). Their
    armed verify forwards then run every multi-row quantized projection,
    DeltaNet prework and attention row with the arithmetic of a serial
    decode step, so greedy MTP output equals MTP-off output byte for byte.
    """
    for candidate in (
        model,
        getattr(model, "_language_model", None),
        getattr(model, "language_model", None),
    ):
        if getattr(candidate, "_omlx_mtp_row_exact_verify", False):
            return True
    return False


def _set_dspark_target_verify(model: Any, flag: bool) -> None:
    try:
        import sys

        host = _dspark_host(model)
        if host is None:
            return
        module = sys.modules.get(type(host).__module__)
        setter = getattr(module, "set_dspark_verify_armed", None)
        if setter is not None:
            setter(flag)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def apply() -> bool:
    """Wrap ``GenerationBatch`` and ``BatchGenerator`` MTP hooks.

    One-shot by design: the wraps capture ``original_*`` in closures so
    re-applying would chain wraps and double-init. ``GenerationBatch`` is
    not touched by dflash so the leftover-class-patch risk that motivates
    self-healing elsewhere doesn't apply here.
    """
    try:
        from mlx_lm.generate import BatchGenerator, GenerationBatch
    except ImportError:
        logger.debug("mlx_lm.generate GenerationBatch/BatchGenerator not importable")
        return False

    if not hasattr(GenerationBatch, "_omlx_mtp_patched"):
        original_init = GenerationBatch.__init__
        original_next = GenerationBatch.next
        original_filter = GenerationBatch.filter
        original_extend = GenerationBatch.extend

        def patched_init(self, model, uids, *args, **kwargs):
            with _prompt_priming.decode_scope(model, uids), _drafter_scope(model, uids):
                original_init(self, model, uids, *args, **kwargs)
            # Do not activate MTP here. Fresh singleton batches created by
            # PromptProcessingBatch.generate() may still be merged into a larger
            # continuous batch; mutating their cache in __init__ can corrupt the
            # later standard batched path. Activation is lazy in patched_next().
            uids = getattr(self, "uids", None)
            if uids:
                reason = _ineligibility_reason(self)
                if reason:
                    logger.debug("MTP path not active: %s", reason)

        def patched_next(self, *args, **kwargs):
            if _is_mtp_batch_eligible(self):
                policy = _batch_policy_for_next(self)
                _batch_park_memory(self.model).tick()
                if policy is not None and policy.needs_standard():
                    if not _reconcile_mtp_batch_to_standard(self):
                        raise RuntimeError(
                            "Lightning MTP could not restore batch calibration state"
                        )
                    _drop_mtp_batch_state(
                        self, "batch-standard-calibration", log_stats=True
                    )
                    started = time.perf_counter()
                    result = original_next(self, *args, **kwargs)
                    if tuple(self.uids) == policy.uids:
                        elapsed = policy.cycle_time_ms(
                            "standard", started, time.perf_counter()
                        )
                        policy.observe_standard(elapsed)
                        if elapsed is not None:
                            logger.debug(
                                "Lightning MTP ordinary batch sample: rows=%d ms=%.3f",
                                len(self.uids),
                                elapsed,
                            )
                    return result
                try:
                    batch_state = _prepare_mtp_batch_state_for_next(self)
                    if batch_state is not None:
                        with _spec_command_buffers():
                            return _mtp_batch_next(self, batch_state)
                except _MtpStepFallback as exc:
                    logger.debug("MTP batch next() fallback to standard step: %s", exc)
                    if not _reconcile_mtp_batch_to_standard(self):
                        raise RuntimeError(
                            "Lightning MTP could not restore the committed batch cache"
                        ) from exc
                    _drop_mtp_batch_state(self, "batch-step-fallback")
            elif getattr(self, "_omlx_mtp_batch_state", None) is not None:
                if not _reconcile_mtp_batch_to_standard(self):
                    raise RuntimeError(
                        "Lightning MTP could not restore the committed batch cache"
                    )
                _drop_mtp_batch_state(self, "batch-ineligible")

            if _is_mtp_eligible(self):
                handed_off = False
                if _singleton_mtp_handoff_ready(self):
                    # A prefill is waiting on this batch generator; hand the
                    # singleton back to the standard step at the drained-queue
                    # boundary so the late join merges this very call (#2515).
                    handed_off = _handoff_mtp_for_late_join(self, self._omlx_mtp_state)
                if not handed_off:
                    try:
                        state = _prepare_mtp_state_for_next(self)
                        if state is not None:
                            with _spec_command_buffers():
                                return _mtp_next(self, state)
                    except _MtpStepFallback as exc:
                        logger.debug("MTP next() fallback to standard step: %s", exc)
                        active = getattr(self, "_omlx_mtp_state", None)
                        if active is not None:
                            if not _reconcile_mtp_to_standard(self, active):
                                raise RuntimeError(
                                    "Lightning MTP could not restore the committed cache"
                                ) from exc
                            if active.reentry_probe:
                                try:
                                    delattr(self, "_omlx_mtp_park_state")
                                except AttributeError:
                                    pass
                        _drop_mtp_state(self, "step-fallback")
            else:
                _drop_mtp_state(self, "non-singleton-or-ineligible")
            _log_multirow_mtp_inactive_once(self)
            _mark_standard_multirow_decode(self)
            tax_probe = getattr(self, "_omlx_mtp_tax_probe", None)
            park_state = _mtp_park_state_for_batch(self)
            if tax_probe is not None or park_state is not None:
                step_t0 = time.perf_counter()
                result = original_next(self, *args, **kwargs)
                if tax_probe is not None:
                    _record_std_tax_sample(
                        self, (time.perf_counter() - step_t0) * 1000.0
                    )
                if park_state is not None:
                    _record_parked_standard_step(self)
                return result
            return original_next(self, *args, **kwargs)

        def patched_extend(self, batch, *args, **kwargs):
            # Reconcile before adding rows without MTP state so the drained
            # batch can feed its last tokens without replaying its history.
            if not _reconcile_mtp_batch_to_standard(self):
                raise RuntimeError(
                    "Lightning MTP could not restore the committed batch cache"
                )
            _drop_mtp_batch_state(self, "extend-reconciled")
            _drop_mtp_batch_state(batch, "donor-extended")

            host_state = getattr(self, "_omlx_mtp_state", None)
            if host_state is not None and _mtp_state_valid_for_batch(self, host_state):
                # A shared batch that a finishing row just filtered to this
                # singleton sits at a drained frontier: hand it off with at
                # most a one-token forward instead of replaying its history.
                if not _handoff_mtp_for_late_join(self, host_state):
                    if host_state.reentry_probe:
                        park_state = _mtp_park_state_for_batch(self)
                        if park_state is not None:
                            park_state.defer_probe()
                    if not _reconcile_mtp_to_standard(self, host_state):
                        raise RuntimeError(
                            "Lightning MTP could not restore the committed cache"
                        )
                    _drop_mtp_state(self, "extend-reconciled")
            result = original_extend(self, batch, *args, **kwargs)
            _drop_mtp_state(batch, "donor-extended")
            _drop_invalid_mtp_state(self, "extend")
            _drop_invalid_mtp_batch_state(self, "extend")
            # Priming only serves a singleton timeline: once this batch
            # holds >1 rows, the context can never be consumed — release
            # its head cache now instead of riding the merged decode.
            uids = getattr(self, "uids", None)
            if not uids or len(uids) != 1:
                _prompt_priming.drop_ctx(getattr(self, "model", None))
            return result

        def patched_filter(self, keep, *args, **kwargs):
            old_uids = list(getattr(self, "uids", []) or [])
            result = original_filter(self, keep, *args, **kwargs)
            _prompt_priming.release_uids(self.model, set(old_uids) - set(self.uids))
            _release_drafter_uids(self.model, set(old_uids) - set(self.uids))
            _drop_invalid_mtp_state(self, "filter", log_empty=True)
            _drop_invalid_mtp_batch_state(
                self,
                "filter",
                old_uids=old_uids,
                log_empty=True,
            )
            _mtp_park_state_for_batch(self)
            return result

        def scoped_next(self, *args, **kwargs):
            realign_rows = getattr(self, "_omlx_realign_rows", None)
            if callable(realign_rows):
                realign_rows()
            _maybe_clear_multirow_marker(self)
            model = getattr(self, "model", None)
            uids = getattr(self, "uids", ())
            with _prompt_priming.decode_scope(model, uids), _drafter_scope(model, uids):
                return patched_next(self, *args, **kwargs)

        GenerationBatch.__init__ = patched_init
        GenerationBatch.next = scoped_next
        GenerationBatch.filter = patched_filter
        GenerationBatch.extend = patched_extend
        GenerationBatch._omlx_mtp_patched = True

    if not hasattr(BatchGenerator, "_omlx_mtp_patched"):
        original_bg_next = BatchGenerator._next
        original_bg_remove = BatchGenerator.remove
        original_bg_close = BatchGenerator.close

        def patched_bg_remove(self, uids, *args, **kwargs):
            uids = tuple(uids)
            result = original_bg_remove(self, uids, *args, **kwargs)
            _prompt_priming.release_uids(self.model, uids)
            _release_drafter_uids(self.model, uids)
            return result

        def patched_bg_close(self):
            uids = []
            for name in ("_prompt_batch", "_generation_batch"):
                uids.extend(getattr(getattr(self, name, None), "uids", ()))
            uids.extend(seq[0] for seq in getattr(self, "_unprocessed_sequences", ()))
            try:
                return original_bg_close(self)
            finally:
                _prompt_priming.release_uids(getattr(self, "model", None), uids)
                _release_drafter_uids(getattr(self, "model", None), uids)

        def patched_bg_next(self, *args, **kwargs):
            gen_batch = getattr(self, "_generation_batch", None)
            if gen_batch is not None:
                # Reconcile runs on GenerationBatch, which upstream creates
                # without the owning generator's prefill configuration.
                gen_batch.prefill_step_size = getattr(self, "prefill_step_size", 512)
                gen_batch._omlx_mtp_activation_safe = (
                    _batch_generator_allows_mtp_activation(self)
                )
            if (
                _generation_batch_has_active_mtp(gen_batch)
                and not _singleton_mtp_handoff_ready(gen_batch)
                and getattr(gen_batch, "_omlx_mtp_batch_state", None) is None
            ):
                old_completion_batch_size = getattr(
                    self,
                    "completion_batch_size",
                    None,
                )
                had_completion_batch_size = hasattr(self, "completion_batch_size")
                # Drain singleton speculation before admitting a late join.
                self.completion_batch_size = 0
                try:
                    return original_bg_next(self, *args, **kwargs)
                finally:
                    if had_completion_batch_size:
                        self.completion_batch_size = old_completion_batch_size
                    elif hasattr(self, "completion_batch_size"):
                        delattr(self, "completion_batch_size")
            result = original_bg_next(self, *args, **kwargs)
            if result[0]:
                interrupt_batch_timing(self)
            return result

        BatchGenerator._next = patched_bg_next
        BatchGenerator.remove = patched_bg_remove
        BatchGenerator.close = patched_bg_close
        BatchGenerator._omlx_mtp_patched = True
    return True


def interrupt_batch_timing(generator: Any) -> None:
    """Exclude a prefill-interrupted interval from batch cost learning."""
    batch = getattr(generator, "_generation_batch", None)
    policy = getattr(batch, "_omlx_mtp_batch_policy", None)
    if policy is not None:
        policy.interrupt_timing()


def _model_has_mtp_module(model: Any) -> bool:
    """Check whether the model actually has an MTP head attached.

    The ``mtp_forward`` method is added to the class unconditionally by
    the patch, but the per-instance ``mtp`` module is only attached when
    ``mtp_enabled`` was True at load time (see qwen35_model._patch_model
    and deepseek_v4_model._patch_model). Without the inner module the
    ``mtp_forward`` call would AttributeError, so we gate eligibility on
    the actual module's presence.
    """
    inner = getattr(model, "language_model", model)
    return hasattr(inner, "mtp") and getattr(inner, "mtp", None) is not None


# MLX commits a command buffer every ~50 ops or 50 MB of inputs, weights
# included, and blocks eval at ten in flight, so a cycle could not queue the
# next draft behind a running verify. Prefill keeps MLX's caps: larger ones
# raise its peak memory.
_SPEC_BUFFER_CAPS = (200, 512)


@functools.lru_cache(maxsize=1)
def _raises_spec_buffer_caps() -> bool:
    """True on GPUs where the raised caps were measured: M5 and the M3 family."""
    import mlx.core as mx

    from omlx.custom_kernels.nax import is_nax_available

    if is_nax_available():
        return True
    try:
        architecture = str(mx.device_info().get("architecture", ""))
    except Exception:
        return False
    return architecture.startswith("applegpu_g15")


@contextlib.contextmanager
def _spec_command_buffers():
    """Raise MLX's command-buffer caps for one speculative decode step.

    Measured on M5 and M3 Ultra, so other GPUs keep MLX's caps.
    """
    from omlx.custom_kernels.qwen35_prefill.fast import set_command_buffer_caps

    previous = None
    if _raises_spec_buffer_caps():
        previous = set_command_buffer_caps(*_SPEC_BUFFER_CAPS)
    try:
        yield
    finally:
        if previous is not None:
            set_command_buffer_caps(*previous)


def _drafter_for(model: Any) -> Optional[Any]:
    """Return the external block drafter attached to the model, if any.

    A drafter replaces the embedded MTP head as the draft source. It is
    stamped on the language model as ``_omlx_drafter`` at attach time and
    exposes ``depth``, ``target_layer_ids``, ``draft``, ``observe``,
    ``release`` and ``decode_scope`` (see omlx.speculative.dflash_drafter).
    """
    candidates = [model]
    for attr in ("language_model", "_language_model"):
        inner = getattr(model, attr, None)
        if inner is not None and inner is not model:
            candidates.append(inner)
    for candidate in candidates:
        # Only an attribute attach_drafter actually set counts; a dynamic
        # __getattr__ (mocks, adapters) must not look like a drafter.
        drafter = inspect.getattr_static(candidate, "_omlx_drafter", None)
        if drafter is not None:
            return drafter
    return None


def _drafter_capture_ids(model: Any) -> Optional[List[int]]:
    drafter = _drafter_for(model)
    if drafter is None:
        return None
    return list(drafter.target_layer_ids)


def _release_drafter_uids(model: Any, uids) -> None:
    drafter = _drafter_for(model)
    if drafter is not None:
        drafter.release(uids)


@contextlib.contextmanager
def _drafter_scope(model: Any, uids):
    """Attribute ordinary decode forwards inside the scope to ``uids``.

    The model runtime captures the drafter's layers on every plain decode
    forward while a scope is open, so tokens processed by ordinary steps
    (batch init, calibration, late-join handoff) stay in the drafter context.
    """
    drafter = _drafter_for(model) if model is not None else None
    if drafter is None or uids is None:
        yield
        return
    with drafter.decode_scope(uids):
        yield


def _model_mtp_decode_enabled(model: Any) -> bool:
    """Return the MTP decode decision captured on the loaded model instance.

    ``mlx_lm_mtp._MTP_ACTIVE`` is a construction-time switch. It is reset
    before each model load so patched ``__init__`` methods know whether to
    attach MTP heads, but decode-time eligibility must not read that global:
    a later non-MTP load would otherwise disable already-loaded MTP models.
    """
    candidates = [model]
    for attr in ("language_model", "_language_model"):
        inner = getattr(model, attr, None)
        if inner is not None and inner is not model:
            candidates.append(inner)
    return any(
        bool(getattr(candidate, "_omlx_mtp_decode_enabled", False))
        for candidate in candidates
    )


def _batch_generator_allows_mtp_activation(batch_gen: Any) -> bool:
    """True when lazy MTP activation cannot race with a pending batch merge."""
    try:
        return (
            len(getattr(batch_gen, "_unprocessed_sequences", [])) == 0
            and len(getattr(batch_gen, "_prompt_batch", [])) == 0
            and len(getattr(batch_gen, "_currently_processing", [])) == 0
        )
    except Exception:
        return False


def _generation_batch_has_active_mtp(gen_batch: Any) -> bool:
    """True while a generation batch owns Lightning MTP cache state."""
    if gen_batch is None:
        return False
    try:
        if len(gen_batch) == 0:
            return False
    except Exception:
        pass
    return (
        getattr(gen_batch, "_omlx_mtp_state", None) is not None
        or getattr(gen_batch, "_omlx_mtp_batch_state", None) is not None
    )


def _singleton_mtp_handoff_ready(gen_batch: Any) -> bool:
    """Allow a singleton handoff once at most one committed token is unstreamed."""
    if gen_batch is None:
        return False
    if getattr(gen_batch, "_omlx_mtp_activation_safe", True):
        return False
    if getattr(gen_batch, "_omlx_mtp_batch_state", None) is not None:
        return False
    state = getattr(gen_batch, "_omlx_mtp_state", None)
    if not _mtp_state_valid_for_batch(gen_batch, state):
        return False
    return len(state.queue) <= 1


def _mtp_common_eligible(gen_batch: Any) -> bool:
    park_state = _mtp_park_state_for_batch(gen_batch)
    if park_state is not None and len(getattr(gen_batch, "uids", ()) or ()) == 1:
        active = getattr(gen_batch, "_omlx_mtp_state", None)
        active_probe = bool(
            active is not None
            and getattr(active, "uid", None) == park_state.uid
            and getattr(active, "reentry_probe", False)
        )
        # Batch parking uses its own cost policy; this cooldown belongs to one UID.
        if not active_probe and not park_state.probe_ready():
            return False
    if not hasattr(gen_batch, "model"):
        return False
    drafter = _drafter_for(gen_batch.model)
    if drafter is None:
        if not hasattr(gen_batch.model, "mtp_forward"):
            return False
        if not _model_has_mtp_module(gen_batch.model):
            return False
    if not _model_mtp_decode_enabled(gen_batch.model):
        return False
    uids = getattr(gen_batch, "uids", None)
    if uids is None or len(uids) == 0:
        return False
    if _has_grammar_processors(gen_batch):
        return False
    # XTC changes the target distribution but is absent from acceptance math.
    # Resolve each active row's sampler because the generator is reused.
    return not _has_xtc_sampler(gen_batch)


def _allows_new_mtp_activation(gen_batch: Any, state_attr: str) -> bool:
    if getattr(gen_batch, state_attr, None) is not None:
        return True
    # The multirow-decode marker guards the singleton-init invariant only
    # (see _mark_standard_multirow_decode). Row-wise batch activation seeds
    # every row from a freshly extracted per-row cache, so a prior standard
    # multi-row decode is exactly the state it expects — blocking it here
    # would permanently lock batches out of MTP, because a batch's first
    # decode step is always standard.
    if state_attr == "_omlx_mtp_state" and getattr(
        gen_batch, "_omlx_mtp_saw_standard_multirow_decode", False
    ):
        return False
    return bool(getattr(gen_batch, "_omlx_mtp_activation_safe", True))


def _mark_standard_multirow_decode(gen_batch: Any) -> None:
    """Remember that this batch has decoded with shared standard cache state.

    A row that survives a standard multi-row decode and later becomes singleton
    no longer satisfies the narrow invariant that singleton MTP initialization
    relies on. Existing row-wise MTP state may continue, but starting a fresh
    singleton MTP state after late-join/late-finish reshaping is unsafe.

    The marker is not permanent: once the batch shrinks back to one row with a
    verifiably compact cache, ``_maybe_clear_multirow_marker`` lifts it so the
    surviving request regains MTP for the rest of its generation.
    """
    try:
        if len(getattr(gen_batch, "uids", []) or []) > 1:
            gen_batch._omlx_mtp_saw_standard_multirow_decode = True
    except Exception:
        pass


def _log_multirow_mtp_inactive_once(gen_batch: Any) -> None:
    """Say once, at INFO, why an MTP-capable batch is decoding without MTP.

    #2150 showed the silent fallback is easy to misread: the benchmark's
    batched phases report plain continuous-batching numbers while every log
    line about MTP inactivity hides at DEBUG. One line per batch keeps the
    signal visible without per-step spam.
    """
    if getattr(gen_batch, "_omlx_mtp_inactive_logged", False):
        return
    uids = getattr(gen_batch, "uids", None)
    if uids is None or len(uids) <= 1:
        return
    if not _mtp_common_eligible(gen_batch):
        return
    gen_batch._omlx_mtp_inactive_logged = True
    logger.info(
        "MTP inactive for %d-row batch: %s",
        len(uids),
        _ineligibility_reason(gen_batch) or "activation deferred",
    )


def _maybe_clear_multirow_marker(gen_batch: Any) -> None:
    """Re-enable singleton MTP once a shrunken batch is verifiably safe again.

    The multirow marker exists because a row surviving batch reshaping may sit
    in a cache whose layout singleton MTP's raw backbone calls don't expect
    (left padding). ``BatchKVCache.filter()`` shifts out the minimum shared
    left padding, so a batch filtered down to one row is compact again in the
    common case — verify that per layer instead of assuming, and only then
    lift the marker. Without this, a request that ever shared a decode step
    with another request is locked out of MTP for the rest of its generation
    even once it is running alone (#2150).
    """
    if not getattr(gen_batch, "_omlx_mtp_saw_standard_multirow_decode", False):
        return
    uids = getattr(gen_batch, "uids", None)
    if uids is None or len(uids) != 1:
        return
    # CacheList layers (GLM 5.2 / DeepSeek v3.2 lineage) keep left padding on
    # their sub-caches, not on the container — recurse instead of skipping.
    pending = list(getattr(gen_batch, "prompt_cache", None) or [])
    while pending:
        cache = pending.pop()
        sub_caches = getattr(cache, "caches", None)
        if sub_caches is not None:
            pending.extend(sub_caches)
            continue
        left_padding = getattr(cache, "left_padding", None)
        if left_padding is None:
            continue
        try:
            if max(int(v) for v in left_padding.tolist()) > 0:
                return
        except Exception:
            return
    gen_batch._omlx_mtp_saw_standard_multirow_decode = False
    logger.info("MTP singleton recovery: multirow marker cleared (compact cache)")


def _is_mtp_eligible(gen_batch: Any) -> bool:
    """``__init__`` and ``next`` only engage MTP for single-sequence batches
    when the model exposes ``mtp_forward``, has an attached MTP head, and
    was loaded with MTP decode enabled.

    The MTP head may be attached unconditionally (e.g. by the mlx-vlm
    runtime patches, which need it for weight-load matching even when
    inference-time MTP is off) — so head presence alone is not enough
    to decide whether to run the draft/verify cycle. The per-instance
    ``_omlx_mtp_decode_enabled`` marker reflects the per-load
    ``model_settings.mtp_enabled`` choice without being affected by later
    model loads in the same process.
    """
    if not _mtp_common_eligible(gen_batch):
        return False
    uids = getattr(gen_batch, "uids", None)
    if uids is None or len(uids) != 1:
        return False
    if not _allows_new_mtp_activation(gen_batch, "_omlx_mtp_state"):
        return False
    return True


def _model_supports_batch_mtp(model: Any) -> bool:
    """Only validated model adapters opt into multi-request Lightning MTP."""
    return any(
        getattr(host, "_omlx_mtp_multi_request", False) is True
        for host in (
            model,
            getattr(model, "_language_model", None),
            getattr(model, "language_model", None),
        )
    )


def _is_mtp_batch_eligible(gen_batch: Any) -> bool:
    if not _mtp_common_eligible(gen_batch):
        return False
    model = getattr(gen_batch, "model", None)
    if not _model_supports_batch_mtp(model):
        return False
    uids = getattr(gen_batch, "uids", None)
    if uids is None or len(uids) <= 1:
        return False
    if not _allows_new_mtp_activation(gen_batch, "_omlx_mtp_batch_state"):
        return False
    return True


def _ineligibility_reason(gen_batch: Any) -> str:
    """Return a short human-readable reason for why the MTP path isn't active.

    Only used for debug logging — the patched_init / patched_next paths
    don't act on this string.
    """
    if not hasattr(gen_batch, "model"):
        return "GenerationBatch has no .model attribute"
    if not hasattr(gen_batch.model, "mtp_forward"):
        return (
            f"model {type(gen_batch.model).__module__}.{type(gen_batch.model).__name__} "
            "has no mtp_forward (qwen35 patch may not have applied to this class)"
        )
    if not _model_has_mtp_module(gen_batch.model):
        return "model has no attached mtp head"
    if not _model_mtp_decode_enabled(gen_batch.model):
        return (
            "model instance MTP decode flag is off "
            "(model_settings.mtp_enabled was False when this model was loaded)"
        )
    uids = getattr(gen_batch, "uids", None)
    if uids is None:
        return "GenerationBatch has no uids"
    if _has_xtc_sampler(gen_batch):
        return "XTC sampling is not supported by Lightning MTP acceptance math"
    if len(uids) != 1:
        if not _model_supports_batch_mtp(gen_batch.model):
            return "this model supports single-request Lightning MTP only"
        if not _allows_new_mtp_activation(gen_batch, "_omlx_mtp_batch_state"):
            return "pending prompt work may still merge into this batch"
        return ""
    if not _allows_new_mtp_activation(gen_batch, "_omlx_mtp_state"):
        return "pending prompt work may still merge into this singleton batch"
    if _has_grammar_processors(gen_batch):
        return "grammar-constrained decoding uses GenerationBatch._step hooks"
    return ""


class _MtpStepFallback(RuntimeError):
    """Raised inside the MTP path to signal a clean fallback to the standard step."""


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------


@dataclass
class _MtpStats:
    """Acceptance / throughput counters for one MTP-active sequence.

    Logged at INFO when the sequence finishes (length / stop / filter)
    so the operator can see whether the draft+verify cycle is actually
    productive on this model + sampler combo.
    """

    cycles: int = 0  # number of verify cycles run
    accepts: int = 0  # accepted draft tokens (depth-k: sum over positions)
    rejects: int = 0  # cycles that ended in a rejection
    init_emits: int = 0  # tokens emitted from the post-init queue (always 2)
    draft_emits: int = 0  # tokens emitted as accepted drafts
    bonus_emits: int = 0  # tokens emitted as bonus (accepted + emit_bonus)
    verify_emits: int = 0  # tokens emitted as verify-position correction (reject path)
    # Per-depth accept telemetry for chained drafting: drafted[j] counts
    # cycles where a draft existed at depth j; accepted[j] counts how many
    # of those were verified. Depth-1 legacy path fills index 0 only.
    depth_drafted: List[int] = field(default_factory=list)
    depth_accepted: List[int] = field(default_factory=list)
    # Cycles the depth controller parked at 0 (plain steps, no speculation).
    zero_cycles: int = 0
    # Cycles whose drafts were copied from the context instead of the head,
    # and their drafted / accepted token counts (kept out of depth[...]).
    copy_cycles: int = 0
    copy_drafted: int = 0
    copy_accepted: int = 0
    # Component-level timings. Help diagnose where MTP overhead comes from
    # when accept rate is healthy but wall-clock throughput isn't.
    backbone_ms: float = 0.0  # cumulative time inside the 2-token verify forward
    mtp_head_ms: float = 0.0  # cumulative time inside MTP-head forwards
    sample_ms: float = 0.0  # cumulative time in sampling + acceptance check
    cache_ops_ms: float = 0.0  # cumulative time in trim / rollback restore


@dataclass
class _MtpState:
    """Per-batch MTP state stashed on the GenerationBatch instance."""

    # MTP state is valid only for this exact singleton uid. It must be dropped
    # across any standard batched step or batch reshape that breaks ownership.
    uid: Any = None

    # Pending tokens to emit in upcoming next() calls. Each entry is
    # (token_id_int, logprobs_1d, source_label). source_label is one of
    # "init", "draft", "bonus", "verify" — used to bucket stats correctly
    # when the queue is drained.
    queue: Deque[Tuple[int, Any, str]] = field(default_factory=deque)

    # Cache for the MTP head (separate from gen_batch.prompt_cache).
    mtp_cache: Optional[List[Any]] = None

    # First input token of the next verify forward. Tracked as a 1-element
    # mx.array (uint32) so it can be concatenated with `draft_tok` cheaply.
    next_main: Optional[Any] = None

    # Draft logprobs (vocab,) needed by stochastic acceptance / residual sampling.
    draft_tok: Optional[Any] = None  # (1,) uint32
    draft_lp: Optional[Any] = None  # (vocab,) float
    # Filtered (sampler-applied) draft logprobs reused by the next cycle's
    # acceptance ratio + residual sampling. Mirrors PR 990's accept_lp,
    # adapted to oMLX's callable-sampler contract via metadata-introspection.
    # None when the sampler exposes no metadata (raw-lp fallback path).
    draft_accept_lp: Optional[Any] = None  # (vocab,) float
    # Host-side int copy of draft_tok. Cached at draft creation time so the
    # verify cycle can compare draft vs verify ids without a separate
    # GPU→CPU sync (`int(draft_tok.tolist()[0])` would force a stall).
    draft_id: int = -1

    # --- depth-k chained drafting (Qwen3.5/3.6 only) ---
    # chain=True routes decode through _run_verify_cycle_chain; False keeps
    # the PR-990 depth-1 legacy cycle.
    chain: bool = False
    depth: int = 1
    # head_clone=True runs speculative head steps on a per-cycle cache clone
    # (models whose head cache can't be exactly trimmed once rotated).
    head_clone: bool = False
    # Pending draft tokens for the next verify forward: (depth,) uint32 array.
    # Host-side ids are read in the verify cycle's single sync, not here.
    drafts: Optional[Any] = None
    # Per-draft raw logprob rows (vocab,) — emitted as the accepted drafts'
    # logprobs (PR 990 contract) — and sampler-filtered rows for stochastic
    # acceptance. Lazy arrays; only evaluated if a consumer touches them.
    draft_lps: List[Any] = field(default_factory=list)
    draft_accept_lps: List[Any] = field(default_factory=list)
    # MTP-head cache offset at cycle start. Chain entries beyond this offset
    # are speculative and trimmed at commit; committed history is re-appended
    # from verify-forward hidden rows so the head sees a dense, committed-only
    # timeline.
    hist_offset: int = 0
    # A consumed priming context proves this request's hidden capture works.
    head_history_primed: bool = False
    # Sampler for draft tokens (lazily resolved). For stochastic target
    # samplers this is a *sharper* distribution than the target (temp 0.6 /
    # top_p 0.95 / top_k 20) — the Leviathan/Chen acceptance ratio uses the
    # true draft distribution q, so any q keeps the output distribution
    # exact, and truncating the 1-layer head's noisy tail is what keeps
    # acceptance usable on high-entropy content (creative prose collapses to
    # ~10-20% with matched-temp drafts).
    draft_sampler: Optional[Any] = None
    # Adaptive depth controller (None = fixed depth). Chooses how many
    # drafts the next chain builds from rolling accept/latency estimates.
    controller: Optional[Any] = None

    # True while this state is a bounded re-entry probe after a performance
    # handoff. Correctness fallbacks and late-join handoffs do not set it.
    reentry_probe: bool = False

    # Boundary tokens need a one-row forward on a private cache.
    boundary_emit_pending: bool = False

    # Context-copy proposer (greedy chain cycles), whether the pending drafts
    # came from it rather than the MTP head, and whether this cycle rebuilt
    # its index (a one-off host cost the depth controller must not time as
    # the window's).
    context_copy: Optional[Any] = None
    copy_drafts: bool = False
    copy_untimed: bool = False

    # Accept-rate / throughput counters. Surfaced via logger.info on finish.
    stats: _MtpStats = field(default_factory=_MtpStats)


@dataclass
class _MtpBatchState:
    """Request-local Lightning MTP state for a continuous generation batch."""

    states: Dict[Any, _MtpState] = field(default_factory=dict)
    head: Optional[Any] = None


# The existing depth controller decides whether a re-entry probe wins. This
# policy state only schedules retries; it deliberately does not duplicate the
# controller's acceptance and cycle-cost model.
_MTP_REENTRY_INITIAL_COOLDOWN_TOKENS = 128
_MTP_REENTRY_MAX_COOLDOWN_TOKENS = 4096


@dataclass
class _MtpParkState:
    """Per-sequence policy state for reversible performance parking.

    The MTP state is dropped so the standard decoder regains its pipelined
    fast path; prompt priming keeps the committed head history and records the
    parked tokens for the probe. This host-side record survives the handoff
    and admits a later MTP probe. It is keyed by uid because GenerationBatch
    objects are reused across requests.
    """

    uid: Any
    cooldown_tokens: int = _MTP_REENTRY_INITIAL_COOLDOWN_TOKENS
    tokens_remaining: int = _MTP_REENTRY_INITIAL_COOLDOWN_TOKENS

    def observe_standard(self) -> None:
        self.tokens_remaining = max(0, self.tokens_remaining - 1)

    def probe_ready(self) -> bool:
        return self.tokens_remaining <= 0 and not _prefill_activity_recent()

    def restart_after_failed_probe(self) -> None:
        self.cooldown_tokens = min(
            _MTP_REENTRY_MAX_COOLDOWN_TOKENS,
            self.cooldown_tokens * 2,
        )
        self.tokens_remaining = self.cooldown_tokens

    def defer_probe(self) -> None:
        """Yield a probe for a batch-shape handoff without penalizing it."""
        self.tokens_remaining = 0


def _mtp_park_state_for_batch(gen_batch: Any) -> Optional[_MtpParkState]:
    state = getattr(gen_batch, "_omlx_mtp_park_state", None)
    if state is None:
        return None
    uids = getattr(gen_batch, "uids", None) or ()
    if state.uid in uids:
        return state
    try:
        delattr(gen_batch, "_omlx_mtp_park_state")
    except AttributeError:
        pass
    return None


def _record_parked_standard_step(gen_batch: Any) -> None:
    state = _mtp_park_state_for_batch(gen_batch)
    if state is not None:
        state.observe_standard()


def _maybe_finish_mtp_reentry_probe(
    gen_batch: Any,
    state: _MtpState,
    *,
    was_warmup: bool,
) -> bool:
    """Clear the cooldown once the existing controller measures a win."""
    controller = state.controller
    if (
        not state.reentry_probe
        or controller is None
        or was_warmup
        or controller._warmup
        or controller.exit_streak != 0
    ):
        return False
    try:
        delattr(gen_batch, "_omlx_mtp_park_state")
    except AttributeError:
        pass
    state.reentry_probe = False
    logger.info("MTP[%s] re-entry probe succeeded", state.uid)
    return True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _has_xtc_sampler(gen_batch: Any) -> bool:
    samplers = getattr(gen_batch, "samplers", None)
    fallback = getattr(gen_batch, "fallback_sampler", None)
    for idx in range(len(gen_batch.uids)):
        sampler = _row_value(samplers, idx)
        if sampler is None:
            sampler = fallback
        if (
            getattr(sampler, "temp", 0.0) != 0.0
            and getattr(sampler, "xtc_probability", 0.0) > 0.0
        ):
            return True
    return False


def _resolve_sampler(gen_batch: Any):
    """Match ``GenerationBatch._step``'s per-sequence sampler resolution (batch=1)."""
    if gen_batch.samplers and gen_batch.samplers[0] is not None:
        return gen_batch.samplers[0]
    return gen_batch.fallback_sampler


def _is_greedy(gen_batch):
    sampler = _resolve_sampler(gen_batch)
    if sampler is not None:
        return getattr(sampler, "temp", 0.0) == 0.0
    return True


def _proc_list(gen_batch: Any) -> Optional[List[Any]]:
    if gen_batch.logits_processors and gen_batch.logits_processors[0]:
        return gen_batch.logits_processors[0]
    return None


def _has_grammar_processors(gen_batch: Any) -> bool:
    """True when MTP would bypass grammar state advanced by scheduler._step."""
    processors_by_seq = getattr(gen_batch, "logits_processors", None)
    if not processors_by_seq:
        return False
    try:
        from omlx.api.grammar import GrammarConstraintProcessor
    except Exception:
        return False
    return any(
        isinstance(proc, GrammarConstraintProcessor)
        for processors in processors_by_seq
        for proc in (processors or [])
    )


def _mtp_state_valid_for_batch(gen_batch: Any, state: Optional[_MtpState]) -> bool:
    """MTP state may only represent one uid in one current singleton slot."""
    if state is None:
        return False
    uids = getattr(gen_batch, "uids", None)
    return bool(uids is not None and len(uids) == 1 and uids[0] == state.uid)


def _drop_mtp_state(
    gen_batch: Any,
    reason: str,
    *,
    log_stats: bool = False,
) -> Optional[_MtpState]:
    """Delete attached MTP state, optionally surfacing stats for external finish.

    Deliberately does NOT drop the prompt-priming context: mlx-lm's insert
    flow routes every fresh singleton through ``extend()`` (donor merge),
    which drops MTP state defensively — but the priming context must survive
    that hop or activation always sees an unprimed cache. The context is
    released at activation (``take_primed``), on real multi-row merges
    (``patched_extend``), or with the cache itself at request end.
    """
    state = getattr(gen_batch, "_omlx_mtp_state", None)
    if state is None:
        return None
    if log_stats:
        try:
            _log_mtp_stats(
                getattr(state, "uid", "?"),
                state.stats,
                getattr(state, "_finish_reason", reason),
            )
        except Exception:
            pass
    try:
        delattr(gen_batch, "_omlx_mtp_state")
    except AttributeError:
        pass
    logger.debug("MTP state dropped: %s", reason)
    return state


def _drop_invalid_mtp_state(
    gen_batch: Any,
    reason: str,
    *,
    log_empty: bool = False,
) -> Optional[_MtpState]:
    """Drop state after a batch reshape unless ownership still matches."""
    state = getattr(gen_batch, "_omlx_mtp_state", None)
    if state is None:
        return None
    if _mtp_state_valid_for_batch(gen_batch, state):
        return state
    uids = getattr(gen_batch, "uids", None)
    return _drop_mtp_state(
        gen_batch,
        reason,
        log_stats=bool(log_empty and not uids),
    )


def _mtp_batch_state_valid_for_batch(
    gen_batch: Any, batch_state: Optional[_MtpBatchState]
) -> bool:
    if batch_state is None:
        return False
    uids = getattr(gen_batch, "uids", None)
    if not uids:
        return False
    return all(uid in batch_state.states for uid in uids)


def _drop_mtp_batch_state(
    gen_batch: Any,
    reason: str,
    *,
    log_stats: bool = False,
) -> Optional[_MtpBatchState]:
    batch_state = getattr(gen_batch, "_omlx_mtp_batch_state", None)
    if batch_state is None:
        return None
    from . import batched_head

    batched_head.flush(batch_state)
    if log_stats:
        for state in list(batch_state.states.values()):
            try:
                _log_mtp_stats(
                    getattr(state, "uid", "?"),
                    state.stats,
                    getattr(state, "_finish_reason", reason),
                )
            except Exception:
                pass
    try:
        delattr(gen_batch, "_omlx_mtp_batch_state")
    except AttributeError:
        pass
    logger.debug("MTP batch state dropped: %s", reason)
    return batch_state


def _drop_invalid_mtp_batch_state(
    gen_batch: Any,
    reason: str,
    *,
    old_uids: Optional[List[Any]] = None,
    log_empty: bool = False,
) -> Optional[_MtpBatchState]:
    batch_state = getattr(gen_batch, "_omlx_mtp_batch_state", None)
    if batch_state is None:
        return None
    from . import batched_head

    batched_head.flush(batch_state)
    uids = list(getattr(gen_batch, "uids", []) or [])
    if not uids:
        return _drop_mtp_batch_state(
            gen_batch,
            reason,
            log_stats=bool(log_empty),
        )

    keep = set(uids)
    removed = set(old_uids or []) - keep
    for uid in removed:
        state = batch_state.states.pop(uid, None)
        if state is not None and log_empty:
            try:
                _log_mtp_stats(uid, state.stats, reason)
            except Exception:
                pass
    batch_state.states = {
        uid: state for uid, state in batch_state.states.items() if uid in keep
    }
    if _mtp_batch_state_valid_for_batch(gen_batch, batch_state):
        if len(uids) == 1:
            gen_batch._omlx_mtp_state = batch_state.states[uids[0]]
            _drop_mtp_batch_state(gen_batch, "filter-to-singleton")
            return None
        return batch_state
    return _drop_mtp_batch_state(gen_batch, reason)


def _row_value(values: Optional[List[Any]], idx: int, default: Any = None) -> Any:
    if values is None:
        return default
    try:
        if len(values) == 0:
            return default
        return values[idx]
    except Exception:
        return default


def _make_row_batch(
    gen_batch: Any,
    idx: int,
    *,
    prompt_cache: Optional[List[Any]] = None,
    state: Optional[_MtpState] = None,
) -> Any:
    if prompt_cache is None:
        prompt_cache = gen_batch.extract_cache(idx)

    next_tokens = getattr(gen_batch, "_next_tokens", None)
    next_logprobs = getattr(gen_batch, "_next_logprobs", None)
    row = SimpleNamespace(
        model=gen_batch.model,
        prefill_step_size=getattr(gen_batch, "prefill_step_size", 512),
        uids=[gen_batch.uids[idx]],
        prompt_cache=prompt_cache,
        tokens=[gen_batch.tokens[idx]],
        samplers=[_row_value(getattr(gen_batch, "samplers", None), idx)],
        fallback_sampler=gen_batch.fallback_sampler,
        logits_processors=[
            _row_value(getattr(gen_batch, "logits_processors", None), idx, [])
        ],
        stop_sequences=[_row_value(getattr(gen_batch, "stop_sequences", None), idx)],
        max_tokens=[_row_value(getattr(gen_batch, "max_tokens", None), idx)],
        _next_tokens=next_tokens[idx : idx + 1] if next_tokens is not None else None,
        _next_logprobs=(
            [next_logprobs[idx]]
            if next_logprobs is not None and len(next_logprobs) > idx
            else []
        ),
        _token_context=[gen_batch._token_context[idx]],
        _num_tokens=[gen_batch._num_tokens[idx]],
        _matchers=[gen_batch._matchers[idx]],
    )
    if state is not None:
        row._omlx_mtp_state = state
    return row


def _merge_row_caches(row_caches: List[List[Any]]) -> List[Any]:
    if not row_caches:
        return []
    merged = []
    for layer_idx in range(len(row_caches[0])):
        per_row = [cache[layer_idx] for cache in row_caches]
        merge = getattr(per_row[0], "merge", None)
        if not callable(merge):
            raise _MtpStepFallback(
                f"cache {type(per_row[0]).__name__} cannot merge row caches"
            )
        merged.append(merge(per_row))
    return merged


def _replace_cache_rows(
    gen_batch: Any,
    replacements: Dict[int, List[Any]],
) -> None:
    if not replacements:
        return
    row_caches = [
        replacements.get(idx) or gen_batch.extract_cache(idx)
        for idx in range(len(gen_batch.uids))
    ]
    gen_batch.prompt_cache = _merge_row_caches(row_caches)


def _initial_batch_forward(gen_batch):
    """Advance fresh Qwen rows together without extracting target caches."""
    from mlx_lm.models.cache import ArraysCache, BatchKVCache

    cache_types = (ArraysCache, BatchKVCache)
    try:
        from mlx_vlm.models.cache import ArraysCache as VLMArray
        from mlx_vlm.models.cache import BatchKVCache as VLMKV
    except ImportError:
        pass
    else:
        cache_types += (VLMArray, VLMKV)

    host = getattr(gen_batch.model, "_language_model", None)
    chain, _, head_clone = _resolve_mtp_chain_depth(gen_batch.model)
    if not (
        len(gen_batch.uids) > 1
        and chain
        and not head_clone
        and getattr(host, "_omlx_mtp_batch_rollback", False)
        and gen_batch._next_tokens is not None
        and all(type(c) in cache_types for c in gen_batch.prompt_cache)
        and all(
            _is_greedy(
                _make_row_batch(gen_batch, i, prompt_cache=gen_batch.prompt_cache)
            )
            and not _row_value(gen_batch.logits_processors, i)
            for i in range(len(gen_batch.uids))
        )
    ):
        return None
    # Validate the offset layout before advancing the shared target cache.
    offsets = _prompt_priming._row_offsets(gen_batch.prompt_cache, len(gen_batch.uids))
    if offsets is None:
        return None
    _set_batched_mrope_deltas(gen_batch, list(gen_batch.uids))
    logits, hidden, _, captured = _call_backbone_captured(
        gen_batch.model,
        gen_batch._next_tokens[:, None],
        gen_batch.prompt_cache,
        capture_layer_ids=_drafter_capture_ids(gen_batch.model),
    )
    _clear_rollback(gen_batch.prompt_cache)
    return logits, hidden, [offset + 1 for offset in offsets], captured


def _slice_captured(captured: Optional[List[Any]], idx: int) -> Optional[List[Any]]:
    if captured is None:
        return None
    return [layer[idx : idx + 1] for layer in captured]


def _prepare_mtp_batch_state_for_next(gen_batch: Any) -> Optional[_MtpBatchState]:
    """Return a valid row-wise MTP state, lazily initializing every row."""
    batch_state = getattr(gen_batch, "_omlx_mtp_batch_state", None)
    if _mtp_batch_state_valid_for_batch(gen_batch, batch_state):
        return batch_state

    replacements: Dict[int, List[Any]] = {}
    token_context_updates: Dict[int, Any] = {}
    states = dict(batch_state.states) if batch_state is not None else {}

    shared = _initial_batch_forward(gen_batch) if not states else None
    for idx, uid in enumerate(gen_batch.uids):
        if uid in states:
            continue
        row = _make_row_batch(
            gen_batch,
            idx,
            prompt_cache=gen_batch.prompt_cache if shared is not None else None,
        )
        _set_singleton_mrope_delta(row)
        if shared is None:
            _post_init_mtp(row)
        else:
            logits, hidden, offsets, captured = shared
            _post_init_mtp(
                row,
                verify_result=(
                    logits[idx : idx + 1],
                    hidden[idx : idx + 1],
                    None,
                    _slice_captured(captured, idx),
                ),
                priming_offset=offsets[idx],
            )
        state = getattr(row, "_omlx_mtp_state", None)
        if not _mtp_state_valid_for_batch(row, state):
            _drop_mtp_batch_state(gen_batch, "batch-post-init-invalid")
            return None
        states[uid] = state
        if shared is None:
            replacements[idx] = row.prompt_cache
        token_context_updates[idx] = row._token_context[0]

    _replace_cache_rows(gen_batch, replacements)
    for idx, token_context in token_context_updates.items():
        gen_batch._token_context[idx] = token_context

    batch_state = _MtpBatchState(states=states)
    gen_batch._omlx_mtp_batch_state = batch_state
    if hasattr(gen_batch, "_omlx_mtp_park_state"):
        # A singleton timing decision does not describe shared verification.
        del gen_batch._omlx_mtp_park_state
    logger.info(
        "Lightning MTP batch activated for %d sequences",
        len(gen_batch.uids),
    )
    return batch_state


# One ParkMemory per live model object (keyed by id: models are dict-like
# modules; the weak reference keeps a reused id from inheriting verdicts).
_BATCH_PARK_MEMORY: Dict[int, Tuple[Any, Any]] = {}


def _batch_park_memory(model: Any):
    from .batch_policy import ParkMemory

    entry = _BATCH_PARK_MEMORY.get(id(model))
    if entry is None or entry[0]() is not model:
        entry = _BATCH_PARK_MEMORY[id(model)] = (weakref.ref(model), ParkMemory())
    return entry[1]


def _batch_policy_for_next(gen_batch: Any):
    from .batch_policy import BatchPolicy

    policy = getattr(gen_batch, "_omlx_mtp_batch_policy", None)
    if policy is None or policy.uids != tuple(gen_batch.uids):
        memory = _batch_park_memory(gen_batch.model)
        if policy is not None:
            memory.retired(policy)
        chain, depth, _ = _resolve_mtp_chain_depth(gen_batch.model)
        policy = BatchPolicy(
            gen_batch.uids,
            depth if chain else 1,
            fixed=_drafter_for(gen_batch.model) is not None
            or _mtp_depth_fixed(gen_batch.model),
        )
        memory.seed(policy)
        gen_batch._omlx_mtp_batch_policy = policy
    return policy


def _reconcile_mtp_batch_to_standard(gen_batch: Any) -> bool:
    batch_state = getattr(gen_batch, "_omlx_mtp_batch_state", None)
    if batch_state is None:
        return True
    from . import batched_head

    batched_head.flush(batch_state)
    if not getattr(gen_batch, "uids", None):
        return True

    import mlx.core as mx

    row_caches: Dict[int, List[Any]] = {}
    next_tokens = []
    next_logprobs = []
    token_context_updates: Dict[int, Any] = {}

    try:
        if _feed_batch_mains_to_standard(gen_batch, batch_state):
            return True
        for idx, uid in enumerate(gen_batch.uids):
            state = batch_state.states.get(uid)
            if state is None:
                row_caches[idx] = gen_batch.extract_cache(idx)
                if getattr(gen_batch, "_next_tokens", None) is not None:
                    next_tokens.append(gen_batch._next_tokens[idx : idx + 1])
                if len(getattr(gen_batch, "_next_logprobs", [])) > idx:
                    next_logprobs.append(gen_batch._next_logprobs[idx])
                continue

            row = _make_row_batch(gen_batch, idx, state=state)
            if not _reconcile_mtp_to_standard(row, state):
                return False
            row_caches[idx] = [cache.extract(0) for cache in row.prompt_cache]
            next_tokens.append(row._next_tokens)
            next_logprobs.extend(row._next_logprobs)
            token_context_updates[idx] = row._token_context[0]

        if row_caches:
            _replace_cache_rows(gen_batch, row_caches)
        if next_tokens:
            gen_batch._next_tokens = mx.concatenate(next_tokens)
            gen_batch._next_logprobs = next_logprobs
        for idx, token_context in token_context_updates.items():
            gen_batch._token_context[idx] = token_context
        return True
    except Exception as exc:
        logger.warning("MTP batch reconcile failed: %s", exc)
        return False


def _prepare_mtp_state_for_next(gen_batch: Any) -> Optional[_MtpState]:
    """Return a valid singleton MTP state, lazily initializing if needed."""
    state = getattr(gen_batch, "_omlx_mtp_state", None)
    if _mtp_state_valid_for_batch(gen_batch, state):
        return state
    if state is not None:
        _drop_mtp_state(gen_batch, "stale-owner")

    park_state = _mtp_park_state_for_batch(gen_batch)
    _set_singleton_mrope_delta(gen_batch)
    _post_init_mtp(gen_batch)
    state = getattr(gen_batch, "_omlx_mtp_state", None)
    if not _mtp_state_valid_for_batch(gen_batch, state):
        _drop_mtp_state(gen_batch, "post-init-invalid")
        return None

    # Eligibility already admitted this parked singleton. Mark the fresh
    # state unconditionally so a prefill arriving between the two checks
    # cannot strand the cooldown marker beside a normal MTP state.
    if park_state is not None:
        state.reentry_probe = True
        logger.info(
            "MTP[%s] re-entry probe started after %d standard tokens",
            state.uid,
            park_state.cooldown_tokens,
        )

    logger.info(
        "MTP path activated for uid=%s (model has mtp_forward, batch=1, primed=%d)",
        state.uid,
        max(0, int(getattr(state, "hist_offset", 0)) - 1),
    )
    return state


def _set_singleton_mrope_delta(gen_batch: Any) -> None:
    """Mirror scheduler._step's per-uid mRoPE setup for direct MTP forwards."""
    model = getattr(gen_batch, "model", None)
    uids = getattr(gen_batch, "uids", None)
    if (
        model is not None
        and getattr(model, "_uses_mrope", False)
        and getattr(model, "_uid_rope_deltas", None)
        and uids
        and len(uids) == 1
        and hasattr(model, "set_batch_rope_deltas")
    ):
        import mlx.core as mx

        delta = model._uid_rope_deltas.get(uids[0], 0.0)
        # uid-aware seam keeps a text-proven request on Qwen4's rank-two
        # positions for the verify window (gathered-QSA eligibility).
        step_setter = getattr(type(model), "set_step_rope_deltas", None)
        if callable(step_setter):
            step_setter(model, mx.array([delta]), list(uids))
        else:
            model.set_batch_rope_deltas(mx.array([delta]))


def _rebuild_singleton_cache(model: Any) -> Optional[List[Any]]:
    """Build a fresh cache through the same merge path as prompt processing."""
    from mlx_lm.models.cache import make_prompt_cache
    from omlx.scheduler import _patched_merge_caches

    try:
        return _patched_merge_caches([make_prompt_cache(model)])
    except Exception as exc:
        logger.warning("MTP reconcile: cache rebuild unavailable: %s", exc)
        return None


def _reconcile_mtp_to_standard(gen_batch: Any, state: _MtpState) -> bool:
    """Rewind a to-be-dropped MTP singleton into a standard-resumable state.

    The MTP path never maintains mlx-lm's ``_next_tokens`` — it streams tokens
    from ``state.queue`` and advances the shared cache speculatively, and the
    GatedDeltaNet rollback snapshot is cleared on accept, so a partial rollback
    at an arbitrary drop point is not reliable. Instead, rebuild the cache by
    re-prefilling exactly the already-streamed tokens (``gen_batch.tokens[0]``)
    into a fresh cache (which deterministically reconstructs every layer state,
    KV and SSM), then set ``_next_tokens`` to the correct next-to-emit token:

    - if ``state.queue`` is non-empty, ``queue[0]`` is the correct, not-yet-
      streamed next token — reuse it (and its logprobs). The rest of the queue
      is discarded; standard decode re-derives those positions.
    - otherwise (cycle boundary) sample from the re-prefill's last-position
      logits, exactly as a standard ``_step`` would after feeding ``tokens[-1]``.

    Leaves ``tokens[0]`` / ``_num_tokens[0]`` untouched (they already reflect
    streamed tokens), so there is no duplicated or skipped token. Returns False
    when reconcile cannot be done safely; callers must stop decoding.
    """
    import mlx.core as mx

    tokens = gen_batch.tokens[0] if getattr(gen_batch, "tokens", None) else None
    if not tokens:
        return False
    try:
        new_cache = _rebuild_singleton_cache(gen_batch.model)
        if new_cache is None:
            return False
        procs = _proc_list(gen_batch)
        _set_singleton_mrope_delta(gen_batch)
        tok_arr = _ensure_uint32(mx.array(list(tokens)))
        # Bound each rebuild forward by the owning generator's prefill size.
        step = int(getattr(gen_batch, "prefill_step_size", 0) or 0) or 512
        total = int(tok_arr.shape[0])
        logits = None
        # Inherits the per-engine stream from the enclosing BatchGenerator context.
        for start in range(0, total, step):
            # Committed history needs no per-token speculative rollback states.
            logits = gen_batch.model(
                tok_arr[None, start : start + step], cache=new_cache
            )
            if start + step < total:
                mx.eval(logits)
        last_logits = logits[:, -1, :]  # (1, vocab) — dist after tokens[-1]

        if state.queue:
            next_id, next_lp_1d, _src = state.queue[0]
            next_tok = mx.array([int(next_id)], dtype=mx.uint32)
            next_lp = next_lp_1d
        else:
            prev_buf = (
                mx.array(list(tokens), dtype=mx.int32) if procs is not None else None
            )
            ll = _apply_processors(procs, prev_buf, last_logits)
            next_lp_2d = _logprobs(ll)
            next_tok = _ensure_uint32(_resolve_sampler(gen_batch)(next_lp_2d))
            next_lp = next_lp_2d.squeeze(0)

        mx.eval(next_tok)
        _clear_rollback(new_cache)
        gen_batch.prompt_cache = new_cache
        gen_batch._next_tokens = next_tok
        gen_batch._next_logprobs = [next_lp]
        if procs is not None:
            from mlx_lm.models.cache import TokenBuffer

            gen_batch._token_context[0] = TokenBuffer(list(tokens))
        logger.debug(
            "MTP reconciled to standard on reshape (uid=%s tokens=%d queue=%d)",
            getattr(state, "uid", "?"),
            len(tokens),
            len(state.queue),
        )
        return True
    except Exception as exc:
        logger.warning("MTP reconcile failed: %s", exc)
        return False


def _apply_processors(processors, prev_tokens, logits_2d):
    if not processors:
        return logits_2d
    for proc in processors:
        logits_2d = proc(prev_tokens, logits_2d)
    return logits_2d


def _snap_snapshotable(procs):
    """Checkpoint state of processors exposing ``snapshot_state`` (budget).

    Returns ``None`` when no processor supports position-keyed rewind, so
    callers can skip the restore unconditionally (the DSpark path applies
    processors to speculative draft positions; only the budget processor
    tracks position-sensitive mutable state today).
    """
    if not procs:
        return None
    snaps = [p.snapshot_state() for p in procs if hasattr(p, "snapshot_state")]
    return snaps or None


def _restore_snapshotable(procs, snaps) -> None:
    """Rewind processors previously checkpointed by :func:`_snap_snapshotable`."""
    if not procs or not snaps:
        return
    it = iter(snaps)
    for p in procs:
        if hasattr(p, "restore_state"):
            try:
                p.restore_state(next(it))
            except StopIteration:
                return


def _logprobs(logits_2d):
    import mlx.core as mx

    return logits_2d - mx.logsumexp(logits_2d, axis=-1, keepdims=True)


# Serial greedy decoding (mlx-lm ``GenerationBatch._step``) samples
# ``logits - logsumexp(logits)`` in the logits dtype, so its argmax runs over
# rounded log-probabilities: once a logit is below half the logsumexp the
# bf16 subtraction is inexact, two adjacent logits can land on one
# log-probability, and the tie goes to the lower token id. Verify rows take
# the same argmax so greedy MTP output equals MTP-off output.
def _greedy_targets(logprobs):
    """Greedy tokens of verify rows, as the serial greedy sampler picks them."""
    import mlx.core as mx

    return mx.argmax(logprobs, axis=-1).astype(mx.int32)


def _accept_lp_for(sampler, lp):
    """Reproduce the sampler's filter+temperature pipeline on `lp` so the
    acceptance ratio (and residual distribution) match the distribution the
    sampler actually drew from.

    Reads sampling params off the callable as function attributes (set by
    ``omlx.utils.sampling.make_sampler``). For samplers without metadata —
    e.g. mlx-lm stock callables, fallback samplers — returns `lp` unchanged
    so behavior matches the pre-PR-990 raw-lp acceptance.
    """
    import mlx.core as mx

    from omlx.utils.sampling import (
        apply_min_p,
        apply_top_k,
        apply_top_p,
        apply_top_p_top_k,
    )

    temp = float(getattr(sampler, "temp", 0.0) or 0.0)
    if temp == 0.0:
        # Greedy / unknown sampler — raw lp is the acceptance distribution.
        return lp

    out = lp
    top_p = float(getattr(sampler, "top_p", 0.0) or 0.0)
    min_p = float(getattr(sampler, "min_p", 0.0) or 0.0)
    top_k = int(getattr(sampler, "top_k", 0) or 0)
    if 0.0 < top_p < 1.0 and top_k > 0 and min_p == 0.0:
        out = apply_top_p_top_k(out, top_p, top_k)
    else:
        if 0.0 < top_p < 1.0:
            out = apply_top_p(out, top_p)
        if min_p != 0.0:
            min_keep = int(getattr(sampler, "min_tokens_to_keep", 1) or 1)
            out = apply_min_p(out, min_p, min_keep)
        if top_k > 0:
            out = apply_top_k(out, top_k)

    # Temperature scale + renormalize so the output is a proper logprob
    # distribution that can be indexed by token id for the acceptance check.
    scaled = (out * (1.0 / temp)).astype(mx.float32)
    return scaled - mx.logsumexp(scaled, axis=-1, keepdims=True)


def _sample_draft_with_logprobs(sampler, lp):
    shared = getattr(sampler, "sample_with_logprobs", None)
    if shared is not None:
        return shared(lp)
    return sampler(lp), _accept_lp_for(sampler, lp)


def _sample_draft_sparse(sampler, lp, top_k: int):
    """``sample_with_logprobs`` on the ``top_k`` support only.

    Returns the token, the candidate ids and their draft log-densities. The
    filters match ``apply_top_p_top_k`` on full-vocab log-probabilities, so
    the distribution equals the dense one restricted to its support.
    """
    import mlx.core as mx

    from omlx.utils.sampling import top_k_indices

    top_p = float(getattr(sampler, "top_p", 0.0) or 0.0)
    temp = float(sampler.temp)
    ids = top_k_indices(lp, top_k)
    vals = mx.take_along_axis(lp, ids, axis=-1).astype(mx.float32)
    order = mx.argsort(-vals, axis=-1)
    vals = mx.take_along_axis(vals, order, axis=-1)
    ids = mx.take_along_axis(ids, order, axis=-1)
    if 0.0 < top_p < 1.0:
        probs = mx.exp(vals)
        vals = mx.where(mx.cumsum(probs, axis=-1) - probs < top_p, vals, -float("inf"))
    scaled = vals * (1.0 / temp)
    pick = mx.random.categorical(scaled)
    token = mx.take_along_axis(ids, pick[:, None], axis=-1).reshape(-1)
    logq = scaled - mx.logsumexp(scaled, axis=-1, keepdims=True)
    return token, ids.reshape(-1).astype(mx.int32), logq


# Draft chains score each step's whole vocabulary with a 3-bit copy of the
# lm_head and rescore only its best candidates with the real weights. On
# code, the coarse top-64 holds 99.8% of the exact top-20 (Flash-Next: 91% at
# 2 bits), and a step reads about 30-60% fewer bytes.
_COARSE_HEAD_BITS = 3
_COARSE_HEAD_GROUP = 128
_COARSE_CANDIDATES = 64
_COARSE_MIN_VOCAB = 65536
_COARSE_HEADS: Dict[int, Any] = {}


class _CoarseDraftHead:
    """MTP chain head that rescores a few coarse candidates per step."""

    def __init__(self, lang, mtp, coarse):
        self.lang = lang
        self.mtp = mtp
        self.coarse = coarse

    def hidden(self, hidden_states, tokens, cache):
        """The head's ``(logits source, chain hidden)``.

        Qwen4 heads return both; its mixer folds the hyper streams for the logits.
        """
        out = self.mtp(hidden_states, tokens, self.lang.model.embed_tokens, cache)
        return out if isinstance(out, tuple) else (out, out)

    def candidates(self, h):
        """Vocab ids ``(1, M)`` and their log-probabilities for hidden ``h``.

        The candidates normalize among themselves: the coarse logits are too
        narrow to estimate the vocabulary's normalizer.
        """
        import mlx.core as mx

        from omlx.utils.sampling import top_k_indices

        head = self.lang.lm_head
        approx = self.coarse(h[:, -1, :]).astype(mx.float32)
        ids = top_k_indices(approx, _COARSE_CANDIDATES)
        exact = mx.quantized_matmul(
            h[:, -1, :],
            *_head_rows(head, ids.reshape(-1)),
            transpose=True,
            group_size=head.group_size,
            bits=head.bits,
        )
        exact = exact.astype(mx.float32)
        return ids, exact - mx.logsumexp(exact, axis=-1, keepdims=True)


def _head_rows(head, rows):
    """Weight, scales and biases of lm_head rows, also from M5's packed layout."""
    gather = getattr(head, "quantized_rows", None)
    if gather is not None:
        return gather(rows)
    return head.weight[rows], head.scales[rows], head.biases[rows]


def _head_vocab(head) -> int:
    return int(getattr(head, "output_dims", 0) or head.weight.shape[0])


def _mtp_language_model(model):
    for name in ("_language_model", "language_model"):
        inner = getattr(model, name, None)
        if inner is not None:
            return inner
    return model


def _mtp_module(lang):
    get = getattr(lang, "get_mtp_module", None)
    return get() if callable(get) else getattr(lang, "mtp", None)


def _drafts_before_commit(model) -> bool:
    forward = getattr(type(_mtp_language_model(model)), "mtp_forward", None)
    return bool(getattr(forward, "_omlx_head_cache_only", False))


def _chain_tail_caches(model, mtp_cache):
    """Tail views of the head's KV caches, or None when the head cannot use them."""
    from mlx_lm.models.cache import KVCache

    from ..qwen35_verify_sdpa_split import ChainKVCache, install_chain_attention

    if not _drafts_before_commit(model) or not mtp_cache:
        return None
    layers = getattr(getattr(_mtp_language_model(model), "mtp", None), "layers", [])
    if len(layers) != len(mtp_cache) or not all(
        type(c) is KVCache and c.keys is not None for c in mtp_cache
    ):
        return None
    if not all(install_chain_attention(type(layer.self_attn)) for layer in layers):
        return None
    return [ChainKVCache(c) for c in mtp_cache]


# ``_sample_draft_sparse`` over at most 64 candidate log-probabilities in one
# simdgroup: rank by (value desc, index asc), keep top_k, cut at top_p on the
# given probabilities, then scale by 1/temp and draw by inverse CDF.
_CANDIDATE_SAMPLE_SOURCE = """
    uint lane = thread_index_in_simdgroup;
    threadgroup float sv[64];
    threadgroup int si[64];
    float v[2];
    for (int h = 0; h < 2; ++h) {
        int idx = int(lane) + h * 32;
        v[h] = idx < M ? lp[idx] : -INFINITY;
    }
    for (int h = 0; h < 2; ++h) {
        int idx = int(lane) + h * 32;
        int rank = 0;
        for (int j = 0; j < 64; ++j) {
            float o = simd_shuffle(v[j / 32], ushort(j % 32));
            rank += (j < M && (o > v[h] || (o == v[h] && j < idx))) ? 1 : 0;
        }
        if (idx < M && rank < TOPK) {
            sv[rank] = v[h];
            si[rank] = idx;
        }
    }
    simdgroup_barrier(mem_flags::mem_threadgroup);
    bool live = int(lane) < min(TOPK, M);
    float x = live ? sv[lane] : -INFINITY;
    int id = live ? si[lane] : 0;
    if (TOP_P_ON) {
        float p = live ? exp(x) : 0.0f;
        if (!(simd_prefix_exclusive_sum(p) < params[0]))
            x = -INFINITY;
    }
    float scaled = x * params[1];
    float m = simd_max(scaled);
    float e = scaled == -INFINITY ? 0.0f : exp(scaled - m);
    float total = simd_sum(e);
    float q = scaled == -INFINITY ? -INFINITY : scaled - m - log(total);
    float cdf = simd_prefix_inclusive_sum(e) / total;
    int first = simd_min((e > 0.0f && cdf > params[2]) ? int(lane) : 32);
    int last = simd_max(e > 0.0f ? int(lane) : -1);
    int pick = first < 32 ? first : last;
    if (int(lane) < TOPK) {
        ids[lane] = id;
        logq[lane] = q;
    }
    int chosen = simd_shuffle(id, ushort(pick));
    if (lane == 0)
        token[0] = chosen;
"""
_CANDIDATE_SAMPLE_KERNEL = None


def _sample_candidates_fused(sampler, lp, top_k: int):
    """``_sample_draft_sparse`` for ``(1, M)`` log-probs, M <= 64, top_k <= 32."""
    import mlx.core as mx

    global _CANDIDATE_SAMPLE_KERNEL
    if _CANDIDATE_SAMPLE_KERNEL is None:
        _CANDIDATE_SAMPLE_KERNEL = mx.fast.metal_kernel(
            name="omlx_mtp_candidate_sample",
            input_names=["lp", "params"],
            output_names=["token", "ids", "logq"],
            source=_CANDIDATE_SAMPLE_SOURCE,
        )
    top_p = float(getattr(sampler, "top_p", 0.0) or 0.0)
    params = mx.concatenate(
        [
            mx.array([top_p, 1.0 / float(sampler.temp)], dtype=mx.float32),
            mx.random.uniform(shape=(1,)),
        ]
    )
    token, ids, logq = _CANDIDATE_SAMPLE_KERNEL(
        inputs=[lp.reshape(-1).astype(mx.float32), params],
        template=[
            ("M", int(lp.shape[-1])),
            ("TOPK", int(top_k)),
            ("TOP_P_ON", int(0.0 < top_p < 1.0)),
        ],
        grid=(32, 1, 1),
        threadgroup=(32, 1, 1),
        output_shapes=[(1,), (top_k,), (top_k,)],
        output_dtypes=[mx.int32, mx.int32, mx.float32],
    )
    return token, ids, logq[None]


def _quantize_mtp_fc(mtp) -> None:
    """Store a dense MTP input projection at 4 bits.

    Checkpoints keep it in bf16; at 4 bits the head's first-step acceptance
    is unchanged on code and Korean text and each draft step reads 76 MB less.
    """
    import mlx.core as mx
    import mlx.nn as nn

    fc = getattr(mtp, "fc", None)
    if (
        type(fc) is not nn.Linear
        or "bias" in fc
        or fc.weight.dtype not in (mx.bfloat16, mx.float16)
        or fc.weight.shape[1] % 64
    ):
        return
    mtp.fc = nn.QuantizedLinear.from_linear(fc, group_size=64, bits=4)
    mx.eval(mtp.fc.parameters())


def _coarse_draft_head(model) -> Optional[_CoarseDraftHead]:
    """The coarse chain head for Qwen3.5/Qwen4 MTP with a quantized lm_head.

    The first call per head builds the coarse copy and stores the MTP ``fc``
    at 4 bits.
    """
    import mlx.core as mx
    import mlx.nn as nn

    lang = _mtp_language_model(model)
    head = getattr(lang, "lm_head", None)
    mtp = _mtp_module(lang)
    forward = getattr(type(lang), "mtp_forward", None)
    if (
        not getattr(forward, "_omlx_lm_head_logits", False)
        or mtp is None
        or getattr(getattr(lang, "args", None), "tie_word_embeddings", True)
        or not (isinstance(head, nn.QuantizedLinear) or hasattr(head, "quantized_rows"))
        or getattr(head, "mode", "affine") != "affine"
        or "bias" in head
        or _head_vocab(head) < _COARSE_MIN_VOCAB
    ):
        return None
    coarse = _COARSE_HEADS.get(id(head))
    if coarse is None:
        _quantize_mtp_fc(mtp)
        rows = _head_vocab(head)
        parts = []
        for start in range(0, rows, 16384):
            end = min(rows, start + 16384)
            weight = mx.dequantize(
                *_head_rows(head, mx.arange(start, end)),
                group_size=head.group_size,
                bits=head.bits,
            )
            part = mx.quantize(
                weight, group_size=_COARSE_HEAD_GROUP, bits=_COARSE_HEAD_BITS
            )
            mx.eval(part)
            parts.append(part)
        coarse = nn.QuantizedLinear(
            int(weight.shape[1]),
            rows,
            bias=False,
            group_size=_COARSE_HEAD_GROUP,
            bits=_COARSE_HEAD_BITS,
        )
        coarse.weight, coarse.scales, coarse.biases = (
            mx.concatenate([part[i] for part in parts], axis=0) for i in range(3)
        )
        mx.eval(coarse.parameters())
        _COARSE_HEADS[id(head)] = coarse
        # The copy lives as long as its model.
        weakref.finalize(head, _COARSE_HEADS.pop, id(head), None)
    return _CoarseDraftHead(lang, mtp, coarse)


def _trim_token_buffer(gen_batch: Any, n: int) -> None:
    """Shrink ``_token_context[0]`` by ``n`` (mirrors PR 990 ``prev[:-n]``)."""
    if n <= 0:
        return
    procs = _proc_list(gen_batch)
    if procs is None:
        return
    buf = gen_batch._token_context[0]
    buf._size = max(0, buf._size - n)


def _restore_or_trim_caches(prompt_cache: List[Any]) -> bool:
    """Roll back one token from each layer cache after a draft rejection.

    SSM / linear-attention layers expose ``rollback_state`` populated by the
    patched ``GatedDeltaNet.__call__``; we restore that snapshot. Standard
    KV cache layers (full-attention) expose ``trim`` and ``is_trimmable``;
    we trim by 1. Layers that support neither cause the entire MTP step to
    fall back to the standard path.

    All layers are checked before anything is mutated: a partial rollback
    (early layers trimmed, a later layer refusing) leaves per-layer KV
    lengths desynchronised by one position and corrupts every subsequent
    forward (the shared attention mask is built from the first layer's
    cache, so the mismatch surfaces as a broadcast error on DeepSeek-V4
    compressed-attention layers).
    """
    for c in prompt_cache:
        if getattr(c, "rollback_state", None) is not None:
            # A draft stash marks the chain-path *pre-forward* snapshot
            # semantics (qwen35_model unsplit verify); restoring it here
            # would drop the confirmed token too. Only mtp_partial_rollback
            # knows how to replay it — refuse so the caller falls back.
            if getattr(c, "_mtp_draft_stash", None) is not None:
                return False
            continue
        if hasattr(c, "is_trimmable") and c.is_trimmable():
            continue
        return False
    for c in prompt_cache:
        rollback = getattr(c, "rollback_state", None)
        if rollback is not None:
            conv_snap, ssm_snap = rollback
            c[0] = conv_snap
            c[1] = ssm_snap
            c.rollback_state = None
            continue
        c.trim(1)
    return True


def _rollback_after_reject(
    model: Any,
    prompt_cache: List[Any],
    gdn_states: Optional[list],
    accepted: int = 0,
    block_size: int = 2,
) -> bool:
    """Roll back per-layer cache state after a rejected MTP draft token.

    Two mechanisms are supported, dispatched on the model's capability:

    1. **mlx-vlm path** — when the model exposes ``rollback_speculative_cache``
       (Qwen3.5 LanguageModel ships with it upstream) AND ``gdn_states`` is
       populated, we delegate to that method. It batches the per-layer SSM
       replay into a single ``gated_delta_update`` call and trims KV
       caches by ``block_size - (accepted + 1)``. The backbone forward was
       run with both confirmed and draft tokens; the rollback replays only
       the accepted prefix through the original pre-update state.

    2. **mlx-lm path** (PR 990) — per-layer ``cache.rollback_state`` snapshot
       written by the patched ``GatedDeltaNet.__call__`` during the
       confirmed/draft split. We restore the snapshot for SSM layers and
       trim KV layers by 1. ``gdn_states`` is None in this path.

    Returns True on success. False means a cache layer in the list supports
    neither mechanism, in which case the caller falls back to the standard
    non-MTP step.
    """
    if gdn_states is not None and hasattr(model, "rollback_speculative_cache"):
        model.rollback_speculative_cache(prompt_cache, gdn_states, accepted, block_size)
        return True
    return _restore_or_trim_caches(prompt_cache)


def _call_backbone(
    model: Any,
    inputs: Any,
    cache: List[Any],
    n_confirmed: int = 0,
) -> Tuple[Any, Any, Optional[list]]:
    """Backbone forward without layer captures; see ``_call_backbone_impl``."""
    return _call_backbone_impl(model, inputs, cache, n_confirmed, None)[:3]


def _call_backbone_captured(
    model: Any,
    inputs: Any,
    cache: List[Any],
    n_confirmed: int = 0,
    capture_layer_ids: Optional[List[int]] = None,
) -> Tuple[Any, Any, Optional[list], Optional[List[Any]]]:
    """``_call_backbone`` plus the drafter's layer captures as a 4th entry.

    Without a capture request this defers to ``_call_backbone`` so the
    plain forward keeps one entry point.
    """
    if not capture_layer_ids:
        if n_confirmed:
            plain = _call_backbone(model, inputs, cache, n_confirmed=n_confirmed)
        else:
            plain = _call_backbone(model, inputs, cache)
        return (*plain, None)
    return _call_backbone_impl(model, inputs, cache, n_confirmed, capture_layer_ids)


def _call_backbone_impl(
    model: Any,
    inputs: Any,
    cache: List[Any],
    n_confirmed: int,
    capture_layer_ids: Optional[List[int]],
) -> Tuple[Any, Any, Optional[list], Optional[List[Any]]]:
    """Run the backbone with ``return_hidden=True`` and normalise the result.

    Returns ``(logits, hidden_pre_norm, gdn_states_or_None, captured)``.
    ``captured`` is the list of per-layer hidden states requested through
    ``capture_layer_ids`` (block drafters consume them), or ``None``. The
    MTP head's ``hidden_pre_norm`` is the same array with or without a
    capture request.

    The first three entries:

    - mlx-lm path returns the 2-tuple ``(logits, hidden)``; ``gdn_states``
      is ``None`` and rollback uses ``cache.rollback_state``.
    - mlx-vlm path returns a ``LanguageModelOutput`` or 3-tuple
      ``(logits, hidden, gdn_states)`` so a rejected draft can be rolled
      back via ``rollback_speculative_cache``.

    ``n_confirmed`` is forwarded so the mlx-lm path can split its
    GatedDeltaNet forward into confirmed and draft chunks. mlx-vlm
    discards it (irrelevant — rollback is post-hoc, not splitwise).

    The rotating-cache undo stash (cache_rollback) is armed for the
    duration of the forward so a rejected draft can be rolled back even on
    a rotated RotatingKVCache; non-MTP forwards keep stock trim semantics.
    """
    kwargs = {"cache": cache, "return_hidden": True}
    if n_confirmed:
        kwargs["n_confirmed"] = n_confirmed
    if capture_layer_ids:
        kwargs["capture_layer_ids"] = list(capture_layer_ids)
    dspark_verify = bool(n_confirmed and _dspark_host(model) is not None)
    _rollback_mod.set_undo_armed(True)
    # The affine verify qmm kernel is a Qwen-specific optimization. Keep the
    # DeepSeek target on its architecture-native quantized linear path.
    # Row-exact runs each row as a one-row matvec. Batched decode has no
    # one-row baseline, so B > 1 verify keeps the multi-row kernels.
    _set_verify_qmm_armed(
        not dspark_verify,
        row_exact=inputs.shape[0] == 1 and _row_exact_verify(model),
    )
    _set_dspark_target_verify(model, dspark_verify)
    try:
        result = model(inputs, **kwargs)
    finally:
        if dspark_verify:
            _set_dspark_target_verify(model, False)
        _set_verify_qmm_armed(False)
        _rollback_mod.set_undo_armed(False)

    # LanguageModelOutput (mlx-vlm dataclass)
    if hasattr(result, "logits") and hasattr(result, "hidden_states"):
        hidden = result.hidden_states
        captured = None
        if isinstance(hidden, list):
            if capture_layer_ids:
                # The runtime wrapper orders the list as the requested
                # captures followed by the head's last-layer hidden.
                captured = list(hidden[:-1])
                if len(captured) != len(capture_layer_ids):
                    raise TypeError(
                        "backbone returned %d captures for %d requested layers"
                        % (len(captured), len(capture_layer_ids))
                    )
            hidden = hidden[-1] if hidden else None
        rollback_state = getattr(result, "gdn_states", None)
        try:
            from mlx_vlm.speculative.cache_state import SpeculativeCacheTransaction
        except ImportError:
            SpeculativeCacheTransaction = ()

        if not n_confirmed and isinstance(rollback_state, SpeculativeCacheTransaction):
            model.rollback_speculative_cache(
                cache,
                rollback_state,
                [inputs.shape[1] - 1] * inputs.shape[0],
                inputs.shape[1],
            )
            rollback_state = None
        return result.logits, hidden, rollback_state, captured
    if isinstance(result, tuple):
        if capture_layer_ids:
            raise TypeError("backbone tuple output cannot carry layer captures")
        if len(result) == 3:
            return (*result, None)
        if len(result) == 2:
            return result[0], result[1], None, None
    raise TypeError(f"backbone returned unexpected shape: {type(result).__name__}")


def _clear_rollback(prompt_cache: List[Any]) -> None:
    """Drop rollback snapshots after a draft is accepted."""
    pending = list(prompt_cache)
    while pending:
        c = pending.pop()
        pending.extend(getattr(c, "caches", ()))
        if hasattr(c, "rollback_state") and c.rollback_state is not None:
            c.rollback_state = None
        if getattr(c, "_mtp_draft_stash", None) is not None:
            c._mtp_draft_stash = None
        if getattr(c, "_mtp_undo", None) is not None:
            c._mtp_undo = None
        if getattr(c, "_undo", None) is not None:
            c._undo = None
            c._undo_chain = False


def _ensure_uint32(arr):
    """Ensure a 1-element mx.array is uint32 (cache update_and_fetch expects it)."""
    import mlx.core as mx

    if arr.dtype == mx.uint32:
        return arr
    return arr.astype(mx.uint32)


# ---------------------------------------------------------------------------
# Depth-k chained drafting helpers (Qwen3.5/3.6): a linear draft chain through
# the MTP head, one batched verify forward covering all drafts plus a free
# bonus row, offset-trim KV rollback with GDN prefix replay, and a
# committed-only MTP-head history rebuilt from verify hidden rows each cycle.
# ---------------------------------------------------------------------------


def _resolve_mtp_chain_depth(model: Any) -> Tuple[bool, int, bool]:
    """Read the chain capability markers stamped on the model at load.

    Returns ``(chain, depth, head_clone)``. ``head_clone`` marks models
    whose MTP-head cache cannot be exactly trimmed (e.g. DeepSeek-V4's
    RotatingKVCache head once rotated): the chain then runs its speculative
    draft steps on a per-cycle clone and keeps the persistent head cache
    committed-only, instead of trimming speculative entries afterwards.
    """
    candidates = [model]
    for attr in ("language_model", "_language_model"):
        inner = getattr(model, attr, None)
        if inner is not None and inner is not model:
            candidates.append(inner)
    for candidate in candidates:
        if getattr(candidate, "_omlx_mtp_chain", False):
            depth = int(getattr(candidate, "_omlx_mtp_depth", 1) or 1)
            head_clone = bool(getattr(candidate, "_omlx_mtp_head_clone", False))
            return True, max(1, min(8, depth)), head_clone
    return False, 1, False


def _mtp_depth_fixed(model: Any) -> bool:
    """True when the model was loaded with a fixed draft depth (no controller)."""
    candidates = [model]
    for attr in ("language_model", "_language_model"):
        inner = getattr(model, attr, None)
        if inner is not None and inner is not model:
            candidates.append(inner)
    return any(
        getattr(candidate, "_omlx_mtp_chain", False)
        and bool(getattr(candidate, "_omlx_mtp_depth_fixed", False))
        for candidate in candidates
    )


def _clone_mtp_head_cache(mtp_cache: List[Any]) -> List[Any]:
    """Detached per-cycle copy of the MTP-head cache for speculative steps.

    ``copy.copy`` keeps scalars; mx.array attributes are detached with
    ``v + 0`` so the clone's in-place ring writes never mutate arrays the
    persistent cache still references; list attributes are shallow-copied.
    Container caches (``CacheList``-style, exposing ``.caches``) recurse.
    """
    import copy

    import mlx.core as mx

    def clone_one(c):
        if c is None:
            return None
        subs = getattr(c, "caches", None)
        if subs is not None:
            return type(c)(*[clone_one(sub) for sub in subs])
        new = copy.copy(c)
        for attr, val in vars(c).items():
            if isinstance(val, mx.array):
                setattr(new, attr, val + 0)
            elif isinstance(val, list):
                setattr(new, attr, list(val))
        return new

    cloned = copy.copy(mtp_cache)
    cloned[:] = [clone_one(c) for c in mtp_cache]
    return cloned


def _trunk_norm_module(model: Any):
    """Final RMSNorm of the backbone (for post_norm head inputs).

    Walks both wrapper conventions: mlx-lm's outer ``Model.language_model``
    and oMLX's ``VLMModelAdapter._language_model`` (mlx-vlm path).

    Models whose ``return_hidden`` output is already post-norm mark
    ``_omlx_mtp_head_hidden_normed`` (instance or inner language model) and
    get an identity here — applying the trunk norm again would double-norm
    the head inputs, and the ``inner.model.norm`` walk does not fit every
    backbone layout (e.g. ``backbone.norm_f``).
    """
    inner = model
    for attr in ("language_model", "_language_model"):
        candidate = getattr(model, attr, None)
        if candidate is not None:
            inner = candidate
            break
    if getattr(model, "_omlx_mtp_head_hidden_normed", False) or getattr(
        inner, "_omlx_mtp_head_hidden_normed", False
    ):
        return lambda x: x
    return inner.model.norm


# Single source of truth lives in prompt_priming: the prefill-time priming
# folds and the decode-time history folds here must use the same hidden
# variant or the primed history would be inconsistent with the chained one.
_HEAD_HIDDEN_POST_NORM = _prompt_priming.HEAD_HIDDEN_POST_NORM


def _head_input(model: Any, hidden: Any) -> Any:
    """Trunk hidden as the MTP head consumes it.

    Models whose head normalizes its input internally (inkling's per-block
    hidden_norm, Qwen4's raw hyper streams) mark themselves and receive the
    raw pre-norm trunk hidden.
    """
    head_prenorm = getattr(model, "_omlx_mtp_head_prenorm", False) or getattr(
        getattr(model, "_language_model", None), "_omlx_mtp_head_prenorm", False
    )
    if _HEAD_HIDDEN_POST_NORM and not head_prenorm and hidden.ndim == 3:
        return _trunk_norm_module(model)(hidden)
    return hidden


def _mtp_head_trim_to(mtp_cache: List[Any], offset: int) -> None:
    """Trim speculative chain entries so the head cache ends at ``offset``."""
    for c in mtp_cache:
        current = int(getattr(c, "offset", 0))
        extra = current - offset
        if extra > 0:
            c.trim(extra)


# Loop-tax measurement (feeds _DepthController.EXIT_MARGIN): right after a
# hand-off the standard decoder runs on the same model, machine, and
# context, so the ratio of the exit-time t[0] to the measured standard-step
# time IS the MTP loop's synchronous-cycle tax. Stored on the model
# instance so later sequences exit against a measured margin instead of
# the fallback prior.
_STD_TAX_SKIP = 2  # first post-hand-off steps still carry transition costs
_STD_TAX_SAMPLES = 8
_STD_TAX_EMA = 0.5
_STD_TAX_MAX = 1.5
# Cycle timings sampled while another request is prefilling (any engine on
# the shared GPU) are contention-shaped, not loop-shaped. A park probe armed
# or finalized in that window latches a poisoned t0/t_std ratio on the model
# and depresses MTP for every later sequence (#2622).
_STD_TAX_CONTENTION_WINDOW_S = 3.0
_STD_TAX_WARN = 1.3  # a stored tax at/above this is worth an INFO line
_STD_TAX_DECAY_S = 600.0  # stale latch decays toward the default margin


def _prefill_activity_recent() -> bool:
    try:
        return get_prefill_tracker().recently_active(_STD_TAX_CONTENTION_WINDOW_S)
    except Exception:
        return False


def _arm_std_tax_probe(gen_batch: Any, t0_ms: Optional[float], uid: Any = None) -> None:
    if not (t0_ms and t0_ms > 0.0):
        return
    if _prefill_activity_recent():
        logger.debug(
            "MTP loop-tax probe skipped: prefill activity within %.1fs, "
            "t0=%.1fms is contention-contaminated",
            _STD_TAX_CONTENTION_WINDOW_S,
            t0_ms,
        )
        return
    gen_batch._omlx_mtp_tax_probe = {
        "t0": float(t0_ms),
        "skip": _STD_TAX_SKIP,
        "samples": [],
        "uid": uid,
    }


def _record_std_tax_sample(gen_batch: Any, duration_ms: float) -> None:
    probe = getattr(gen_batch, "_omlx_mtp_tax_probe", None)
    if probe is None:
        return
    uids = getattr(gen_batch, "uids", None)
    if probe.get("uid") is not None and list(uids or ()) != [probe["uid"]]:
        # The batch gained or swapped rows since the hand-off; multi-row
        # step timings would contaminate the singleton loop-tax ratio.
        try:
            delattr(gen_batch, "_omlx_mtp_tax_probe")
        except AttributeError:
            pass
        return
    if probe["skip"] > 0:
        probe["skip"] -= 1
        return
    probe["samples"].append(float(duration_ms))
    if len(probe["samples"]) < _STD_TAX_SAMPLES:
        return
    try:
        delattr(gen_batch, "_omlx_mtp_tax_probe")
    except AttributeError:
        pass
    samples = sorted(probe["samples"])
    t_std = samples[len(samples) // 2]
    if t_std <= 0.0:
        return
    if _prefill_activity_recent():
        logger.debug(
            "MTP loop-tax probe discarded: prefill activity during the "
            "std sampling window"
        )
        return
    tax = min(_STD_TAX_MAX, max(1.0, probe["t0"] / t_std))
    model = getattr(gen_batch, "model", None)
    if model is None:
        return
    prev = getattr(model, "_omlx_mtp_loop_tax", None)
    if prev:
        tax = (1.0 - _STD_TAX_EMA) * float(prev) + _STD_TAX_EMA * tax
    try:
        model._omlx_mtp_loop_tax = tax
        model._omlx_mtp_loop_tax_ts = time.monotonic()
    except Exception:
        return
    log = logger.info if tax >= _STD_TAX_WARN else logger.debug
    log(
        "MTP loop tax measured: %.3f (parked t0=%.1fms, std step=%.1fms)",
        tax,
        probe["t0"],
        t_std,
    )


def _effective_loop_tax(model: Any) -> Optional[float]:
    """Measured loop tax, decayed toward the default exit margin with age.

    A genuine loop tax is stable and re-latches through fresh park probes,
    so decay costs nothing in the steady state. A high value that stopped
    being reproduced — the signature of a probe that sampled around a
    contention episode despite the arm/finalize guards — must not depress
    MTP until the next restart (#2622).
    """
    tax = getattr(model, "_omlx_mtp_loop_tax", None)
    if tax is None:
        return None
    ts = getattr(model, "_omlx_mtp_loop_tax_ts", None)
    if ts is None:
        return float(tax)
    age = max(0.0, time.monotonic() - float(ts))
    prior = float(_DepthController.EXIT_MARGIN)
    return prior + (float(tax) - prior) * math.exp(-age / _STD_TAX_DECAY_S)


class _DepthController:
    """Adaptive draft-depth selection.

    Pure host-side bookkeeping — no extra GPU syncs. Tracks an EMA of
    conditional acceptance per depth position and a wall-time EMA of cycle
    cost per depth used, then picks the depth with the best expected tokens
    per unit time:

        score(d) = (1 + p1 + p1*p2 + ... ) / t_est(d)

    Everything the decision uses is measured on this machine, on this model,
    under the current load — no hand-tuned per-chip or per-model value:

    - Cost: a warmup sweep runs each depth once so every ``t[d]`` starts from
      a real cycle; the marginal cost of an extra verify row is the measured
      slope between depths (``_marginal_est``), so a fine-grained MoE on a
      bandwidth-limited chip learns its true (large) marginal within the first
      few cycles. ``MARGINAL_MS`` is only the pre-measurement fallback.
    - Drift: the cost EMA horizon is wall-clock (``TAU_MS``), not a cycle
      count, so context growth, thermal throttling and external GPU contention
      are tracked at constant real-time responsiveness however long a cycle
      is; a one-off slow cycle is damped (``SPIKE_RATIO``).
    - Staleness: only the depth currently run gets fresh measurements, and a
      fresh-vs-stale cost comparison is systematically biased — e.g. a depth
      whose t was measured during the slow post-prefill cycles looks expensive
      forever, so the controller locks into its rival (measured as a depth-2
      lock costing prose ~2-4%). Probes are therefore BIDIRECTIONAL and
      staleness-directed: on a wall-clock cadence, re-run the best rival depth
      (shallower or deeper) when its score is within ``PROBE_MARGIN`` of the
      current choice, and periodically the most-stale depth, so every t[d] has
      bounded age. On heavy models a fixed wall-clock cadence would spend a
      large share of cycles probing, so probing is duty-bounded to
      ~``PROBE_DUTY`` of cycles — a scale-free ratio, not a per-model tuning.

    Depth 0 — the escape hatch: speculation is only profitable while the
    multi-token verify forward is cheap relative to a plain decode step.
    On models with a large L=1 -> L=2 forward-cost jump (gemma4 head_dim
    256/512 leaves the single-token attention kernel; MoE expert loads
    scale with verify tokens) the whole depth menu can be worse than
    standard decoding — measured 0.67x on gemma4 26B story/16k with the
    best depth choice. Depth 0 runs the cycle as a plain 1-token step
    ([next_main] only, no drafts, no rollback) whose cost is tracked as
    ``t[0]`` through the same EMA/probe machinery, so the controller
    parks at 0 when every speculative depth loses and re-enters through
    the existing bidirectional probes. ``t[0]`` gets its first real
    measurement from the warmup sweep (which ends with one depth-0
    cycle) and stays fresh via parked cycles and the staleness explorer.
    Parking alone is not enough on fast backbones — a parked cycle still
    pays the MTP loop's synchronous host round-trip that the standard
    decoder pipelines away — so a sustained park hands the sequence back
    to the standard step entirely (``_park_mtp_to_standard``).

    Content-adaptive by construction: prose/chat settles at depth 1,
    code/predictable text climbs. Rejected alternatives (interleaved
    in-process A/B, rotated order, paired per rep, on Qwen3.6-35B-A3B +
    GLM-5.2, M3 Ultra): a fixed shallow-bias constant (won earlier separate-
    process comparisons only by masking the staleness lock; this design beats
    it on 3 of 4 model x content cells and ties the 4th), a pure realized
    tok/s bandit (exploration tax), a live per-cycle learned correction
    (decision churn), a frozen cross-generation correction (content
    oscillation), and a base x shape cost decomposition (unidentifiable while
    one depth runs for long stretches).
    """

    ALPHA = 0.08  # acceptance EMA weight (token domain, content-driven)
    TAU_MS = 400.0  # cost EMA horizon in wall-clock ms (load/thermal/context)
    PROBE_PERIOD_MS = 1000.0  # min wall-time between probes (light models)
    PROBE_PERIOD_MAX_MS = 5000.0  # staleness-exploration cadence floor
    PROBE_LEN = 4
    PROBE_DUTY = 0.15  # probes never consume more than ~this share of cycles
    PROBE_MARGIN = 1.15  # a rival within this score ratio is worth re-measuring
    SPIKE_RATIO = 2.0  # a cycle above this * the EMA is treated as an outlier
    SPIKE_DAMP = 0.25  # ...and folded in at this fraction of the normal weight
    # Fallback prior for one extra verify token's cost, used only until two
    # depths have actually been measured; after that the marginal is the
    # measured slope between depths. 7 ms matches dense backbones (6-10 ms).
    MARGINAL_MS = 7.0
    HYSTERESIS = 1.03  # switch depth only for a >3% score gain
    # Hand-off gate: ``t[0]`` is measured INSIDE the MTP loop, so it carries
    # the loop's synchronous host round-trip that the standard decoder
    # pipelines away. Speculation that cannot beat this taxed baseline by
    # EXIT_MARGIN is losing to the real standard step; after EXIT_STREAK
    # consecutive losing decisions the sequence leaves the MTP path
    # entirely (_park_mtp_to_standard). EXIT_MARGIN is only the
    # pre-measurement fallback (like MARGINAL_MS): each hand-off measures
    # the actual standard-step rate right after it and stores the real
    # loop tax on the model instance, which seeds later controllers via
    # the ``exit_margin`` constructor arg — machine/model-measured, not
    # a hardcoded ratio.
    EXIT_MARGIN = 1.15
    EXIT_STREAK = 16

    def __init__(
        self,
        max_depth: int,
        marginal_ms: Optional[float] = None,
        exit_margin: Optional[float] = None,
        seed: Optional["_DepthController"] = None,
    ):
        if marginal_ms:
            self.MARGINAL_MS = float(marginal_ms)
        if exit_margin:
            self.EXIT_MARGIN = min(_STD_TAX_MAX, max(1.0, float(exit_margin)))
        self.max_depth = max(1, int(max_depth))
        self.cur = self.max_depth  # first cycle drafts deep; warmup sweeps down
        # A position never reached yet (None) borrows the estimate of the
        # position before it; a flat 0.6 prior kept deep drafts unexplored.
        self.p: List[Optional[float]] = [0.6] + [None] * (self.max_depth - 1)
        self.t: Dict[int, float] = {}
        self.t_age: Dict[int, float] = {}  # ms since each depth was measured
        self.cycles = 0
        self.probe_left = 0
        self.exit_streak = 0
        self._ms_probe = 0.0  # wall-time since any probe burst
        self._ms_explore = 0.0  # wall-time since a staleness-exploration burst
        # Measure each depth once (max..1), then the depth-0 plain step
        # three times, before the score gate takes over — t[], including
        # the baseline the exit decision compares against, is data-driven
        # within max_depth + 3 cycles. The baseline gets extra samples
        # because it may never be selected again (no refresh path), and
        # a performance handoff must not hang on a single first-run sample;
        # plain-step warmup cycles cost almost nothing.
        self._warmup: List[int] = list(range(self.max_depth, 0, -1))
        if self.max_depth > 1:
            self._warmup.extend([0, 0, 0])
        if seed is not None and seed.t:
            self._adopt(seed)

    def _adopt(self, seed: "_DepthController") -> None:
        """Reuse estimates, then remeasure costs in the new request's warmup."""
        for j in range(min(self.max_depth, len(seed.p))):
            self.p[j] = seed.p[j]
        self.t = {d: v for d, v in seed.t.items() if d <= self.max_depth}
        self.t_age = {d: math.inf for d in self.t}

    def observe(
        self,
        used: int,
        accepted: int,
        cycle_ms: float,
        time_sample: bool = True,
    ) -> None:
        self.cycles += 1
        used = max(0, min(int(used), self.max_depth))
        accepted = max(0, min(int(accepted), used))
        # Acceptance: token-domain EMA (a property of model/content, not load).
        a = self.ALPHA
        for j in range(used):
            if self.p[j] is None:
                self.p[j] = self._p_eff(j)
            hit = 1.0 if j < accepted else 0.0
            self.p[j] = (1.0 - a) * self.p[j] + a * hit
            if j >= accepted:
                break
        # Cost: wall-time-domain EMA with a one-off-spike guard, plus per-depth
        # ages so probes can target the estimate that is most stale.
        # ``time_sample=False`` marks cycles carrying a one-off maintenance
        # cost (a multi-block head keepalive refold) whose spike would bias
        # this depth's estimate; the acceptance update above still applies.
        cycle_ms = max(0.0, float(cycle_ms))
        if time_sample:
            self._update_time(used, cycle_ms)
        for d in list(self.t_age):
            self.t_age[d] += cycle_ms
        if time_sample:
            self.t_age[used] = 0.0
        self._ms_probe += cycle_ms
        self._ms_explore += cycle_ms

        if self._speculation_losing():
            self.exit_streak += 1
        else:
            self.exit_streak = 0

        # Warmup sweep: keep walking max..1 until every depth is measured once.
        if self._warmup:
            if not time_sample:
                return
            self._warmup.pop(0)
            if self._warmup:
                self.cur = self._warmup[0]
                return
            self.cur = self._best()
            self._ms_probe = 0.0
            return

        # Finishing a probe burst.
        if self.probe_left > 0:
            self.probe_left -= 1
            if self.probe_left == 0:
                self.cur = self._best()
                self._ms_probe = 0.0
            return

        # Re-decide every cycle (cheap); HYSTERESIS in _best prevents thrash.
        self.cur = self._best()

        # Probe scheduling: bounded-staleness re-measurement in either
        # direction, at a duty-bounded wall-clock cadence.
        if self.max_depth > 1:
            period = max(
                self.PROBE_PERIOD_MS,
                self.PROBE_LEN * cycle_ms / self.PROBE_DUTY,
            )
            if self._ms_probe >= period:
                explore_due = self._ms_explore >= max(
                    self.PROBE_PERIOD_MAX_MS, 2.0 * period
                )
                target = self._most_stale() if explore_due else self._best_rival()
                if target is not None:
                    self.cur = target
                    self.probe_left = self.PROBE_LEN
                    self._ms_probe = 0.0
                    if explore_due:
                        self._ms_explore = 0.0

    def _time_alpha(self, cycle_ms: float) -> float:
        # EMA weight for a cycle of this wall-time: the memory horizon is
        # ~TAU_MS regardless of cycle duration, so responsiveness is constant
        # in real time whether a cycle is 8 ms (short) or 80 ms (128k context).
        return 1.0 - math.exp(-max(0.0, float(cycle_ms)) / self.TAU_MS)

    def _update_time(self, used: int, cycle_ms: float) -> None:
        cycle_ms = max(0.0, float(cycle_ms))
        prev = self.t.get(used)
        # Inherited costs must not cap the new request's first measurement.
        if prev is None or self.t_age.get(used) == math.inf:
            self.t[used] = cycle_ms
            return
        if self._warmup:
            # Repeated warmup samples (the depth-0 tail): keep the fastest.
            # First-run shape/branch warmup inflates early samples, and the
            # slow EMA below would freeze that bias into the exit decision.
            self.t[used] = min(prev, cycle_ms)
            return
        # Deliberately a per-cycle EMA, NOT an irregular-sampling EMA weighted
        # by staleness age. Age-weighting (nearly replacing a stale estimate at
        # the first probe cycle) is the textbook form, but it was measured
        # WORSE here: single-cycle noise is ~±10%, so replacing an estimate
        # from a 4-cycle probe burst injects that noise straight into the depth
        # decision every probe (~1s), and prose re-over-drafted (-1.6%). The
        # slow EMA is a variance shield; stale errors are corrected by probe
        # REPETITION instead (each ~1s rival probe moves the estimate ~10% of
        # the gap, converging within a few seconds).
        a = self._time_alpha(cycle_ms)
        if cycle_ms > self.SPIKE_RATIO * prev:
            a *= self.SPIKE_DAMP  # a one-off spike moves the estimate slowly
        self.t[used] = (1.0 - a) * prev + a * cycle_ms

    def _marginal_est(self) -> float:
        # Measured cost of one extra verify row: the slope between the cheapest
        # and priciest measured depths. Falls back to the prior until two
        # depths exist. This is what self-calibrates the controller to the real
        # (model x chip x context) marginal instead of a hardcoded value.
        if len(self.t) >= 2:
            depths = sorted(self.t)
            lo, hi = depths[0], depths[-1]
            if hi > lo:
                slope = (self.t[hi] - self.t[lo]) / (hi - lo)
                if slope > 0.0:
                    return slope
        return self.MARGINAL_MS

    def _t_est(self, d: int) -> float:
        if d in self.t:
            return self.t[d]
        if not self.t:
            return 30.0 + self.MARGINAL_MS * d
        if d == 0:
            # The plain step sits below the L=1 -> L=2 verify jump, so the
            # per-row marginal says nothing about it. Estimate it at the
            # cheapest measured cycle: conservative (true t[0] is lower),
            # which keeps an unmeasured baseline from hijacking probes —
            # yet still within PROBE_MARGIN exactly when acceptance is so
            # poor that the baseline is a genuine rival.
            return min(self.t.values())
        ref = min(self.t, key=lambda x: abs(x - d))
        return max(1e-3, self.t[ref] + self._marginal_est() * (d - ref))

    def _p_eff(self, j: int) -> float:
        while self.p[j] is None:
            j -= 1
        return self.p[j]

    def _score(self, d: int) -> float:
        expected = 1.0
        run = 1.0
        for j in range(d):
            run *= self._p_eff(j)
            expected += run
        return expected / max(1e-6, self._t_est(d))

    def _speculation_losing(self) -> bool:
        # True when the best speculative depth cannot beat the (taxed)
        # in-loop baseline by EXIT_MARGIN. Only meaningful once the warmup
        # sweep has measured t[0].
        if self._warmup or 0 not in self.t:
            return False
        base = self._score(0)
        if base <= 0.0:
            return False
        best = max(self._score(d) for d in range(1, self.max_depth + 1))
        return best < base * self.EXIT_MARGIN

    def should_exit(self) -> bool:
        """Sustained losing speculation: hand the sequence back to the
        standard decoder."""
        return self.exit_streak >= self.EXIT_STREAK

    def _select_candidates(self) -> List[int]:
        # Depth 0 is only selectable once its cost has actually been
        # measured (or seeded) — an extrapolated baseline must never PARK
        # the sequence, only motivate a probe.
        ds = list(range(1, self.max_depth + 1))
        if 0 in self.t:
            ds.insert(0, 0)
        return ds

    def _probe_candidates(self) -> List[int]:
        # Probing depth 0 is always safe (it IS a plain decode step), so
        # the baseline is discoverable before any measurement exists.
        # Speculative depths come first: on an unmeasured-vs-unmeasured
        # staleness tie they keep priority (warmup semantics), while a
        # never-measured baseline still outranks any finite age.
        return list(range(1, self.max_depth + 1)) + [0]

    def _best_rival(self) -> Optional[int]:
        # The highest-scoring depth other than cur, if within PROBE_MARGIN —
        # i.e. a depth whose (possibly stale) estimate could flip the choice.
        # Bidirectional on purpose: re-measuring a SHALLOWER rival is what
        # breaks the depth-2 lock (a stale-high t[1] hides depth 1's true
        # advantage and nothing else would ever refresh it).
        best = self._score(self.cur)
        if best <= 0.0:
            return self._most_stale()
        rival = None
        rival_score = 0.0
        for d in self._probe_candidates():
            if d == self.cur:
                continue
            s = self._score(d)
            if s > rival_score:
                rival, rival_score = d, s
        if rival is not None and rival_score >= best / self.PROBE_MARGIN:
            return rival
        return None

    def _most_stale(self) -> Optional[int]:
        # The depth whose cost estimate has gone longest unmeasured (never
        # measured counts as infinitely stale). Keeps every t[d] fresh enough
        # that fresh-vs-stale comparison bias stays bounded.
        cand = None
        worst = -1.0
        for d in self._probe_candidates():
            if d == self.cur:
                continue
            age = self.t_age.get(d)
            age = float("inf") if age is None else age
            if age > worst:
                cand, worst = d, age
        return cand

    def _best(self) -> int:
        # argmax of measured score with switch hysteresis; ascending scan
        # with strict '>' keeps the shallower choice on an exact tie.
        best_d = self.cur
        best_score = -1.0
        for d in self._select_candidates():
            s = self._score(d)
            if s > best_score:
                best_d, best_score = d, s
        if best_d != self.cur and best_score < self._score(self.cur) * self.HYSTERESIS:
            return self.cur
        return best_d


# Legacy defaults for custom samplers without request sampling metadata.
_DRAFT_SAMPLER_TEMP = 0.6
_DRAFT_SAMPLER_TOP_P = 0.95
_DRAFT_SAMPLER_TOP_K = 20


def _resolve_draft_sampler(gen_batch: Any, state: _MtpState):
    """Sampler used to draw MTP draft tokens.

    Greedy target → greedy drafts (preserves the greedy-identity contract).
    Match a stochastic target's temperature and deterministic filters rather
    than sharpening a high-entropy request's draft distribution. Acceptance
    and residual sampling use the resulting normalized distribution as q.
    Callables without sampling metadata retain the original draft defaults.
    """
    if state.draft_sampler is not None:
        return state.draft_sampler
    if _is_greedy(gen_batch):
        state.draft_sampler = _resolve_sampler(gen_batch)
        return state.draft_sampler

    from omlx.utils.sampling import make_sampler

    target = _resolve_sampler(gen_batch)
    state.draft_sampler = make_sampler(
        temp=getattr(target, "temp", _DRAFT_SAMPLER_TEMP),
        top_p=getattr(target, "top_p", _DRAFT_SAMPLER_TOP_P),
        top_k=getattr(target, "top_k", _DRAFT_SAMPLER_TOP_K),
        min_p=getattr(target, "min_p", 0.0),
        min_tokens_to_keep=getattr(target, "min_tokens_to_keep", 1),
    )
    return state.draft_sampler


def _dspark_host(model: Any) -> Optional[Any]:
    """Return the model object that owns an active embedded DSpark head."""
    candidates = [model]
    for attr in ("language_model", "_language_model"):
        inner = getattr(model, attr, None)
        if inner is not None and inner is not model:
            candidates.append(inner)
    for candidate in candidates:
        if getattr(candidate, "_omlx_dspark_decode_enabled", False):
            return candidate
    return None


def _dspark_next_drafts(
    gen_batch: Any,
    state: _MtpState,
    hidden_rows: Any,
    committed: Any,
    prev_buf: Optional[Any],
    depth: Optional[int] = None,
) -> None:
    """Append committed target taps and sample one DSpark block.

    The expensive three-stage decoder runs once over anchor+noise positions.
    A rank-R Markov head then samples left-to-right, preserving DSpark's
    intra-block dependency without another decoder pass.
    """
    import mlx.core as mx

    host = _dspark_host(gen_batch.model)
    if host is None:
        raise _MtpStepFallback("embedded DSpark host is unavailable")

    if depth is None:
        depth = state.controller.cur if state.controller is not None else state.depth
    depth = min(int(depth), int(getattr(host.args, "dspark_block_size", depth)))
    n = int(committed.shape[0])
    if depth <= 0:
        host.dspark_append_context(hidden_rows, state.mtp_cache)
        state.hist_offset += n
        state.drafts = mx.zeros((0,), dtype=mx.uint32)
        state.draft_lps = []
        state.draft_accept_lps = []
        return

    anchor = committed[-1:].reshape(1, 1)
    logits, _ = host.dspark_forward(
        hidden_rows,
        anchor,
        state.mtp_cache,
        draft_length=depth,
    )
    state.hist_offset += n

    sampler = _resolve_sampler(gen_batch)
    procs = _proc_list(gen_batch)
    draft_toks: List[Any] = []
    draft_lps: List[Any] = []
    draft_accept_lps: List[Any] = []
    previous = anchor.reshape(1)

    # Drafts are speculative — processor calls shape the draft
    # distribution but must not advance the thinking budget (they would
    # count tokens that are only emitted if verified later). Checkpoint
    # before the loop and rewind after.
    snap = _snap_snapshotable(procs)

    for idx in range(depth):
        bias, _ = host.dspark_markov(previous)
        logits_2d = logits[:, idx, :] + bias
        if procs is not None and prev_buf is not None:
            prefix = mx.concatenate(
                [prev_buf.astype(mx.int32), anchor.reshape(1).astype(mx.int32)]
                + [token.reshape(1).astype(mx.int32) for token in draft_toks]
            )
            logits_2d = _apply_processors(procs, prefix, logits_2d)
        lp_2d = _logprobs(logits_2d)
        token = _ensure_uint32(sampler(lp_2d))
        draft_toks.append(token)
        draft_lps.append(lp_2d.squeeze(0))
        draft_accept_lps.append(_accept_lp_for(sampler, lp_2d).squeeze(0))
        previous = token.reshape(1)

    _restore_snapshotable(procs, snap)

    state.drafts = mx.concatenate(draft_toks)
    state.draft_lps = draft_lps
    state.draft_accept_lps = draft_accept_lps
    mx.async_eval(state.drafts)


def _chain_next_drafts(
    gen_batch: Any,
    state: _MtpState,
    hidden_rows: Any,
    committed: Any,
    prev_buf: Optional[Any],
    depth: Optional[int] = None,
) -> None:
    """Rebuild committed MTP-head history and draft the next chain.

    ``hidden_rows`` is the trunk hidden at the positions of the n tokens
    *preceding* each committed token — (1, n, H) pre-norm for Qwen (the
    final trunk norm is applied here), or the model's native 4D raw hidden
    for DeepSeek-V4 (passed through untouched); ``committed`` is the (n,)
    uint32 committed tokens. One batched head forward appends n committed
    history entries and yields the next cycle's first draft logits for free
    (its last entry pairs the newest committed token with the hidden of its
    predecessor — exactly the fused state that predicts the next-next token).
    The remaining drafts chain on the head's own output hidden; with
    ``state.head_clone`` those speculative steps run on a per-cycle clone so
    the persistent head cache stays committed-only.

    Populates ``state.drafts`` / ``draft_lps`` / ``draft_accept_lps`` and
    advances ``state.hist_offset`` by n. All arrays are dispatched with
    ``mx.async_eval`` and stay lazy on the host; the next verify cycle's
    single sync resolves them.
    """
    import mlx.core as mx

    model = gen_batch.model
    if _dspark_host(model) is not None:
        return _dspark_next_drafts(
            gen_batch,
            state,
            hidden_rows,
            committed,
            prev_buf,
            depth,
        )
    sampler = _resolve_draft_sampler(gen_batch, state)
    procs = _proc_list(gen_batch)

    if depth is None:
        depth = state.controller.cur if state.controller is not None else state.depth
    if depth == 0 and not state.mtp_cache:
        # Depth-0 with a stateless head (no cache to keep warm, e.g. the
        # gemma4 assistant): skip the fold entirely — on fast backbones its
        # head forward + trunk norm is a measurable per-step tax (~15% of a
        # plain step on gemma4 26B) that would keep the parked throughput
        # below baseline. Head-history models keep folding below so their
        # cache stays consistent for re-entry.
        state.drafts = mx.zeros((0,), dtype=mx.uint32)
        state.draft_lps = []
        state.draft_accept_lps = []
        return

    hidden_rows = _head_input(model, hidden_rows)

    # Multi-block heads (inkling) route fold/chain by a per-cycle pass
    # counter on the cache list; reset it before the fold. Single-block
    # heads have no hook and are unaffected.
    begin = getattr(model, "mtp_begin_cycle", None) or getattr(
        getattr(model, "_language_model", None), "mtp_begin_cycle", None
    )
    if begin is not None:
        begin(state.mtp_cache, depth)

    sparse_k = _sparse_top_k(sampler) if procs is None else 0
    coarse = _coarse_draft_head(model) if 0 < sparse_k <= 32 else None
    n = committed.shape[0]
    if coarse is None:
        logits, head_hidden = model.mtp_forward(
            hidden_rows,
            committed.reshape(1, n),
            state.mtp_cache,
            return_hidden=True,
            logits_keep=1,
        )
    else:
        logits = None
        source, head_hidden = coarse.hidden(
            hidden_rows, committed.reshape(1, n), state.mtp_cache
        )
    state.hist_offset += int(n)

    draft_toks: List[Any] = []
    draft_lps: List[Any] = []
    draft_accept_lps: List[Any] = []

    chain_prefix = committed[-1:]
    h = head_hidden[:, -1:]
    chain_cache = state.mtp_cache
    if state.head_clone and depth > 1:
        chain_cache = _clone_mtp_head_cache(state.mtp_cache)
    elif depth > 1:
        chain_cache = _chain_tail_caches(model, state.mtp_cache) or chain_cache

    # Speculative draft shaping — see _dspark_next_drafts.
    snap = _snap_snapshotable(procs)

    sparse_ids: List[Any] = []
    for j in range(depth):
        if coarse is not None:
            # Emitted drafts then report the target's own log-probabilities.
            cand_ids, cand_lp = coarse.candidates(source)
            tok, ids, accept_lp = _sample_candidates_fused(sampler, cand_lp, sparse_k)
            tok = mx.take(cand_ids.reshape(-1), tok)
            sparse_ids.append(mx.take(cand_ids.reshape(-1), ids))
        else:
            logits_2d = logits[:, -1, :]
            if procs is not None and prev_buf is not None:
                prev = mx.concatenate(
                    [prev_buf.astype(mx.int32), chain_prefix.astype(mx.int32)]
                    + [t.reshape(1).astype(mx.int32) for t in draft_toks]
                )
                logits_2d = _apply_processors(procs, prev, logits_2d)
            lp_2d = _logprobs(logits_2d)
            if sparse_k:
                tok, ids, accept_lp = _sample_draft_sparse(sampler, lp_2d, sparse_k)
                sparse_ids.append(ids)
            else:
                tok, accept_lp = _sample_draft_with_logprobs(sampler, lp_2d)
            draft_lps.append(lp_2d.squeeze(0))
        tok = _ensure_uint32(tok)
        draft_toks.append(tok)
        draft_accept_lps.append(accept_lp.squeeze(0))
        if j + 1 == depth:
            break
        # Start this step on the GPU while the host encodes the next one.
        mx.async_eval(tok, h)
        if coarse is None:
            logits, head_hidden = model.mtp_forward(
                h,
                tok.reshape(1, 1),
                chain_cache,
                return_hidden=True,
            )
        else:
            source, head_hidden = coarse.hidden(h, tok.reshape(1, 1), chain_cache)
        h = head_hidden[:, -1:]

    _restore_snapshotable(procs, snap)

    if draft_toks:
        state.drafts = mx.concatenate(draft_toks)
        # Fire-and-forget dispatch: the GPU evaluates the chain while the
        # host finishes emit bookkeeping; the next cycle's sync finds it
        # materialized.
        mx.async_eval(state.drafts)
    else:
        # Depth 0 (controller escape hatch): no drafts — the next cycle
        # verifies [next_main] alone, i.e. a plain decode step. The fold
        # above still ran so head-history models stay warm for re-entry.
        state.drafts = mx.zeros((0,), dtype=mx.uint32)
        # Keep the head-cache fold from piling up lazily across draftless
        # cycles; its logits are never read, so they are never computed.
        mx.async_eval(head_hidden)
    state.draft_lps = draft_lps
    if sparse_ids:
        vocab = (
            _head_vocab(coarse.lang.lm_head) if coarse is not None else lp_2d.shape[-1]
        )
        draft_accept_lps = SparseDraftQ(
            mx.stack(sparse_ids), mx.stack(draft_accept_lps), vocab
        )
    state.draft_accept_lps = draft_accept_lps


# ---------------------------------------------------------------------------
# Post-init: run one extra backbone forward + MTP forward; queue the two
# emitted tokens; stash a draft for the first verify cycle.
# ---------------------------------------------------------------------------


def _post_init_mtp(gen_batch: Any, *, verify_result=None, priming_offset=None) -> None:
    """Bridge from standard ``__init__``'s ``_step()`` into PR 990's cycle 1.

    State on entry (after standard ``__init__``):
      - cache contains the prompt up to ``prompt[-1]`` inclusive
      - ``_next_tokens`` = ``main_tok`` (token sampled from ``prompt[-1]``'s logits)
      - ``_next_logprobs[0]`` = main_tok's distribution
      - ``tokens[0]`` = original prompt list

    We perform one more 1-token backbone forward (so the cache also includes
    ``main_tok`` and we obtain the hidden state at that position), run the
    MTP head to produce a draft for the next verify cycle, and seed
    ``state.queue`` with two confirmed tokens — ``main_tok`` and the
    standard-sample at the next position. After this, the queue handles
    the first two emit calls and the third call enters the verify cycle.

    If the batch was empty when ``__init__`` ran, ``_next_tokens`` is
    ``None`` — we leave MTP inactive and the standard path runs unchanged.
    """
    import mlx.core as mx

    if gen_batch._next_tokens is None or not gen_batch.uids:
        # Nothing was sampled in the standard _step (empty batch). The
        # next() call will be a no-op anyway; leave the patch inert.
        return

    sampler = _resolve_sampler(gen_batch)
    procs = _proc_list(gen_batch)

    main_tok = _ensure_uint32(gen_batch._next_tokens)  # (1,)
    main_lp = gen_batch._next_logprobs[0]  # (vocab,)

    if procs is not None:
        prev_buf = gen_batch._token_context[0].update_and_fetch(main_tok)
    else:
        prev_buf = None

    # 1-token backbone forward at main_tok with hidden state. No draft yet,
    # so no rollback is possible — discard gdn_states.
    # Inherits the per-engine stream from the enclosing BatchGenerator context.
    drafter = _drafter_for(gen_batch.model)
    if verify_result is None:
        verify_result = _call_backbone_captured(
            gen_batch.model,
            main_tok[:, None],
            gen_batch.prompt_cache,
            capture_layer_ids=_drafter_capture_ids(gen_batch.model),
        )
    logits, hidden, rollback_state = verify_result[:3]
    captured = verify_result[3] if len(verify_result) > 3 else None
    if rollback_state is not None:
        gen_batch.model.rollback_speculative_cache(
            gen_batch.prompt_cache, rollback_state, 0, 1
        )
    _clear_rollback(gen_batch.prompt_cache)

    next_main_logits = logits[:, -1, :]  # (1, vocab) — distribution after main_tok
    next_main_logits = _apply_processors(procs, prev_buf, next_main_logits)
    next_main_lp = _logprobs(next_main_logits)
    next_main_tok = sampler(next_main_lp)  # (1,)

    chain, depth, head_clone = _resolve_mtp_chain_depth(gen_batch.model)

    if chain:
        # Depth-k seed: the history fold pairs hidden(main_tok) with
        # next_main_tok — the first committed history entry — and its logits
        # are the first draft's distribution; the rest of the chain follows.
        mx.eval(main_tok, next_main_tok)
        state = _MtpState(uid=gen_batch.uids[0])
        state.chain = True
        state.depth = depth
        state.head_clone = head_clone
        if drafter is not None:
            # Block drafters keep their own per-request context and draft a
            # fixed block, so neither the head cache nor the depth
            # controller applies. The captured hidden of main_tok is the
            # newest context entry; next_main is the anchor.
            state.mtp_cache = []
            state.next_main = _ensure_uint32(next_main_tok)
            state.queue.append((int(main_tok.tolist()[0]), main_lp, "init"))
            state.queue.append(
                (int(next_main_tok.tolist()[0]), next_main_lp.squeeze(0), "init")
            )
            drafter.draft([(gen_batch, state, captured, state.next_main, prev_buf)])
            gen_batch._omlx_mtp_state = state
            return
        if depth > 1 and not _mtp_depth_fixed(gen_batch.model):
            factory = getattr(
                _dspark_host(gen_batch.model), "make_mtp_depth_controller", None
            )
            if factory is not None:
                state.controller = factory(depth)
            else:
                state.controller = _DepthController(
                    depth,
                    marginal_ms=getattr(gen_batch.model, "_omlx_mtp_marginal_ms", None),
                    exit_margin=_effective_loop_tax(gen_batch.model),
                    seed=getattr(gen_batch.model, "_omlx_mtp_depth_seed", None),
                )
                try:
                    # The next sequence starts from this one's latest estimates.
                    gen_batch.model._omlx_mtp_depth_seed = state.controller
                except Exception:
                    pass
        primed = _prompt_priming.take_primed(
            gen_batch.model,
            gen_batch.prompt_cache,
            main_tok,
            uid=gen_batch.uids[0],
            cache_offset=priming_offset,
        )
        if primed is not None:
            state.mtp_cache, state.hist_offset = primed
            state.head_history_primed = True
        else:
            state.mtp_cache = gen_batch.model.make_mtp_cache()
        state.next_main = _ensure_uint32(next_main_tok)
        state.queue.append((int(main_tok.tolist()[0]), main_lp, "init"))
        state.queue.append(
            (int(next_main_tok.tolist()[0]), next_main_lp.squeeze(0), "init")
        )
        _chain_next_drafts(
            gen_batch,
            state,
            hidden[:, -1:],
            state.next_main,
            prev_buf,
        )
        gen_batch._omlx_mtp_state = state
        return

    # MTP head sees (hidden_at_main, next_main_tok) and proposes the draft
    # that the *next* verify cycle will check against forward([next_main, draft]).
    # The legacy depth-1 cycle rebuilds head history per cycle and never
    # consumes a primed cache; release any capture leftovers.
    _prompt_priming.drop_ctx(gen_batch.model)
    mtp_cache = gen_batch.model.make_mtp_cache()
    hidden_at_main = hidden[:, -1:, :]  # (1, 1, H)
    next_ids = next_main_tok.reshape(1, 1)
    mtp_logits = gen_batch.model.mtp_forward(hidden_at_main, next_ids, mtp_cache)
    mtp_logits_2d = mtp_logits[:, -1, :]
    # The seed draft is speculative — shape but do not count.
    snap = _snap_snapshotable(procs)
    if procs is not None:
        prev_with_main_and_next = mx.concatenate(
            [prev_buf, _ensure_uint32(next_main_tok)]
        )
        mtp_logits_2d = _apply_processors(procs, prev_with_main_and_next, mtp_logits_2d)
    _restore_snapshotable(procs, snap)
    draft_lp_2d = _logprobs(mtp_logits_2d)
    draft_tok = sampler(draft_lp_2d)
    # Filtered draft lp — what the sampler actually drew from. The next
    # cycle's acceptance ratio uses this so the math matches the
    # sampling distribution rather than the raw softmax.
    draft_accept_lp_2d = _accept_lp_for(sampler, draft_lp_2d)

    mx.eval(main_tok, next_main_tok, draft_tok)

    # Queue the two confirmed tokens (main_tok + next_main_tok); their
    # logprobs come from the standard / patched samplers. Cache draft_id
    # while the array is already evaluated to avoid re-syncing in cycle 1.
    state = _MtpState(uid=gen_batch.uids[0])
    state.mtp_cache = mtp_cache
    state.next_main = _ensure_uint32(next_main_tok)
    state.draft_tok = _ensure_uint32(draft_tok)
    state.draft_lp = draft_lp_2d.squeeze(0)
    state.draft_accept_lp = draft_accept_lp_2d.squeeze(0)
    state.draft_id = int(draft_tok.tolist()[0])
    state.queue.append((int(main_tok.tolist()[0]), main_lp, "init"))
    state.queue.append(
        (int(next_main_tok.tolist()[0]), next_main_lp.squeeze(0), "init")
    )

    gen_batch._omlx_mtp_state = state


# ---------------------------------------------------------------------------
# Shared target verification and request-local emission.
# ---------------------------------------------------------------------------


def _set_batched_mrope_deltas(gen_batch: Any, uids: list[Any]) -> None:
    """Per-row mRoPE deltas for the batched verify (batched _set_singleton_mrope_delta)."""
    model = getattr(gen_batch, "model", None)
    if (
        model is not None
        and getattr(model, "_uses_mrope", False)
        and getattr(model, "_uid_rope_deltas", None)
        and hasattr(model, "set_batch_rope_deltas")
    ):
        import mlx.core as mx

        deltas = [float(model._uid_rope_deltas.get(u, 0.0)) for u in uids]
        step_setter = getattr(type(model), "set_step_rope_deltas", None)
        if callable(step_setter):
            step_setter(model, mx.array(deltas), list(uids))
        else:
            model.set_batch_rope_deltas(mx.array(deltas))


def _run_verify_cycle_batched(gen_batch: Any, batch_state: _MtpBatchState) -> Any:
    from .fused_batch import advance

    states = [batch_state.states[uid] for uid in gen_batch.uids]
    policy = getattr(gen_batch, "_omlx_mtp_batch_policy", None)
    if policy is not None and policy.uids != tuple(gen_batch.uids):
        policy = None
    saved = [(state.controller, state.depth) for state in states]
    depths = [int(state.drafts.shape[0]) if state.chain else 1 for state in states]
    # Copied windows are not draft-depth decisions; the singleton depth
    # controller skips them too.
    copied = any(state.copy_drafts for state in states)
    previous = [(state.stats.cycles, state.stats.accepts) for state in states]
    requested = policy.cur if policy is not None else None
    if policy is not None:
        for state in states:
            state.controller = None
            state.depth = requested
    started = time.perf_counter()
    try:
        advance(gen_batch, batch_state)
        per_row = {}
        for uid in gen_batch.uids:
            state = batch_state.states[uid]
            per_row[uid] = list(state.queue)
            state.queue.clear()
        result = _emit_ragged_responses(gen_batch, batch_state, per_row)
    finally:
        for state, (controller, depth) in zip(states, saved):
            state.controller, state.depth = controller, depth
    elapsed = (
        policy.cycle_time_ms("mtp", started, time.perf_counter())
        if policy is not None
        else 0.0
    )
    if (
        policy is not None
        and not copied
        and tuple(gen_batch.uids) == policy.uids
        and len(set(depths)) == 1
        and depths[0] > 0
        and all(
            state.stats.cycles == cycles + 1
            for state, (cycles, _) in zip(states, previous)
        )
    ):
        accepted = [
            state.stats.accepts - count for state, (_, count) in zip(states, previous)
        ]
        policy.observe_mtp(depths[0], accepted, elapsed, stable=depths[0] == requested)
        if elapsed is not None:
            logger.debug(
                "Lightning MTP batch cost: rows=%d depth=%d accepts=%s ms=%.3f next_depth=%d",
                len(states),
                depths[0],
                accepted,
                elapsed,
                policy.cur,
            )
        if policy.should_park():
            if not _reconcile_mtp_batch_to_standard(gen_batch):
                raise RuntimeError(
                    "Lightning MTP could not restore batch parking state"
                )
            policy.park()
            _batch_park_memory(gen_batch.model).parked(policy)
            logger.info(
                "Lightning MTP batch parked: rows=%d standard_ms=%.3f cooldown=%d",
                len(states),
                median(policy.standard),
                policy.remaining,
            )
            _drop_mtp_batch_state(gen_batch, "batch-parked", log_stats=True)
    return result


# ---------------------------------------------------------------------------
# next() dispatch
# ---------------------------------------------------------------------------


def _mtp_batch_next(gen_batch: Any, batch_state: _MtpBatchState) -> Any:
    """Verify compatible rows together and emit each request's accepted run."""
    if not getattr(gen_batch, "uids", None):
        return []
    return _run_verify_cycle_batched(gen_batch, batch_state)


def _emit_ragged_responses(
    gen_batch: Any, batch_state: _MtpBatchState, per_row: dict[Any, list]
) -> list[Any]:
    """Emit ordered runs, stopping each UID at its first terminal token."""
    Response = type(gen_batch).Response
    keep: list[int] = []
    responses: list[Any] = []
    finished_uids: list[Any] = []

    for idx, uid in enumerate(list(gen_batch.uids)):
        toks = per_row.get(uid)
        if not toks:
            raise _MtpStepFallback(f"ragged emit: row uid={uid} produced no tokens")
        state = batch_state.states.get(uid)
        row_finished = False
        for token_id, logprobs_1d, source in toks:
            if state is not None:
                _bump_emit_stat(state, source)
            finish_reason: Optional[str] = None
            gen_batch.tokens[idx].append(token_id)
            gen_batch._num_tokens[idx] += 1
            if gen_batch._num_tokens[idx] >= gen_batch.max_tokens[idx]:
                finish_reason = "length"
            if gen_batch._matchers[idx].advance(token_id):
                finish_reason = "stop"
            if finish_reason is not None:
                responses.append(
                    Response(
                        uid=uid,
                        token=token_id,
                        logprobs=logprobs_1d,
                        finish_reason=finish_reason,
                        prompt_cache=gen_batch.extract_cache(idx),
                        all_tokens=gen_batch.tokens[idx],
                    )
                )
                if state is not None:
                    _log_mtp_stats(uid, state.stats, finish_reason)
                finished_uids.append(uid)
                row_finished = True
                break
            responses.append(
                Response(
                    uid=uid,
                    token=token_id,
                    logprobs=logprobs_1d,
                    finish_reason=None,
                    prompt_cache=None,
                    all_tokens=None,
                )
            )
        if not row_finished:
            keep.append(idx)

    for uid in finished_uids:
        batch_state.states.pop(uid, None)
    if len(keep) < len(gen_batch.uids):
        gen_batch.filter(keep)
    return responses


def _feed_batch_mains_to_standard(gen_batch: Any, batch_state: _MtpBatchState) -> bool:
    """Restore the ordinary batched step at drained chain frontiers.

    Every row's last emitted token is still outside its target cache, even
    when acceptance has left rows at different offsets. Feed those tokens
    together and retain the resulting successors for GenerationBatch._step.
    No emitted token is replayed into the stream and no prompt is re-prefilled.
    """
    import mlx.core as mx

    states = [batch_state.states.get(uid) for uid in gen_batch.uids]
    if not states or any(
        state is None or not state.chain or state.queue or state.next_main is None
        for state in states
    ):
        return False
    _prompt_priming.retain_batch_head_history(gen_batch, batch_state)
    rows = [
        _make_row_batch(gen_batch, i, prompt_cache=gen_batch.prompt_cache, state=state)
        for i, state in enumerate(states)
    ]
    contexts = []
    for row, state in zip(rows, states):
        procs = _proc_list(row)
        previous = (
            row._token_context[0].update_and_fetch(state.next_main)
            if procs is not None
            else None
        )
        contexts.append((procs, previous))
    _set_batched_mrope_deltas(gen_batch, gen_batch.uids)
    inputs = mx.stack([state.next_main for state in states])
    # Match GenerationBatch._step, including models whose hidden capture is
    # singleton-only even though their ordinary forward accepts a batch.
    drafter = _drafter_for(gen_batch.model)
    with _prompt_priming.decode_scope(gen_batch.model, gen_batch.uids):
        if drafter is not None:
            # Keep every committed token in the drafter context, even the
            # ones processed by an ordinary step.
            logits, _, _, captured = _call_backbone_captured(
                gen_batch.model,
                inputs,
                gen_batch.prompt_cache,
                capture_layer_ids=list(drafter.target_layer_ids),
            )
            drafter.observe(gen_batch.uids, captured)
        else:
            logits = gen_batch.model(inputs, cache=gen_batch.prompt_cache)
    tokens, logprobs = [], []
    for i, (row, (procs, previous)) in enumerate(zip(rows, contexts)):
        last = _apply_processors(procs, previous, logits[i : i + 1, -1, :])
        lp = _logprobs(last)
        tokens.append(_ensure_uint32(_resolve_sampler(row)(lp)))
        logprobs.append(lp.squeeze(0))
    next_tokens = mx.concatenate(tokens)
    mx.eval(next_tokens)
    gen_batch._next_tokens = next_tokens
    gen_batch._next_logprobs = logprobs
    _clear_rollback(gen_batch.prompt_cache)
    return True


def _feed_next_main_to_standard(
    gen_batch: Any, state: _MtpState, retain_head: bool = False
) -> bool:
    """Materialize the committed main token and sample its successor.

    A failed one-token handoff retries once by rebuilding committed history.
    Only an absent main token returns False; failed recovery stops decoding.
    ``retain_head`` hands the committed head history to prompt priming.
    """
    import mlx.core as mx

    if state.next_main is None:
        return False
    procs = _proc_list(gen_batch)
    snapshot = _snap_snapshotable(procs)
    try:
        _set_singleton_mrope_delta(gen_batch)
        prev_buf = None
        if procs is not None:
            prev_buf = gen_batch._token_context[0].update_and_fetch(state.next_main)
        drafter = _drafter_for(gen_batch.model)
        logits, hidden, _, captured = _call_backbone_captured(
            gen_batch.model,
            state.next_main[:, None],
            gen_batch.prompt_cache,
            capture_layer_ids=_drafter_capture_ids(gen_batch.model),
        )
        if drafter is not None:
            drafter.observe(gen_batch.uids, captured)
        if retain_head and state.chain and state.head_history_primed:
            if not state.head_clone:
                _mtp_head_trim_to(state.mtp_cache, state.hist_offset)
            _prompt_priming.retain_parked_head_history(
                gen_batch.model,
                state.uid,
                state.mtp_cache,
                state.hist_offset,
                _head_input(gen_batch.model, hidden[:, -1:]),
                gen_batch.prompt_cache,
            )
        last = _apply_processors(procs, prev_buf, logits[:, -1, :])
        lp_2d = _logprobs(last)
        next_tok = _ensure_uint32(_resolve_sampler(gen_batch)(lp_2d))
        mx.eval(next_tok)
        gen_batch._next_tokens = next_tok
        gen_batch._next_logprobs = [lp_2d.squeeze(0)]
        _clear_rollback(gen_batch.prompt_cache)
    except Exception as exc:
        logger.warning("MTP handoff failed; rebuilding committed cache: %s", exc)
        _restore_snapshotable(procs, snapshot)
        if not _reconcile_mtp_to_standard(gen_batch, state):
            raise RuntimeError(
                "Lightning MTP could not restore the committed cache"
            ) from exc
    return True


def _park_mtp_to_standard(gen_batch: Any, state: _MtpState) -> bool:
    """Hand a parked sequence back to the standard pipelined decoder.

    At a depth-0 cycle boundary the cache is committed-only and compact, so
    unlike ``_reconcile_mtp_to_standard`` no re-prefill is needed: feed
    ``state.next_main`` (already streamed, not yet in the cache), sample its
    successor as ``_next_tokens``, and drop the MTP state. The batch is
    marked for a cooldown so the standard step's async pipelining can run
    without the MTP loop tax. A later singleton probe creates a fresh depth
    controller; repeated failed probes exponentially extend the cooldown.
    """
    if not _feed_next_main_to_standard(gen_batch, state, retain_head=True):
        return False
    park_state = _mtp_park_state_for_batch(gen_batch)
    if state.reentry_probe and park_state is not None:
        park_state.restart_after_failed_probe()
    else:
        park_state = _MtpParkState(uid=state.uid)
        gen_batch._omlx_mtp_park_state = park_state
    if state.controller is not None:
        _arm_std_tax_probe(gen_batch, state.controller.t.get(0), state.uid)
    logger.info(
        "MTP[%s] parked for %d standard tokens before re-entry probe",
        state.uid,
        park_state.cooldown_tokens,
    )
    state._finish_reason = "parked"
    _drop_mtp_state(gen_batch, "parked-at-depth-0", log_stats=True)
    return True


def _handoff_mtp_for_late_join(gen_batch: Any, state: _MtpState) -> bool:
    """Hand a singleton MTP decode to the standard step for a late join.

    A pending prefill can only merge into this batch through mlx-lm's
    promotion path, which the active-MTP completion pin blocks (#2515). At
    the drained-queue boundary the handoff is exact and cheap: with one
    queued token left it is the only committed token whose KV is absent
    from the cache, so it becomes ``_next_tokens`` verbatim and its stored
    logprobs keep the standard step's emission byte-identical; with an
    empty queue the park-style 1-token forward re-derives the same state.
    Unlike ``_park_mtp_to_standard`` this starts no performance cooldown and
    arms no std-tax probe: the sequence is yielding to a batch merge, not
    losing to standard decode, and must regain MTP once it is a compact
    singleton again.
    """
    import mlx.core as mx

    if len(state.queue) > 1:
        return False
    if len(state.queue) == 1:
        token_id, logprobs_1d, _src = state.queue[0]
        gen_batch._next_tokens = mx.array([int(token_id)], dtype=mx.uint32)
        gen_batch._next_logprobs = [logprobs_1d]
        _clear_rollback(gen_batch.prompt_cache)
    elif not _feed_next_main_to_standard(gen_batch, state):
        return False
    if state.reentry_probe:
        park_state = _mtp_park_state_for_batch(gen_batch)
        if park_state is not None:
            park_state.defer_probe()
    state._finish_reason = "late-join-handoff"
    _drop_mtp_state(gen_batch, "late-join-handoff", log_stats=True)
    return True


def _mtp_next(gen_batch: Any, state: _MtpState) -> Any:
    """Emit one token; run a verify cycle if the queue is empty."""
    if state.queue:
        token_id, logprobs_1d, source = state.queue.popleft()
        _bump_emit_stat(state, source)
        return _emit_response(gen_batch, token_id, logprobs_1d, state.stats)

    _run_verify_cycle(gen_batch, state)
    if not state.queue:
        # Verify cycle should always populate the queue with at least the
        # rejected-verify token; if it didn't, fall back to the standard
        # step rather than yield an undefined response.
        raise _MtpStepFallback("verify cycle produced no emit tokens")

    token_id, logprobs_1d, source = state.queue.popleft()
    _bump_emit_stat(state, source)
    result = _emit_response(gen_batch, token_id, logprobs_1d, state.stats)
    if (
        state.chain
        and state.controller is not None
        and state.controller.should_exit()
        and not state.queue
        and result[0].finish_reason is None
    ):
        # Record the emitted token before a handoff can rebuild its history.
        _park_mtp_to_standard(gen_batch, state)
    return result


def _log_mtp_stats(uid: Any, stats: "_MtpStats", finish_reason: str) -> None:
    """Emit a one-line summary of MTP draft/verify activity for a finished sequence.

    Format chosen to match PR 990's headline metrics, plus component timings
    that make wall-clock vs. accept-rate gaps debuggable:
      MTP[<uid>] finish=<reason> tokens=<N> cycles=<C> accept=<A>/<C> (<rate>%)
        emits[init=<i>,draft=<d>,bonus=<b>,verify=<v>]
        timing[backbone=<X>ms mtp=<Y>ms sample=<S>ms cache=<C>ms]
    """
    total_emits = (
        stats.init_emits + stats.draft_emits + stats.bonus_emits + stats.verify_emits
    )
    total_drafted = sum(stats.depth_drafted) or stats.cycles
    if total_drafted > 0:
        rate_str = f"{stats.accepts / total_drafted * 100:.1f}%"
    else:
        rate_str = "n/a"
    if stats.depth_drafted:
        depth_str = (
            " depth["
            + ",".join(
                f"d{i + 1}={a}/{d}"
                for i, (a, d) in enumerate(
                    zip(stats.depth_accepted, stats.depth_drafted)
                )
            )
            + "]"
        )
    else:
        depth_str = ""
    if stats.zero_cycles:
        depth_str += f" d0={stats.zero_cycles}"
    if stats.copy_cycles:
        depth_str += (
            f" copy={stats.copy_accepted}/{stats.copy_drafted}"
            f" in {stats.copy_cycles}"
        )
    tpc = total_emits / stats.cycles if stats.cycles else 0.0
    logger.info(
        "MTP[%s] finish=%s tokens=%d cycles=%d tok/cycle=%.2f accept=%d/%d (%s)%s "
        "emits[init=%d,draft=%d,bonus=%d,verify=%d] "
        "timing[backbone=%.1fms mtp=%.1fms sample=%.1fms cache=%.1fms]",
        uid,
        finish_reason,
        total_emits,
        stats.cycles,
        tpc,
        stats.accepts,
        total_drafted,
        rate_str,
        depth_str,
        stats.init_emits,
        stats.draft_emits,
        stats.bonus_emits,
        stats.verify_emits,
        stats.backbone_ms,
        stats.mtp_head_ms,
        stats.sample_ms,
        stats.cache_ops_ms,
    )


def _bump_emit_stat(state: _MtpState, source: str) -> None:
    if source == "init":
        state.stats.init_emits += 1
    elif source == "draft":
        state.stats.draft_emits += 1
    elif source == "bonus":
        state.stats.bonus_emits += 1
    elif source == "verify":
        state.stats.verify_emits += 1


# ---------------------------------------------------------------------------
# Verify cycle: 2-token forward + accept/reject + MTP forward for next draft.
# ---------------------------------------------------------------------------


def _run_verify_cycle(gen_batch: Any, state: _MtpState) -> None:
    """Dispatch to the depth-k chain cycle or the PR-990 depth-1 legacy cycle."""
    if state.chain:
        return _run_verify_cycle_chain(gen_batch, state)
    return _run_verify_cycle_legacy(gen_batch, state)


class SparseDraftQ:
    """Draft log-densities over per-position candidate ids, zero elsewhere.

    ``ids`` and ``logq`` are ``(k, C)``. Indexing yields the dense
    ``(vocab,)`` log row for consumers that need the full distribution.
    """

    def __init__(self, ids, logq, vocab: int):
        self.ids = ids
        self.logq = logq
        self.vocab = int(vocab)

    def __len__(self) -> int:
        return int(self.ids.shape[0])

    def __getitem__(self, index):
        import mlx.core as mx

        row = mx.full((self.vocab,), -float("inf"), dtype=mx.float32)
        return mx.put_along_axis(row, self.ids[index], self.logq[index], axis=-1)

    def arrays(self) -> list:
        return [self.ids, self.logq]


def _dense_q_rows(draft_accept_lps) -> list:
    if isinstance(draft_accept_lps, SparseDraftQ):
        return [draft_accept_lps[i] for i in range(len(draft_accept_lps))]
    return list(draft_accept_lps)


def _sparse_top_k(sampler) -> int:
    """Top-k of a sampler whose target filter is exactly top-p + top-k, else 0."""
    top_k = int(getattr(sampler, "top_k", 0) or 0)
    if (
        float(getattr(sampler, "temp", 0.0) or 0.0) <= 0.0
        or not 0 < top_k <= 64
        or float(getattr(sampler, "min_p", 0.0) or 0.0) != 0.0
        or float(getattr(sampler, "xtc_probability", 0.0) or 0.0) > 0.0
    ):
        return 0
    return top_k


def _stochastic_verify_tokens_sparse(
    sampler, combined_lp, drafts, draft_accept_lps, top_k
):
    """``_stochastic_verify_tokens`` on the target's top-k support only.

    With a top-k filter the target density p is zero outside its top-k
    tokens, and so are the residual max(p - q, 0) and the bonus draw. Only the
    draft densities q are read at the needed ids, so no vocab-wide op runs
    after the top-k selection. The sampled distributions are unchanged.
    """
    import mlx.core as mx

    from omlx.utils.sampling import top_k_indices

    k = int(drafts.shape[0])
    top_p = float(getattr(sampler, "top_p", 0.0) or 0.0)
    temp = float(sampler.temp)
    ids = top_k_indices(combined_lp, top_k)
    vals = mx.take_along_axis(combined_lp, ids, axis=-1).astype(mx.float32)
    order = mx.argsort(-vals, axis=-1)
    vals = mx.take_along_axis(vals, order, axis=-1)
    ids = mx.take_along_axis(ids, order, axis=-1)
    if 0.0 < top_p < 1.0:
        probs = mx.exp(vals)
        vals = mx.where(mx.cumsum(probs, axis=-1) - probs < top_p, vals, -float("inf"))
    scaled = vals * (1.0 / temp)
    logp = scaled - mx.logsumexp(scaled, axis=-1, keepdims=True)  # (k+1, top_k)

    d = drafts.astype(mx.int32)
    hit = ids[:k] == d[:, None]
    p_at = mx.where(
        mx.any(hit, axis=-1),
        mx.sum(mx.where(hit, logp[:k], 0.0), axis=-1),
        -float("inf"),
    )
    if isinstance(draft_accept_lps, SparseDraftQ):
        q_ids = draft_accept_lps.ids[:k]
        q_lp = draft_accept_lps.logq[:k]
        q_hit = q_ids == d[:, None]
        q_at = mx.where(
            mx.any(q_hit, axis=-1),
            mx.sum(mx.where(q_hit, q_lp, 0.0), axis=-1),
            -float("inf"),
        )
    else:
        q_rows = mx.stack(draft_accept_lps)  # (k, V)
        q_at = mx.take_along_axis(q_rows, d[:, None], axis=-1).squeeze(-1)
    ratio = p_at - q_at
    u = mx.random.uniform(shape=(k,))
    acc = mx.logical_or(ratio >= 0, mx.log(u) < ratio)
    m_arr = mx.cumprod(acc.astype(mx.int32)).sum().reshape(1)
    p_sup = mx.exp(logp[:k])
    if isinstance(draft_accept_lps, SparseDraftQ):
        match = ids[:k, :, None] == q_ids[:, None, :]
        q_sup = mx.sum(mx.where(match, mx.exp(q_lp)[:, None, :], 0.0), axis=-1)
    else:
        q_sup = mx.exp(mx.take_along_axis(q_rows, ids[:k], axis=-1).astype(mx.float32))
    res = mx.maximum(p_sup - q_sup, 0.0)
    z = res.sum(axis=-1, keepdims=True)
    res_dist = mx.where(z > 0, res, p_sup)
    res_pos = mx.random.categorical(mx.log(res_dist))
    res_samples = mx.take_along_axis(ids[:k], res_pos[:, None], axis=-1).squeeze(-1)
    bonus_pos = mx.random.categorical(logp[k : k + 1])
    bonus_tok = mx.take_along_axis(ids[k : k + 1], bonus_pos[:, None], axis=-1).reshape(
        1
    )
    return mx.concatenate(
        [
            m_arr.astype(mx.int32),
            d,
            res_samples.astype(mx.int32),
            bonus_tok.astype(mx.int32),
        ]
    )


def _stochastic_verify_tokens(sampler, combined_lp, drafts, draft_accept_lps):
    """Build acceptance and correction tokens without a host synchronization."""
    import mlx.core as mx

    k = int(drafts.shape[0])
    top_k = _sparse_top_k(sampler)
    if top_k and k > 0:
        return _stochastic_verify_tokens_sparse(
            sampler, combined_lp, drafts, draft_accept_lps, top_k
        )
    sampling_logits = getattr(sampler, "_mtp_sampling_logits", None)
    filtered = None
    if sampling_logits is None:
        accept_rows = _accept_lp_for(sampler, combined_lp)
    else:
        filtered = sampling_logits(combined_lp)
        density = filtered.astype(mx.float32)
        accept_rows = density - mx.logsumexp(density, axis=-1, keepdims=True)
    q_rows = mx.stack(_dense_q_rows(draft_accept_lps))  # (k, V)
    idx = drafts.astype(mx.int32)[:, None]
    p_at = mx.take_along_axis(accept_rows[:k], idx, axis=-1).squeeze(-1)
    q_at = mx.take_along_axis(q_rows, idx, axis=-1).squeeze(-1)
    ratio = p_at - q_at  # (k,) log acceptance ratios
    u = mx.random.uniform(shape=(k,))
    acc = mx.logical_or(ratio >= 0, mx.log(u) < ratio)
    m_arr = mx.cumprod(acc.astype(mx.int32)).sum().reshape(1)
    # Residual distributions max(p - q, 0) per draft position. Only the
    # reject position's sample is used; computing all k keeps the cycle
    # single-sync and costs a few elementwise vocab ops on GPU.
    p_all = mx.exp(accept_rows[:k])
    res = mx.maximum(p_all - mx.exp(q_rows), 0.0)
    z = res.sum(axis=-1, keepdims=True)
    res_dist = mx.where(z > 0, res, p_all)
    res_samples = mx.random.categorical(mx.log(res_dist))  # (k,)
    bonus_tok = (
        sampler(combined_lp[k : k + 1])
        if filtered is None
        else mx.random.categorical(filtered[k : k + 1])
    ).reshape(1)
    return mx.concatenate(
        [
            m_arr.astype(mx.int32),
            drafts.astype(mx.int32),
            res_samples.astype(mx.int32),
            bonus_tok.astype(mx.int32),
        ]
    )


def _predraft(gen_batch, state, drafter, captured, host_arr, m_arr, anchor) -> bool:
    """Queue the next block draft behind this cycle's acceptance, pre-sync."""
    import mlx.core as mx

    predraft = getattr(drafter, "predraft", None)
    if predraft is None or captured is None:
        return False
    # Scheduled alone, the host read gets its own completion event; read as
    # an input of the draft it would wait for the whole draft.
    mx.async_eval(host_arr)
    return bool(predraft(gen_batch, state, captured, m_arr + 1, anchor))


def _context_copy_drafts(
    gen_batch: Any, state: _MtpState, committed_ids: List[int]
) -> List[int]:
    """Draft the next window by copying from the context, if it repeats.

    Singleton chain cycles. Greedy acceptance is exact token equality against
    the target's own argmax; sampled acceptance treats the copy as a draft
    distribution with all its mass on the copied token (``_copy_draft_q``),
    so the Leviathan/Chen rule keeps the sampled distribution exact. Either
    way any draft source leaves the output distribution unchanged. Returns
    ``[]`` when the MTP head should draft instead.
    """
    if state.context_copy is None:
        state.context_copy = _context_copy.ContextCopy(
            wide_window=_row_exact_verify(gen_batch.model)
        )
    copier = state.context_copy
    state.copy_untimed = copier.extend(gen_batch.tokens[0], committed_ids)
    # The next cycle emits up to len(drafts) + 1 tokens after the queued ones.
    room = (
        gen_batch.max_tokens[0] - gen_batch._num_tokens[0] - len(committed_ids) - 1
    )
    if _dspark_host(gen_batch.model) is None:
        return copier.propose(room)
    # Copies verify in DSpark's window sizes, and only a copy that fills the
    # block replaces it: DSpark already drafts repeated text accurately.
    copied = copier.propose(min(room, state.depth))
    return copied if len(copied) == state.depth else []


def _copy_draft_q(copied: List[int], vocab: int) -> SparseDraftQ:
    """One-hot draft distributions for a copied window."""
    import mlx.core as mx

    ids = mx.array(copied, dtype=mx.int32)[:, None]
    return SparseDraftQ(ids, mx.zeros(ids.shape, dtype=mx.float32), vocab)


def _run_verify_cycle_chain(
    gen_batch: Any,
    state: _MtpState,
    *,
    verify_result=None,
    commit_cache=None,
    verify_ms=0.0,
    defer_commit=False,
    greedy_result=None,
    stochastic_result=None,
    draft_jobs=None,
) -> None:
    """One depth-k verify cycle.

    Verify ``[next_main, d1..dk]`` in a single backbone forward with
    ``n_confirmed=1``. Greedy acceptance is computed in-graph, so the whole
    cycle costs exactly ONE host sync (a ~2k-int ``tolist``); the next draft
    chain is dispatched with ``mx.async_eval`` and resolves inside the next
    cycle's sync. Emits ``m + 1`` tokens per cycle (m = accepted drafts, plus
    bonus on full accept or the verify-position correction on reject).
    """
    import time

    import mlx.core as mx

    if state.next_main is None or state.drafts is None:
        raise _MtpStepFallback("chain cycle entered without next_main / drafts")

    sampler = _resolve_sampler(gen_batch)
    procs = _proc_list(gen_batch)
    is_greedy = _is_greedy(gen_batch)
    # Adaptive depth: the chain may have drafted fewer than state.depth
    # tokens this cycle — the verify window follows the actual drafts.
    k = int(state.drafts.shape[0])
    copy_cycle = state.copy_drafts
    cycle_t0 = time.perf_counter()

    inputs = mx.concatenate([state.next_main, state.drafts])  # (k+1,)

    # Token buffer per input position (mirrors PR 990 _step_backbone). Row j's
    # processor prefix is everything before that input position.
    prev_rows: List[Optional[Any]] = [None] * (k + 1)
    if procs is not None:
        buf = gen_batch._token_context[0]
        prev_rows[0] = buf.update_and_fetch(state.next_main)
        for j in range(k):
            prev_rows[j + 1] = buf.update_and_fetch(state.drafts[j : j + 1])

    # --- backbone verify forward + single host sync ---
    t0 = time.perf_counter()
    drafter = _drafter_for(gen_batch.model)
    if verify_result is None:
        verify_result = _call_backbone_captured(
            gen_batch.model,
            inputs[None, :],
            gen_batch.prompt_cache,
            n_confirmed=1,
            capture_layer_ids=_drafter_capture_ids(gen_batch.model),
        )
    logits, hidden, gdn_states = verify_result[:3]
    captured = verify_result[3] if len(verify_result) > 3 else None
    if drafter is not None and captured is None:
        raise _MtpStepFallback("block drafter verify returned no layer captures")
    state.stats.backbone_ms += verify_ms
    rows = logits[0]  # (k+1, vocab)
    row_snaps: List[Optional[Any]] = [None] * (k + 1)
    if procs is not None:
        applied = []
        for j in range(k + 1):
            applied.append(
                _apply_processors(procs, prev_rows[j], rows[j : j + 1]).squeeze(0)
            )
            # Checkpoint after each row: rows 0..m correspond to the m+1
            # tokens actually emitted this cycle (m accepted drafts + the
            # bonus/verify correction). Rows m+1..k are speculative — they
            # predict rejected drafts and are re-verified next cycle.
            row_snaps[j] = _snap_snapshotable(procs)
        rows = mx.stack(applied)
    combined_lp = rows - mx.logsumexp(rows, axis=-1, keepdims=True)  # (k+1, V)
    # A block drafter can start the next block on the GPU while the host
    # settles this cycle; plain single-row cycles only.
    can_predraft = (
        drafter is not None
        and procs is None
        and draft_jobs is None
        and commit_cache is None
        and not defer_commit
    )
    predrafted = False

    if k == 0:
        # Depth-0 cycle (controller escape hatch): the forward above was a
        # plain 1-token step at [next_main]; sample its next token and emit
        # it as the bonus. No drafts to accept, nothing to roll back —
        # per-cycle cost is the baseline step the controller tracks as t[0].
        step_tok = _ensure_uint32(sampler(combined_lp[:1]).reshape(1))
        m = 0
        draft_ids: List[int] = []
        emit_last_id = int(step_tok.tolist()[0])
        emit_last_lp = combined_lp[0]
        state.stats.backbone_ms += (time.perf_counter() - t0) * 1000
        t0 = time.perf_counter()
        state.stats.zero_cycles += 1
    elif is_greedy:
        if greedy_result is None:
            targets = _greedy_targets(combined_lp)  # (k+1,)
            matches = (targets[:k] == state.drafts.astype(mx.int32)).astype(mx.int32)
            m_arr = mx.cumprod(matches).sum().reshape(1)
            host_arr = mx.concatenate([m_arr, targets, state.drafts.astype(mx.int32)])
            if can_predraft:
                predrafted = _predraft(
                    gen_batch,
                    state,
                    drafter,
                    captured,
                    host_arr,
                    m_arr,
                    mx.take(targets, m_arr),
                )
            host = host_arr.tolist()
        else:
            host = greedy_result
        m = int(host[0])
        target_ids = host[1 : k + 2]
        draft_ids = host[k + 2 :]
        state.stats.backbone_ms += (time.perf_counter() - t0) * 1000
        t0 = time.perf_counter()
        emit_last_id = target_ids[m] if m < k else target_ids[k]
        emit_last_lp = combined_lp[m if m < k else k]
    else:
        # Stochastic: batched Leviathan/Chen acceptance computed in-graph —
        # per-position ratios of the filtered target rows (p) against the
        # draft sampler's filtered rows (q), cumulative accept, residual
        # samples for every position, and the bonus draw, all resolved in
        # ONE host sync (mirrors the greedy path's sync structure).
        host = stochastic_result
        if host is None:
            result = _stochastic_verify_tokens(
                sampler, combined_lp, state.drafts, state.draft_accept_lps
            )
            if can_predraft:
                m_arr = result[:1]
                anchor = mx.where(
                    m_arr < k,
                    mx.take(result[k + 1 : 2 * k + 1], mx.minimum(m_arr, k - 1)),
                    result[2 * k + 1 : 2 * k + 2],
                )
                predrafted = _predraft(
                    gen_batch, state, drafter, captured, result, m_arr, anchor
                )
            host = result.tolist()
        m = int(host[0])
        draft_ids = host[1 : k + 1]
        res_ids = host[k + 1 : 2 * k + 1]
        bonus_id = host[2 * k + 1]
        state.stats.backbone_ms += (time.perf_counter() - t0) * 1000
        t0 = time.perf_counter()
        if m < k:
            emit_last_id = res_ids[m]
            emit_last_lp = combined_lp[m]
        else:
            emit_last_id = bonus_id
            emit_last_lp = combined_lp[k]

    # Clamp the accepted count to what every cache layer can roll back
    # (optional model hook — DeepSeek-V4 PoolingCache replay windows are
    # bounded). Emitting fewer verified drafts is always correct; position
    # ``m`` was itself accepted when the clamp lowers it, so its draft
    # token is a fair emit for the correction slot.
    m_gpu = m
    clamp = getattr(gen_batch.model, "mtp_clamp_accept", None)
    if m < k:
        if callable(clamp):
            clamped = int(clamp(gen_batch.prompt_cache, m, k))
            if clamped < m:
                m = clamped
                emit_last_id = draft_ids[m]
                emit_last_lp = combined_lp[m]

    # Apply boundary alignment after the rollback clamp so its final accepted
    # count remains authoritative. If alignment itself requires more rollback,
    # re-run the model clamp against the shorter accepted prefix.
    align = int(getattr(gen_batch.model, "_omlx_mtp_commit_align", 0) or 0)
    emitted = len(gen_batch.tokens[0])
    to_boundary = ((emitted // align) + 1) * align - emitted if align > 0 else 0
    if 0 < to_boundary < m:
        m = to_boundary
        if callable(clamp):
            clamped = int(clamp(gen_batch.prompt_cache, m, k))
            if clamped < m:
                m = clamped
        emit_last_id = draft_ids[m]
        emit_last_lp = combined_lp[m]

    remaining = gen_batch.max_tokens[0] - gen_batch._num_tokens[0]
    limit = max(0, remaining - 1)
    from copy import copy

    matcher = copy(gen_batch._matchers[0])
    for j, token in enumerate(draft_ids[:m] + [emit_last_id]):
        if matcher.advance(token):
            limit = min(limit, j)
            break
    if limit < m:
        m = limit
        emit_last_id = draft_ids[m]
        emit_last_lp = combined_lp[m]

    # Rewind budget-capable processors to the last emitted position.
    # Rows 0..m produced the m+1 emitted tokens (m accepted drafts + the
    # bonus/verify correction); rows m+1..k predicted rejected drafts that
    # are re-verified next cycle, so their processor calls must be undone
    # (they would over-count the thinking budget / corrupt state). Mirrors
    # MTPProcessingSampler's position-keyed snapshot/restore on vlm_mtp.
    # Uses the FINAL m (after the model clamp and boundary alignment above).
    if m < k and row_snaps[m] is not None:
        _restore_snapshotable(procs, row_snaps[m])

    # A clamp can put the final verify token on the boundary, while a full
    # accept can put its bonus token there. Neither token is present in the
    # backbone cache yet, so materialize it before the queue reaches it.
    materialize_boundary_emit = align > 0 and to_boundary > 0 and to_boundary == m + 1
    state.boundary_emit_pending = materialize_boundary_emit

    # --- stats ---
    state.stats.cycles += 1
    if copy_cycle:
        state.stats.copy_cycles += 1
        state.stats.copy_drafted += k
        state.stats.copy_accepted += m
        state.context_copy.observe(m, k)
    else:
        if len(state.stats.depth_drafted) < state.depth:
            pad = state.depth - len(state.stats.depth_drafted)
            state.stats.depth_drafted.extend([0] * pad)
            state.stats.depth_accepted.extend([0] * pad)
        for j in range(k):
            state.stats.depth_drafted[j] += 1
            if j < m:
                state.stats.depth_accepted[j] += 1
            else:
                break
        state.stats.accepts += m
    if m < k:
        state.stats.rejects += 1
    state.stats.sample_ms += (time.perf_counter() - t0) * 1000

    accept_ms = (time.perf_counter() - cycle_t0) * 1000

    def draft_next():
        # --- MTP-head history + next draft chain (async-dispatched) ---
        t0 = time.perf_counter()
        if draft_jobs is None and not state.head_clone:
            _mtp_head_trim_to(state.mtp_cache, state.hist_offset)
        committed_ids = [int(d) for d in draft_ids[:m]] + [int(emit_last_id)]
        committed = mx.array(committed_ids, dtype=mx.uint32)
        next_main = committed[-1:]
        hidden_rows = hidden[:, : m + 1]
        prev_buf = None
        if procs is not None:
            prev_buf = gen_batch._token_context[0].tokens
        state.copy_drafts = False
        if drafter is not None and predrafted and m == m_gpu:
            drafter.adopt_predraft(state, m + 1)
        elif drafter is not None:
            if predrafted:
                drafter.discard_predraft()
            rows_hidden = [c[:, : m + 1] for c in captured]
            job = (gen_batch, state, rows_hidden, committed, prev_buf)
            if draft_jobs is None:
                drafter.draft([job])
            else:
                draft_jobs.append(job)
        elif draft_jobs is None:
            copied = _context_copy_drafts(gen_batch, state, committed_ids)
            _chain_next_drafts(
                gen_batch,
                state,
                hidden_rows,
                committed,
                prev_buf,
                depth=0 if copied else None,
            )
            if copied:
                state.drafts = mx.array(copied, dtype=mx.uint32)
                state.draft_lps = []
                # A copy is a deterministic proposer: q puts all its mass on
                # the copied token, so acceptance is p(token) and the
                # residual on rejection is p without it.
                state.draft_accept_lps = (
                    [] if is_greedy else _copy_draft_q(copied, combined_lp.shape[-1])
                )
                state.copy_drafts = True
        else:
            draft_jobs.append((gen_batch, state, hidden_rows, committed, prev_buf))
        state.next_main = next_main
        state.stats.mtp_head_ms += (time.perf_counter() - t0) * 1000

    def finish(shared_commit_ms=0.0):
        finish_t0 = time.perf_counter()
        # --- commit: queue emits + cache rollback ---
        for j in range(m):
            # Block drafters carry no draft distribution; the target row is
            # the distribution the accepted token was verified against.
            draft_lp = state.draft_lps[j] if state.draft_lps else combined_lp[j]
            state.queue.append((int(draft_ids[j]), draft_lp, "draft"))
        state.queue.append(
            (int(emit_last_id), emit_last_lp, "bonus" if m == k else "verify")
        )
        if m < k and procs is not None:
            _trim_token_buffer(gen_batch, k - m)
        # The GPU runs a chain that never reads the backbone cache while the
        # host rolls that cache back.
        draft_first = (
            drafter is None
            and draft_jobs is None
            and commit_cache is None
            and _drafts_before_commit(gen_batch.model)
        )
        if draft_first:
            draft_next()
        t0 = time.perf_counter()
        if commit_cache is not None:
            gen_batch.prompt_cache = commit_cache(m)
        elif m == k and gdn_states is None:
            _clear_rollback(gen_batch.prompt_cache)
        elif not _chain_rollback(
            gen_batch.model, gen_batch.prompt_cache, m, k, gdn_states
        ):
            raise _MtpStepFallback("cache layer rejects chain rollback")
        state.stats.cache_ops_ms += (time.perf_counter() - t0) * 1000 + shared_commit_ms
        if not draft_first:
            draft_next()
        if materialize_boundary_emit:
            _materialize_mtp_boundary_emit(gen_batch, state)
            state.boundary_emit_pending = False
        untimed, state.copy_untimed = state.copy_untimed, False
        if state.controller is not None and not copy_cycle:
            was_warmup = bool(state.controller._warmup)
            keepalive = bool(getattr(state.mtp_cache, "fold_keepalive", False))
            if keepalive:
                state.mtp_cache.fold_keepalive = False
            state.controller.observe(
                k,
                m,
                accept_ms
                + (time.perf_counter() - finish_t0) * 1000
                + verify_ms
                + shared_commit_ms,
                time_sample=not keepalive and not untimed,
            )
            _maybe_finish_mtp_reentry_probe(
                gen_batch,
                state,
                was_warmup=was_warmup,
            )

    if defer_commit:
        return m, finish
    finish()


def _materialize_mtp_boundary_emit(gen_batch: Any, state: _MtpState) -> None:
    """Commit a queued verify/bonus boundary token before it is emitted.

    MTP normally leaves the final token of a cycle one position ahead of the
    backbone cache. If that token is the next block boundary, process it with a
    confirmed one-token forward and seed the following target token. The queue
    then reaches the boundary with an exactly aligned cache snapshot and keeps
    the usual one-token pipeline skew after the following token is emitted.
    """
    import time

    import mlx.core as mx

    if not state.queue:
        raise _MtpStepFallback("boundary materialization has no queued token")

    boundary_id = int(state.queue[-1][0])
    boundary_tok = mx.array([boundary_id], dtype=mx.uint32)
    procs = _proc_list(gen_batch)
    prev_buf = None
    if procs is not None:
        prev_buf = gen_batch._token_context[0].update_and_fetch(boundary_tok)

    t0 = time.perf_counter()
    drafter = _drafter_for(gen_batch.model)
    logits, hidden, _, captured = _call_backbone_captured(
        gen_batch.model,
        boundary_tok[:, None],
        gen_batch.prompt_cache,
        capture_layer_ids=_drafter_capture_ids(gen_batch.model),
    )
    _clear_rollback(gen_batch.prompt_cache)
    next_logits = _apply_processors(procs, prev_buf, logits[:, -1, :])
    next_lp_2d = _logprobs(next_logits)
    next_tok = _ensure_uint32(_resolve_sampler(gen_batch)(next_lp_2d))
    mx.eval(next_tok)
    state.stats.backbone_ms += (time.perf_counter() - t0) * 1000

    # The drafts below replace any copied window.
    state.copy_drafts = False
    t0 = time.perf_counter()
    if drafter is not None:
        drafter.draft([(gen_batch, state, captured, next_tok, prev_buf)])
    else:
        _chain_next_drafts(
            gen_batch,
            state,
            hidden[:, -1:],
            next_tok,
            prev_buf,
        )
    state.stats.mtp_head_ms += (time.perf_counter() - t0) * 1000
    next_id = int(next_tok.tolist()[0])
    state.next_main = next_tok
    state.queue.append((next_id, next_lp_2d.squeeze(0), "bonus"))


def _chain_rollback(
    model: Any,
    prompt_cache: List[Any],
    accepted: int,
    num_drafts: int,
    gdn_states: Optional[list] = None,
) -> bool:
    """Roll the backbone cache back to ``accepted`` drafts after a chain verify.

    mlx-vlm path (``gdn_states`` populated): delegate to the stock
    ``rollback_speculative_cache``, which natively supports partial accepts —
    it keeps ``accepted + 1`` positions of the ``num_drafts + 1``-token
    verify window and replays the accepted prefix through the captured GDN
    states. mlx-lm path: ``mtp_partial_rollback`` (qwen35_model patch).
    """
    if gdn_states is not None and hasattr(model, "rollback_speculative_cache"):
        try:
            model.rollback_speculative_cache(
                prompt_cache, gdn_states, accepted, num_drafts + 1
            )
            return True
        except Exception as exc:
            logger.debug("rollback_speculative_cache failed: %s", exc, exc_info=True)
            return False
    # VLM adapters keep the rollback hook on the inner language model.
    rollback = None
    for candidate in (
        model,
        getattr(model, "language_model", None),
        getattr(model, "_language_model", None),
    ):
        rollback = getattr(candidate, "mtp_partial_rollback", None)
        if callable(rollback):
            break
    if callable(rollback):
        try:
            return bool(rollback(prompt_cache, accepted, num_drafts))
        except Exception as exc:
            logger.debug("mtp_partial_rollback failed: %s", exc)
            return False
    if accepted == 0 and num_drafts == 1:
        return _restore_or_trim_caches(prompt_cache)
    return False


def _run_verify_cycle_legacy(gen_batch: Any, state: _MtpState) -> None:
    """Run one verify cycle. Populates ``state.queue`` with 1 (reject) or 2
    (accept) tokens for upcoming emit calls. Updates ``state.next_main`` and
    ``state.draft_tok`` / ``state.draft_lp`` for the cycle after that.
    """
    import time

    import mlx.core as mx

    if state.next_main is None or state.draft_tok is None:
        raise _MtpStepFallback("verify cycle entered without next_main / draft")

    sampler = _resolve_sampler(gen_batch)
    procs = _proc_list(gen_batch)
    is_greedy = _is_greedy(gen_batch)

    inputs = mx.concatenate([state.next_main, state.draft_tok])  # (2,)

    # Update the token buffer per-position (mirrors PR 990 _step_backbone).
    prev_main = None
    prev_draft = None
    if procs is not None:
        prev_main = gen_batch._token_context[0].update_and_fetch(state.next_main)
        prev_draft = gen_batch._token_context[0].update_and_fetch(state.draft_tok)

    # --- backbone forward (materialized before sampling) ---
    # Dispatch the backbone on the generation stream, then force ``mx.eval``
    # on the logits before the sampler runs. MLX is lazy, so without this the
    # later ``mx.eval(verify_tok, bonus_tok)`` barrier would resolve the whole
    # graph in one stall and the heavy verify forward would leak into
    # sample_ms (this is what made the sampler look like the bottleneck in
    # #1097 / #1311 / #1330). The extra eval costs one CPU<->GPU round-trip
    # per cycle (negligible vs the forward compute) and keeps the
    # backbone_ms / sample_ms split accurate.
    t0 = time.perf_counter()
    logits, hidden, gdn_states = _call_backbone(
        gen_batch.model,
        inputs[None, :],
        gen_batch.prompt_cache,
        n_confirmed=1,
    )
    verify_logits = logits[:, 0, :]
    bonus_logits = logits[:, 1, :]
    mx.eval(logits)
    state.stats.backbone_ms += (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    verify_snap = None
    if procs is not None:
        verify_logits = _apply_processors(procs, prev_main, verify_logits)
        # Checkpoint after the verify row: it produced the one token that is
        # ALWAYS emitted (draft on accept, verify correction on reject).
        verify_snap = _snap_snapshotable(procs)
        bonus_logits = _apply_processors(procs, prev_draft, bonus_logits)
    # Batched logprobs: one logsumexp over (2, vocab) instead of two over
    # (1, vocab). Shaves one reduction per cycle on the vocab dimension.
    combined_logits = mx.concatenate(
        [verify_logits, bonus_logits], axis=0
    )  # (2, vocab)
    combined_lp = combined_logits - mx.logsumexp(
        combined_logits, axis=-1, keepdims=True
    )
    verify_lp_2d = combined_lp[0:1]
    bonus_lp_2d = combined_lp[1:2]
    verify_tok = sampler(verify_lp_2d)
    bonus_tok = sampler(bonus_lp_2d)
    mx.eval(verify_tok, bonus_tok)

    # ``draft_id`` was cached when the draft was sampled (post_init or the
    # prior _step_mtp); skip the GPU→CPU sync that ``state.draft_tok.tolist()``
    # would impose on every cycle.
    draft_id = state.draft_id
    verify_id = int(verify_tok.tolist()[0])
    bonus_id = int(bonus_tok.tolist()[0])

    # Filtered logprobs — distribution the sampler actually drew from.
    # Used for acceptance ratio + residual sampling so they match the
    # sampling distribution rather than raw softmax (PR 990 alignment).
    verify_accept_lp = _accept_lp_for(sampler, verify_lp_2d)
    draft_accept_lp = (
        state.draft_accept_lp
        if state.draft_accept_lp is not None
        else _accept_lp_for(sampler, state.draft_lp)
    )

    if is_greedy:
        accept = verify_id == draft_id
    else:
        log_accept = (
            verify_accept_lp[0, draft_id].item() - draft_accept_lp[draft_id].item()
        )
        # Draw the acceptance roll from mx.random so it follows the same
        # mx.random.seed the rest of the sampler uses (line ~962 residual
        # sampling). stdlib ``random`` was never seeded by oMLX, which made
        # stochastic acceptance irreproducible even with a fixed seed (#1330).
        accept = log_accept >= 0 or float(
            mx.random.uniform(shape=()).item()
        ) < math.exp(log_accept)
    state.stats.sample_ms += (time.perf_counter() - t0) * 1000

    hidden_at_confirmed = hidden[:, 0:1, :]
    hidden_at_draft = hidden[:, 1:2, :]

    state.stats.cycles += 1
    if accept:
        state.stats.accepts += 1
        # --- cache cleanup (timed) ---
        t0 = time.perf_counter()
        if gdn_states is not None:
            gen_batch.model.rollback_speculative_cache(
                gen_batch.prompt_cache, gdn_states, 1, 2
            )
        _clear_rollback(gen_batch.prompt_cache)
        state.stats.cache_ops_ms += (time.perf_counter() - t0) * 1000

        # --- MTP head forward for next draft (timed inside _step_mtp) ---
        new_draft, new_draft_lp = _step_mtp(
            gen_batch,
            hidden_at_draft,
            _ensure_uint32(bonus_tok),
            prev_buf=prev_draft if procs is not None else None,
            stats=state.stats,
        )
        # Queue the two emitted tokens. Per PR 990: the accepted draft uses
        # the *MTP head's* original draft distribution as its logprobs; the
        # bonus uses the verify forward's bonus distribution.
        state.queue.append((draft_id, state.draft_lp, "draft"))
        state.queue.append((bonus_id, bonus_lp_2d.squeeze(0), "bonus"))
        state.next_main = _ensure_uint32(bonus_tok)
        state.draft_tok = new_draft
        state.draft_lp = new_draft_lp
        return

    # Reject path.
    state.stats.rejects += 1
    t0 = time.perf_counter()
    # The bonus row's processor call was speculative (its token is not
    # emitted on reject) — rewind to the verify-row checkpoint. Mirrors the
    # chain cycle's restore-on-partial-accept.
    if procs is not None and verify_snap is not None:
        _restore_snapshotable(procs, verify_snap)
    # accepted=0 means only the confirmed token (verify position) is kept;
    # block_size=2 covers both the confirmed and the rejected draft.
    if not _rollback_after_reject(
        gen_batch.model,
        gen_batch.prompt_cache,
        gdn_states,
        accepted=0,
        block_size=2,
    ):
        if procs is not None:
            _trim_token_buffer(gen_batch, 1)
        raise _MtpStepFallback("cache layer rejects rollback")
    if procs is not None:
        _trim_token_buffer(gen_batch, 1)
    state.stats.cache_ops_ms += (time.perf_counter() - t0) * 1000

    # Pick the verify-position emit token: residual sample for stochastic.
    # Residual is computed on the *filtered* distributions so the sample
    # comes from `max(p_target_filt - p_draft_filt, 0)` — matching what the
    # sampler would have produced if it had drawn directly from the verify
    # position. emit_lp returned to the caller stays as the raw verify lp
    # so downstream logprobs reporting is consistent with non-MTP paths.
    if is_greedy:
        emit_id = verify_id
        emit_lp = verify_lp_2d.squeeze(0)
    else:
        emit_id, _ = _residual_sample(verify_accept_lp, draft_accept_lp)
        emit_lp = verify_lp_2d.squeeze(0)

    emit_tok = mx.array([emit_id], dtype=mx.uint32)
    new_draft, new_draft_lp = _step_mtp(
        gen_batch,
        hidden_at_confirmed,
        emit_tok,
        prev_buf=prev_main if procs is not None else None,
        stats=state.stats,
    )

    state.queue.append((emit_id, emit_lp, "verify"))
    state.next_main = emit_tok
    state.draft_tok = new_draft
    state.draft_lp = new_draft_lp


# ---------------------------------------------------------------------------
# Helpers used by the verify cycle.
# ---------------------------------------------------------------------------


def _step_mtp(
    gen_batch: Any,
    hidden_at_position: Any,
    next_main_tok: Any,
    prev_buf: Optional[Any],
    stats: Optional["_MtpStats"] = None,
) -> Tuple[Any, Any]:
    """Run one MTP-head forward + sample. Returns ``(draft_tok, draft_lp)``.

    Side effect: caches the host-side int copy of the new draft on
    ``gen_batch._omlx_mtp_state.draft_id`` so the next verify cycle's
    accept check is sync-free.
    """
    import time

    import mlx.core as mx

    state = gen_batch._omlx_mtp_state
    sampler = _resolve_sampler(gen_batch)
    procs = _proc_list(gen_batch)

    t0 = time.perf_counter()
    next_ids = next_main_tok.reshape(1, 1)
    mtp_logits = gen_batch.model.mtp_forward(
        hidden_at_position, next_ids, state.mtp_cache
    )
    mtp_logits_2d = mtp_logits[:, -1, :]
    # The draft is speculative — shape it but do not advance the budget.
    snap = _snap_snapshotable(procs)
    if procs is not None and prev_buf is not None:
        prev_with_next = mx.concatenate([prev_buf, _ensure_uint32(next_main_tok)])
        mtp_logits_2d = _apply_processors(procs, prev_with_next, mtp_logits_2d)
    _restore_snapshotable(procs, snap)
    new_lp = _logprobs(mtp_logits_2d)
    new_tok = sampler(new_lp)
    # Filtered draft lp — what the sampler actually drew from. The next
    # verify cycle's acceptance ratio uses this so the math matches the
    # sampling distribution rather than raw softmax (PR 990 alignment).
    new_accept_lp = _accept_lp_for(sampler, new_lp)
    # ``.tolist()`` forces evaluation; replaces the explicit ``mx.eval`` and
    # piggybacks the host-side int caching on the same sync.
    draft_id_int = int(new_tok.tolist()[0])
    state.draft_id = draft_id_int
    state.draft_accept_lp = new_accept_lp.squeeze(0)
    if stats is not None:
        stats.mtp_head_ms += (time.perf_counter() - t0) * 1000
    return _ensure_uint32(new_tok), new_lp.squeeze(0)


def _residual_sample(verify_lp_2d: Any, draft_lp_1d: Any) -> Tuple[int, Any]:
    """Sample from ``max(p_target - p_draft, 0)`` (Leviathan et al. 2022).

    On degenerate input (residual all zero) falls back to the target
    distribution rather than the verify-position argmax — keeps the sample
    drawn from a proper distribution and stays in-graph (no host sync).
    Mirrors mlx-lm PR 990 commit 6594348.

    Returns ``(token_id_int, verify_lp_1d)``.
    """
    import mlx.core as mx

    p_target = mx.exp(verify_lp_2d.squeeze(0))
    p_draft = mx.exp(draft_lp_1d)
    residual = mx.maximum(p_target - p_draft, 0.0)
    # Keep z in graph; mx.where switches to the target distribution when
    # the residual mass is zero. ``categorical`` treats log(0) = -inf as
    # p=0 so no safety epsilon is needed.
    z = residual.sum(keepdims=True)
    dist = mx.where(z > 0, residual, p_target)
    sample = mx.random.categorical(mx.log(dist).reshape(1, -1))
    return int(sample.item()), verify_lp_2d.squeeze(0)


# ---------------------------------------------------------------------------
# Response builder — mirrors GenerationBatch.next()'s per-sequence epilogue.
# ---------------------------------------------------------------------------


def _emit_response(
    gen_batch: Any,
    token_id: int,
    logprobs_1d: Any,
    stats: Optional["_MtpStats"] = None,
) -> List[Any]:
    """Produce a single-element response list, applying the standard
    epilogue (token append + max_tokens / matcher checks) so external
    callers (BatchGenerator, scheduler, response stream) see the same
    contract as the unmodified next().
    """
    Response = type(gen_batch).Response

    finish_reason: Optional[str] = None

    gen_batch.tokens[0].append(token_id)
    gen_batch._num_tokens[0] += 1
    if gen_batch._num_tokens[0] >= gen_batch.max_tokens[0]:
        finish_reason = "length"

    if gen_batch._matchers[0].advance(token_id):
        finish_reason = "stop"

    if finish_reason is not None:
        prompt_cache = gen_batch.extract_cache(0)
        all_tokens = gen_batch.tokens[0]
        response = Response(
            uid=gen_batch.uids[0],
            token=token_id,
            logprobs=logprobs_1d,
            finish_reason=finish_reason,
            prompt_cache=prompt_cache,
            all_tokens=all_tokens,
        )
        if stats is not None:
            _log_mtp_stats(gen_batch.uids[0], stats, finish_reason)
        # Drop state *before* filter([]) so the patched_filter epilogue
        # doesn't double-log when the standard finish path already logged.
        if hasattr(gen_batch, "_omlx_mtp_state"):
            try:
                delattr(gen_batch, "_omlx_mtp_state")
            except AttributeError:
                pass
        gen_batch.filter([])
        return [response]

    return [
        Response(
            uid=gen_batch.uids[0],
            token=token_id,
            logprobs=logprobs_1d,
            finish_reason=None,
            prompt_cache=None,
            all_tokens=None,
        )
    ]
