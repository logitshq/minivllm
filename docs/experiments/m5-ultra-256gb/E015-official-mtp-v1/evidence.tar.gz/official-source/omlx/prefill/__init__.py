"""Resumable text prefill helpers."""
