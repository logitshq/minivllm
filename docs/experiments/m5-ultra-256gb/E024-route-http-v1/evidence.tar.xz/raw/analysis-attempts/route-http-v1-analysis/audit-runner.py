"""Offline audits of one CLOSED E024 route HTTP v1 cycle; default describes only.

No service/controller/owner execution. --run invokes only the already registered
restoration, recorded-numerical and cycle auditors. New output directory only;
failures/timeouts and unavailable replay plans remain explicit, never fabricated
independent audit results. Repeat with --analysis ...-analysis-repeat-N.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/Users/ryanli/code/minivllm')
ART = ROOT / '.artifacts/m5-ultra-256gb'
NAME = 'route-http-v1'
SOURCE = ROOT / 'bench/m5_ultra_256gb/route_http_cycle'
ROUTE = SOURCE.parent / 'route_decode_graph'
PREREG = SOURCE / 'prereg-http-v1'
OWNER = ART / (NAME + '-owner')
JOURNAL = ART / (NAME + '-cold-journal')
EXECUTION = ART / (NAME + '-execution')
DEFAULT_ANALYSIS = ART / (NAME + '-analysis')
PYTHON = ROOT / '.venv/bin/python'
PHASES = ['c1-capture', 'c1-replay', 'c8-capture', 'c8-replay']


def need(ok, message):
    if not ok: raise ValueError(message)


def read(path):
    def pairs(items):
        out = {}
        for k, v in items:
            need(k not in out, 'duplicate JSON key'); out[k] = v
        return out
    def invalid(value): raise ValueError('nonfinite JSON: ' + value)
    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs, parse_constant=invalid)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while chunk := stream.read(1 << 20): digest.update(chunk)
    return digest.hexdigest()


def ref(path): return dict(path=str(path), sha256=sha(path))
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def analysis_path(path):
    path = Path(path).absolute()
    need(path.parent == ART and re.fullmatch(NAME + r'-analysis(?:-repeat-[1-9][0-9]*)?', path.name)
         and not path.exists(), 'fresh exact cycle analysis or analysis-repeat-N directory required')
    return path


def run(args):
    out = analysis_path(args.analysis)
    final = read(EXECUTION / 'final.json'); journal = read(JOURNAL / 'journal.json')
    receipt = read(PREREG / 'receipt.json'); plan = read(PREREG / 'owner-plan.json')
    need(journal['schema'] == 'E024-route-http-cold-journal-v1'
         and journal['state'] == final['journal_state'] == 'RESTORED'
         and type(final['recovery_returncode']) is int and final['recovery_returncode'] == 0,
         'actual final RESTORED and recovery rc0 required before any audit')
    pins = receipt['source_pins']; plan_sha = receipt['owner_plan_sha256']
    need(receipt['schema'] == 'route-http-execution-receipt-v1'
         and type(pins) is dict and type(receipt['source_count']) is int and len(pins) == receipt['source_count']
         and pins == read(PREREG / 'source-manifest.json')['source_pins']
         and plan['schema'] == 'E024-route-http-owner-plan-v1'
         and sha(PREREG / 'owner-plan.json') == plan_sha == journal['owner_plan']['sha256']
         and journal['owner_directory'] == str(OWNER), 'registered actual cycle binding')
    need(sha(EXECUTION / 'execution-receipt.json') == sha(PREREG / 'receipt.json')
         and sha(EXECUTION / 'prepared-journal.json') == receipt['prepared_journal_sha256'], 'actual execution receipt')
    for p in (SOURCE/'audit_restore.py', SOURCE/'audit_cycle.py', ROUTE/'http_audit_v2.py'):
        need(str(p) in pins, 'auditor must have been registered before this cycle')
    for p, h in pins.items():
        path = Path(p)
        need(path.is_absolute() and path.is_relative_to(ROOT) and not path.is_symlink()
             and path.is_file() and path.stat().st_size < 32*(1 << 20), 'small registered source only')
        need(sha(path) == h, 'registered source changed: ' + p)
    stable = {p:sha(p) for p in (EXECUTION/'final.json', JOURNAL/'journal.json', PREREG/'receipt.json')}
    complete = read(OWNER/'complete.json') if OWNER.exists() else None
    if complete is not None:
        need(complete['schema'] == 'E024-route-http-owner-result-v1' and complete['status'] in ('PASS','FAIL')
             and complete['owner_plan_sha256'] == plan_sha, 'owner must be terminal')
        stable[OWNER/'complete.json'] = sha(OWNER/'complete.json')
        if complete['status'] == 'PASS':
            need([row['phase'] for row in complete['phases']] == PHASES
                 and complete['all_children_reaped'] is complete['numerical_replay_complete'] is True
                 and final['owner_returncode'] == 0, 'successful owner requires complete four-phase close')
    out.mkdir()
    (out/'audit-runner.py').write_bytes(Path(__file__).read_bytes())
    summary = dict(schema='E024-route-http-closed-audit-execution-v1', started_at=now(),
        source_only_runner=False, owner_directory=str(OWNER), journal_directory=str(JOURNAL),
        owner_plan_sha256=plan_sha, execution_receipt=ref(PREREG/'receipt.json'),
        journal_sha256=stable[JOURNAL/'journal.json'], owner_status=complete['status'] if complete else 'NOT_STARTED',
        registered_source_pins=pins, runner_sha256=sha(out/'audit-runner.py'), jobs={},
        qualified=False, performance_qualified=False)
    save(out/'binding.json', {k:v for k,v in summary.items() if k != 'jobs'})

    def attempt(name, script, arguments, result_name):
        target = out/result_name
        command = [str(PYTHON), '-I', '-B', str(script), *arguments, '--out', str(target)]
        row = dict(argv=command, cwd=str(ROOT), started_at=now(), timeout_seconds=args.timeout_seconds,
                   source=ref(script), result_path=str(target), execution_status='STARTED')
        save(out/(name+'-command.json'), row)
        start = time.monotonic()
        try:
            with (out/(name+'.stdout')).open('xb') as stdout, (out/(name+'.stderr')).open('xb') as stderr:
                result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr,
                                        timeout=args.timeout_seconds, check=False)
            row.update(execution_status='RETURNED', returncode=result.returncode)
        except Exception as exc:
            row.update(execution_status='ERROR', error=dict(type=type(exc).__name__, message=str(exc)))
        finally:
            row.update(finished_at=now(), elapsed_seconds=time.monotonic()-start)
            if target.is_file():
                row['result_sha256'] = sha(target)
                try:
                    value = read(target); row['audit_status'] = value.get('status'); row['result_schema'] = value.get('schema')
                except Exception as exc:
                    row['invalid_result'] = dict(type=type(exc).__name__, message=str(exc))
            save(out/(name+'-execution.json'), row); summary['jobs'][name] = row
        return row

    def skip(name, reason):
        row = dict(execution_status='NOT_RUN', reason=reason, time=now(), qualified=False)
        save(out/(name+'-execution.json'), row); summary['jobs'][name] = row

    try:
        restored = attempt('restoration', SOURCE/'audit_restore.py', ['--journal',str(JOURNAL)], 'restoration-audit.json')
        if restored.get('returncode') != 0 or restored.get('audit_status') != 'PASS':
            for name in ('c1-numerical','c8-numerical','cycle'):
                skip(name, 'Independent restoration did not PASS; no closed-history qualification attempted.')
        else:
            for C in (1,8):
                folder = OWNER/'phases'/f'c{C}-replay'; path = folder/'plan.json'; child = folder/'qualification'
                if not path.is_file():
                    skip(f'c{C}-numerical', 'No actual replay plan was produced; no substituted plan/hash or fake audit receipt.')
                    continue
                attempt(f'c{C}-numerical', ROUTE/'http_audit_v2.py',
                        ['--child',str(child),'--plan-sha256',sha(path)], f'c{C}-independent-numerical.json')
            results = [out/f'c{C}-independent-numerical.json' for C in (1,8)]
            if all(p.is_file() for p in results):
                argv = ['--owner',str(OWNER),'--journal',str(JOURNAL),'--plan-sha256',plan_sha]
                for C,p in zip((1,8),results): argv += [f'--c{C}-audit',str(p),f'--c{C}-audit-sha256',sha(p)]
                attempt('cycle', SOURCE/'audit_cycle.py', argv, 'independent-cycle.json')
            else:
                skip('cycle', 'One or both independent numerical audit files do not exist; no placeholder audit input.')
        summary['sources_unchanged'] = all(sha(p) == h for p,h in pins.items())
        summary['terminal_files_unchanged'] = all(sha(p) == h for p,h in stable.items())
        need(summary['sources_unchanged'] and summary['terminal_files_unchanged'], 'sources/closed evidence changed during audit')
        summary['qualified'] = all(summary['jobs'][k].get('returncode') == 0
            and summary['jobs'][k].get('audit_status') == 'PASS' for k in ('restoration','c1-numerical','c8-numerical','cycle'))
    except BaseException as exc:
        summary['runner_error'] = dict(type=type(exc).__name__, message=str(exc))
        raise
    finally:
        summary['finished_at'] = now(); save(out/'execution-summary.json',summary)
    print(json.dumps(dict(analysis=str(out), qualified=summary['qualified'],
        jobs={k:v.get('audit_status',v['execution_status']) for k,v in summary['jobs'].items()})))
    return 0 if summary['qualified'] else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true')
    parser.add_argument('--analysis',type=Path,default=DEFAULT_ANALYSIS)
    parser.add_argument('--timeout-seconds',type=int,default=1800,choices=range(1,3601))
    args = parser.parse_args()
    if args.run: raise SystemExit(run(args))
    print('DESCRIPTION_ONLY: after actual RESTORED/recovery rc0, --run records restoration -> C1/C8 recorded replay audits -> cycle audit. No service/GPU operation; no action performed.')
