"""Package CLOSED E024 route HTTP v1 evidence; default describes, --run writes.

Independent restoration PASS is mandatory even for a failed experiment. Numerical
and cycle audit failures/NOT_RUN remain unqualified. This is retention/hash
verification, not a replacement numerical/resource auditor. It never imports a
producer, opens model/runtime payloads, queries a process, or touches a service.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile

ROOT = Path('/Users/ryanli/code/minivllm')
ART = ROOT/'.artifacts/m5-ultra-256gb'
NAME = 'route-http-v1'
SOURCE = ROOT/'bench/m5_ultra_256gb/route_http_cycle'
ROUTE = SOURCE.parent/'route_decode_graph'
PREREG = SOURCE/'prereg-http-v1'
OUT = ROOT/'docs/experiments/m5-ultra-256gb/E024-route-http-v1'
PHASES = ['c1-capture','c1-replay','c8-capture','c8-replay']
BINARY_SUFFIXES = ('.safetensors','.dylib','.so','.pack','.bin','.metallib')
SCHEMAS = {'restoration':'cold-service-restoration-audit-v1',
           'numerical':'E024-recorded-route-http-independent-audit-v2',
           'cycle':'E024-route-http-cycle-independent-audit-v1'}


def need(ok, message):
    if not ok: raise ValueError(message)


def read(path):
    def pairs(items):
        value = {}
        for k,v in items:
            need(k not in value,'duplicate JSON key'); value[k] = v
        return value
    def invalid(value): raise ValueError('nonfinite JSON: '+value)
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=invalid)


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def info(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(),'regular evidence file required: '+str(path))
    key = lambda s: (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    before = path.stat(); digest = hashlib.sha256(); size = 0
    with path.open('rb') as stream:
        need(key(os.fstat(stream.fileno())) == key(before),'replaced before read')
        while chunk := stream.read(1 << 20): digest.update(chunk); size += len(chunk)
        need(key(os.fstat(stream.fileno())) == key(before),'open file changed')
    need(key(path.stat()) == key(before) and size == before.st_size,'file changed after read')
    return dict(sha256=digest.hexdigest(),bytes=size)


def sha(path): return info(path)['sha256']


def listing(root, failure_arrays):
    need(root.is_dir() and not root.is_symlink(),'real evidence tree required: '+str(root))
    files = []
    for folder, dirs, names in os.walk(root,followlinks=False):
        for name in sorted(dirs+names):
            path = Path(folder)/name
            need(not path.is_symlink(),'unexpected evidence/model symlink: '+str(path))
            if path.is_file():
                need(not path.name.endswith(BINARY_SUFFIXES) or path in failure_arrays,
                     'unexpected model/runtime payload: '+str(path))
                files.append(path)
            else: need(path.is_dir(),'special evidence entry: '+str(path))
    return sorted(files)


def archive(analysis):
    analysis = Path(analysis).absolute()
    need(analysis.parent == ART and re.fullmatch(NAME+r'-analysis(?:-repeat-[1-9][0-9]*)?',analysis.name),
         'exact selected analysis directory')
    need(not OUT.exists() and OUT.parent.is_dir(),'fresh archive output required')
    owner,cold,execution,cpu = [ART/(NAME+'-'+k) for k in ('owner','cold-journal','execution','cpu-prepare')]
    final = read(execution/'final.json'); journal = read(cold/'journal.json')
    plan = read(PREREG/'owner-plan.json'); receipt = read(PREREG/'receipt.json')
    pins = receipt['source_pins']; plan_sha = sha(PREREG/'owner-plan.json')
    need(receipt['schema'] == 'route-http-execution-receipt-v1' and type(pins) is dict
         and type(receipt['source_count']) is int and len(pins) == receipt['source_count']
         and pins == read(PREREG/'source-manifest.json')['source_pins']
         and read(PREREG/'source-manifest.json')['schema'] == 'route-http-registered-small-source-v1',
         'actual dynamic registered-source inventory')
    need(plan['schema'] == 'E024-route-http-owner-plan-v1' and plan_sha == receipt['owner_plan_sha256']
         and journal['owner_plan']['sha256'] == plan_sha and journal['owner_directory'] == str(owner),
         'actual registered owner plan/journal')
    need(journal['schema'] == 'E024-route-http-cold-journal-v1' and journal['state'] == final['journal_state'] == 'RESTORED'
         and type(final['recovery_returncode']) is int and final['recovery_returncode'] == 0,
         'terminal actual restoration required; live evidence cannot be packaged')
    need(info(execution/'execution-receipt.json') == info(PREREG/'receipt.json')
         and sha(execution/'prepared-journal.json') == receipt['prepared_journal_sha256']
         and sha(PREREG/'prepared-journal.json') == receipt['prepared_journal_sha256'], 'executed registration identity')
    for source,digest in pins.items():
        path = Path(source)
        need(path.is_absolute() and path.is_relative_to(ROOT) and path.resolve() == path
             and not path.name.endswith(BINARY_SUFFIXES) and path.stat().st_size < 32*(1 << 20), 'small canonical registered source')
        need(sha(path) == digest,'registered source changed: '+source)
        copy = PREREG/'frozen-source'/source.lstrip('/')
        need(info(copy) == info(path),'registered frozen source differs: '+source)
    restore = read(analysis/'restoration-audit.json'); run = read(analysis/'execution-summary.json')
    need(run['schema'] == 'E024-route-http-closed-audit-execution-v1' and run['owner_directory'] == str(owner)
         and run['journal_directory'] == str(cold) and run['owner_plan_sha256'] == plan_sha
         and run['registered_source_pins'] == pins and run['journal_sha256'] == sha(cold/'journal.json')
         and run['sources_unchanged'] is run['terminal_files_unchanged'] is True
         and run['performance_qualified'] is False and 'runner_error' not in run, 'closed actual offline audit execution')
    need(restore['schema'] == SCHEMAS['restoration'] and restore['status'] == 'PASS' and restore['qualified'] is True
         and restore['numerical_qualified'] is restore['performance_qualified'] is False
         and restore['journal_sha256'] == sha(cold/'journal.json') and restore['owner_plan_sha256'] == plan_sha
         and restore['audit_source_sha256'] == pins[str(SOURCE/'audit_restore.py')]
         and restore['controller_sha256'] == pins[str(SOURCE/'controller.py')]
         and restore['service_restore']['replacement'] == journal['replacement'], 'independent bound restoration PASS')
    jobs = run['jobs']; need(set(jobs) == {'restoration','c1-numerical','c8-numerical','cycle'},'all four audit attempts accounted for')
    audits = {}
    expected_jobs = {'restoration':('restoration-audit.json',SOURCE/'audit_restore.py'),
                     'c1-numerical':('c1-independent-numerical.json',ROUTE/'http_audit_v2.py'),
                     'c8-numerical':('c8-independent-numerical.json',ROUTE/'http_audit_v2.py'),
                     'cycle':('independent-cycle.json',SOURCE/'audit_cycle.py')}
    for name,(filename,source) in expected_jobs.items():
        row = jobs[name]; target = analysis/filename
        need(read(analysis/(name+'-execution.json')) == row,'audit attempt/summary mismatch')
        if row['execution_status'] == 'NOT_RUN':
            need(not target.exists() and row['qualified'] is False,'skipped audit must not fabricate a result')
            audits[name] = None; continue
        need(row['execution_status'] in ('RETURNED','ERROR') and row['source'] == dict(path=str(source),sha256=pins[str(source)])
             and row['cwd'] == str(ROOT) and row['result_path'] == str(target)
             and row['argv'][:4] == [str(ROOT/'.venv/bin/python'),'-I','-B',str(source)]
             and row['argv'][-2:] == ['--out',str(target)],'actual registered offline audit invocation')
        if target.exists():
            need(row['result_sha256'] == sha(target),'actual audit output digest')
            value = read(target)
            kind = 'numerical' if name.endswith('-numerical') else name
            need(value['schema'] == SCHEMAS[kind] and value['status'] in ('PASS','FAIL','INCOMPLETE') and row['audit_status'] == value['status']
                 and value['audit_source_sha256'] == pins[str(source)] and value['performance_qualified'] is False,
                 'actual audit source/status/scope')
            if value['status'] == 'PASS': need(row.get('returncode') == 0,'PASS requires auditor rc0')
            audits[name] = value
        else:
            need(row['execution_status'] == 'ERROR' or row.get('returncode') != 0,'missing successful audit output')
            audits[name] = None
    need(audits['restoration'] == restore and jobs['restoration'].get('returncode') == 0,'restoration audit really returned PASS')
    complete = read(owner/'complete.json') if owner.exists() else None
    if complete is not None:
        need(complete['schema'] == 'E024-route-http-owner-result-v1' and complete['status'] in ('PASS','FAIL')
             and complete['owner_plan_sha256'] == plan_sha and complete['independently_qualified'] is False
             and complete['performance_qualified'] is False and restore['owner_reap']['owner_status'] == complete['status'],
             'closed actual owner status, including failures')
        if (owner/'owner-plan.json').exists(): need(sha(owner/'owner-plan.json') == plan_sha,'saved owner plan')
        children = read(owner/'children.json')['children'] if (owner/'children.json').exists() else []
        need([r['phase'] for r in children] == PHASES[:len(children)],'closed actual direct-child prefix')
        need(restore['owner_reap']['status'] in ('ALL_OBSERVED_CHILDREN_REAPED','NO_CHILD_STARTED'), 'all observed children independently closed')
        if complete['status'] == 'PASS':
            need(len(children) == 4 and [r['phase'] for r in complete['phases']] == PHASES
                 and complete['all_children_reaped'] is complete['numerical_replay_complete'] is True
                 and final['owner_returncode'] == 0, 'PASS needs four phases, not a partial prefix')
    else:
        children = []
        need(restore['owner_reap']['status'] == 'NO_EXPERIMENT' and journal['reap'] == {'no_experiment':True},
             'missing owner requires independent NO_EXPERIMENT closure')
    # Selected attempt can qualify only if all independent gates actually PASS.
    eligible = complete is not None and complete['status'] == 'PASS' and all(
        audits[k] is not None and audits[k]['status'] == 'PASS' and audits[k]['qualified'] is True
        for k in ('c1-numerical','c8-numerical','cycle'))
    need(run['qualified'] is eligible,'audit execution summary cannot grant a missing gate')
    cycle = audits['cycle']
    if cycle and cycle['status'] == 'PASS':
        need(eligible and cycle['schema'] == SCHEMAS['cycle'] and cycle['http_history_qualified'] is True
             and cycle['independent_resource_verified'] is cycle['restoration_verified'] is True
             and cycle['owner_directory'] == str(owner) and cycle['owner_plan_sha256'] == plan_sha
             and cycle['owner_complete_sha256'] == sha(owner/'complete.json')
             and cycle['journal_sha256'] == sha(cold/'journal.json') and cycle['restoration'] == restore,
             'independent cycle PASS terminal/resource/restoration binding')
        for C in (1,8):
            row = cycle['numerical_audits'][str(C)]; path = analysis/f'c{C}-independent-numerical.json'
            need(row['path'] == str(path) and row['sha256'] == sha(path),'cycle consumes selected actual numerical audit')
    trees = {'raw/'+k:ART/(NAME+'-'+k) for k in ('owner','cold-journal','execution','cpu-prepare')}
    attempts = sorted(p for p in ART.glob(NAME+'-analysis*') if p.is_dir()
                      and re.fullmatch(NAME+r'-analysis(?:-repeat-[1-9][0-9]*)?',p.name))
    need(analysis in attempts,'selected analysis is present')
    trees.update({'raw/analysis-attempts/'+p.name:p for p in attempts})
    trees['preregistration'] = PREREG
    failure_arrays = {owner/'phases'/f'c{C}-replay/qualification/base/failure-arrays.safetensors' for C in (1,8)}
    inputs = {}; snapshots = {}; missing = []
    for prefix,root in trees.items():
        if root == owner and complete is None: missing.append(prefix); continue
        files = listing(root,failure_arrays); snapshots[prefix] = [str(p.relative_to(root)) for p in files]
        inputs.update({prefix+'/'+p.relative_to(root).as_posix():p for p in files})
    inputs.update({'registered-source/'+Path(p).relative_to(ROOT).as_posix():Path(p) for p in pins})
    inputs['archive-source/archive.py'] = Path(__file__).resolve()
    manifest = {name:dict(path=str(path),**info(path)) for name,path in inputs.items()}
    by_path = {str(path):manifest[name] for name,path in inputs.items()}

    def bound(path,digest,size=None):
        row = by_path.get(str(path))
        need(row is not None and row['sha256'] == digest and (size is None or row['bytes'] == size),'archive/ref mismatch: '+str(path))

    # Capture PASS inventories and replay/audit inputs are checked even when a
    # later phase fails. No artificial seal/observer file from another vendor.
    numeric_coverage = {}; diagnostic_tensors = []
    for C in (1,8):
        capture = owner/'phases'/f'c{C}-capture/capture'
        if (capture/'complete.json').exists():
            record = read(capture/'complete.json')
            if record['status'] == 'PASS':
                need(record['schema'] == 'E024-route-http-capture-result-v1'
                     and record['capture_complete'] is record['cleanup_complete'] is record['server_reaped'] is True,
                     'actual closed route capture contract')
                actual = {p.name for p in capture.iterdir() if p.is_file() and p.name != 'complete.json'}
                need(set(record['artifacts']) == actual,'capture full top-level inventory')
                for name,pin in record['artifacts'].items():
                    need(Path(name).name == name and set(pin) == {'sha256','bytes'},'safe actual capture artifact')
                    bound(capture/name,pin['sha256'],pin['bytes'])
        child = owner/'phases'/f'c{C}-replay/qualification'; audit = audits[f'c{C}-numerical']
        if audit and audit['status'] == 'PASS':
            need(audit['schema'] == SCHEMAS['numerical'] and audit['concurrency'] == C
                 and audit['child_directory'] == str(child) and audit['http_history_qualified'] is True
                 and audit['ledger']['requests'] == (8 if C == 1 else 16)
                 and audit['http']['max_http_outstanding'] == C and audit['http']['fully_drained'] is True
                 and audit['owner_resources_restore_qualified'] is audit['offline_tensor_bytes_rechecked'] is False,
                 'actual captured HTTP numerical scope')
            path = child.parent/'plan.json'; replay = read(path)
            need(audit['plan_sha256'] == sha(path) == sha(child/'plan.json')
                 and replay['schema'] == 'E024-recorded-route-http-plan-v1'
                 and audit['raw_inputs'] == replay['inputs'] and audit['capture'] == replay['capture']
                 and audit['serving_prerequisite'] == replay['serving'] and audit['sources'] == replay['sources'],
                 'actual route replay plan, capture and serving binding')
            need(set(audit['terminal_sha256']) == {'plan.json','complete.json','base/plan.json','base/complete.json','recording.json'},'exact five replay terminals')
            for name,digest in audit['terminal_sha256'].items(): bound(child/name,digest)
            for field in ('inputs','capture'):
                for item in replay[field].values():
                    p = Path(item['path']); need(p.parent == capture,'actual corresponding C capture path'); bound(p,item['sha256'])
            bound(child/'base/steps.jsonl',audit['ledger']['sha256'])
            bound(child/'replay-route-events.jsonl',audit['routes']['replay']['sha256'])
            numeric_coverage[str(C)] = dict(requests=audit['ledger']['requests'],http=audit['http'],
                ahead_retirement=audit['ahead_retirement'],routes=audit['routes'],ledger=audit['ledger'])
        failed = child/'base/failure-arrays.safetensors'
        if failed.exists():
            item = dict(path=str(failed),**info(failed),scope='Original-dtype first-failure/partial diagnostic payload; not model weights.')
            failure = child/'base/failure.json'
            if failure.exists() and read(failure).get('array_artifact'):
                pin = read(failure)['array_artifact']
                need(pin['path'] == failed.name and pin['sha256'] == item['sha256'],'failure tensor receipt changed')
                item['failure_receipt_bound'] = True
            else: item['failure_receipt_bound'] = False  # Preserve partial write, do not invent proof.
            diagnostic_tensors.append(item)
    OUT.mkdir()
    write(OUT/'packaging-start.json',dict(schema='E024-route-http-archive-start-v1',selected_analysis=str(analysis),
        owner_plan_sha256=plan_sha,source=info(Path(__file__)),retention_only=True))
    sidecars = {'restored-journal.json':cold/'journal.json','restoration-audit.json':analysis/'restoration-audit.json',
                'audit-execution-summary.json':analysis/'execution-summary.json'}
    if complete is not None: sidecars['owner-complete.json'] = owner/'complete.json'
    for name in ('c1-independent-numerical.json','c8-independent-numerical.json','independent-cycle.json'):
        if (analysis/name).exists(): sidecars[name] = analysis/name
    for name,path in sidecars.items():
        shutil.copyfile(path,OUT/name); need(info(path) == info(OUT/name),'sidecar changed')
    target = OUT/'evidence.tar.xz'
    # Multiple registered aliases can refer to one inode. Write each as a
    # regular member; listing() has already rejected every source symlink.
    with tarfile.open(target,'w:xz',dereference=True) as tar:
        for name,path in inputs.items(): tar.add(path,arcname=name,recursive=False)
    actual = {}
    with tarfile.open(target,'r:xz') as tar:
        for member in tar:
            path = PurePosixPath(member.name)
            need(member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in actual,
                 'unsafe/duplicate archive member')
            digest = hashlib.sha256(); size = 0
            with tar.extractfile(member) as stream:
                while chunk := stream.read(1 << 20): digest.update(chunk); size += len(chunk)
            actual[member.name] = dict(sha256=digest.hexdigest(),bytes=size)
    need(set(actual) == set(manifest),'archive membership differs')
    need(all(actual[n] == {k:manifest[n][k] for k in ('sha256','bytes')} for n in actual),'archive SHA/size mismatch')
    need(all(info(p) == actual[n] for n,p in inputs.items()),'source evidence changed during archive')
    for prefix,root in trees.items():
        if prefix in missing: need(not root.exists(),'unstarted owner appeared'); continue
        need([str(p.relative_to(root)) for p in listing(root,failure_arrays)] == snapshots[prefix],'tree membership changed')
    need(sorted(p for p in ART.glob(NAME+'-analysis*') if p.is_dir()
         and re.fullmatch(NAME+r'-analysis(?:-repeat-[1-9][0-9]*)?',p.name)) == attempts,'audit attempt set changed')
    write(OUT/'manifest.json',dict(schema='E024-route-http-archive-manifest-v1',files=manifest,
        registered_source_count=len(pins),analysis_attempts=[str(p) for p in attempts],missing_unstarted_trees=missing,
        first_failure_tensors=diagnostic_tensors,model_payloads_included=False,runtime_payloads_included=False))
    summary = dict(schema='E024-route-http-archive-summary-v1',owner_plan_sha256=plan_sha,
        owner_status=complete['status'] if complete else 'NOT_STARTED',actual_child_phases=[r['phase'] for r in children],
        audit_statuses={k:v['status'] if v else jobs[k]['execution_status'] for k,v in audits.items()},
        selected_analysis=str(analysis),http_history_qualified=eligible,
        independent_resource_verified=bool(cycle and cycle.get('independent_resource_verified')),
        restoration_verified=True,performance_qualified=False,offline_tensor_bytes_rechecked=False,
        captured_history_coverage=numeric_coverage,resources=cycle.get('resources') if cycle else None,
        original_identity=journal['original'],restored_identity=journal['replacement'],
        first_failure_tensors=diagnostic_tensors,packaging_grants_qualification=False,
        scope='Actual route-ON C1x8/C8x16 histories only when independently PASS. All failed/skipped attempts retained. '
              'Device full-state/logit comparison receipts plus independent HTTP/schedule/ahead/route audit; no offline '
              'GPU reexecution, future arrival qualification, formal timing, Pareto point, exact runtime or warm-KV restoration.')
    write(OUT/'summary.json',summary)
    verification = dict(schema='E024-route-http-archive-verification-v1',status='PASS',archive=info(target),
        members=len(actual),logical_file_bytes=sum(v['bytes'] for v in actual.values()),registered_source_count=len(pins),
        analysis_attempts=len(attempts),first_failure_tensor_files=len(diagnostic_tensors),all_member_hashes_verified=True,
        all_original_files_rehashed=True,all_tree_members_rechecked=True,model_payloads_rehashed=False,
        runtime_payloads_rehashed=False,packaging_grants_qualification=False)
    write(OUT/'archive-verification.json',verification)
    (OUT/'ARCHIVE.md').write_text('# Closed E024 route HTTP evidence\n\n'
        'This package verifies retained file bytes and the exact member set. Independent restoration PASS is required. '
        'Failed or unstarted phases remain failed or unstarted; packaging grants no qualification. See summary.json '
        'and the actual independent audit sidecars for the selected attempt. All analysis attempts, preregistration, '
        'raw phase/resource/route/HTTP evidence and original-dtype first-failure tensors are retained. '
        'No model weights/runtime binaries, formal throughput point or warm-KV restoration is claimed.\n')
    print(json.dumps(dict(output=str(OUT),**verification)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true')
    parser.add_argument('--analysis',type=Path,default=ART/(NAME+'-analysis'))
    args = parser.parse_args()
    if args.run: archive(args.analysis)
    else: print('DESCRIPTION_ONLY: --run packages only actual CLOSED route HTTP v1 evidence with independent restoration PASS. No action performed.')
