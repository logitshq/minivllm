import json,subprocess,time,hashlib
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';H=R/'bench/m5_ultra_256gb/glm_flash_cycle_v3';O=A/'glm-v3-e033-seals-v1';reg=A/'glm-flash-v3-registration-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
argv=[str(R/'.venv/bin/python'),'-I','-B',str(H/'preregister.py'),'--seal-prepared',str(reg)];write(O/'receipt-command.json',dict(argv=argv,time=time.time()));(O/'receipt.py').write_bytes(Path(__file__).read_bytes());t=time.monotonic()
with (O/'receipt.stdout').open('x') as so,(O/'receipt.stderr').open('x') as se:r=subprocess.run(argv,cwd=R,stdout=so,stderr=se)
row=dict(returncode=r.returncode,elapsed_seconds=time.monotonic()-t);write(O/'receipt-result.json',row)
if r.returncode==0:
 receipt=json.loads((reg/'receipt.json').read_bytes());journal=A/'glm-flash-v3-cold-journal-v1/journal.json';j=json.loads(journal.read_bytes());row.update(registration=str(reg),receipt_sha256=sha(reg/'receipt.json'),owner_plan_sha256=receipt['owner_plan_sha256'],source_pin_count=len(receipt['source_pins']),state=j['state'],original=j['original'],execution_command=[str(R/'.venv/bin/python'),'-I','-B',str(H/'execute.py'),'--run','--registration',str(reg),'--out',str(A/'glm-flash-v3-execution-v1')]);write(O/'prepared-summary.json',row)
print(json.dumps(row,indent=2));raise SystemExit(r.returncode)
