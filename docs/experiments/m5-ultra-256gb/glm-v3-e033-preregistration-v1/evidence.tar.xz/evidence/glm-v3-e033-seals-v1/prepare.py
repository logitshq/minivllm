import json,subprocess,time
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';O=A/'glm-v3-e033-seals-v1';reg=A/'glm-flash-v3-registration-v1'
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
argv=json.loads((reg/'commands.json').read_bytes())['controller_prepare'];write(O/'controller-prepare-command.json',dict(argv=argv,time=time.time()));(O/'prepare.py').write_bytes(Path(__file__).read_bytes());t=time.monotonic()
with (O/'controller-prepare.stdout').open('x') as so,(O/'controller-prepare.stderr').open('x') as se:r=subprocess.run(argv,cwd=R,stdout=so,stderr=se)
row=dict(returncode=r.returncode,elapsed_seconds=time.monotonic()-t);write(O/'controller-prepare-result.json',row);print(json.dumps(row));raise SystemExit(r.returncode)
