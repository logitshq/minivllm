import hashlib,json
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');H=R/'bench/m5_ultra_256gb/glm_flash_cycle_v3';A=R/'docs/experiments/m5-ultra-256gb/E033-gdn-graph-combined-formal-v2';O=R/'.artifacts/m5-ultra-256gb/glm-v3-e033-seals-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
O.mkdir();(O/'before').mkdir();(O/'after').mkdir();paths=[H/n for n in ('predecessor-manifest.json','controller.py','audit_restore.py','audit_closed.py','execute.py','preregister.py')]
for p in paths:(O/'before'/p.name).write_bytes(p.read_bytes())
write(O/'source-before.json',{str(p):sha(p) for p in paths})
jp=A/'restored-journal.json';ap=A/'restoration-audit.json';j=json.loads(jp.read_bytes());a=json.loads(ap.read_bytes())
assert j['state']=='RESTORED' and a['status']=='PASS' and a['qualified'] is True and len(j['trials'])==12
m=H/'predecessor-manifest.json';old=json.loads(m.read_bytes());assert old['status']=='UNSEALED' and old['binding'] is None and old['trials'] is None
m.write_text(json.dumps(dict(schema=old['schema'],status='SEALED',binding=dict(path=str(jp),sha256=sha(jp),audit=dict(path=str(ap),sha256=sha(ap))),trials=j['trials']),indent=2)+'\n')
def replace(p,old,new):
 s=p.read_text();assert s.count(old)==1,(str(p),old);p.write_text(s.replace(old,new,1))
c=H/'controller.py';replace(c,"The predecessor manifest is deliberately unsealed until a real twelve-phase combined formal cycle has\nclosed RESTORED with its independent audit.","The predecessor manifest binds the actual twelve-phase E033 combined formal cycle,\nclosed RESTORED with its independent audit.")
replace(c,"BOUND_MANIFEST_SHA = 'UNSEALED'",f"BOUND_MANIFEST_SHA = '{sha(m)}'")
r=H/'audit_restore.py';replace(r,'Controller pin remains explicitly unsealed until the real predecessor closes.','Controller pin binds the actual sealed E033 predecessor and recovery lifecycle.')
replace(r,"CONTROLLER_SHA='UNSEALED'",f"CONTROLLER_SHA='{sha(c)}'")
closed=H/'audit_closed.py';replace(closed,"RESTORE_SHA='UNSEALED'",f"RESTORE_SHA='{sha(r)}'")
exe=H/'execute.py';replace(exe,"REGISTRAR_SHA='UNSEALED'",f"REGISTRAR_SHA='{sha(H/'preregister.py')}'")
for p in paths:(O/'after'/p.name).write_bytes(p.read_bytes())
write(O/'source-after.json',{str(p):sha(p) for p in paths})
write(O/'sealed.json',dict(status='SOURCE_SEALED',predecessor=dict(journal=dict(path=str(jp),sha256=sha(jp)),audit=dict(path=str(ap),sha256=sha(ap))),pins={p.name:sha(p) for p in paths},scope='Exact archived predecessor and dependent source seals only; no service preparation or model execution.'))
(O/'seal.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(json.loads((O/'sealed.json').read_text()),indent=2))
