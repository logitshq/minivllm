import json,subprocess,time,hashlib
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';H=R/'bench/m5_ultra_256gb/glm_flash_cycle_v3';E=R/'docs/experiments/m5-ultra-256gb/E033-gdn-graph-combined-formal-v2';O=A/'glm-v3-e033-seals-v1';P=str(R/'.venv/bin/python')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
analysis=A/'glm-flash-v3-analysis-v1';analysis.mkdir()
argv=[P,'-I','-B',str(H/'preregister.py'),'--run','--out',str(A/'glm-flash-v3-registration-v1'),'--owner',str(A/'glm-flash-v3-owner-v1'),'--journal',str(A/'glm-flash-v3-cold-journal-v1'),'--analysis',str(analysis/'closed-audit.json'),'--python',P,'--probe-plan',str(A/'glm-flash-inputs-v1/probe-plan.json'),'--probe-plan-sha256','700f0a785138a75ebb4554d6eddee7dfbd1375c5b92bd596f8bd2e3e16f9be87','--verification',str(A/'glm-flash-inputs-v1/model-runtime-inventory.json'),'--verification-sha256','bdf025b9fdfd5cb22eb1991c9b3e7c20c73b962a3e86e4306a0af9c33aca58be','--predecessor-journal',str(E/'restored-journal.json'),'--predecessor-journal-sha256',sha(E/'restored-journal.json'),'--predecessor-audit',str(E/'restoration-audit.json'),'--predecessor-audit-sha256',sha(E/'restoration-audit.json'),'--child-limit-bytes','236223201280','--interval-seconds','1','--probe-seconds','5']
write(O/'registration-command.json',dict(argv=argv,time=time.time()));(O/'register.py').write_bytes(Path(__file__).read_bytes())
t=time.monotonic()
with (O/'registration.stdout').open('x') as so,(O/'registration.stderr').open('x') as se:r=subprocess.run(argv,cwd=R,stdout=so,stderr=se)
row=dict(returncode=r.returncode,elapsed_seconds=time.monotonic()-t);write(O/'registration-result.json',row);print(json.dumps(row));raise SystemExit(r.returncode)
