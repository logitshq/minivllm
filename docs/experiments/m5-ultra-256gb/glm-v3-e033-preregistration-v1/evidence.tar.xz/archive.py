import hashlib,json,tarfile,io
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';H=R/'bench/m5_ultra_256gb/glm_flash_cycle_v3';O=R/'docs/experiments/m5-ultra-256gb/glm-v3-e033-preregistration-v1'
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha(p):return sha_bytes(p.read_bytes())
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
reg=A/'glm-flash-v3-registration-v1';receipt=json.loads((reg/'receipt.json').read_bytes())
assert all(sha(Path(p))==h for p,h in receipt['source_pins'].items())
assert json.loads((A/'glm-flash-v3-cold-journal-v1/journal.json').read_bytes())['state']=='PREPARED'
O.mkdir(); sources={}
for name in ('glm-v3-e033-focused-cpu-v1','glm-v3-e033-focused-cpu-v2','glm-v3-e033-seals-v1','glm-flash-v3-registration-v1','glm-flash-v3-cold-journal-v1'):
 for p in sorted((A/name).rglob('*')):
  if p.is_file():
   assert not p.is_symlink();sources[str(Path('evidence')/name/p.relative_to(A/name))]=p
for p in sorted(H.iterdir()):
 if p.is_file() and p.suffix in ('.py','.json','.md'):sources[str(Path('source')/p.name)]=p
sources['archive.py']=Path(__file__).resolve()
manifest={};total=0
with tarfile.open(O/'evidence.tar.xz','x:xz') as tar:
 for name,p in sorted(sources.items()):
  raw=p.read_bytes();meta=tarfile.TarInfo(name);meta.size=len(raw);meta.mode=0o644;meta.mtime=int(p.stat().st_mtime);tar.addfile(meta,io.BytesIO(raw));manifest[name]=dict(source=str(p),sha256=sha_bytes(raw),bytes=len(raw));total+=len(raw)
write(O/'manifest.json',manifest)
with tarfile.open(O/'evidence.tar.xz','r:xz') as tar:
 assert sorted(tar.getnames())==sorted(manifest)
 for member in tar.getmembers():
  raw=tar.extractfile(member).read();row=manifest[member.name];assert len(raw)==row['bytes'] and sha_bytes(raw)==row['sha256'] and sha(Path(row['source']))==row['sha256']
assert all(sha(Path(p))==h for p,h in receipt['source_pins'].items())
write(O/'archive-verification.json',dict(status='PASS',members=len(manifest),raw_bytes=total,archive=dict(sha256=sha(O/'evidence.tar.xz'),bytes=(O/'evidence.tar.xz').stat().st_size),scope='Every tar member, original source and copied receipt pin checked at PREPARED archive creation. Live journal may advance only in later actual execution.'))
for name in ('owner-plan.json','commands.json','source-manifest.json','plan-build.json','receipt.json'):(O/name).write_bytes((reg/name).read_bytes())
(O/'prepared-journal.json').write_bytes((A/'glm-flash-v3-cold-journal-v1/journal.json').read_bytes())
for name in ('result.json','actual-seals-validation.json'):(O/('postseal-'+name)).write_bytes((A/'glm-v3-e033-focused-cpu-v2'/name).read_bytes())
(O/'preseal-result.json').write_bytes((A/'glm-v3-e033-focused-cpu-v1/result.json').read_bytes())
summary=json.loads((A/'glm-v3-e033-seals-v1/prepared-summary.json').read_bytes());summary.update(schema='GLM-v3-E033-preregistration-archive-v1',status='PREPARED',experiment_started=False,performance_qualified=False,archive_verification='PASS',cpu_tests=dict(preseal=16,postseal=16,actual_seals='PASS'))
write(O/'summary.json',summary)
(O/'README.md').write_text('''# GLMv3 actual E033-bound preregistration

Status: **PREPARED; no GLM owner/model run**. The actual E033 predecessor is
RESTORED with independent restoration PASS. CPU registration, actual read-only
controller preparation and receipt sealing returned zero. The source chain and
61 receipt pins were checked again while this archive was written.

The broad CPU attempt previously found one test exception-class mismatch: the
controller correctly raised Refuse, but the test expected ValueError. Only tests
were repaired, with an explicit synthetic UNSEALED pin so later sealed checkouts
still exercise rejection. Both focused 16-test runs passed under backend/process/
network/signal guards; postseal also validated the real source/predecessor chain.
No GPU or performance result is claimed.

`summary.json` records exact future execution argv, original service identity,
plan/receipt hashes and output paths. `commands.json` is the unchanged registered
controller/owner/auditor argv. `prepared-journal.json` is a byte-for-byte PREPARED
snapshot. `evidence.tar.xz` retains the complete focused CPU source snapshots,
stdout/stderr/results, before/after seals, actual registration and controller
receipts. `manifest.json` maps every member to its original source/hash/size;
`archive-verification.json` confirms all copied members and original bytes.

Root commits and pushes this archive and sealed sources before executing the
actual driver, which always attempts finally recovery. Closure uses the saved
`restoration_audit` and `closed_audit` commands. A diagnostic failure is preserved;
restoration success alone cannot qualify the model or performance.
''')
print(json.dumps({'archive':str(O),**json.loads((O/'archive-verification.json').read_bytes())},indent=2))
