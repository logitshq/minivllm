"""Two fresh oMLX D512 qualification trials; owner directly owns both servers.

Narrow adaptation of frozen native_formal_owner.py, with its durable intents,
settled async probes and TERM/KILL/wait protocol. No model/service action on
import/help/prepare-only. Actual execution requires a separately reviewed cold
controller and exact STOPPED journal. No controller is implemented here.
Four supplied oMLX runtime/source/target/outer-runtime pin groups are verified
before and after; no native preparation substitutes for those dependencies.
The adjacent reviewed controller and three independent auditors must exist and
be source-pinned before preparation/execution. This file implements none of them.
Supplied file coverage is not proof of a complete recursive environment closure.
"""
import argparse
import asyncio
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PHASES = ('omlx-c1', 'omlx-c8')
JOURNAL_SCHEMA = 'E023-omlx-D512-cold-journal-v1'
PREPARE_SECONDS = 300
POSTFLIGHT_SECONDS = 120
NUMERICAL_SHA = '21ba52e43ce54c2b463ab46bfd212c53d06d6303530c77939e3e6b801df547fb'
E020_PLAN = HERE.parent / 'external_spec_http/prereg-v1/plan.json'
E020_SHA = 'e3f0c3e24d4ea841d5e6c0b0094652e65e463c02367836e765ef6d9e3c6e2bdc'
OMLX_VENV = HERE.parents[2] / '.artifacts/omlx-baseline/.venv'
OMLX_SITE = OMLX_VENV / 'lib/python3.13/site-packages'
GROUPS = ('omlx_runtime', 'omlx_source', 'target_model', 'outer_runtime')
LOCAL = ('trial.py', 'serve_probe_v2.py', 'join_v2.py')
REQUIRED_AUDIT_SOURCES = ('audit_qualification.py', 'audit_resources.py', 'audit_restore.py')
FIXED = {
    '../pareto_realistic/native_cleanup.py': '6c292a9d3cb28c047d1dc92ac0fec4abe19fa8df84c172ef61d2f6ce41157ca6',
    '../pareto_realistic/client.py': 'ef64a114f4f7d90ec5044d6bdcf058ca05f98dea445d6639db706a4fc75217dc',
    '../pareto_realistic/http_capture_v2.py': '536fe41d6c8e2bdffe83ba6f43fba87dd6265deb4c84f6204bc9c7220f8280e3',
    '../pareto_realistic/qualify_absent_owner.py': '5beb6c9bcfa4e22041a386cdbea3f5ecee210cdcb9b345512c50b6c6f873c62d',
    '../resource_base.py': '41e23aed50dca8782bc1e182237f2dfe63bf6a2b9bf8061932ba2df1cdf2bf26',
    '../resources.py': '5a743d8ba5e0f1ab211a044fb1a1006b940163bb62f652e93dd849afe05da200',
    '../resources_v2.py': '15a207240436e92500c76b2ae791ba896540e53cd52c1f9c6237b83976b072d0',
}


def need(ok, message):
    if not ok: raise RuntimeError(message)


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(name):
    relative = 'trial.py' if name == 'trial' else '../pareto_realistic/qualify_absent_owner.py'
    need(name in ('trial', 'qualify_absent_owner'), 'only fixed stdlib modules')
    path = (HERE / relative).resolve()
    if relative in FIXED:
        need(sha(path) == FIXED[relative], 'frozen source changed: ' + str(path))
    spec = importlib.util.spec_from_file_location('_omlx_owner_' + name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module


def source_pins():
    for name in (*LOCAL, *REQUIRED_AUDIT_SOURCES):
        need((HERE / name).is_file(), 'required reviewed source not yet supplied: ' + name)
    return {**{str((HERE / n).resolve()): digest for n, digest in FIXED.items()},
            **{str(HERE / n): sha(HERE / n) for n in (*LOCAL, *REQUIRED_AUDIT_SOURCES)},
            str(Path(__file__).resolve()): sha(__file__)}


def trial_names(trials):
    need(trials == list(PHASES) and type(trials) is list, 'exact oMLX C1 then C8 qualification phases')
    return trials


def work_seconds(trials, deadlines):
    trial_names(trials)
    values = [deadlines[k] for k in ('overall', 'close', 'term', 'kill')]
    need(all(type(v) in (int, float) and math.isfinite(v) and v > 0 for v in values), 'finite trial budgets')
    return math.ceil(PREPARE_SECONDS + len(trials) * (sum(values) + 12))


def plan_template(qualification, cold_restart, http, verification):
    return dict(schema='E023-omlx-D512-owner-plan-v1', execution=dict(
        owner=dict(path=str(Path(__file__).resolve()), sha256=sha(__file__)), pins=source_pins()),
        qualification=qualification, cold_restart=cold_restart, http=http, verification=verification,
        trials=list(PHASES), deadline_seconds=work_seconds(list(PHASES), http['deadlines']))


def prior_replacement(plan):
    item = plan['cold_restart']['controller']
    need(sha(item['path']) == item['sha256'], 'controller source changed')
    spec = importlib.util.spec_from_file_location('_omlx_owner_controller', item['path'])
    controller = importlib.util.module_from_spec(spec); spec.loader.exec_module(controller)
    prior, _ = controller.predecessor(plan['cold_restart']['predecessor'])
    return prior['replacement']


def verification_contract(verification, numeric, specs):
    """Small metadata only. Frozen E020 inventories define minimum real dependencies."""
    need(type(verification) is dict and set(verification) == {'python', 'groups'}, 'verification fields')
    python = Path(verification['python'])
    need(python.is_absolute() and python.resolve() == Path(sys.executable).resolve(), 'actual outer Python identity')
    groups = verification['groups']
    need(type(groups) is dict and set(groups) == set(GROUPS), 'all four explicit pin groups required')
    union = {}
    for group, rows in groups.items():
        need(type(rows) is dict and bool(rows), 'nonempty pin group: ' + group)
        for name, row in rows.items():
            path = Path(name)
            need(path.is_absolute() and '..' not in path.parts and type(row) is dict
                 and set(row) == {'sha256', 'bytes', 'mtime_ns'}, 'explicit absolute pin metadata')
            digest = row['sha256']
            need(type(digest) is str and len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
                 and type(row['bytes']) is int and row['bytes'] >= 0
                 and type(row['mtime_ns']) is int and row['mtime_ns'] >= 0, 'strict pin SHA/size/stat')
            need(name not in union or union[name] == row, 'conflicting group pin')
            union[name] = row
    need(sha(E020_PLAN) == E020_SHA, 'original external inventory changed')
    old = json.loads(E020_PLAN.read_bytes())
    model_ref = numeric['model_manifest']
    need(sha(model_ref['path']) == model_ref['sha256'], 'target manifest pin')
    model = json.loads(Path(model_ref['path']).read_bytes())
    need(len(specs) == 2 and [s['concurrency'] for s in specs] == [1, 8]
         and all(s['model_directory'] == model['model'] and s['observer_enabled'] is True
                 and s['command'][0] == str(OMLX_VENV / 'bin/python') for s in specs),
         'same registered target and actual observed oMLX interpreter')
    official = {p:d for spec in specs for p,d in spec['sources'].items()
                if Path(p).is_relative_to(OMLX_SITE)}
    required = {
        'omlx_runtime': {p:d for p,d in old['pins'].items() if p.startswith(str(OMLX_VENV) + '/')},
        'omlx_source': official,
        'target_model': {str(Path(model['model']) / p):d for p,d in model['files'].items()},
    }
    for group, required_rows in required.items():
        need(bool(required_rows) and all(groups[group].get(p, {}).get('sha256') == d for p,d in required_rows.items()),
             'missing/changed frozen ' + group + ' inventory')
    server_python = str((OMLX_VENV / 'bin/python').resolve())
    need(server_python in old['pins'] and groups['omlx_runtime'].get(server_python, {}).get('sha256') == old['pins'][server_python],
         'actual resolved oMLX Python binary must retain its registered identity')
    need(all(groups['omlx_runtime'].get(p, {}).get('sha256') == d for p,d in official.items()),
         'observed official source must also belong to verified server runtime')
    outer = groups['outer_runtime']
    need(str(python.resolve()) in outer, 'actual outer Python binary pin')
    version = f'python{sys.version_info.major}.{sys.version_info.minor}'
    site = Path(sys.prefix) / 'lib' / version / 'site-packages'
    for package in ('httpx', 'httpcore', 'tokenizers'):
        need(str(site / package / '__init__.py') in outer, 'outer runtime package missing: ' + package)
    return union


def validate_plan(args):
    base = load('qualify_absent_owner'); raw = base.absolute(args.plan).read_bytes()
    need(base.sha_bytes(raw) == args.plan_sha256, 'oMLX owner plan SHA')
    plan = json.loads(raw)
    need(set(plan) == {'schema','execution','qualification','cold_restart','http','verification','trials','deadline_seconds'}
         and plan['schema'] == 'E023-omlx-D512-owner-plan-v1', 'oMLX owner plan schema')
    trial_names(plan['trials'])
    need(type(plan['deadline_seconds']) is int and plan['deadline_seconds'] == work_seconds(plan['trials'],plan['http']['deadlines']), 'exact work budget')
    need(plan['execution'] == dict(owner=dict(path=str(Path(__file__).resolve()),sha256=sha(__file__)),pins=source_pins()), 'exact owner/source pins')
    for path,digest in plan['execution']['pins'].items(): need(sha(path) == digest, 'source changed: ' + path)
    q = plan['qualification']
    need(set(q) == {'path','sha256'} and q['sha256'] == NUMERICAL_SHA and sha(base.absolute(q['path'])) == NUMERICAL_SHA, 'unchanged D fixture/resource plan')
    numeric = json.loads(Path(q['path']).read_bytes()); cold = plan['cold_restart']
    need(set(cold) == {'journal_path','controller','approved_contract','proposal_plan_sha256','predecessor'}, 'cold contract fields')
    base.absolute(cold['journal_path']); controller = cold['controller']
    need(set(controller) == {'path','sha256'} and base.absolute(controller['path']) == HERE / 'controller.py'
         and sha(controller['path']) == controller['sha256'], 'actual separate oMLX controller required')
    need(cold['approved_contract'] == base.CONTRACT and cold['proposal_plan_sha256'] == base.PROPOSAL_SHA, 'unchanged authorized contract')
    predecessor = cold['predecessor']
    need(set(predecessor) == {'path','sha256','audit'} and set(predecessor['audit']) == {'path','sha256'}, 'immutable restored predecessor')
    for item in (predecessor,predecessor['audit']): need(sha(base.absolute(item['path'])) == item['sha256'], 'predecessor changed')
    prior_replacement(plan)
    http = plan['http']; need(set(http) == {'port','api_key','deadlines','environment'}, 'oMLX HTTP fields')
    d = http['deadlines']
    need(0 < d.get('overall',0) <= 3600 and d.get('term') == d.get('kill') == 15
         and 0 < d.get('close',0) <= 15 and 0 < d.get('resource_interval',0) <= 5, 'original bounded cleanup/resource policy')
    trial = load('trial')
    specs = [trial.prepare(args.out / 'phases' / phase / 'trial', c, http['port'], http['api_key'],
             deadlines=d, environment=http['environment']) for phase,c in zip(PHASES,(1,8))]
    verification_contract(plan['verification'], numeric, specs)
    return base,plan,raw,numeric,specs


def stopped(base, plan, args, binding=None):
    raw = (Path(plan['cold_restart']['journal_path']) / 'journal.json').read_bytes(); j = json.loads(raw)
    expected = dict(schema=JOURNAL_SCHEMA,state='STOPPED',plan_sha256=base.PROPOSAL_SHA,
        controller_sha256=plan['cold_restart']['controller']['sha256'],approved_contract=base.CONTRACT,
        owner_directory=str(args.out),owner_plan=dict(path=str(args.plan),sha256=args.plan_sha256),
        owner_source=plan['execution']['owner'],predecessor=plan['cold_restart']['predecessor'],trials=plan['trials'])
    need(all(j.get(k) == v for k,v in expected.items()), 'bound oMLX cold journal is not STOPPED')
    need(type(j.get('original')) is dict and type(j['original'].get('pid')) is int and j['original']['pid'] > 1, 'original identity')
    need(j['original'] == (prior_replacement(plan) if binding is None else binding['original']), 'predecessor replacement identity')
    need(type(j.get('id')) is str and bool(j['id']) and type(j.get('removed_at')) in (int,float)
         and math.isfinite(j['removed_at']) and 0 < j['removed_at'] <= time.time(), 'journal runtime identity')
    need(type(j.get('predecessor_copies')) is dict, 'retained predecessor copies')
    stable = {k:j[k] for k in (*expected,'id','removed_at','original','predecessor_copies')}
    need(binding is None or binding == stable, 'STOPPED identity changed'); return raw,stable


def full_prepare(base, plan, numeric, out, check):
    """Hash supplied real dependencies from stable open files; never load models."""
    out.mkdir(); verified = {}
    base.durable(out / 'verification-plan.json', plan['verification'], exclusive=True)
    try:
        for group in GROUPS:
            verified[group] = {}
            for name, expected in plan['verification']['groups'][group].items():
                check(); path = Path(name); before = path.stat(); digest = hashlib.sha256()
                need(before.st_size == expected['bytes'] and before.st_mtime_ns == expected['mtime_ns'], 'pinned stat changed: ' + name)
                with path.open('rb') as stream:
                    opened = os.fstat(stream.fileno())
                    need((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns) ==
                         (opened.st_dev,opened.st_ino,opened.st_size,opened.st_mtime_ns), 'pin replaced before read')
                    while chunk := stream.read(1 << 20): check(); digest.update(chunk)
                    after = os.fstat(stream.fileno())
                final = path.stat()
                need(all((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns) ==
                         (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns) for s in (after,final))
                     and digest.hexdigest() == expected['sha256'], 'pin changed or SHA differs: ' + name)
                verified[group][name] = dict(**expected,inode=before.st_ino,device=before.st_dev)
            base.durable(out / 'verified-pins.json', verified)
        folder = out / 'frozen-sources'; folder.mkdir()
        for name,digest in plan['execution']['pins'].items():
            check(); raw = Path(name).read_bytes(); need(base.sha_bytes(raw) == digest, 'adapter source changed')
            dest = folder / name.lstrip('/'); dest.parent.mkdir(parents=True,exist_ok=True)
            base.durable(dest,raw,exclusive=True,raw=True)
        base.durable(out / 'complete.json', dict(status='PASS', groups=list(GROUPS),files=sum(map(len,verified.values())),
            recursive_runtime_coverage_verified=False,
            scope='Explicit supplied dependencies only; inherited inventory is not a recursive dependency proof. No native preparation substituted; OS shared libraries/stdlib not encapsulated.'), exclusive=True)
    except BaseException:
        # A failed receipt write must not replace the original pin/deadline error.
        try: base.durable(out / 'verified-pins.json', verified)
        except BaseException: pass
        raise
    else:
        base.durable(out / 'verified-pins.json', verified)


class System:
    """All real OS actions are execution-only; CPU tests inject a fake."""
    def __init__(self, base):
        self.base = base.System()
    def __getattr__(self, name):
        return getattr(self.base, name)
    def postflight_deadline(self):
        signal.setitimer(signal.ITIMER_REAL, POSTFLIGHT_SECONDS)
    def trial_backend(self, module):
        return module.System()


def run(args, *, system=None, resources=None, trial_module=None):
    base, plan, plan_raw, numeric, specs = validate_plan(args)
    system = system or System(base)
    trial_module = trial_module or load('trial')
    directory = Path(plan['cold_restart']['journal_path'])
    phases = tuple(plan['trials']); budget = plan['deadline_seconds']
    started = time.monotonic()
    children, samples, errors, stages = [], [], [], []
    absence_count = 0
    reap_attempts = {}
    phase_intent_started = set()
    binding = attempt = None
    intent = deadline_active = cancelled = False
    trial_task = None
    phase = 'attempt'
    live = {}  # only direct Popen objects actually returned to this owner

    def failure(exc, where):
        row = dict(phase=where, type=type(exc).__name__, error=str(exc), time=time.time())
        errors.append(row); base.durable(args.out / 'errors.json', errors)
        if len(errors) == 1:
            base.durable(args.out / 'first-error.json', row, exclusive=True)

    def stop(*unused):
        nonlocal cancelled
        cancelled = True
        if trial_task is not None:
            trial_task.cancel()
        else:
            raise TimeoutError('oMLX owner absolute deadline or cancellation')

    def check(*, cleanup=False):
        if not cleanup:
            need(not cancelled and time.monotonic() - started < budget, 'owner cancelled/deadline')
        return stopped(base, plan, args, binding)

    def probe(label, pid=None, *, cleanup=False):
        nonlocal absence_count
        check(cleanup=cleanup)
        absence = base.absence(system, binding['original']['pid'])
        n = len(samples)
        absence_count += 1
        base.durable(args.out / f'absence-{absence_count-1:03d}.json',
                     dict(label=label, time=time.time(), resource_index_if_sampled=n, **absence), exclusive=True)
        need(absence['status'] == 'PASS', 'removed service PID/job/8001 reappeared or unknown')
        sample = resources.snapshot(label, pid, suspended_pids=())
        samples.append(sample)
        base.durable(args.out / f'resource-{n:03d}.json', sample, exclusive=True)
        resources.guard(samples)
        need(sample['authorized_suspended_pids'] == [] and all(p['owned'] and p['pid'] == pid
             and not p['authorized_suspended'] for p in sample['native_inference_processes']), 'foreign process/exemption')
        need(sample['pressure_level_value'] == 1 and sample['power_metadata']['source'] == 'AC Power'
             and sample['processinfo_thermal_metadata']['code'] in (0, 1), 'pressure/power/thermal guard')
        check(cleanup=cleanup)

    def ref(path):
        return {'path': str(path.relative_to(args.out)), 'sha256': sha(path)}

    def index():
        base.durable(args.out / 'children.json', dict(schema='cold-service-owner-children-v1', children=children))

    def bound():
        return {k: attempt[k] for k in ('owner_pid', 'owner_identity', 'owner_source', 'owner_plan_sha256',
                                        'journal_id', 'removed_at')}

    def spawn_impl(stage, spawn_call):
        nonlocal intent
        folder = args.out / 'phases' / stage
        with base.journal_lock(directory):
            check()
            absent = base.absence(system, binding['original']['pid'])
            base.durable(folder / 'pre-spawn-absence.json', absent, exclusive=True)
            need(absent['status'] == 'PASS', 'service absence changed before spawn intent')
            evidence = dict(phase=stage, owner_pid=os.getpid(), journal_id=binding['id'],
                owner_plan_sha256=args.plan_sha256, attempt_sha256=sha(args.out / 'attempt.json'), time=time.time())
            if not intent:
                intent = True  # failed fsync is unknown, never NO_CHILD_STARTED
                base.durable(args.out / 'spawn-intent.json', evidence, exclusive=True)
            phase_intent_started.add(stage)  # failed durable write is not a no-Popen proof
            base.durable(folder / 'intent.json', evidence, exclusive=True)
            child = spawn_call()  # unknown outcome after intent deliberately fails closed
            live[stage] = child
            need(type(child.pid) is int and child.pid > 1 and child.pid != os.getpid()
                 and all(row['pid'] != child.pid for row in children), 'unique returned child PID required')
            child_receipt = dict(phase=stage, pid=child.pid, owner_pid=os.getpid(), identity=None,
                                 ownership='direct-Popen-returned', spawned_at=time.time())
            base.durable(folder / 'child.json', child_receipt, exclusive=True)
            entry = dict(phase=stage, pid=child.pid, identity=None,
                intent=ref(folder / 'intent.json'), child=ref(folder / 'child.json'), release=None)
            children.append(entry)
            index()
            # A failure here is still a known direct Popen child. It is reaped,
            # retained as identity:null, and never admitted to the next phase.
            identity = system.identity(child.pid)
            need(identity['pid'] == child.pid and identity['ppid'] == os.getpid(), 'direct owned child identity')
            child_receipt['identity'] = entry['identity'] = identity
            base.durable(folder / 'child.json', child_receipt)
            entry['child'] = ref(folder / 'child.json'); index()
            return child

    def spawn(stage, spawn_call):
        try:
            return spawn_impl(stage, spawn_call)
        except BaseException as exc:
            # The oMLX trial writes its local intent immediately before invoking
            # this tracked backend. A failed lock/check here has not called Popen.
            # Record that positive fact; absence of a child file is insufficient.
            inner = args.out / 'phases' / stage / 'trial/spawn-intent.json'
            known_next = (len(children) < len(phases) and stage == phases[len(children)]
                          and all(row['release'] is not None for row in children))
            if (known_next and stage not in phase_intent_started and not live
                    and (not intent or bool(children)) and inner.exists()):
                raw = json.loads(inner.read_bytes())
                base.durable(args.out / 'phases' / stage / 'no-popen.json', dict(
                    schema='cold-service-no-popen-v1', phase=stage, owner_pid=os.getpid(),
                    journal_id=binding['id'], owner_plan_sha256=args.plan_sha256,
                    attempt_sha256=sha(args.out / 'attempt.json'),
                    ownership='tracked-backend-rejected-before-Popen', popen_called=False,
                    time=time.time(), inner_spawn_intent=ref(inner), command=raw['command'],
                    error={'type': type(exc).__name__, 'message': str(exc)}), exclusive=True)
            raise

    def release(stage):
        child = live[stage]
        folder = args.out / 'phases' / stage
        serial = reap_attempts.get(stage, 0)
        reap_attempts[stage] = serial + 1
        if child.poll() is None:
            try:
                child.terminate(); child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                pass
            except BaseException as exc:
                failure(exc, 'terminate:' + stage)
            if child.poll() is None:
                child.kill()
        child.wait(timeout=15)
        raw = system.read(['/bin/ps', '-p', str(child.pid), '-o', 'pid='])
        absent_path = folder / f'child-absence-{serial:02d}.json'
        base.durable(absent_path, raw, exclusive=True)
        need(type(child.returncode) is int and raw['returncode'] == 1 and not raw['stdout'].strip(),
             'strict direct child reap/absence missing')
        if stage in phases:
            raw_port = system.read(['/usr/sbin/lsof', '-nP', '-a',
                f"-iTCP:{plan['http']['port']}", '-sTCP:LISTEN', '-Fpn'])
            base.durable(folder / f'port-absence-{serial:02d}.json', raw_port, exclusive=True)
            need(raw_port['returncode'] == 1 and not raw_port['stdout'].strip(), 'oMLX listener survives')
        receipt = dict(phase=stage, pid=child.pid, returncode=child.returncode,
                       waited_reaped=True, strict_absence=True, absence=ref(absent_path), time=time.time())
        release_path = folder / 'release.json'
        if release_path.exists():
            # A previous durable release may precede an index write failure. Do
            # not overwrite it or treat mere file presence as successful reap.
            old = json.loads(release_path.read_bytes())
            need(set(old) == set(receipt) and all(old[k] == receipt[k] for k in
                ('phase', 'pid', 'returncode', 'waited_reaped', 'strict_absence'))
                and type(old['time']) in (int, float) and math.isfinite(old['time'])
                and binding['removed_at'] <= old['time'] <= time.time(), 'existing release mismatch')
            previous_absence = args.out / old['absence']['path']
            need(previous_absence.parent == folder and previous_absence.name.startswith('child-absence-')
                 and sha(previous_absence) == old['absence']['sha256'], 'existing release absence pin')
            previous_raw = json.loads(previous_absence.read_bytes())
            need(previous_raw['command'] == ['/bin/ps', '-p', str(child.pid), '-o', 'pid=']
                 and previous_raw['returncode'] == 1 and not previous_raw['stdout'].strip(), 'existing strict absence')
        else:
            base.durable(release_path, receipt, exclusive=True)
        row = next(row for row in children if row['phase'] == stage)
        row['release'] = ref(release_path); index()
        del live[stage]

    async def trial_one(spec, folder, stage):
        nonlocal trial_task
        underlying = system.trial_backend(trial_module)
        class Tracked:
            def __getattr__(self, name):
                return getattr(underlying, name)
            def spawn(self, command, environment, stdout, stderr, *, cwd):
                return spawn(stage, lambda: underlying.spawn(command, environment, stdout, stderr, cwd=cwd))
        async def checkpoint(label, pid):
            # Keep synchronous probe processes off the HTTP loop; finish the bounded
            # probe before propagating cancellation so no thread writes after reap.
            task = asyncio.create_task(asyncio.to_thread(probe, stage + ':' + label, pid,
                cleanup=label in ('after-reap', 'cleanup-incomplete')))
            interrupted = False
            while not task.done():
                try:
                    await asyncio.shield(task)
                except asyncio.CancelledError:
                    interrupted = True
            task.result()
            if interrupted:
                raise asyncio.CancelledError()
        trial_task = asyncio.create_task(trial_module.run(spec, folder / 'trial',
                                            checkpoint=checkpoint, backend=Tracked()))
        try:
            return await trial_task
        finally:
            trial_task = None

    with base.journal_lock(directory):
        snapshot, binding = stopped(base, plan, args)
        identity = system.identity(os.getpid())
        need(identity['pid'] == os.getpid(), 'owner identity')
        args.out.mkdir(exist_ok=False)
        (args.out / 'phases').mkdir()
        base.durable(args.out / 'stopped-journal.json', snapshot, exclusive=True, raw=True)
        attempt = dict(schema='cold-service-owner-attempt-v1', owner_pid=os.getpid(), owner_identity=identity,
            owner_source=plan['execution']['owner'], owner_plan_sha256=args.plan_sha256,
            journal_id=binding['id'], journal_path=str(directory), controller_sha256=binding['controller_sha256'],
            removed_at=binding['removed_at'], created_at=time.time(), phase='PRESPAWN',
            stopped_journal_sha256=base.sha_bytes(snapshot))
        base.durable(args.out / 'attempt.json', attempt, exclusive=True)
        index()
    try:
        system.start_deadline(budget - (time.monotonic() - started), stop); deadline_active = True
        base.durable(args.out / 'owner-plan.json', plan_raw, exclusive=True, raw=True)
        resources = resources or base.load_resources(numeric)
        phase = 'prepare'
        probe('before-prepare')
        full_prepare(base, plan, numeric, args.out / 'preflight', check)
        base.durable(args.out / 'trial-specs.json', specs, exclusive=True)
        probe('after-prepare')
        for phase, spec in zip(phases, specs):
            folder = args.out / 'phases' / phase; folder.mkdir()
            result = asyncio.run(trial_one(spec, folder, phase))
            if phase in live:
                release(phase)
            entry = next((row for row in children if row['phase'] == phase), None)
            need(entry is not None and entry['release'] is not None
                 and json.loads((folder / 'trial/child.json').read_bytes())['pid'] == entry['pid'],
                 'oMLX trial did not return the actually owned/reaped server')
            need(result['schema'] == 'E023-omlx-D512-trial-result-v1'
                 and result['concurrency'] == spec['concurrency']
                 and result['status'] == 'PASS' and result['route_count_text_qualified'] is True
                 and result['full_state_qualified'] is False
                 and result['performance_qualified'] is False and result['cleanup_complete'] is True
                 and result['server_reaped'] is True and result['cleanup_task_resolved'] is True
                 and result['client_task_resolved'] is True and result['small_pins_rechecked'] is True
                 and result['request_sealed'] is True,
                 'oMLX qualification trial/cleanup failed; following trial forbidden')
            inner_release = json.loads((folder / 'trial/release.json').read_bytes())
            outer_release = json.loads((folder / 'release.json').read_bytes())
            need(inner_release['pid'] == entry['pid'] and inner_release['waited_reaped'] is True
                 and inner_release['strict_absence'] is True and inner_release['port_absent'] is True
                 and type(inner_release['returncode']) is int
                 and inner_release['returncode'] == outer_release['returncode']
                 and (inner_release['returncode'] == 0 or
                      (inner_release['returncode'] == -15 and inner_release['term_sent'] is True)),
                 'trial release does not match direct server')
            # Request seal is an actual protocol boundary, not process-close/EOF
            # evidence. Closed logs and real exit/reap remain separate artifacts.
            raw_join = json.loads((folder / 'trial/raw-join.json').read_bytes())
            seal = json.loads((folder / 'trial/request-seal.json').read_bytes())
            need(raw_join['schema'] == 'E023-omlx-D512-observed-join-v2'
                 and raw_join['status'] == 'PASS' and raw_join['protocol_route_count_qualified'] is True
                 and raw_join['performance_qualified'] is False and raw_join['full_state_numerical_qualified'] is False
                 and raw_join['request_sealed'] is True and raw_join['seal'] == seal
                 and raw_join['concurrency'] == spec['concurrency']
                 and len(raw_join['requests']) == (8 if spec['concurrency'] == 1 else 16)
                 and raw_join['max_http_outstanding'] == spec['concurrency'],
                 'actual oMLX request-seal/raw-join binding')
            need(all((folder / 'trial' / name).is_file() for name in
                 ('group.json', 'server.stdout', 'server.stderr', 'probe/observer.jsonl')),
                 'closed oMLX raw evidence missing')
            check(); probe(phase + ':released')
            stages.append(dict(phase=phase,status='PASS',concurrency=spec['concurrency'],
                result=ref(folder / 'trial/complete.json'),raw_join=ref(folder / 'trial/raw-join.json'),
                request_seal=ref(folder / 'trial/request-seal.json'),group=ref(folder / 'trial/group.json'),
                stdout=ref(folder / 'trial/server.stdout'),stderr=ref(folder / 'trial/server.stderr')))
            base.durable(args.out / 'qualifications.json', dict(schema='E023-omlx-D512-qualifications-v1',
                trials=stages,performance_qualified=False,full_state_qualified=False,
                scope='Observed route/count/text only; independent outer resource/restoration audit required.'))
        need([row['phase'] for row in children] == list(phases)
             and [row['phase'] for row in stages] == list(phases), 'complete registered trial cycle required')
    except BaseException as exc:
        failure(exc, phase)
    finally:
        if deadline_active:
            system.cleanup_mode()
        for stage in list(live):
            try:
                release(stage)
            except BaseException as exc:
                failure(exc, 'cleanup:' + stage)
        try:
            if deadline_active:
                system.postflight_deadline()
            if resources is not None:
                probe('postflight', cleanup=True)
                base.durable(args.out / 'resources.json', resources.deltas(samples))
            validate_plan(args)
            full_prepare(base, plan, numeric, args.out / 'postflight', lambda: check(cleanup=True))
        except BaseException as exc:
            failure(exc, 'postflight')
        finally:
            if deadline_active:
                system.restore_deadline()
        deep_spawn = [p for p in (args.out / 'phases').rglob('*.json')
                      if p.name in ('intent.json', 'child.json', 'release.json', 'spawn-intent.json')]
        no_popen = args.out / 'phases/omlx-c1/no-popen.json'
        only_rejected_inner = (no_popen.exists() and deep_spawn == [args.out / 'phases/omlx-c1/trial/spawn-intent.json'])
        if not intent and (not deep_spawn or only_rejected_inner):
            need(not children and not live and errors, 'no-child requires pre-intent failure')
            base.durable(args.out / 'terminal.json', dict(schema='cold-service-owner-terminal-v1',
                status='NO_CHILD_STARTED', **bound(), terminal_at=time.time(), phase=errors[0]['phase'],
                error=errors[0], attempt_sha256=sha(args.out / 'attempt.json'),
                spawn_intent_written=False, child_started=False,
                no_popen_receipt=ref(no_popen) if only_rejected_inner else None), exclusive=True)
        elif intent:
            intended = [stage for stage in phases if (args.out / 'phases' / stage / 'intent.json').exists()]
            resolved = [row['phase'] for row in children if row['release'] is not None]
            extra_inner = [stage for stage in phases if stage not in resolved
                           and (args.out / 'phases' / stage / 'trial/spawn-intent.json').exists()]
            next_proof = (args.out / 'phases' / phases[len(resolved)] / 'no-popen.json') if len(resolved) < len(phases) else None
            known_rejection = (extra_inner == list(phases[len(resolved):len(resolved)+1])
                               and next_proof is not None and next_proof.exists())
            if (not live and intended == resolved and resolved == list(phases[:len(resolved)])
                    and (not extra_inner or known_rejection)):
                base.durable(args.out / 'release.json', dict(schema='cold-service-owner-release-v2',
                    **bound(), attempt_sha256=sha(args.out / 'attempt.json'), children=children,
                    children_sha256=sha(args.out / 'children.json'), all_children_reaped=True, time=time.time(),
                    **({'no_popen_receipt': ref(next_proof)} if known_rejection else {})), exclusive=True)
        else:
            failure(RuntimeError('nested spawn evidence without global intent; no no-child certificate'), 'terminal')
        result = dict(schema='E023-omlx-D512-owner-result-v1', status='FAIL' if errors else 'PASS',
            owner_pid=os.getpid(), owner_plan_sha256=args.plan_sha256, errors=errors, absence_probes=absence_count,
            first_failure=errors[0] if errors else None, phases=stages, samples=len(samples),
            spawn_intent_written=intent,
            child_started=True if children else False if (args.out / 'terminal.json').exists() else None,
            all_children_reaped=(args.out / 'release.json').exists(), elapsed_wall_s=time.monotonic() - started,
            qualification_trials_complete=not errors and len(stages) == len(phases),
            planned_trials=list(phases),
            independently_qualified=False, performance_qualified=False,full_state_qualified=False,
            recursive_runtime_coverage_verified=False,closed_server_logs_independently_verified=False,
            scope='Observed oMLX route/count/text only; request seal is not EOF/process close. Actual server/reap and closed logs retained. Independent qualification/resource/restoration audits required; no full-state/performance or recursive runtime-coverage claim.')
        base.durable(args.out / 'complete.json', result)
    return int(bool(errors))


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan', type=Path, required=True)
    p.add_argument('--plan-sha256', required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--prepare-only', action='store_true')
    args = p.parse_args(argv)
    args.plan, args.out = args.plan.resolve(), args.out.resolve()
    need(args.out.parent.is_dir() and not args.out.exists(), 'fresh output in existing parent required')
    if args.prepare_only:
        base, plan, _, _, specs = validate_plan(args)
        args.out.mkdir()
        base.durable(args.out / 'prepared.json', dict(schema='E023-omlx-D512-owner-prepare-v1', status='PREPARED',
            owner_plan_sha256=args.plan_sha256, trial_specs=specs, sources=plan['execution']['pins'],
            runtime_weights_verified=False,recursive_runtime_coverage_verified=False,
            scope='CPU small source/metadata only; no service or model action; supplied file coverage is not a recursive dependency proof.'), exclusive=True)
        return 0
    return run(args)


if __name__ == '__main__':
    raise SystemExit(main())
