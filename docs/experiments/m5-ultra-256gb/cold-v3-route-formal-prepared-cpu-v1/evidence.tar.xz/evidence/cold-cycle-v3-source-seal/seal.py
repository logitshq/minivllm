"""Seal four v3 migration constants from the actually archived route HTTP cycle.
Default describes only. No service/backend operation; all algorithm AST is fixed.
"""
import argparse, ast, hashlib, json, re
from pathlib import Path
R=Path('/Users/ryanli/code/minivllm');B=R/'bench/m5_ultra_256gb'
S=B/'cold_cycle_v3';A=R/'docs/experiments/m5-ultra-256gb/E024-route-http-v1'
OUT=R/'.artifacts/m5-ultra-256gb/cold-cycle-v3-source-seal'
EXPECTED={'controller.py':'c5a57793501190430619df24c5d1f240b08b96263b3d9f6e78bff67092a6c7a9',
'owner.py':'4c2cc6f305de3ecf0c6495e45838baae885efbf7a8f479ed2043dc0ffb67f31c',
'audit_restore.py':'34d608b54ed5779b97e85a0463c17f8796876be731f6f0aafcbe804ffc7b15ca'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_bytes())
def need(ok,msg):
 if not ok: raise ValueError(msg)
def save(p,x):
 with p.open('x') as f: json.dump(x,f,indent=2);f.write('\n')
def stable_tree(source,keys):
 t=ast.parse(source)
 for n in t.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in keys:n.value=ast.Constant(value='MIGRATION_SHA')
 return ast.dump(t,include_attributes=False)
def run():
 jpath=A/'restored-journal.json';apath=A/'restoration-audit.json';j=read(jpath);a=read(apath);v=read(A/'archive-verification.json')
 values={'MIGRATION_CONTROLLER_SHA':sha(B/'route_http_cycle/controller.py'),'MIGRATION_AUDITOR_SHA':sha(B/'route_http_cycle/audit_restore.py'),'MIGRATION_JOURNAL_SHA':sha(jpath),'MIGRATION_AUDIT_SHA':sha(apath)}
 need(v['schema']=='E024-route-http-archive-verification-v1' and v['status']=='PASS','closed actual archive required')
 need(j['schema']=='E024-route-http-cold-journal-v1' and j['state']=='RESTORED' and a['schema']=='cold-service-restoration-audit-v1' and a['status']=='PASS' and a['qualified'] is True,'actual independent restored predecessor required')
 need(a['journal_sha256']==values['MIGRATION_JOURNAL_SHA'] and a['controller_sha256']==j['controller_sha256']==values['MIGRATION_CONTROLLER_SHA'] and a['audit_source_sha256']==values['MIGRATION_AUDITOR_SHA'],'actual immutable source/journal/audit binding')
 need(a['service_restore']['replacement']==j['replacement'],'actual replacement identity')
 for name,digest in EXPECTED.items():need(sha(S/name)==digest,'source-only version changed: '+name)
 need(not OUT.exists(),'fresh sealing evidence')
 p=S/'controller.py';old=p.read_text();new=old
 for key,value in values.items():
  need(re.fullmatch('[0-9a-f]{64}',value),'actual SHA syntax')
  new,count=re.subn(r'(?m)^'+re.escape(key)+r"='UNSEALED[^']*'",key+'='+repr(value),new)
  need(count==1,'exact once unsealed assignment: '+key)
 need(stable_tree(old,values)==stable_tree(new,values),'only four migration constant values may change')
 before=read(S/'lifecycle.json')
 need(before['schema']=='cold-single-child-lifecycle-v3' and set(before['sources'])=={'controller','owner','audit_restore'},'original exact lifecycle')
 for key,row in before['sources'].items():need(row=={'path':str(S/(key+'.py')),'sha256':EXPECTED[key+'.py']},'original lifecycle identity')
 OUT.mkdir();(OUT/'seal.py').write_bytes(Path(__file__).read_bytes())
 (OUT/'controller.py.before').write_bytes(p.read_bytes());(OUT/'lifecycle.json.before').write_bytes((S/'lifecycle.json').read_bytes())
 p.write_text(new)
 manifest={'schema':'cold-single-child-lifecycle-v3','sources':{key:{'path':str(S/(key+'.py')),'sha256':sha(S/(key+'.py'))} for key in ('controller','owner','audit_restore')}}
 (S/'lifecycle.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (OUT/'controller.py.after').write_bytes(p.read_bytes());(OUT/'lifecycle.json.after').write_bytes((S/'lifecycle.json').read_bytes())
 save(OUT/'result.json',dict(schema='cold-v3-actual-route-predecessor-seal-v1',status='PASS_SOURCE_ONLY',values=values,before_sources=EXPECTED,after_manifest=manifest,algorithm_ast_unchanged=True,service_operation=False,tests_run=False,numerical_qualified=False,performance_qualified=False))
 print(json.dumps(dict(status='PASS_SOURCE_ONLY',controller_sha256=sha(p),lifecycle_sha256=sha(S/'lifecycle.json'),values=values)))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',action='store_true');a=p.parse_args()
 if a.run:run()
 else:print('DESCRIPTION_ONLY: actual archived restored cycle required; no operations.')
