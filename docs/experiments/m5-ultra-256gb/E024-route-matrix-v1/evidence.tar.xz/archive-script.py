"""Archive all small evidence; retain large original tensors locally with exact hashes."""
from pathlib import Path
import hashlib,json,tarfile
R=Path('/Users/ryanli/code/minivllm');A=R/'.artifacts/m5-ultra-256gb';O=R/'docs/experiments/m5-ultra-256gb/E024-route-matrix-v1'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(8<<20):h.update(b)
 return h.hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def read(p):return json.loads(p.read_bytes())
J=A/'route-decode-matrix-v1-cold-journal/journal.json';owner=A/'route-decode-matrix-v1-owner';analysis=A/'route-decode-matrix-v1-analysis'
j=read(J);assert j['state']=='RESTORED'
rest=analysis/'restoration-audit.json';ra=read(rest);assert ra['status']=='PASS' and ra['journal_sha256']==sha(J)
assert read(A/'route-decode-matrix-v1-execution/final.json')['journal_state']=='RESTORED'
O.mkdir(exist_ok=False)
for name,p in [('restored-journal.json',J),('restoration-audit.json',rest),('independent-numerical.json',analysis/'independent-numerical.json')]:
 (O/name).write_bytes(p.read_bytes());assert sha(O/name)==sha(p)
roots={'raw/owner':owner,'raw/cold-journal':J.parent,'raw/execution':A/'route-decode-matrix-v1-execution',
       'cpu-prepare':A/'route-decode-matrix-v1-cpu-prepare','analysis':analysis,
       'preregistration':R/'bench/m5_ultra_256gb/route_decode_graph/prereg-matrix-v1'}
inputs={};trees={}
for prefix,root in roots.items():
 paths=sorted(root.rglob('*'));assert not any(p.is_symlink() for p in paths)
 files=[p for p in paths if p.is_file()];trees[prefix]=[str(p.relative_to(root)) for p in files]
 for p in files:inputs[prefix+'/'+str(p.relative_to(root))]=p
for folder,names in [('route_decode_graph',['candidate.py','qualify.py','test_cpu.py','qualifier_matrix.py','test_matrix_cpu.py','audit_matrix.py','test_audit_matrix_cpu.py']),
 ('cold_cycle',['controller.py','owner.py','audit_restore.py','lifecycle.json','test_cpu.py','README.md']),
 ('long_decode_isolation',['qualify.py','audit_raw.py']),('long_decode_graph',['qualify.py','candidate.py','model-source-pins.json']),('pareto_realistic',['qualify_native.py'])]:
 for name in names:
  p=R/'bench/m5_ultra_256gb'/folder/name;inputs['audit-source/'+str(p.relative_to(R))]=p
for name in ['docs/experiments/m5-ultra-256gb/E028-identity-refill-v3/verify.py','bench/reviews/2026-10-17-e024-route-preserving-bounds.md','bench/reviews/sources/mlx-v0.32.3-scaled_dot_product_attention.cpp','bench/reviews/sources/mlx-v0.32.3-LICENSE','bench/reviews/sources/mlx-v0.32.3-sdpa_vector.h']:
 p=R/name;inputs['audit-source/'+name]=p
for name in ('resource_reparse.py','test_resource_reparse_cpu.py'):
 p=R/'bench/m5_ultra_256gb'/name;inputs['audit-source/bench/m5_ultra_256gb/'+name]=p
inputs['archive-script.py']=Path(__file__).resolve()
records={name:dict(source=str(p),bytes=p.stat().st_size,sha256=sha(p),mtime_ns=p.stat().st_mtime_ns,archived=p.suffix!='.safetensors') for name,p in inputs.items()}
included={n:r for n,r in records.items() if r['archived']};large={n:r for n,r in records.items() if not r['archived']}
assert all(inputs[n].suffix=='.safetensors' for n in large),'only explicitly identified original tensor files may be omitted'
write(O/'manifest.json',dict(schema='E024-route-matrix-evidence-manifest-v1',members=records,included_members=len(included),local_tensor_members=len(large),
 all_original_bytes=sum(r['bytes'] for r in records.values()),local_tensor_bytes=sum(r['bytes'] for r in large.values()),
 large_tensor_storage='Original files retained unchanged at listed local source paths; not inside Git archive. Remote-only readers need an actual rerun or these original files for raw re-audit.'))
package=O/'evidence.tar.xz'
with tarfile.open(package,'w:xz',preset=6) as tar:
 for name in included:tar.add(inputs[name],arcname=name,recursive=False)
seen=set()
with tarfile.open(package,'r:xz') as tar:
 for m in tar:
  assert m.isfile() and m.name in included and m.name not in seen;seen.add(m.name);h=hashlib.sha256();size=0
  with tar.extractfile(m) as f:
   while b:=f.read(8<<20):h.update(b);size+=len(b)
  assert h.hexdigest()==records[m.name]['sha256'] and size==records[m.name]['bytes']
assert seen==set(included)
for name,p in inputs.items():
 r=records[name];assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes'] and p.stat().st_mtime_ns==r['mtime_ns']
for prefix,root in roots.items():assert trees[prefix]==[str(p.relative_to(root)) for p in sorted(root.rglob('*')) if p.is_file()]
write(O/'archive-verification.json',dict(schema='E024-route-matrix-archive-verification-v1',status='PASS',archive_sha256=sha(package),archive_bytes=package.stat().st_size,
 manifest_sha256=sha(O/'manifest.json'),included_members=len(included),local_tensor_members=len(large),local_tensor_bytes=sum(r['bytes'] for r in large.values()),
 all_archived_member_hashes_verified=True,all_original_files_including_local_tensors_rehashed=True,all_tree_members_rechecked=True,exact_restoration_sidecars=True,
 qualification_source='Separate numerical/restoration audits; packaging grants no performance eligibility. Large original tensors remain local and are not in this archive.'))
print((O/'archive-verification.json').read_text())
