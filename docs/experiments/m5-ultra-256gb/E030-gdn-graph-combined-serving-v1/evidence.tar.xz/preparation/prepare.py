from pathlib import Path
import importlib.util,json,hashlib,unittest,sys,io,time
root=Path('/Users/ryanli/code/minivllm'); folder=root/'bench/m5_ultra_256gb/cold_observed_cycle'
out=root/'.artifacts/m5-ultra-256gb/gdn-graph-combined-prepare-v1';out.mkdir()
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def ref(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
c=load(folder/'controller.py','observed_cold_test');o=load(folder/'owner.py','observed_owner_test');a=load(folder/'audit_restore.py','observed_audit_test')
lr=ref(folder/'lifecycle.json');ar=c.OBSERVED_ARCHIVE
binding={**ref(ar/'service-baseline.json'),'audit':ref(ar/'operational-recovery.json')}
class BridgeTests(unittest.TestCase):
 def test_actual_observation_not_historical_pass(self):
  p,raw=c.predecessor(binding,lr);self.assertNotIn('state',p);self.assertFalse(p['original_monitored_recovery_passed']);self.assertEqual(p['original_journal_state'],'LOAD_INTENT');self.assertEqual(p['original_http_worker_returncode'],-15);self.assertEqual(len(raw),2)
 def test_actual_namespaces(self):
  self.assertIs(c.prepare.__globals__,vars(c));self.assertIs(c.recover.__globals__,vars(c));self.assertIs(o.run.__globals__,vars(o));self.assertIs(a.audit.__globals__,vars(a));self.assertEqual(o.CONTROLLER,folder/'controller.py')
 def test_wrong_audit_ref_rejected(self):
  b={**binding,'audit':{**binding['audit'],'sha256':'0'*64}}
  with self.assertRaises(Exception):c.predecessor(b,lr)
 def test_wrong_baseline_ref_rejected(self):
  b={**binding,'path':str(ar/'journal.json')}
  with self.assertRaises(Exception):c.predecessor(b,lr)
 def test_wrong_baseline_sha_rejected(self):
  with self.assertRaises(Exception):c.predecessor({**binding,'sha256':'0'*64},lr)
 def test_lifecycle_source_binding(self):
  m=c.lifecycle(lr);self.assertEqual(m['sources']['controller'],ref(folder/'controller.py'))
  with self.assertRaises(Exception):c.lifecycle({**lr,'sha256':'0'*64})
text=io.StringIO();start=time.time();r=unittest.TextTestRunner(stream=text,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BridgeTests))
(out/'cpu.stdout').write_text(text.getvalue());result={'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped),'success':r.wasSuccessful(),'time':time.time(),'started':start,'scope':'CPU immutable evidence/namespace only; no service/model action','sources':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*') if p.is_file()}}
(out/'cpu-result.json').write_text(json.dumps(result,indent=2)+'\n');(out/'prepare.py').write_bytes(Path(__file__).read_bytes())
print(text.getvalue());assert r.wasSuccessful()
q=load(root/'bench/m5_ultra_256gb/gdn_graph_combined/qualify.py','combined_qual_prepare')
old=json.loads((root/'.artifacts/m5-ultra-256gb/route-decode-serving-v1-owner/owner-plan.json').read_bytes())
inherited=old['inherited_owner_plan'];numeric=json.loads(Path(inherited['path']).read_bytes())['inherited_plan']
child=q.make_plan(Path(numeric['path']));cp=out/'qualification-plan.json';cp.write_text(json.dumps(child,indent=2)+'\n')
plan={'schema':c.RUN_SCHEMA,'lifecycle':lr,'predecessor':binding,'experiment':{'phase':'gdn-graph-combined-serving','qualifier':ref(Path(q.__file__)),'plan':ref(cp),'source_pins':child['sources']},'inherited_owner_plan':inherited,'outputs':{'journal':str(root/'.artifacts/m5-ultra-256gb/gdn-graph-combined-v1-cold-journal'),'out':str(root/'.artifacts/m5-ultra-256gb/gdn-graph-combined-v1-owner')},'budgets':{'work_seconds':1830,'child_seconds':1800,'term_seconds':15,'kill_seconds':15}}
p=out/'owner-plan.json';p.write_text(json.dumps(plan,indent=2)+'\n');c.run_plan(p,ref(p)['sha256']);o.validate_plan(type('Args',(),{'plan':p,'plan_sha256':ref(p)['sha256'],'out':Path(plan['outputs']['out'])})())
(out/'source-pins.json').write_text(json.dumps(c.source_pins(plan,c.lifecycle(lr)),indent=2)+'\n')
print(json.dumps({'owner_plan':ref(p),'child_plan':ref(cp),'read_only_validation':'PASS'}))
