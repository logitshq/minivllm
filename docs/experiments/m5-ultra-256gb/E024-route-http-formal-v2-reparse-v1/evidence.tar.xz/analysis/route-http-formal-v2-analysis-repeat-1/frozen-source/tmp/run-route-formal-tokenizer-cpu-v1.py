import contextlib, hashlib, importlib.abc, json, os
from pathlib import Path
import sys, time, unittest
R=Path('/Users/ryanli/code/minivllm'); D=R/'bench/m5_ultra_256gb/route_http_formal'
OUT=R/'.artifacts/m5-ultra-256gb/route-http-formal-tokenizer-cpu-v1'
PINS={'audit_formal.py':'ed8ad64c3eb5fed052effd05981a386006f4ea1f752463bb0ada0c2f0e4ea5e0','audit_formal_v2.py':'b2bc55b87043d66d79154fd32dc7579cc7c6fdb457844a1b1d3df932ff41224e','test_audit_formal_v2_cpu.py':'9bff5e7d2c1d52d18c0c39d4a286cd17e3be28c19128a82078dc30b8fc120bac'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
assert not OUT.exists();OUT.mkdir();(OUT/'source').mkdir()
for name,digest in PINS.items():
 assert sha(D/name)==digest
 (OUT/'source'/name).write_bytes((D/name).read_bytes())
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
record=dict(status='INCOMPLETE',started_at=time.time(),argv=sys.argv,python=sys.executable,pins=PINS,model_actions=False,service_actions=False,denied=[])
save('result.json',record)
banned={'mlx','mlx_lm','mlx_vlm','omlx','torch','numpy','tokenizers','tutorial_code','minivllm'}
def deny(kind,value):
 record['denied'].append(dict(kind=kind,value=str(value)));raise RuntimeError('forbidden operation: '+kind)
def audit(event,args):
 if event=='import' and str(args[0]).split('.')[0] in banned:deny(event,args[0])
 if event in ('subprocess.Popen','os.system','os.posix_spawn','os.fork','os.kill','socket.__new__','socket.connect','socket.bind','socket.getaddrinfo'):deny(event,args)
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)) and str(args[0]).endswith(('.safetensors','.pack','.metallib')):deny(event,args[0])
sys.addaudithook(audit);sys.path.insert(0,str(R))
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in banned:deny('backend import',fullname)
sys.meta_path.insert(0,Block())
with (OUT/'stdout').open('x') as sout,(OUT/'stderr').open('x') as serr,contextlib.redirect_stdout(sout),contextlib.redirect_stderr(serr):
 suite=unittest.defaultTestLoader.loadTestsFromName('bench.m5_ultra_256gb.route_http_formal.test_audit_formal_v2_cpu');assert suite.countTestCases()==8
 result=unittest.TextTestRunner(stream=serr,verbosity=2).run(suite)
record.update(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),sources_unchanged=all(sha(D/n)==s for n,s in PINS.items()),ended_at=time.time())
record['status']='PASS' if result.wasSuccessful() and result.testsRun==8 and not result.skipped and not record['denied'] and record['sources_unchanged'] else 'FAIL'
save('result.json',record)
save('manifest.json',{str(p.relative_to(OUT)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()})
print(json.dumps(record));raise SystemExit(record['status']!='PASS')
