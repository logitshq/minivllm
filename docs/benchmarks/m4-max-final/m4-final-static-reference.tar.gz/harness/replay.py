"""CPU raw replay and seven independent points; no best-point selection."""
import json,statistics,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent
FIELDS=('x','y','TTFT_s','E2E_s')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify(output):
 output=Path(output);plan=json.loads((D/'plan.json').read_text());complete=json.loads((output/'suite-complete.json').read_text());assert complete['actual_requests']==270 and complete['actual_completion_tokens']==8640
 assert [r['label'] for r in complete['configs']]==[r['label'] for r in plan['configs']]
 rows=[];allgroups=[];requests=0;tokens=0;workload=json.loads((D.parent/'workload.json').read_text())
 from client import validate_warm
 for item,entry in zip(plan['configs'],complete['configs']):
  p=output/item['label']/'result.json';assert str(p)==entry['report'] and sha(p)==entry['report_sha256'];r=json.loads(p.read_text());batch=item['batch'];assert r['concurrency']==batch and r['engine']==item['engine'];measure=[]
  for phase,key in [('warm','warmups'),('measure','runs')]:
   assert len(r[key])==3
   for i,g in enumerate(r[key]):
    assert g==json.loads((p.parent/f'C{batch}-{phase}-{i}.json').read_text()) and len(g['requests'])==g['actual_request_count']==batch
    xs=[];starts=[];ends=[];tt=[];tot=[]
    for q in g['requests']:
     assert q['usage']['prompt_tokens']==19 and q['usage']['completion_tokens']==32 and q['finish_reason']=='length' and q['usage'].get('prompt_tokens_details',{}).get('cached_tokens',0)==0 and len(q['visible_roundtrip_ids'])==32
     if item['engine']=='native':
      assert q['output_ids_when_available']==q['visible_roundtrip_ids']
      if batch==1:assert q['output_ids_when_available']==workload['continuation_ids']
     x=(32-q['first_chunk_reconstructed_tokens'])/(q['done_perf_counter_s']-q['first_text_perf_counter_s']);assert x==q['x_client_estimated_interactivity_tok_s_user'];xs.append(x);starts.append(q['start_perf_counter_s']);ends.append(q['done_perf_counter_s']);tt.append(q['first_text_perf_counter_s']-q['start_perf_counter_s']);tot.append(q['done_perf_counter_s']-q['start_perf_counter_s']);requests+=1;tokens+=32
    v={'x':statistics.median(xs),'y':batch*32/(max(ends)-min(starts)),'TTFT_s':statistics.median(tt),'E2E_s':statistics.median(tot)};assert v['x']==g['x_client_estimated_interactivity_tok_s_user'] and v['y']==g['y_total_output_throughput_tok_s_mac'];allgroups.append({'label':item['label'],'phase':phase,**v})
    if phase=='measure':measure.append(v)
  if item['engine']=='native':validate_warm(r['post_warm_metadata'],batch)
  assert r['owned_process_exit']['wait_completed'] is True and r['owned_process_exit']['exact_pid_absence']['absent'] is True and json.loads((p.parent/'port-absence.json').read_text())['absent'] is True
  cleanup=json.loads((p.parent/'cleanup.json').read_text());assert cleanup['first_error'] is None and cleanup['cleanup_errors']==[]
  raw=[json.loads(q.read_text()) for q in sorted(p.parent.glob('resource-snapshots-*-raw.json'))];assert len(raw)==17==len(r['resource_snapshots'])
  for a,b in zip(raw,r['resource_snapshots']):
   for k,v in a.items():
    if k not in ('known_inference_processes','known_inference_process_count','only_owned_known_inference_processes'):assert b[k]==v
  rows.append({**item,**{k:statistics.median(v[k] for v in measure) for k in FIELDS}})
 assert requests==270 and tokens==8640
 points=[]
 for engine,batch in [('native',1),('omlx',1),('lithos',1),('native',2),('omlx',2),('native',4),('omlx',4)]:
  group=[v for v in rows if v['engine']==engine and v['batch']==batch];assert len(group)==3;points.append({'engine':engine,'batch':batch,**{k:statistics.median(v[k] for v in group) for k in FIELDS}})
 comparisons=[]
 for batch in [1,2,4]:
  for rep in [1,2,3]:
   n=next(v for v in rows if v['engine']=='native' and v['batch']==batch and v['replica']==rep)
   for engine in (['omlx','lithos'] if batch==1 else ['omlx']):
    b=next(v for v in rows if v['engine']==engine and v['batch']==batch and v['replica']==rep);comparisons.append({'batch':batch,'replica':rep,'baseline':engine,'native_vs_baseline_percent':{k:(n[k]/b[k]-1)*100 for k in FIELDS}})
 aggregate_comparisons=[]
 for batch in [1,2,4]:
  n=next(v for v in points if v['engine']=='native' and v['batch']==batch)
  for engine in (['omlx','lithos'] if batch==1 else ['omlx']):
   b=next(v for v in points if v['engine']==engine and v['batch']==batch);aggregate_comparisons.append({'batch':batch,'baseline':engine,'native_vs_baseline_percent':{k:(n[k]/b[k]-1)*100 for k in FIELDS}})
 return {'status':'PASS_CPU_RAW_REPLAY','aggregate_signed_comparisons':aggregate_comparisons,'seven_points':points,'processes':rows,'all_groups':allgroups,'all_signed_comparisons':comparisons,'raw_requests':requests,'raw_completion_tokens':tokens,'scope':'client x stream proxy, y includes HTTP/queue; no GPU token/s or automatic promotion/default-on/overall-win claim'}
if __name__=='__main__':
 import argparse;ap=argparse.ArgumentParser();ap.add_argument('output',type=Path);a=ap.parse_args();print(json.dumps(verify(a.output),indent=2))
