"""Synthetic CPU regression for the pinned real oMLX title transition; zero live queries/signals."""
import json,os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D))
def fence(event,args):
 if event in ('subprocess.Popen','os.system','os.kill','socket.__new__'):raise AssertionError('CPU live action forbidden')
 if event=='import' and isinstance(args[0],str) and (args[0]=='mlx' or args[0].startswith('mlx.')):raise AssertionError('MLX forbidden')
sys.addaudithook(fence)
import common
class Proc:
 pid=987654
 def poll(self):return None
class TitleCPU(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='m4-title-fixture-');self.d=Path(self.tmp.name);self.birth=['Thu','Oct','15','23:18:35','2026','/pinned/python','-B','official_entry.py','--engine','omlx'];self.title=self.birth[:5]+['omlx-server']
  self.pre={'fixture':True,'engine':'omlx','pid':Proc.pid,'ppid':os.getpid(),'python_executable':common.REGISTRY['omlx']['actual_environment']['python_executable'],'source_native_tree_sha256':common.REGISTRY['omlx']['tree_sha256']}
  self.listener={'fixture':True,'returncode':0,'stderr':'','stdout':'p'+str(Proc.pid)+'\nf4\n','owned_pid':Proc.pid};self.save()
 def tearDown(self):self.tmp.cleanup()
 def save(self):
  (self.d/'official-preimport.json').write_text(json.dumps(self.pre));(self.d/'server-ready-exact-listener.json').write_text(json.dumps(self.listener))
 def lock(self,current=None,ppid=None,phase='ready'):
  with patch.object(common,'identity',return_value=self.title if current is None else current),patch.object(common,'process_parent',return_value={'ppid':os.getpid() if ppid is None else ppid,'fixture':True}):return common.lock_owned_identity(Proc(),self.birth,'omlx',self.d,phase)
 def test_legal_source_title_ready(self):
  self.assertEqual(self.lock(),self.title);v=json.loads((self.d/'owned-title-transition.json').read_text());self.assertEqual(v['initial_identity_words'],self.birth);self.assertEqual(v['current_identity_words'],self.title);self.assertEqual(v['decision'],'ONE_PINNED_OMLX_TITLE_TRANSITION');self.assertEqual(v['ready_listener']['owned_pid'],Proc.pid)
 def test_legal_early_title_with_preimport(self):
  (self.d/'server-ready-exact-listener.json').unlink();self.assertEqual(self.lock(phase='pre-cleanup'),self.title)
 def test_early_missing_preimport_rejected(self):
  (self.d/'official-preimport.json').unlink()
  with self.assertRaises(FileNotFoundError):self.lock(phase='pre-cleanup')
 def test_changed_birth_rejected(self):
  x=self.title.copy();x[3]='23:18:36'
  with self.assertRaisesRegex(AssertionError,'birth changed'):self.lock(current=x)
 def test_foreign_parent_rejected(self):
  with self.assertRaisesRegex(AssertionError,'foreign'):self.lock(ppid=os.getpid()+1)
 def test_arbitrary_title_rejected(self):
  with self.assertRaisesRegex(AssertionError,'unexpected command'):self.lock(current=self.birth[:5]+['omlx-server','foreign-worker'])
 def test_wrong_preimport_pid_rejected(self):
  self.pre['pid']+=1;self.save()
  with self.assertRaisesRegex(AssertionError,'preimport'):self.lock()
 def test_foreign_listener_rejected(self):
  self.listener['stdout']='p1\n';self.save()
  with self.assertRaisesRegex(AssertionError,'listener'):self.lock()
if __name__=='__main__':unittest.main(verbosity=2)
