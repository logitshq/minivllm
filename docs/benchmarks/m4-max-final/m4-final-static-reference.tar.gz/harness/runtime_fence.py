"""Reuse frozen fullqual verified-source/runtime loader before any MLX import."""
import ast,hashlib,json,sys,types
from pathlib import Path
D=Path(__file__).resolve().parent;P=Path('/private/tmp/minivllm-engine-optimization-20261014')
def install_runtime():
 f=json.loads((D/'pins.json').read_text())
 def pinned(name,path):
  data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==f['files'][str(path)]
  m=types.ModuleType(name);m.__file__=str(path);exec(compile(data,str(path),'exec',dont_inherit=True),m.__dict__);return m
 identity=pinned('e2e_v19_identity',P/'v18_activation_identity_v2.py');plan=json.loads((P/'v18-activation-runtime-identity-build3.json').read_text())
 identity.reject_preloaded(sys.modules)
 assert not any(k=='tutorial_code' or k.startswith('tutorial_code.') for k in sys.modules)
 identity.preflight_resolutions(plan);identity.reject_preloaded_native_images(identity.dyld_images(),plan['native_images']);identity.distribution_records(plan['distributions'])
 # Reuse the exact SourceFinder AST from the fullqual worker, without importing model code.
 path=P/'v19-fullmodel-qual-build3/worker.py';data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==f['files'][str(path)]
 node=next(n for n in ast.parse(data).body if isinstance(n,ast.ClassDef) and n.name=='SourceFinder')
 import importlib.abc,importlib.machinery,importlib.util
 ns={'importlib':__import__('importlib'),'Path':Path};exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),ns)
 finder=identity.PinnedMLXFinder(plan);sourcefinder=ns['SourceFinder'](identity,Path(f['native_root']),f['native_sources']);sys.meta_path[:0]=[finder,sourcefinder]
 def verify(mx,nn,activations):return identity.runtime_identity(plan,mx,nn,activations)
 return verify
