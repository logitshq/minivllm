"""Once-only serial 21-process M4 final matrix; no live action without --run."""
import argparse,json,os,signal,sys,traceback
from pathlib import Path
from common import *
def main(argv=None):
 ap=argparse.ArgumentParser();mode=ap.add_mutually_exclusive_group(required=True);mode.add_argument('--cpu-dry-run',action='store_true');mode.add_argument('--run',action='store_true');ap.add_argument('--pins-sha256',required=True);ap.add_argument('--expected-power',choices=['AC'],default='AC');a=ap.parse_args(argv)
 f=verify_frozen(a.pins_sha256);verify_previous_release()
 if a.cpu_dry_run:
  print(json.dumps({'status':'PASS_CPU_DRY_RUN','configs':PLAN['configs'],'fresh_loads':21,'actual_requests':270,'actual_tokens':8640,'MLX_imported':any(n=='mlx' or n.startswith('mlx.') for n in sys.modules),'live_actions':0}));return 0
 assert sys.executable==PYTHON and not selected(os.environ),'native interpreter and empty selected parent controls required'
 assert not any(n=='mlx' or n.startswith('mlx.') for n in sys.modules)
 # Consumes authorization once even if fresh preflight fails. It is never removed or reused.
 write_new(D/'attempt.consumed.json',{'driver_pid':os.getpid(),'pins_sha256':a.pins_sha256,'no_retry':True})
 output=D/'output';output.mkdir();completed=[];shared={};samples=[];error=None;cleanup_errors=[]
 def stop(sig,frame):raise KeyboardInterrupt('owned driver signal '+str(sig))
 old=signal.signal(signal.SIGTERM,stop)
 try:
  write_new(output/'execution-plan.json',{'plan':PLAN,'pins_sha256':a.pins_sha256,'driver_pid':os.getpid(),'power':'AC','GPU_released':False})
  actual_preimport_identity();probe(samples,output/'owner-resource-derived.json','owner-before-first-model','AC')
  from client import run_one
  for item in PLAN['configs']:
   print(json.dumps({'event':'ARM_STARTED',**item}),flush=True)
   completed.append(run_one(item,output,'AC',shared,a.pins_sha256));write_new(output/(item['label']+'-validated.json'),completed[-1]);print(json.dumps({'event':'ARM_COMPLETED','label':item['label'],'completed':len(completed),'total':21}),flush=True)
  verify_frozen(a.pins_sha256)
 except BaseException as exc:
  error={'type':type(exc).__name__,'text':str(exc),'traceback':traceback.format_exc()};write_new(output/'suite-failure.json',{'first_error':error,'completed_configs':len(completed),'raw_groups_preserved':True,'no_retry':True})
 finally:
  try:probe(samples,output/'owner-resource-derived.json','owner-finally-postflight','AC')
  except BaseException as exc:cleanup_errors.append({'phase':'owner-postflight','type':type(exc).__name__,'text':str(exc)})
  signal.signal(signal.SIGTERM,old);write_new(output/'owner-cleanup.json',{'pid':os.getpid(),'completed_configs':len(completed),'first_error':error,'cleanup_errors':cleanup_errors,'GPU_released':False,'external_tool_return_and_exact_absence_required':True})
 if error is not None or cleanup_errors:
  print(json.dumps({'event':'DRIVER_FINISHED','status':'STOP_FIRST_FAILURE','GPU_released':False}),flush=True);return 1
 assert len(completed)==21 and sum(x['actual_completed_requests'] for x in completed)==270 and sum(x['actual_completion_tokens'] for x in completed)==8640
 write_new(output/'suite-complete.json',{'schema':'m4-final-native15-official-complete-v1','configs':completed,'actual_requests':270,'actual_completion_tokens':8640,'measured_requests':135,'measured_tokens':4320,'power':'AC','GPU_released':False})
 from replay import verify
 try:replay=verify(output);write_new(output/'cpu-raw-replay.json',replay)
 except BaseException as exc:
  write_new(output/'replay-failure.json',{'type':type(exc).__name__,'text':str(exc),'traceback':traceback.format_exc(),'raw_all_preserved':True});print(json.dumps({'event':'DRIVER_FINISHED','status':'STOP_CPU_REPLAY_FAILURE','GPU_released':False}),flush=True);return 1
 print(json.dumps({'event':'DRIVER_FINISHED','status':'PASS_AWAIT_EXTERNAL_TOOL_RETURN_AND_RELEASE','GPU_released':False,'points':replay['seven_points']}),flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
