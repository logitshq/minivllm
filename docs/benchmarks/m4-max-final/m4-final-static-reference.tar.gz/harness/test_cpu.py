"""Narrow behavioral CPU checks; no process/network/model/probe operations."""
import ast,contextlib,copy,hashlib,io,json,sys,unittest
from pathlib import Path
from unittest.mock import patch
D=Path(__file__).resolve().parent;P=D.parent
sys.path.insert(0,str(D))
def fence(event,args):
 if event in ('subprocess.Popen','os.system','os.kill','socket.__new__'):raise AssertionError('CPU fence: '+event)
 if event=='import' and isinstance(args[0],str) and (args[0]=='mlx' or args[0].startswith('mlx.')):raise AssertionError('CPU imported MLX')
sys.addaudithook(fence)
import common,client,driver
class CPU(unittest.TestCase):
 def test_plan_denominators(self):
  rows=common.PLAN['configs'];self.assertEqual(len(rows),21);self.assertEqual(sum(6*x['batch'] for x in rows),270);self.assertEqual(sum(192*x['batch'] for x in rows),8640)
  self.assertEqual([[x['engine'] for x in rows[i:i+3]] for i in [0,3,6]],[['native','omlx','lithos'],['omlx','lithos','native'],['lithos','native','omlx']]);self.assertTrue(all(x['batch']==1 for x in rows if x['engine']=='lithos'))
 def test_mature_request_group_byte_exact(self):
  a=(P/'v18-best-baseline-c1-build1/driver.py').read_text();b=(D/'client.py').read_text()
  for name in ['request','group']:
   get=lambda s:ast.get_source_segment(s,next(n for n in ast.walk(ast.parse(s)) if isinstance(n,ast.FunctionDef) and n.name==name))
   self.assertEqual(get(a),get(b))
 def test_raw_before_guard(self):
  s=(D/'common.py').read_text();n=next(x for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name=='probe');v=ast.get_source_segment(s,n);self.assertLess(v.index('write_new(raw_path,raw)'),v.index('phase_guard('))
 def test_parent_controls_and_child_controls(self):
  self.assertEqual(common.boot.environment_record(common.child_environment({}))['knobs'],{'MLX_BFS_MAX_WIDTH':'20','MLX_MAX_MB_PER_BUFFER':'50','MLX_MAX_OPS_PER_BUFFER':'50','MLX_METAL_FAST_SYNCH':'0'})
  for key in ['MLX_FAST_MATH','MLX_METAL_GPU_ARCH','OMLX_FOO','METAL_X','MONOLITH_ACCELERATOR','PYTHONPATH']:
   with self.assertRaises(AssertionError):common.child_environment({key:'1'})
 def test_warm_batches(self):
  for batch in [1,2,4]:
   n=4464;meta={'completed_requests':3*batch,'gates':{'enabled':True,'compiled_callable_count':48 if batch==1 else 0},'parameter_tree_unchanged':True,'routes':{'setter_calls':48,'decode_batch_counts':{str(batch):n},'normal_decode_calls':n,'gates_route_calls':n,'compiled_eligible_calls':n if batch==1 else 0,'fallback_calls':0 if batch==1 else n,'hooks_restored_before_measure':True}}
   client.validate_warm(meta,batch);bad=copy.deepcopy(meta);bad['routes']['hooks_restored_before_measure']=False
   with self.assertRaises(AssertionError):client.validate_warm(bad,batch)
 def test_pid_reuse_blocks_kill(self):
  class Proc:
   pid=99;returncode=None
   def poll(self):return None
   def wait(self,timeout=None):raise common.subprocess.TimeoutExpired('mock',timeout)
  sent=[]
  with patch.object(common,'identity',side_effect=[['same'],['foreign']]),patch.object(common.os,'kill',side_effect=lambda p,s:sent.append(s)):
   with self.assertRaisesRegex(AssertionError,'foreign'):common.cleanup_owned(Proc(),['same'])
  self.assertEqual(sent,[common.signal.SIGTERM])
 def test_pid_absent_reap_no_signal(self):
  class Proc:
   pid=99;returncode=-15
   def poll(self):return None
   def wait(self,timeout=None):return -15
  with patch.object(common,'identity',return_value=None),patch.object(common.os,'kill',side_effect=AssertionError('must not signal')),patch.object(common,'strict_absence',return_value={'absent':True}):
   self.assertTrue(common.cleanup_owned(Proc(),['same'])['wait_completed'])
 def test_inert_no_write(self):
  before={p.name for p in D.iterdir()};h=common.sha(D/'pins.json');buf=io.StringIO()
  with contextlib.redirect_stdout(buf):self.assertEqual(driver.main(['--cpu-dry-run','--pins-sha256',h]),0)
  v=json.loads(buf.getvalue());self.assertEqual(v['live_actions'],0);self.assertFalse(v['MLX_imported']);self.assertEqual(before,{p.name for p in D.iterdir()})
 def test_cross_batch_ids_boundary(self):
  a=list(range(32));b=list(range(32,64));own=lambda ids:{'output_ids_when_available':ids,'visible_roundtrip_ids':ids}
  client.validate_native_requests([own(b)],2,a);client.validate_native_requests([own(b)],4,a)
  with self.assertRaisesRegex(AssertionError,'C1 pinned'):client.validate_native_requests([own(b)],1,a)
  bad=own(b);bad['visible_roundtrip_ids']=a
  with self.assertRaisesRegex(AssertionError,'own canonical'):client.validate_native_requests([bad],4,a)
 def test_official_scheduler(self):
  self.assertEqual(client.scheduler('omlx',4)['prefill_batch_size'],1);self.assertEqual(client.scheduler('omlx',4)['completion_batch_size'],4);self.assertEqual(client.scheduler('omlx',4)['burst_multi_budget_s'],.03)
if __name__=='__main__':unittest.main(verbosity=2)
