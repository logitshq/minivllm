"""Stdlib identity gate and verified-source loader; never imports MLX by itself."""
import ctypes
import hashlib
import importlib.abc
import importlib.machinery
import importlib.metadata
import importlib.util
from pathlib import Path
import sys
import types


def reject_preloaded(modules):
    names = sorted(k for k in modules if k == 'mlx' or k.startswith('mlx.'))
    if names:
        raise ValueError('preloaded MLX modules forbidden: ' + ', '.join(names))


def match_file(actual, expected):
    path = Path(actual).resolve(strict=True)
    if path != Path(expected['path']).resolve(strict=True):
        raise ValueError('unexpected resolved origin: ' + str(path))
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != expected['sha256']:
        raise ValueError('actual origin hash mismatch: ' + str(path))
    return {'path': str(path), 'sha256': digest}


def verified_bytes(expected):
    path = Path(expected['path']).resolve(strict=True)
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected['sha256']:
        raise ValueError('verified source bytes changed: ' + str(path))
    return data


def check_resolved_spec(name, spec, expected):
    if spec is None or not spec.origin or Path(spec.origin).resolve() != Path(expected['path']).resolve():
        raise ValueError('shadow or missing import resolution: ' + name)


def module_identity(name, module, expected):
    if module is None or not getattr(module, '__file__', None):
        raise ValueError('missing actual module file: ' + name)
    check_resolved_spec(name, getattr(module, '__spec__', None), expected)
    record = match_file(module.__file__, expected)
    loaded_sha = getattr(module, '__v18_verified_source_sha256__', None)
    if expected.get('is_package') is not None:
        if loaded_sha != expected['sha256']:
            raise ValueError('Python module not executed from verified source bytes: ' + name)
        record['executed_source_sha256'] = loaded_sha
    return record


def execute_pinned_source(name, entry, *, module=None):
    data = verified_bytes(entry)
    module = types.ModuleType(name) if module is None else module
    module.__file__ = str(Path(entry['path']).resolve())
    code = compile(data, module.__file__, 'exec', dont_inherit=True)
    exec(code, module.__dict__)
    module.__v18_verified_source_sha256__ = entry['sha256']
    return module


class VerifiedSourceLoader(importlib.abc.Loader):
    def __init__(self, entry): self.entry = entry
    def create_module(self, spec): return None
    def exec_module(self, module): execute_pinned_source(module.__name__, self.entry, module=module)


class PinnedMLXFinder(importlib.abc.MetaPathFinder):
    def __init__(self, plan): self.plan = plan
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'mlx':
            spec = importlib.machinery.ModuleSpec(fullname, None, is_package=True)
            spec.submodule_search_locations = [self.plan['namespace_root']]
            return spec
        if not fullname.startswith('mlx.'):
            return None
        if fullname == 'mlx.core':
            return importlib.util.spec_from_file_location(fullname, self.plan['required_modules'][fullname]['path'])
        entry = self.plan['source_modules'].get(fullname)
        if entry is None:
            raise ImportError('unpinned MLX import forbidden: ' + fullname)
        return importlib.util.spec_from_file_location(
            fullname, entry['path'], loader=VerifiedSourceLoader(entry),
            submodule_search_locations=[str(Path(entry['path']).parent)] if entry['is_package'] else None,
        )


def preflight_resolutions(plan):
    root = Path(plan['namespace_root']).resolve()
    namespace = importlib.machinery.PathFinder.find_spec('mlx', sys.path)
    if namespace is None or namespace.origin is not None:
        raise ValueError('shadow/non-namespace mlx import root')
    paths = {Path(p).resolve() for p in namespace.submodule_search_locations or ()}
    if paths != {root}:
        raise ValueError('unexpected mlx namespace search paths: ' + repr(paths))
    for name, entry in plan['required_modules'].items():
        parent_path = root.joinpath(*name.split('.')[1:-1])
        spec = importlib.machinery.PathFinder.find_spec(name, [str(parent_path)])
        check_resolved_spec(name, spec, entry)
        match_file(spec.origin, entry)


def dyld_images():
    """Enumerate actually loaded images; no MLX API, array or device operation."""
    if sys.platform != 'darwin':
        raise ValueError('native image verification requires pinned Darwin runtime')
    lib = ctypes.CDLL(None)
    count = lib._dyld_image_count
    count.argtypes, count.restype = [], ctypes.c_uint32
    image_name = lib._dyld_get_image_name
    image_name.argtypes, image_name.restype = [ctypes.c_uint32], ctypes.c_char_p
    return [image_name(i).decode('utf-8', 'strict') for i in range(count())]


def relevant_native_image(path, plan):
    name = Path(path).name.lower()
    expected_names = {Path(e['path']).name.lower() for e in plan['required'].values()}
    return name in expected_names or 'mlx' in name or 'jaccl' in name


def reject_preloaded_native_images(paths, plan):
    names = [p for p in paths if relevant_native_image(p, plan)]
    if names:
        raise ValueError('preloaded MLX native images forbidden: ' + repr(names))


def validate_native_images(paths, plan):
    expected = {str(Path(e['path']).resolve()): e for e in plan['required'].values()}
    observed = {}
    for path in paths:
        if relevant_native_image(path, plan):
            resolved = str(Path(path).resolve())
            if resolved not in expected:
                raise ValueError('shadow/unpinned loaded MLX native image: ' + path)
            observed[resolved] = match_file(path, expected[resolved])
    if set(observed) != set(expected):
        raise ValueError('required native image missing: ' + repr(set(expected) - set(observed)))
    return observed


def validate_distribution_records(actual, expected):
    if set(actual) != set(expected):
        raise ValueError('distribution set mismatch')
    for name, entry in expected.items():
        if actual[name]['version'] != entry['version']:
            raise ValueError('distribution version mismatch: ' + name)
        if Path(actual[name]['dist_info']).resolve() != Path(entry['dist_info']).resolve():
            raise ValueError('shadow distribution origin: ' + name)
        for field in ('METADATA_sha256', 'RECORD_sha256'):
            if field in entry and actual[name].get(field) != entry[field]:
                raise ValueError('actual distribution metadata hash mismatch: ' + name + ':' + field)
    return actual


def distribution_records(plan):
    records = {}
    for name in plan:
        dist = importlib.metadata.distribution(name)
        root = Path(dist._path).resolve()
        records[name] = {'version': dist.version, 'dist_info': str(root),
                         'METADATA_sha256': hashlib.sha256((root/'METADATA').read_bytes()).hexdigest(),
                         'RECORD_sha256': hashlib.sha256((root/'RECORD').read_bytes()).hexdigest()}
    return validate_distribution_records(records, plan)


def runtime_identity(plan, mx, nn, activations):
    namespace = sys.modules.get('mlx')
    if namespace is None or {Path(p).resolve() for p in namespace.__path__} != {Path(plan['namespace_root']).resolve()}:
        raise ValueError('actual mlx namespace origin changed')
    modules = {'mlx.core': mx, 'mlx.nn': nn, 'mlx.nn.layers.activations': activations}
    records = {name: module_identity(name, module, plan['required_modules'][name]) for name, module in modules.items()}
    for name, module in list(sys.modules.items()):
        if name in plan['source_modules']:
            records[name] = module_identity(name, module, plan['source_modules'][name])
    if nn.silu is not activations.silu:
        raise ValueError('actual nn.silu is not verified activations.silu')
    actual_images = dyld_images()
    return {'modules':records, 'distributions':distribution_records(plan['distributions']),
            'native_images':validate_native_images(actual_images,plan['native_images']),
            'all_loaded_native_image_paths':actual_images,
            'metal_library':match_file(plan['metal_library']['path'],plan['metal_library'])}
