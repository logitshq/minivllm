# M4 Max final static source/harness REFERENCE ONLY

This is a bounded reading/migration package, not a directly executable portable benchmark or new authorization.
Native source25 is exact f976; code default gatesOFF, harness explicitly enables gatesON; V19 is not present.
The historical21-load plan is preserved. Request/group timing, original guards and title-ownership fix are static text only.

Adapt before use:
1. Choose a new target root and native/official Python environments; install pinned versions independently.
2. Download model revision5ff8ef173ad0d7c3aae92f0be43031a6ab8067c6 on target; replace workload model_dir placeholder.
3. Replace source-machine absolute paths in scripts/helpers; acquire official source/native files independently and verify target actual M4/profile/API support.
4. metadata/registry.redacted.json removes historical --api-key; never restore old keys. Generate a new ephemeral local key at actual runtime.
5. metadata/pins.historical.json is ORIGINAL historical hash/path evidence only; registry redaction and target paths invalidate directly running old pins. Rebuild a fresh pins manifest for target.
6. runtime_fence.py historically extracts SourceFinder from a fullqual worker. reference/fullqual-SourceFinder.py preserves that exact class text; wire/review a target loader rather than assuming the old worker path exists.
7. Historical release/fullqual paths and one-time consumed-latch requirements are NOT target authorization. Establish new target correctness, resource readiness, ownership, CPU review and an unused attempt root before any run.
8. Run only a newly frozen/adapted target command. Do not execute the original --run command against this archive.

Excluded: model, virtualenv/native binaries, all state directories/settings/API keys, runtime raw HTTP/request/server logs, private generated PID/birth/preimport identities, attempt markers, old GO/latch files.
Only static metadata inventory hashes/paths remain as provenance; they are not installed artifacts or evidence of a new target PASS.
The original4MB source-reference.tar.gz in the handoff directory remains byte-identical and separate.
