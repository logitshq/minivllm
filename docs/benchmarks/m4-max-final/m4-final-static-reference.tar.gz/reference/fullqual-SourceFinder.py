class SourceFinder(importlib.abc.MetaPathFinder):
 def __init__(self,identity,root,files):self.identity,self.root,self.files=identity,root,files
 def find_spec(self,name,path=None,target=None):
  if name=='tutorial_code':
   spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=[str(self.root.parent)];return spec
  if not name.startswith('tutorial_code.miniengine'):return None
  suffix=name.removeprefix('tutorial_code.miniengine').replace('.','/').lstrip('/')
  rel=(suffix+'/__init__.py').lstrip('/');package=rel in self.files
  if not package:rel=suffix+'.py'
  if rel not in self.files:raise ImportError('unpinned source '+name)
  entry={'path':str(self.root/rel),'sha256':self.files[rel],'is_package':package}
  return importlib.util.spec_from_file_location(name,entry['path'],loader=self.identity.VerifiedSourceLoader(entry),submodule_search_locations=[str(Path(entry['path']).parent)] if package else None)
